<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');



class Html_model extends CI_Model
{
    
   
    
    function __construct()
    {
        parent::__construct();
    }
    
    
    function product_box($product_data = array(), $type = '', $style = '')
    {
        $this->load->view('front/components/product_boxes/product_box_'.$type.'_'.$style, $product_data);

    }

    function ajax_product_box($product_data = array(), $type = '', $style = '')
    {
        $test = $this->load->view('front/components/product_boxes/product_box_'.$type.'_'.$style,$product_data, true);
        return $test;

    }
	
	function home_category_box($category_data = array(), $style = '')
    {
        $this->load->view('front/components/home_category_box/category_box_'.$style,$category_data);

    }
    function home3_category_box($category_data = array(), $style = '')
    {
        $this->load->view('front/components/home3_category_box/category_box_'.$style,$category_data);

    }
	
	function widget($name = '')
    {
        $this->load->view('front/components/widget/'.$name);

    }
    
    
}