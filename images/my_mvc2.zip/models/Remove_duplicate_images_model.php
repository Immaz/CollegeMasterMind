<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Remove_duplicate_images_model extends CI_Model
{
    public function removeDuplicateImages()
    {
        $curr_date = date("Y-m");
        $folder =  FCPATH.'uploads/product_variants_image/'.$curr_date;
        $directory = opendir($folder);
        $counter  = 0;
        $deleted = 0;
        while($files = readdir($directory))
        {
            $counter++;
            if($counter<=2){
                continue;
            }
            $file_parts = explode("-",$files);
            $this->db->where('product_variants_id',$file_parts[0]);
            $this->db->like("images",$files);
            $q = $this->db->get("product_variants");
            if($q->num_rows()>0){
                echo $counter." ) found in db : image name : ".$files;
            }else{
                if($files!="" && $files!=NULL && strlen($files)>1){
                    if(file_exists($folder."/".$files)){
                        unlink($folder."/".$files);
                        $deleted++;
                    }
                }
               echo $counter." ) Not found in db : image name : ".$files;
            }
            echo "<br>";
            if($counter==5000){
                break;
            }
        }
        echo "<br><br><br>";
            echo "--------------".$deleted."---------------------";
        echo "<br><br><br>";
    }
} /* end of class */