<?php
	$system_name	 =  $this->db->get_where('general_settings',array('type' => 'system_name'))->row()->value;
	$system_title	 =  $this->db->get_where('general_settings',array('type' => 'system_title'))->row()->value;
?>
<?php include 'includes_top.php'; ?>
<style type="text/css">
	#content-container{
		background-color: whitesmoke;
	}
	.admin_header_alert{
		margin-bottom: 0px;
	}
</style>
<body>

    <?php include 'header.php'; ?>
	<div id="container" class="<?php if($page_name=='product' || $page_name=='digital' || $page_name=='display_settings' || $page_name=='product_bundle'){ echo 'effect mainnav-sm'; } else{ echo 'effect mainnav-lg'; } ?>">
			<div class="boxed" id="fol">
				<?php if($message = $this->session->flashdata("message")){ ?>
					<div id="content-container" class="content-container2">
						<div class="alert alert-success admin_header_alert">
							<a href="#" class="close" data-dismiss="alert">&times;</a>
							<strong>Success !</strong>
							<p><?php echo $message ; ?></p>
						</div>
					</div>
				<?php } else if($warning = $this->session->flashdata("warning")){ ?>
					<div id="content-container" class="content-container2">
						<div class="alert alert-warning content-container admin_header_alert">
							<a href="#" class="close" data-dismiss="alert">&times;</a>
							<strong>Warning !</strong>
							<p><?php echo $warning; ?></p>
						</div>
					</div>
				<?php } else if(isset($error)){ ?>
					<div id="content-container" class="content-container2">
						<div class="alert alert-danger content-container admin_header_alert">
							<a href="#" class="close" data-dismiss="alert">&times;</a>
							<strong>Error !</strong>
							<p><?php echo $error; ?></p>
						</div>
					</div>
				<?php } ?>
			<!--CONTENT CONTAINER-->
			<div>
				<?php include $this->session->userdata('title').'/'.$page_name.'.php' ?>
			</div>
			<!--END CONTENT CONTAINER-->
			
			<!--MAIN NAVIGATION-->

			<!--  -->
			<!--END MAIN NAVIGATION-->
			
		</div>
		<!-- FOOTER -->
		<?php //include 'footer.php'; ?>
		<?php include 'script_texts.php'; ?>
		<!-- END FOOTER -->
		<!-- SCROLL TOP BUTTON -->
		<button id="scroll-top" class="btn"><i class="fa fa-chevron-up"></i></button>
	</div>
	<!-- END OF CONTAINER -->
<!-- SETTINGS - DEMO PURPOSE ONLY -->	
<?php include 'includes_bottom.php'; ?>