<style type="text/css">
    .btm_border{
        border-bottom: 1px solid #ebebeb;
        padding-bottom: 15px;   
    }
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
    .panel-heading{
        padding: 8px;
    }
    .btn_prod_form{
        margin-right: 5px;
    }
    .img-preview-new{
        margin-left: 8px;
        margin-bottom: 8px;
        max-height: 80px;
        float: left;
        width: 80px;
        position: relative;
    }
    .img-pre-holder{
        margin-left:8px; 
        margin-bottom: 8px;
        max-height: 80px;
        float: left;
        width: 80px;
        position: relative;
    }
    .img-preview{
        max-height: 65px;
    }
    .img-pre-holder img{
        position: absolute;
    }
    .prev-img-preview{
        height: 70px;
        display: inline-block;
        float: left;
    }
    .remove_prev_img{
        position: absolute;
        top: 0;
        right: 0;
        z-index: 2;
    }
    .flat_amount_col{
        display: none;
    }

    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
    .panel-heading{
        padding: 8px;
    }
    .btn_prod_form{
        margin-right: 5px;
    }
    .flat_amount_col{
        display: none;
    }
    .panel-body{
        margin-top: 10px;
    }
    .img-preview{
        max-height: 65px;
    }
    .variant_img_sortable { 
        list-style-type: none; 
        padding: 0; 
    }
    .variant_img_sortable li { 
        margin: 0px 5px;
        float: left; 
        text-align: center; 
        position: relative;
    }
    .panel-body{
        margin-top: 10px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Add Product');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/product'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                      <i class="fa fa-backward"></i>&nbsp;
                    <?php echo translate('back_to_product_list');?>
            </a>
        </div>
    </div>
    <div class="tab-pane fade active in" id="list" style="border:1px solid #ebebeb; border-radius:4px;">
        <?php
            echo form_open(base_url() . 'admin/product/add/', array(
                'class' => 'form-horizontal',
                'method' => 'post',
                'id' => 'product_add',
                'enctype' => 'multipart/form-data'
            ));
        ?>
            <div class="" style="padding-bottom: 30px 30px 20px 30px;">
                <div class="panel panel-info">
                    <div class="panel-heading panel-heading">
                        <span class="heading-info">
                            <?php echo translate("Menu Selection"); ?>
                        </span>
                     </div>
                    <div class="" style="padding: 25px 15px;">
                        <div class="row">
                            <div class="col-md-3">
                               <label class="my_label"><?php echo translate("Category");  ?>  *</label>
                                <select class="form-control required" name="category" id="category">
                                    <option value=""><?php echo translate("-- Select --"); ?></option>
                                    <?php 
                                        foreach($categories as $category){
                                    ?>
                                        <option value="<?php echo $category['category_id']; ?>">
                                            <?php echo $category['category_name']; ?>
                                        </option>
                                    <?php  } ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                               <label class="my_label"><?php echo translate("Sub Category");  ?>  *</label>
                                <select class="form-control required" name="sub_category" id="sub_category">
                                    <option value=""><?php echo translate("-- Select --"); ?></option>
                                </select>
                            </div>
                            <div class="col-md-3">
                               <label  class="my_label"><?php echo translate("Third Sub Category");  ?></label>
                                <select class="form-control" name="third_sub_category" id="third_sub_category">
                                   <option value=""><?php echo translate("-- Select --"); ?></option>
                                </select>
                            </div>
                            <div class="col-md-3">
                               <label  class="my_label"><?php echo translate("Brand");  ?></label>
                                <select class="form-control" name="brand" id="brand">
                                     <option value=""><?php echo translate("-- Select --"); ?></option>
                                    <?php if($single_row['brand_id']!="" && $single_row['brand_id']!=NULL){ ?>
                                        <option value="<?php echo $single_row['brand_id']; ?>" selected="selected">
                                        <?php echo $single_row['brand_name']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="row">
                            <div class="col-md-3">
                               <label  class="my_label"><?php echo translate("Shipping Type");  ?>  *</label>
                                <select class="form-control" disabled name="shipping_type" id="shipping_type">
                                    <option value=""><?php echo translate("-- Select --"); ?></option>
                                    <option value="free"><?php echo translate("Free Shipping"); ?></option>
                                    <option value="flat"><?php echo translate("Flat"); ?></option>
                                    <option value="weight"><?php echo translate("Weight"); ?></option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label  class="my_label"><?php echo translate("Vendor");  ?>  *</label>
                                <select class="form-control required" id="vendors" name="vendors">
                                    <option value=""><?php echo translate("-- Select --"); ?></option>
                                    <?php foreach($vendors as $vendor){?>
                                        <option value="<?php echo $vendor["vendor_id"]; ?>">
                                            <?php echo $vendor["name"]; ?></option>
                                    <?php }?>
                                </select>
                            </div>
                            <div class="col-md-3 flat_amount_col">
                                <label  class="my_label"><?php echo translate("Flat Amount");  ?>  *</label>
                                <input type="number" name="flat_amount" disabled id="flat_amount" class="form-control">
                            </div>
                            <div class="col-md-3">
                                <label  class="my_label"><?php echo translate("meta_keywords");  ?> </label>
                                <input type="text" class="form-control" name="meta_keyword">
                            </div>
                        </div><br />
                        <div class="row">
                            <div class="col-md-12">
                                <label  class="my_label"><?php echo translate("meta_description");  ?> </label>
                                <textarea  class="form-control" rows="3" name="meta_description"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="product_variants_dyanamic_form" style="padding-top: 5px;">
                    <div class="panel panel-info product_variant_first_form" id="dynamic_forms_1">
                        <div class="panel-heading panel-heading panel-heading-remove-form">
                            <span class="heading-info">
                                <?php echo translate("Product Attributes / Properties"); ?>
                                <span class="form_no"><?php echo translate("- 1"); ?></span>
                            </span>
                        </div>
                        <div class="" style="padding: 25px 15px;">
                            <div class="row">
                                   <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("UPC");  ?> *</label>
                                    <input type="number" class="form-control required" name="upc[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("ASIN");  ?></label>
                                    <input type="text" disabled class="form-control" name="asin[]" id="">
                                 </div>
                                <div class="col-md-2">
                                    <label  class="my_label"><?php echo translate("Seller SKU");  ?> *</label>
                                    <input type="text" class="form-control required" name="seller_sku[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label  class="my_label"><?php echo translate("Supplier SKU");  ?></label>
                                    <input type="text" class="form-control" name="supplier_sku[]" id="">
                                </div>
                                <div class="col-md-4">
                                    <label  class="my_label"><?php echo translate("Product Name");  ?> *</label>
                                    <input type="text" class="form-control required" name="product_name[]" id="">
                                </div>
                             </div>
                            <br>
                            <div class="row">
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Stock Staus");  ?> *</label>
                                    <input type="number" class="form-control required" name="stock_status[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Weight");  ?> *</label>
                                    <input type="number" class="form-control required" name="weight[]" id="">
                                </div>
                                 <div class="col-md-4">
                                    <label class="my_label"><?php echo translate("Material");  ?></label>
                                    <input type="text" class="form-control" name="material[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Construct By");  ?></label>
                                    <input type="text" class="form-control" name="construct_by[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Use");  ?></label>
                                    <input type="text" disabled class="form-control" name="use[]" id="">
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                 <div class="col-md-2">
                                    <label  class="my_label"><?php echo translate("Country Of Origin");  ?></label>
                                    <input type="text" disabled class="form-control" name="origin[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Cost");  ?> *</label>
                                    <input type="number" class="form-control required" name="cost[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Total Cost");  ?> *</label>
                                     <input type="number" class="form-control required" name="total_cost[]" id="">
                                </div>
                                <div class="col-md-3">
                                    <label  class="my_label"><?php echo translate("Selling Price");  ?> *</label>
                                     <input type="number" class="form-control required" name="selling_price[]" id="">
                                </div>
                                <div class="col-md-3">
                                    <label  class="my_label"><?php echo translate("Shipping Cost");  ?> *</label>
                                     <input type="number" disabled class="form-control" name="shipping_cost[]" id="">
                                </div>
                              </div>
                            <br>
                            <div class="row">
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Collection");  ?></label>
                                    <input type="text" class="form-control" name="collection[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Style");  ?></label>
                                    <input type="text" class="form-control" name="style[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Colors");  ?></label>
                                    <input type="text" class="form-control" name="color[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label  class="my_label"><?php echo translate("Primary Style");  ?></label>
                                    <input type="text" class="form-control" name="primary_style[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Actual Size");  ?></label>
                                    <input type="text" class="form-control" name="actual_size[]" id="">
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Shape");  ?></label>
                                    <input type="text" class="form-control" disabled name="shape[]" id="">
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="my_label"><?php echo translate("Discount Type");  ?></label>
                                    <select class="form-control" id="" name="discount_type[]">
                                        <option value="amount"><?php echo translate("Amount");  ?></option>
                                        <option value="percent"><?php echo translate("Percent");  ?></option>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <label class="my_label"><?php echo translate("Discount");  ?></label>
                                   <input type="number" class="form-control" name="discount[]" id="" value="0">
                                </div>
                                <div class="col-md-3">
                                    <label class="my_label"><?php echo translate("Video Link");  ?></label>
                                   <input type="file" class="form-control video_file" name="video_link_0" id="">
                                </div>
                                <div class="col-md-3">
                                    <label class="my_label"><?php echo translate("Images");  ?></label>
                                   <input type="file" name="images_0[]" multiple="multiple" id="" class="form-control files" accept="image/jpeg, image/png" >
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-12">
                                    <label class="my_label"><?php echo translate("Preview"); ?></label>
                                </div>
                                <div class="col-md-12">
                                    <ul class="variant_img_sortable">
                                    </ul>
                                    <input type="hidden" name="img_sequence[]"  class="img_sequence form-control"  value=''>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 img-preview">
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                 <div class="col-md-12">
                                    <label class="my_label"><?php echo translate("Description");  ?></label>
                                    <textarea cols="5" rows="5" class="form-control summernotes description" name="description[]" id="description"></textarea>
                                </div>
                                 <div class="col-md-12">
                                    <label class="my_label"><?php echo translate("Features");  ?></label>
                                    <textarea cols="5" rows="5" class="form-control summernotes features" name="features[]" id="features"></textarea>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        <div class="">
            <div class="col-md-7"></div>
            <div class="col-md-5">

                    <input type="hidden" id="is_edit" value="0">

                    <button class="btn btn-green btn-md  pull-right enterer btn_prod_form btn_add_form_prod" >
                      <i class="fa fa-plus"></i>
                    <?php echo translate('Add New');?></button>

                    <button  type="submit" class="btn btn-green btn-md  pull-right enterer btn_prod_form btn_add_product">
                    <i class="fa fa-upload"></i>
                    <?php echo translate('submit');?></button>

                    <a class="btn btn-warning btn-md pro_list_btn pull-right btn_prod_form reset_form" href="<?php echo base_url("admin/product/add");  ?>">
                        <i class="fa fa-refresh"></i>
                         <?php echo translate('reset');?>
                    </a>

            </div>
        </div>
        <br>
        </form>
    </div>
    <script src="<?php echo base_url(); ?>template/back/plugins/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>';
    var user_type = 'admin';
    var module = 'product';
    var list_cont_func = 'add';
    var dlt_cont_func = 'delete';
    var this_page = false;

    $(document).ready(function() {

            $("#product_add").submit(function(e) {
                if($("#is_edit").val()==0){
                    e.preventDefault();
                    $(".overlay_holder1").show();
                    $.ajax({
                        url: "<?php echo base_url('admin/newly_uploaded_img'); ?>",
                        type: "POST",
                        data:  new FormData(this),
                        contentType: false,
                        cache: false,
                        processData:false,
                        success: function(data)
                        {
                            //console.log(data);return false;
                            img_arr = JSON.parse(data);
                            console.log(img_arr)
                            if(img_arr.length>0){
                                var count  = 0;
                                $.each(img_arr,function(ind,val){
                                    if(val!=null){
                                        $.each(val,function(ind2,val2){
                                            if(val2.img!==undefined){
                                                $(".variant_img_sortable").eq(ind).append(val2.img)
                                                delete val2.img
                                            }
                                        });   
                                    }
                                    stringify = JSON.stringify(val);
                                    $(".img_sequence").eq(ind).val(stringify);
                                    $(".files").eq(count).val("");
                                    count++;
                                });
                            }
                            $(".overlay_holder1").hide();
                        },       
                    });
                }
            });

        function initialize_sortable()
        {
            $( ".variant_img_sortable" ).sortable({
                stop  : function(event,ui){
                    var variant_img_sortable_eq =  $(ui.item).parent().index(".variant_img_sortable");
                    var length = $(".variant_img_sortable").eq(variant_img_sortable_eq).find("li").length;
                    var img_new_sequence = {};
                    for(var i=0; i<length; i++){

                        var img_name = $(".variant_img_sortable").eq(variant_img_sortable_eq).find("li").eq(i).attr("data-variant-name");
                        var uploaded = $(".variant_img_sortable").eq(variant_img_sortable_eq).find("li").eq(i).attr("data-uploaded");
                        var name = $(".variant_img_sortable").eq(variant_img_sortable_eq).find("li").eq(i).attr("data-name");
                        var tmp_name = $(".variant_img_sortable").eq(variant_img_sortable_eq).find("li").eq(i).attr("data-tmp-name");
                        var child = {
                            name : img_name , uploaded : uploaded
                        };
                        if(name!==undefined){
                            child['img_name'] = name;
                        }
                        if(tmp_name!==undefined){
                            child['img_tmp_name'] = tmp_name;
                        }
                        img_new_sequence[img_name] = child;

                    }
                    img_new_sequence = JSON.stringify(img_new_sequence)
                    $(".img_sequence").eq(variant_img_sortable_eq).val(img_new_sequence);
                }
            });
            $( ".variant_img_sortable" ).disableSelection();
        }
        
       initialize_sortable();

        $(".reset_form").click(function(e){
            e.preventDefault();
            Swal.fire({
              title: 'Are you sure?',
              text: "Do you want to reset form.",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Reset!'
            }).then((result) => {
                if (result.value) {
                    window.location.href="<?php echo base_url("admin/product/add"); ?>";
                }
            });
        });

        $("#f").change(function(){
            var shipping_type = $(this).val();
            if(shipping_type == "flat"){
                $(".flat_amount_col").show();
                $("#flat_amount").addClass("required");
                $("#flat_amount").val("");
            }else{
                $(".flat_amount_col").hide();
                $("#flat_amount").removeClass("required");
                $("#flat_amount").val("");
            }
        });

        $(document).on("click",".remove_prev_img",function(e){
            e.preventDefault();
            var variant_id = $(this).parent("li").attr("data-variant-id");
            var variant_img_name = $(this).parent("li").attr("data-variant-name");
            var name = $(this).parent("li").attr("data-name");
            var tmp_name = $(this).parent("li").attr("data-tmp-name");
            var uploaded = $(this).parent("li").attr("data-uploaded");
            var holder_ind  =  $(this).parent().parent().index(".variant_img_sortable");
            var json_img_sequence = $(".img_sequence").eq(holder_ind).val();

            if(uploaded==1){
                Swal.fire({
                  title: 'Are you sure?',
                  text: "Do you want to remove it permenantly.",
                  type: 'warning',
                  showCancelButton: true,
                  confirmButtonColor: '#3085d6',
                  cancelButtonColor: '#d33',
                  confirmButtonText: 'Delete!'
                }).then((result) => {
                    $(".overlay_holder1").show();
                    if (result.value) {
                       $(this).parent().remove();
                       var data = {
                        variant_id : variant_id,
                        variant_img_name : variant_img_name,
                        '<?php echo $this->security->get_csrf_token_name() ?>' : '<?php echo $this->security->get_csrf_hash() ?>' 
                       };
                       $.ajax({
                            type : "POST",
                            url : '<?php echo base_url('admin/delete_single_img'); ?>',
                            data : data,
                            success : function(response)
                            {
                                $(".overlay_holder1").hide();
                                Swal.fire(
                                  'Success!',
                                  'Image removed successfully.!',
                                  'success'
                                )
                            }
                        });
                       $(".overlay_holder1").hide();
                    }
                    $(".overlay_holder1").hide();
                });
                
            }else{
                $(this).parent().remove();
            }
            if(json_img_sequence!=""){
                 var sequence_json_parse =  JSON.parse(json_img_sequence);
                $.each(sequence_json_parse,function(ind, val){
                    delete sequence_json_parse[variant_img_name];
                });
                $(".img_sequence").eq(holder_ind).val(JSON.stringify(sequence_json_parse));
            }
        });

        $(document).on("change",".files",function(){
            file_ind = $(this).index(".files");
            $("#product_add").submit();
        });

		$(".btn_add_product").click(function(e){
            $("#is_edit").val(1);
            e.preventDefault();
            Swal.fire({
              title: 'Are you sure?',
              text: "",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Add Product!'
            }).then((result) => {
                if (result.value) {
                    if(form_validation("product_add")){
                       $("#product_add").submit();
                    }
                }
            });
        }); 

        $("#category").change(function(){
            var category_id = $(this).val();
            var sub_categories = "<option value=''><?php echo translate('-- Select --');  ?></option>";
            if(category_id!=""){
                $(".overlay_holder1").show();
                var data = {
                    category_id : category_id,
                    '<?php echo $this->security->get_csrf_token_name() ?>' : '<?php echo $this->security->get_csrf_hash() ?>' 
                }
                $.ajax({
                    url : '<?php echo base_url('admin/get_sub_category_by_id'); ?>',
                    type : "POST",
                    data : data,
                    success : function(response)
                    {
                        var converted = JSON.parse(response);
                        if(converted){
                            $.each(converted,function(ind, val){
                                sub_categories +="<option value='"+val.sub_category_id+"'>"+val.sub_category_name+"</option>";
                           });
                        }
                        $("#sub_category").html(sub_categories);
                        $("#third_sub_category").html("<option value=''>-- Select --</option>");
                        $("#brand").html("<option value=''>-- Select --</option>");
                        $(".overlay_holder1").hide();
                    }
                });
            }else{
                    $("#sub_category").html("<option value=''><?php echo translate('-- Select --');  ?></option>");
                    $("#third_sub_category").html("<option value=''><?php echo translate('-- Select --');  ?></option>");
                    $("#brand").html("<option value=''>-- Select --</option>");
            }
        });

         $("#sub_category").change(function(){
            var category_id = $("#category").val();
            var sub_category_id = $(this).val();
            var third_sub_categories = "<option value=''><?php echo translate('-- Select --');  ?></option>";
            var brand = "<option value=''><?php echo translate('-- Select --');  ?></option>";
            if(sub_category_id!=""){
                $(".overlay_holder1").show();
                var data = {
                    category_id : category_id,
                    sub_category_id : sub_category_id,
                    '<?php echo $this->security->get_csrf_token_name() ?>' : '<?php echo $this->security->get_csrf_hash() ?>' 
                }
                $.ajax({
                    url : '<?php echo base_url('admin/get_third_sub_category_by_sub_category_id'); ?>',
                    type : "POST",
                    data : data,
                    success : function(response)
                    {
                        var converted = JSON.parse(response);
                        console.log(converted)
                        if(converted){
                            $.each(converted,function(ind, val){
                                third_sub_categories +="<option value='"+val.third_sub_category_id+"'>"+val.third_sub_ctg_name+"</option>";
                            });
                        }
                        $("#third_sub_category").html(third_sub_categories);
                        $(".overlay_holder1").hide();
                    }
                });

                $.ajax({
                    url : '<?php echo base_url('admin/get_brand_by_sub_category'); ?>',
                    type : "POST",
                    data : data,
                    success : function(response)
                    {
                        var converted = JSON.parse(response);
                        if(converted){
                            $.each(converted,function(ind, val){
                                brand +="<option value='"+val.brand_id+"'>"+val.name+"</option>";
                            });
                        }
                        $("#brand").html(brand);
                        $(".overlay_holder1").hide();
                    }
                });
            }else{
                    $("#third_sub_category").html("<option value=''><?php echo translate('-- Select --');  ?></option>");
                    $("#brand").html("<option value=''>-- Select --</option>");
            }
        });
        
        function inc_form_no()
        {   
            var form_no = $(".form_no").length;
            var form_no_inc = 2;
            for(var i = 1 ; i<form_no; i++){
                $(".form_no").eq(i).text(" - "+form_no_inc);
                form_no_inc++;
            }   
        }

        function input_img_vide_field_name_set()
        {
            $(".img-preview").eq($(".img-preview").length-1).html(" ");
            
            var files = $(".files").length;
            for(var i = 0 ; i<files; i++){
                $(".files").eq(i).attr("name","images_"+i+"[]");
            }   
            var files = $(".video_file").length;
            for(var i = 0 ; i<files; i++){
                $(".video_file").eq(i).attr("name","video_link_"+i);
            }   
        }
        var form_id = 2;
        function other_form_settings()
        {   
            form_length = $(".product_variant_first_form").length;
            $(".product_variant_first_form").eq(form_length-1).attr("id","dynamic_forms_"+form_id);
            var html = "<button type='button' data-form-id='"+form_id+"' class='btn btn-xs pull-right btn-remove-form btn-danger'>&times;</button>";
            $(".product_variant_first_form .panel-heading-remove-form").eq(form_length-1).find(".btn-remove-form").remove();
            $(".product_variant_first_form .panel-heading-remove-form").eq(form_length-1).append(html);
            $(".variant_id").eq(form_length-1).val("");
            form_id++;
        }
        
        $(".btn_add_form_prod").click(function(e){
            e.preventDefault();
            $("#dynamic_forms_"+($(".product_variant_first_form").length)).clone().insertAfter("#dynamic_forms_"+$(".product_variant_first_form").length);
            $(".product_variant_first_form").eq($(".product_variant_first_form").length-1).find(".description , .features").val("");
            $(".product_variant_first_form").eq($(".product_variant_first_form").length-1).find('.note-editable').html("");
            $(".product_variant_first_form").eq($(".product_variant_first_form").length-1).find(".variant_img_sortable").html(""); 
            initialize_sortable();
            initialize_summer_note();
            inc_form_no();
            input_img_vide_field_name_set();
            other_form_settings();
        });      
         $(document).on("click",".btn-remove-form",function(){
            var form_id = $(this).attr("data-form-id");
            $("#dyanamic_forms_"+form_id).remove();
        });

        $("#third_sub_category").change(function(){
            var third_sub_category_id = $(this).val();
            var brand = "<option value=''><?php echo translate('-- Select --');  ?></option>";
            if(third_sub_category_id!=""){
                $(".overlay_holder1").show();
                var data = {
                    third_sub_category_id : third_sub_category_id,
                    '<?php echo $this->security->get_csrf_token_name() ?>' : '<?php echo $this->security->get_csrf_hash() ?>' 
                }
                $.ajax({
                    url : '<?php echo base_url('admin/get_brand_by_third_sub_category'); ?>',
                    type : "POST",
                    data : data,
                    success : function(response)
                    {
                        var converted = JSON.parse(response);
                        if(converted){
                            $.each(converted,function(ind, val){
                                brand +="<option value='"+val.brand_id+"'>"+val.name+"</option>";
                           });
                        }
                        $("#brand").html(brand);
                        $(".overlay_holder1").hide();
                    }
                });
            }else{
                    $("#brand").html("<option value=''><?php echo translate('-- Select --');  ?></option>");
            }
        });

        function initialize_summer_note()
        {
            $('.summernotes').each(function() {
                var now = $(this);
                var ind = $(this).index(".summernotes");
                now.summernote({
                    height: 150,
                    disableDragAndDrop: false,
                    onChange: function(contents, editable) {
                       $('.summernotes').eq(ind).html(contents.trim());
                    }
                });
            });
        }

        initialize_summer_note();

        $(".note-editor .note-insert , .note-editor .note-snippet , .note-editor .note-view , .note-editor .note-help , .note-editor .note-fontname").remove();
        $(document).keydown(function(e){
            if(e.keyCode==13){
                return false;
            }
        });

    });
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->