<style type="text/css">
    .ticket_from_name{
        font-size: 25px;
        font-weight: lighter;
        vertical-align: sub;
    }
    .media-object{
        padding: 24px 8px;
    }
    .media-body{
        width: 100%;
    }
</style>
<div id="content-container">
<?php 
    foreach($message_data as $row)
    { 
?>
    <div class="row row_page_heading">
        <div class="col-md-11">
                <span class="ticket_from_name">
                    <?php echo translate('ticket_from');?>
                </span>
                 <span>
                    <?php 
                        $from = json_decode($row['from_where'],true);
                        if($from['type'] == 'user'){
                    ?>
                    <a class="badge fa fa-location-arrow" onclick="ajax_modal('view_user','<?php echo translate('view_profile'); ?>','<?php echo translate('successfully_viewed!'); ?>','user_view','<?php echo $from['id']; ?>')">
                        <?php echo $this->db->get_where('user',array('user_id'=>$from['id']))->row()->username; ?>
                    </a>
                    <?php   
                        } else {
                    ?>
                        <?php echo translate('admin');?> 
                    <?php
                        }
                    ?>
            </span>
       </div>
    </div>
    <div class="row ticket_general_info">
        <div class="col-md-12" style="padding: 0px 32px;">
            <div class="pad-all">
                <label class="my_label"><?php echo translate('subject : ');?></label>
                <?php echo $row['subject']?>
            </div>
            <div class="col-md-12">
                <label class="my_label"><?php echo translate('date_&_time : ');?></label>
                <?php echo date('d M,Y h:i:s',$row['time']); ?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <?php
            $msgs=$this->db->get_where('ticket_message',array(' ticket_id'=>$row['ticket_id']))->result_array();
            foreach ($msgs as $row1){
				$from1 = json_decode($row1['from_where'],true);
            ?>
              <div class="col-md-12" >
                  <div class="col-md-12 " style="cursor:pointer; background-color: #F5F5F5; border-color: #D8D8D8; margin-top: 5px;">
                    <div class="media">
                      <div class="media-left">
                          <?php
                                if($from1['type'] == 'admin'){
                            ?>
                                <img src="<?php echo $this->crud_model->logo('admin_login_logo'); ?>" class="media-object" width="50"/>
                            <?php
                                } else if($from1['type'] == 'user'){
                            ?>
                            <img <?php if(file_exists('uploads/user_image/user_'.$from1['id'].'.jpg')){ ?>
                                src="<?php echo base_url(); ?>uploads/user_image/user_<?php echo $from1['id']; ?>.jpg"
                            <?php }  else { ?>
                                src="<?php echo base_url(); ?>uploads/user_image/default.jpg"
                            <?php } ?>
                            class="media-object" alt="Profile Picture" width="50">
                            <?php
                                }
                            ?>
                      </div>
                      <div class="media-body">
                        <div class="media-heading">
                            <h4>
                                <?php
                                    if($from1['type'] == 'admin'){
                                        echo translate('admin');
                                    } else if($from1['type'] == 'user'){
                                        echo $this->crud_model->get_type_name_by_id('user',$from['id'],'username');
                                    }
                                ?>
                             </h4>
                        </div>
                        <p>
                            <?php echo $row1['message']; ?> 
                        </p>
                         <span style="float: right; font-style: italic;"><?php echo date('d F, Y h:i:s A',$row1['time']); ?></span>
                      </div>
                    </div>
                </div>
            </div>
            <?php
                }
            ?>
        </div>
    </div>
    <div>
        <?php
			echo form_open(base_url() . 'admin/ticket/reply/'.$row['ticket_id'], array(
				'class' => 'form-horizontal',
				'method' => 'post',
				'id' => 'ticket_reply',
				'enctype' => 'multipart/form-data'
			));
		?>
            <div class="form-group">
                <div class="col-sm-12" for="demo-hor-1">
                    <label class="my_label"><?php echo translate('reply_message');?></label>
                </div>
                <div class="col-sm-12">
                   <textarea  class="form-control" rows="9" data-height="200" name="reply" style="resize:both"></textarea>
                </div>
            </div>
            <div class="panel-footer">
                <div class="row">
                   <div class="col-md-6 col-md-offset-6">
                        <span class="btn btn-success btn-md btn-labeled fa fa-reply pull-right" 
                            onclick="form_submit('ticket_reply','<?php echo translate('successfully_replied!'); ?>')" >
                                <?php echo translate('reply');?>
                        </span>
                        <span class="btn btn-purple btn-labeled fa fa-refresh pro_list_btn pull-right" 
                            onclick="ajax_set_full('view','<?php echo translate('view_ticket'); ?>','<?php echo translate('successfully_viewed!'); ?>','ticket_view','<?php echo $row['ticket_id']; ?>');">
                                <?php echo translate('refresh');?>
                        </span>
                    </div>
                </div>
            </div>
		</form>
	</div>   
    </div> 
<?php 
	}
?>        
<style>
	.custom_td{
		border-left: 1px solid #ddd;
		border-right: 1px solid #ddd;
		border-bottom: 1px solid #ddd;
	}
</style>

<script>
	var base_url = '<?php echo base_url(); ?>';
    var user_type = 'admin';
    var module = 'ticket';
    var list_cont_func = 'list';
    var dlt_cont_func = 'delete';
    var this_page = false;

	$("form").submit(function(e){
			return false;
		});
</script>