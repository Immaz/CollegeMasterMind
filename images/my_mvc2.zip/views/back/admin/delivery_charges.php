<style type="text/css">
    .table_delivery_charges th{
        font-size: 14px;
    }
    .table_delivery_charges td{
        font-size: 12px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Delivery Charges');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/delivery_charges/add'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-plus"></i>&nbsp;
                    <?php echo translate('add_delivery_charges');?>
            </a>
        </div>
    </div>
    <div class="pd-1">
        <table class="table table-hovered table-bordered table_delivery_charges">
            <thead>
                <th><?php echo translate("title");  ?></th>
                <th><?php echo translate("shipping_type");  ?></th>
                <th><?php echo translate("base Cost/Shipping Charge");  ?></th>
                <th align="center"><?php echo translate("action");  ?></th>
            </thead>
            <tbody>
                <?php
                    if($delivery_charges){
                    foreach($delivery_charges as $delivery_charge){
                ?>
                    <tr>
                        <td><?php echo $delivery_charge['title'];  ?></td>
                        <td><?php if($delivery_charge['type'] == 'f_r_s'){
                            echo 'Flat Rate Shipping';
                        } else if($delivery_charge['type'] == 'w_b_s'){
                            echo 'Weight Base Shipping';
                        }else{
                            echo 'Advanced Shipping';
                        }?></td>
                        <td><?php echo $delivery_charge['base_cost'];  ?></td>
                        <td align="center">
                            <div class='btn_product_action'>
                                <a href="<?php echo base_url('admin/delivery_charges/edit/'.$delivery_charge['delivery_charges_id']); ?>">
                                    <i class='ad_red fa fa-edit'></i>
                                </a>
                                <a onclick ="delete_record('<?php echo base_url('admin/delivery_charges/delete/'.$delivery_charge['delivery_charges_id']); ?>')">
                                    <i class='ad_red fa fa-trash'></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                 <?php }} else{ ?>
                    <tr>
                        <td colspan="7" align="center"><?php echo translate('no_data_are_available'); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    var base_url = '<?php echo base_url(); ?>';
    // var timer = '<?php //$this->benchmark->mark_time(); ?>';
    var user_type = 'admin';
    var module = 'delivery_charges';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->