<style type="text/css">
    .third_sub_category_list_table .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .third_sub_category_list_table .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .third_sub_category_list_table thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow">
                <?php echo translate('manage_third_sub_categories');?>
            </h4>
        </div>
        <div class="col-md-4">
           <button class="btn btn-green btn-md  pull-right" onclick="ajax_modal('add','<?php echo translate('add third sub category'); ?>','<?php echo translate('successfully_added!'); ?>','third_sub_category_add','')"> 
            <i class="fa fa-plus-circle"></i>&nbsp;
                <?php echo translate('create_third_sub_category');?>
            </button>
        </div>
    </div>
    <table id="demo-table" class="table-bordered table table-striped third_sub_category_list_table"  data-pagination="false" data-ignorecol="0,3" data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next" data-search="true" data-sort-name="sno" data-sort-order="desc">
        <thead>
            <tr>
                <th data-field="sno"><?php echo translate('no');?></th>
                <th><?php echo translate('name');?></th>
                <th><?php echo translate('banner');?></th>
                <th><?php echo translate('category');?></th>
                 <th><?php echo translate('sub category');?></th>
                <th><?php echo translate('brands');?></th>
                <th data-width="200"><?php echo translate('featured');?></th>
                <th class="text-center"><?php echo translate('options');?></th>
            </tr>
        </thead>                
        <tbody >
                <?php
                    $sno = 1; 
                    foreach($all_third_sub_category as $row){
                ?>
                <tr>
                    <td><?php echo $sno; ?></td>
                    <td><?php echo $row['third_sub_ctg_name']; ?></td>
                    <td>
                        <?php
                        if($row['banner']!="" && $row['banner']!="" && file_exists('uploads/third_sub_category_image/'.$row['banner'])){
                        ?>
                        <img class="img-md" src="<?php echo base_url(); ?>uploads/third_sub_category_image/<?php echo $row['banner']; ?>" height="100px" />  
                        <?php
                            } else {
                        ?>
                        <img class="img-md" src="<?php echo base_url(); ?>uploads/third_sub_category_image/default.jpg" height="100px" />
                        <?php
                            }
                        ?>
                    </td>
                    <td>
                        <?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name'); ?>
                    </td>
                    <td>
                         <?php echo $this->crud_model->get_type_name_by_id('sub_category',$row['sub_category'],'sub_category_name'); ?>
                    </td>
                    <td>
                        <?php 
                        $brand_ids = json_decode($row['brand'],true);
                        $count = 1;
                        foreach($brand_ids as $brand_id){
                            if( $count == 3){
                                echo "<br>";
                                $count = 1;
                            }
                        ?>
                        <span class="badge badge-info">
                         <?php echo $this->crud_model->get_type_name_by_id('brand', $brand_id, 'name');  ?>
                        </span>
                        <?php $count++; } ?>
                    </td>
                    <div id="prod"></div>
                    <td>
                    <input id="feat_<?php echo $row['third_sub_category_id']; ?>"
                            data-id="<?php echo $row['third_sub_category_id']; ?>" class='sw14'
                            type="checkbox" name="featured"
                            <?php if($row['is_featured'] == 1){ ?>checked<?php } ?>
                            value="ok" />
                    </td>
                    <td class="text-center">
                        <div class="btn_product_action">
                            <a  data-toggle="tooltip" 
                                onclick="ajax_modal('edit','<?php echo translate('edit_third_sub_category'); ?>','<?php echo translate('successfully_edited!'); ?>','third_sub_category_edit','<?php echo $row['third_sub_category_id']; ?>')" 
                                    data-original-title="Edit" 
                                        data-container="body">
                                 <i class="ad_gray fa fa-wrench"></i>
                            </a>
                             <a onclick="delete_record('<?php echo base_url('admin/third_sub_category/delete/'.$row['third_sub_category_id']); ?>')" data-toggle="tooltip" data-original-title="Delete" data-container="body">
                                <i class="ad_red fa fa-trash"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php $sno++; } ?>
        </tbody>
    </table>
</div>

<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'third_sub_category';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
    var this_page = false;
</script>
