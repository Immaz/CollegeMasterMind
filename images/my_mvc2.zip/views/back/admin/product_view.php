<?php $row = $product_data[0];?>
<style type="text/css">
    .table_inv_pro_attr th{
        width: 20%;
    }
     .table_inv_pro_attr td{
       text-align: left;
    }
    .panel_product_view{
        padding: 5px;
    }
    .panel_product_view .row  label{
        font-size: 16px;
        font-weight: bold;
        padding: 8px;
    }
    .panel_product_view .row  p{
        font-size: 14px;
        padding: 8px;
    }
    .row_img_des_holder{
        display: flex;
        align-items: center;
    }
    .media .media-body h4{
        padding-left: 8px;
    }
     .media .media-left{
        width: 130px;
     }
     .heading-info{
        font-weight: bold;
        font-size: 16px;
     }
</style>
<!--CONTENT CONTAINER-->
<div id="content-container">
<div class="row row_page_heading">
    <div class="col-md-8">
        <h4 class="page-header text-overflow"><?php echo translate('view_product_(_physical_)');?></h4>
    </div>
    <div class="col-md-4">
        <a class="btn btn-green btn-md pull-right" href="<?php echo base_url('admin/product'); ?>">
            <i class="fa fa-backward"></i>&nbsp;
            <?php echo translate('back_to_product_list');?>
        </a>
    </div>
</div>
<hr style="margin: 10px 0 !important;">
<div class="panel panel_product_view">
    <div class="panel-body">
        <div class="row row_img_des_holder">
            <div class="col-md-12">
                <div class="media">
                    <div class="media-left media-middle">
                      <img class="img-responsive thumbnail" alt="Profile Picture" 
                        src="<?php echo $this->crud_model->file_view('product',$row['product_id'],'','','thumb','src','multi','one'); ?>">
                     </div>
                     <div class="media-body">
                        <h4 class="media-heading"><?php echo translate('description');?></h4>
                        <p><?php echo $row['description'];?></p>
                    </div>
                </div>
            </div>
        </div>
       
        <ul class="list-group">
            <li class="list-group-item bg-info">
                <span class="heading-info">
                    <i class="fa fa-file fa-info"></i>
                    <?php echo translate('general_information');?>
                </span>
            </li>
            <li class="list-group-item">
                 <div class="row">
                    <div class="col-md-4">
                        <label><?php echo translate('name');?></label>
                        <p><?php echo $row['title']?></p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('category');?></label>
                        <p> <?php echo ($this->crud_model->get_type_name_by_id('category',$row['category'],'category_name')!="") ? $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name') : "<span class='not_available'> Empty </span>";?></p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('sub-category');?></label>
                        <p>
                         <?php 
                             echo ($this->crud_model->get_type_name_by_id('sub_category',$row['sub_category'],'sub_category_name')!="") ? $this->crud_model->get_type_name_by_id('sub_category',$row['sub_category'],'sub_category_name') : "<span class='not_available'> Empty </span>";
                        ?></p>
                    </div>
                </div>
                 <hr style="margin-bottom: 3px; margin-top: 3px;">
                <div class="row">
                    <div class="col-md-4">
                        <label><?php echo translate('brand');?></label>
                        <p>
                            <?php 
                            echo ($this->crud_model->get_type_name_by_id('brand',$row['brand'])!="") ? $this->crud_model->get_type_name_by_id('brand',$row['brand']) : "<span class='not_available'> Empty </span>";
                            ?>
                        </p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('unit');?></label>
                        <p> <?php echo ($row['unit']!="") ? $row['unit'] : "<span class='not_available'> Empty </span>"; ?></p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('sale_price');?></label>
                        <p><?php echo $row['sale_price']; ?> / <?php echo $row['unit']; ?></p>
                    </div>
                </div>
                <hr style="margin-bottom: 3px; margin-top: 3px;">
                <div class="row">
                    <div class="col-md-4">
                        <label><?php echo translate('purchase_price');?></label>
                        <p><?php echo $row['purchase_price']; ?> / <?php echo $row['unit']; ?></p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('shipping_cost');?></label>
                        <p> <?php echo $row['shipping_cost']; ?> / <?php echo $row['unit']; ?></p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('tax');?></label>
                        <p><?php echo $row['tax']; ?>
                            <?php if($row['tax_type'] == 'percent'){ echo '%'; } elseif($row['tax_type'] == 'amount'){ echo '$'; } ?>
                            / <?php echo $row['unit']; ?></p>
                    </div>
                </div>

                <hr style="margin-bottom: 3px; margin-top: 3px;">

                <div class="row">
                    <div class="col-md-4">
                        <label><?php echo translate('discount');?></label>
                        <p>
                            <?php echo $row['discount']; ?>
                            <?php if($row['discount_type'] == 'percent')
                                            { echo '%'; } 
                                        elseif($row['discount_type'] == 'amount')
                                            { echo '$'; } 
                            ?>
                            / <?php echo $row['unit']; ?>
                        </p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('status');?></label>
                        <p><?php echo ($row['status']!="") ? $row['status'] : "<span class='not_available'> Empty </span>" ; ?></p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('featured');?></label>
                        <p> <?php echo ($row['featured']!="") ? $row['featured'] : "<span class='not_available'> Empty </span>"; ?></p>
                    </div>
                </div>

                 <hr style="margin-bottom: 3px; margin-top: 3px;">

                <div class="row">
                    <div class="col-md-4">
                        <label><?php echo translate('colors');?></label>
                        <p>       
                            <?php 
                            $all_af = $this->crud_model->get_additional_fields($row['product_id']);
                            $all_c = json_decode($row['color']);
                            if($all_c){
                                foreach($all_c as $p){
                            ?>
                            <div style="background-color:<?php echo $p; ?>; width:30px; height:30px; margin:5px; float:left;"></div>
                            <?php 
                                } 
                            } 
                            ?>
                          <?php
                            if(!$all_c){
                                echo "<span class='not_available'> Empty </span>";
                             }
                          ?>
                        </p>
                    </div>
                    <div class="col-md-4">
                        <label><?php echo translate('tag');?></label>
                        <p> 
                            <?php foreach(explode(',',$row['tag']) as $tag){ ?>
                                <?php if($tag!="" || $tag!=NULL){ ?>
                                <span class="label label-info label-xs" style="display: inline-block;">
                                    <?php echo $tag; ?>
                                </span>
                                <br>
                                 <?php } ?>
                              <?php } ?>
                              <?php
                                 if($row['tag']=="" || $row['tag']==NULL){
                                    echo "<span class='not_available'> Empty </span>";
                                 }
                              ?>
                        </p>
                    </div>
                </div>

            </li>
        </ul>
  
  </div>
</div>
    <!------row----/---->
</div>  
<!------content----/---->     
<style>
.custom_td
{
    border-left: 1px solid #ddd;
    border-right: 1px solid #ddd;
    border-bottom: 1px solid #ddd;
}
</style>
<script>
	$(document).ready(function(e) {
		
	});
</script>