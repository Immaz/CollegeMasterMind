<style type="text/css">
    .row{
        margin-bottom: 10px;
    }
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('add_free_shipping_limit');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/threshold_rate'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-backward"></i>&nbsp;
                    <?php echo translate('back_to_free_shipping_limit');?>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 pd-1">
            <?php
                echo form_open(base_url() . 'admin/threshold_rate/add/'.$product_id, array(
                    'class' => 'form-horizontal',
                    'method' => 'post',
                    'id' => 'add_threshold_rate',
                    'enctype' => 'multipart/form-data'
                ));
            ?>
                <div class="row">
                    <div class="col-md-4">
                        <label  class="my_label"><?php echo translate("free_shipping_limit_amount"); ?></label>
                        <input type="number" class="form-control required" name="threshold_rate" id="threshold_rate">
                    </div>
                    <div class="col-md-1">
                        <label  class="my_label" style="visibility: hidden;"><?php echo translate("dummy"); ?></label><br />
                        <button class="btn btn-green btn-md pull-left">
                            <?php echo translate("Add"); ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>';
    var user_type = 'admin';
    var module = 'delivery_charges';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';
    
    $(document).ready(function(){
        $("#add_threshold_rate").submit(function(e){
            if(form_validation("add_threshold_rate")){
                $(".overlay_holder1").show();
                $("#add_threshold_rate").submit();
            }else{
                e.preventDefault();
            }
        });
    });
    
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->