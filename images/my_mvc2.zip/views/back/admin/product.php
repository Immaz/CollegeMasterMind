<style type="text/css">
    .panel_product_list .panel-body{
        padding-top: 0px;
    }
    .product_list_table .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .product_list_table .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .product_list_table thead tr th{
        font-size: 14px;
        padding: 5px;
    }
    .variant_img{
        max-height: 50px;
    }
    .block-ellipsis-admin-prod {
        display: block;
        display: -webkit-box;
        width: 400px;
        margin: 0 auto;
        font-size: 14px;
        line-height: 1.5;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-11">
            <h4 class="page-header text-overflow"><?php echo translate('manage_product');?></h4>
        </div>
        <div class="col-md-1">
            <div class="dropdown pull-right">
                <button class="btn btn-green  btn-md add_pro_btn  dropdown-toggle" type="button" data-toggle="dropdown"><span class="fa fa-bars" ></span>
                </button>
                <ul class="dropdown-menu dropdown-menu-right admin_action_ul" role="menu">
                    <li>
                        <a href="<?php echo base_url('admin/product/add'); ?>">
                            <?php echo translate('create_product');?>
                        </a>
                    </li>
                    <li class="make_first"><a  href="#"> 
                        <?php echo translate('make_first_product');?></a></li>

                    <li class="remove_make_first"><a  href="#"> 
                        <?php echo translate('remove_product_from_first');?></a></li>

                    <li class="delete_multiple_products"><a href="#"> 
                        <?php echo translate('Delete Products');?></a></li>

                    <li><a href="<?php echo base_url('admin/product/featured_product'); ?>"> 
                        <?php echo translate('Featured Products');?></a></li>

                    <li><a href="<?php echo base_url('admin/product/see_first'); ?>"> 
                        <?php echo translate('See First Products');?></a></li>
                </ul>
            </div>
        </div>
    </div>
    <form method="post" action="<?php echo base_url("admin/product/req_actions"); ?>" id="form1">
        <table id="events-table" class="table table-striped table-bordered product_list_table"  data-url="<?php echo base_url(); ?>admin/product/list_data?product_id=<?php echo (isset($product_id) ? $product_id : "" ); ?>"data-side-pagination="server" data-pagination="true" data-page-list="[5, 10, 20, 50, 100, 200]" data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next">
            <thead>
                <tr>
                    <th data-field="make_first" data-align="center" data-sortable="false">
                    </th>
                     <th data-field="image" data-align="left" data-sortable="false">
                        <?php echo translate('Image');?>
                    </th>
                    <th data-field="upc" data-align="left" data-sortable="true">
                        <?php echo translate('upc');?>
                    </th>
                    <th data-field="seller_sku" data-align="left" data-sortable="true">
                        <?php echo translate('seller_sku');?>
                    </th>
                    <th data-field="category" data-align="left" data-sortable="true">
                        <?php echo translate('category');?>
                    </th>
                    <th class="admin_panel_text" data-field="title" data-align="left" data-sortable="true">
                        <?php echo translate('title');?>
                    </th>
                       <th class="admin_panel_text" data-field="discount_offer" data-align="center" data-sortable="false">
                        <?php echo translate('discount_offer');?>
                    </th>
                    <th class="admin_panel_text" data-field="current_stock" data-sortable="false" data-align="center">
                        <?php echo translate('stock_status');?>
                    </th>
                    <th data-field="publish" data-sortable="false">
                        <?php echo translate('publish');?>
                    </th>
                    <th data-field="featured" data-sortable="false">
                        <?php echo translate('featured');?>
                    </th>
                    <th data-field="flash_sale" data-sortable="false">
                        <?php echo translate('flash_sale');?>
                    </th>
                    <th data-field="options" data-sortable="false" data-align="center">
                        <?php echo translate('options');?>
                    </th>
                </tr>
            </thead>
        </table>
        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    </form>
</div>
<span id="prod" style="display:none;"></span>
<script>
    var base_url = '<?php echo base_url(); ?>';
	var user_type = 'admin';
	var module = 'product';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
    
	function proceed(type){
		if(type == 'to_list'){
			$(".pro_list_btn").show();
			$(".add_pro_btn").hide();
		} else if(type == 'to_add'){
			$(".add_pro_btn").show();
			$(".pro_list_btn").hide();
		}
	}
     $(document).ready(function(){
        
        $(".make_first").click(function(){
            $("#form1").append("<input type='text' value='1' name='is_make_first'>");
            $("#form1").submit();
        });

        $(".delete_multiple_products").click(function(){
            Swal.fire({
              title: 'Are you sure?',
              text: "",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete!'
            }).then((result) => {
                if (result.value) {
                    $("#form1").attr("action",'<?php echo base_url("admin/product/multiple_delete"); ?>');
                    $("#form1").submit();
                }
            });
        });
        
        $(".remove_make_first").click(function(){
            $("#form1").append("<input type='text' value='0' name='is_make_first'>");
            $("#form1").submit();
        });

        $(document).on("click" , ".btn_delete_product",function(e){
            var url = $(this).attr("data-url");
            Swal.fire({
              title: 'Are you sure?',
              text: "This product and all it variants / imgaes will be permenant deleted",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.value) {
                    window.location.href = url;
                }else{
                    e.preventDefault();
                }
            });
        });

        $(document).on("click" , ".btn_add_thumbnail",function(e){
            var product_id = $(this).attr("data-product-id");
            ajax_modal('add_thumbnail','<?php echo translate('upload_thumbnail'); ?>','<?php echo translate('thumbnail_upload_successfully'); ?>','form_product_thumbnail',product_id);
        });

        $(document).on("click" , ".btn_add_thumbnail_vart",function(e){
            var product_id = $(this).attr("data-product-id");
            ajax_modal('thumbnail_from_variants','<?php echo translate('choose_thumbnail_from_variants_images'); ?>','<?php echo translate('thumbnail_upload_successfully'); ?>','form_product_thumbnail_variants',product_id);
        });

        $('#events-table').bootstrapTable({
         
        }).on('all.bs.table', function (e, name, args) {
         
        }).on('click-row.bs.table', function (e, row, $element) {
            
        }).on('dbl-click-row.bs.table', function (e, row, $element) {
            
        }).on('sort.bs.table', function (e, name, order) {
            
        }).on('check.bs.table', function (e, row) {
            
        }).on('uncheck.bs.table', function (e, row) {
            
        }).on('check-all.bs.table', function (e) {
            
        }).on('uncheck-all.bs.table', function (e) {
            
        }).on('load-success.bs.table', function (e, data) {
            set_switchery();
            $( ".tooltip , .my_tooltip" ).tooltip();
        }).on('load-error.bs.table', function (e, status) {
            
        }).on('column-switch.bs.table', function (e, field, checked) {
            
        }).on('page-change.bs.table', function (e, size, number) {
           
        }).on('search.bs.table', function (e, text) {
            
        });
        
    });
</script>

