<style type="text/css">
    .table_delivery_charges th{
        font-size: 14px;
    }
    .table_delivery_charges td{
        font-size: 12px;
    }
    .action_btn a{
        margin-left: 2px;
        font-size: 16px;
    }
    .action_btn a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('free shipping limit');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/threshold_rate/add'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-plus"></i>&nbsp;
                    <?php echo translate('free_shipping_limit');?>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 pd-1">
            <table class="table table-hovered table-bordered table_delivery_charges">
        <thead>
            <th width="10%"><?php echo translate("Sno");  ?></th>
            <th><?php echo translate("free_shipping_limit");  ?></th>
            <th width="10%"><?php echo translate("actions");  ?></th>
        </thead>
        <tbody>
            <?php
                if($threshold){
            ?>
                <tr>
                    <td>1 </td>
                    <td><?php echo $threshold['threshold_rate'];  ?></td>
                    <td class="action_btn">
                        <a onclick="delete_record('<?php echo base_url('admin/threshold_rate/delete/'.$threshold['threshold_rate_id']); ?>')" data-toggle="tooltip"  data-original-title="Delete" data-container="body">
                            <i class="ad_red fa fa-trash"></i>
                        </a>
                    </td>
                </tr>
             <?php } else{ ?>
                <tr>
                    <td colspan="3" align="center"><?php echo translate('no_data_are_available'); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
        </div>
    </div>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>';
    var user_type = 'admin';
    var module = 'delivery_charges';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->