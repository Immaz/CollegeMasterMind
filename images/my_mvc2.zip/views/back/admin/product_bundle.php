<style type="text/css">
    .row_page_heading{
        display: flex;
        align-items: center;
        padding : 0px 15px 0px 15px;
        margin : 15px 0px 15px 0px;
    }
    .product_bundle_list_table .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .product_bundle_list_table .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .product_bundle_list_table thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div id="content-container">
	<div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('manage_product_bundle');?></h4>
        </div>
        <div class="col-md-4">
        	 <button class="btn btn-green btn-md  add_pro_btn pull-right" onclick="ajax_set_full('add','<?php echo translate('add_product_bundle'); ?>','<?php echo translate('successfully_added!'); ?>','product_bundle_add',''); proceed('to_list');">
        	 	<i class="fa fa-plus-circle"></i>&nbsp;
        	 	<?php echo translate('create_product_bundle');?>
             </button>
            <button class="btn btn-green btn-md pull-right pro_list_btn" style="display:none;"  onclick="ajax_set_list();  proceed('to_add');">
            	<i class="fa fa-backward"></i>&nbsp;
            	<?php echo translate('back_to_product_bundle_list');?>
            </button>
        </div>
    </div>
     <!-- LIST -->
    <div class="tab-pane fade active in" id="list" style="border:1px solid #ebebeb; border-radius:4px;"> 
        <div class="panel-body" id="demo_s">
            <table id="bundle-table" class="table-bordered table-hovered table table-striped product_bundle_list_table"  data-url="<?php echo base_url(); ?>admin/product_bundle/list_data" data-side-pagination="server" data-pagination="true" data-page-list="[5, 10, 20, 50, 100, 200]"   data-search="true"  data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next">
                <thead>
                    <tr>
                        <th data-field="image" data-align="left" data-sortable="true">
                            <?php echo translate('image');?>
                        </th>
                        <th class="admin_panel_text" data-field="title" data-align="center" data-sortable="true">
                            <?php echo translate('title');?>
                        </th>
                        <th class="admin_panel_text" data-field="current_stock" data-sortable="true">
                            <?php echo translate('current_stock');?>
                        </th>
                        <th data-field="deal" data-sortable="false">
                            <?php echo translate("today's_deal");?>
                        </th>
                        <th data-field="publish" data-sortable="false">
                            <?php echo translate('publish');?>
                        </th>
                        <th data-field="featured" data-sortable="false">
                            <?php echo translate('featured');?>
                        </th>
                        <th data-field="options" data-sortable="false" data-align="center" data-width="200">
                            <?php echo translate('options');?>
                        </th>
                    </tr>   
                </thead>
            </table>
        </div>
    </div>
</div>
<span id="bund" style="display:none;"></span>
<script>
	var base_url = '<?php echo base_url(); ?>';
	var user_type = 'admin';
	var module = 'product_bundle';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;

	function proceed(type){
		if(type == 'to_list'){
			$(".pro_list_btn").show();
			$(".add_pro_btn").hide();
		} else if(type == 'to_add'){
			$(".add_pro_btn").show();
			$(".pro_list_btn").hide();
		}
	}
    
    $(document).ready(function(){
        $('#bundle-table').bootstrapTable({

        }).on('all.bs.table', function (e, name, args) {
            //alert('1');
            //set_switchery();
        }).on('click-row.bs.table', function (e, row, $element) {
            
        }).on('dbl-click-row.bs.table', function (e, row, $element) {
            
        }).on('sort.bs.table', function (e, name, order) {
            
        }).on('check.bs.table', function (e, row) {
            
        }).on('uncheck.bs.table', function (e, row) {
            
        }).on('check-all.bs.table', function (e) {
            
        }).on('uncheck-all.bs.table', function (e) {
            
        }).on('load-success.bs.table', function (e, data) {
            set_switchery();
        }).on('load-error.bs.table', function (e, status) {
            
        }).on('column-switch.bs.table', function (e, field, checked) {
            
        }).on('page-change.bs.table', function (e, size, number) {
            //alert('1');
            //set_switchery();
        }).on('search.bs.table', function (e, text) {
            
        });
    });


</script>

