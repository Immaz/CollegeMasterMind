<style type="text/css">
    .table_user_view_profile th{
        width: 140px;
    }
    .modal-footer{
        display: none;
    }
    .custom_td{
        border-left: 1px solid #ddd;
        border-right: 1px solid #ddd;
        border-bottom: 1px solid #ddd;
    }
</style>
<?php 
	foreach($user_data as $row)
	{ 
?>
    <div id="content-container" style="padding-top:0px !important;">
        <table class="table table-striped table-hovered table_user_view_profile">
              <tr>
                <th class="custom_td"><?php echo translate('Image');?></th>
                <td class="custom_td">
                    <img 
                    <?php if(file_exists('uploads/user_image/user_'.$row['user_id'].'.jpg')){ ?>
                        src="<?php echo base_url(); ?>uploads/user_image/user_<?php echo $row['user_id']; ?>.jpg"
                    <?php } else if($row['fb_id'] !== NULL){ ?>
                        src="https://graph.facebook.com/<?php echo $row['fb_id']; ?>/picture?type=large" 
                    <?php } else if($row['g_id'] !== NULL){ ?>
                        src="<?php echo $row['g_photo']; ?>"
                    <?php } else { ?>
                        src="<?php echo base_url(); ?>uploads/user_image/default.jpg"
                    <?php } ?>
                    class="img-md img-border img-circle" alt="Profile Picture">
                </td>
            </tr>
            <tr>
                <th class="custom_td"><?php echo translate('name');?></th>
                <td class="custom_td"><?php echo $row['username'].' '.$row['surname']; ?></td>
            </tr>
            <tr>
                <th class="custom_td"><?php echo translate('email');?></th>
                <td class="custom_td"><?php echo $row['email']?></td>
            </tr>
            <tr>
                <th class="custom_td"><?php echo translate('country');?></th>
                <td class="custom_td"><?php echo $this->crud_model->get_type_name_by_id("country",$row['country'],"country_name");  ?></td>
            </tr>
            <tr>
                <th class="custom_td"><?php echo translate('state');?></th>
                <td class="custom_td"><?php echo $this->crud_model->get_type_name_by_id("state",$row['state'],"state_name");  ?></td>
            </tr>
            <tr>
                <th class="custom_td"><?php echo translate('city');?></th>
                <td class="custom_td"><?php echo $this->crud_model->get_type_name_by_id("city",$row['city'],"city_name");  ?></td>
            </tr>
            <tr>
                <th class="custom_td"><?php echo translate('phone_number');?></th>
                <td class="custom_td"><?php echo $row['phone']?></td>
            </tr>
            <?php if($row['skype'] != ''){ ?>
            <tr>
                <th class="custom_td"><?php echo translate('skype');?></th>
                <td class="custom_td"><?php echo $row['skype']?></td>
            </tr>
            <?php } if($row['facebook'] != ''){ ?>
            <tr>
                <th class="custom_td"><?php echo translate('facebook');?></th>
                <td class="custom_td"><?php echo $row['facebook']?></td>
            </tr>
            <?php } if($row['google_plus'] != ''){ ?>
            <tr>
                <th class="custom_td"><?php echo translate('google_plus');?></th>
                <td class="custom_td"><?php echo $row['google_plus']?></td>
            </tr>
            <?php } ?>
            <tr>
                <th class="custom_td"><?php echo translate('creation_date');?></th>
                <td class="custom_td"><?php echo date('d M,Y',$row['creation_date']);?></td>
            </tr>
            <tr>
                <th class="custom_td"><?php echo translate('address');?></th>
                <td class="custom_td">
                    <?php echo $row['address1']?><br>
                </td>
            </tr>
        </table>					
    </div>					
<?php 
	}
?>
<script>
$(document).ready(function(e) {
    $('.modal-footer').find('.btn-purple').hide();
});
</script>