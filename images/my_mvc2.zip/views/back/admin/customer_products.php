<script src="<?php echo base_url(); ?>template/back/plugins/bootstrap-table/extensions/export/bootstrap-table-export.js"></script>
<style type="text/css">
    .row_page_heading{
        display: flex;
        align-items: center;
        padding : 0px 15px 0px 15px;
        margin : 15px 0px 15px 0px;
    }
    .customer_uploaded_products .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .customer_uploaded_products .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .customer_uploaded_products thead tr th{
        font-size: 14px;
        padding: 5px;
    }
    .highlight{
        background-color: #E7F4FA;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('customer_uploaded_products');?></h4>
        </div>
        <div class="col-md-4">
            <!-- <button class="btn btn-primary btn-labeled fa fa-plus-circle add_pro_btn pull-right" 
                onclick="ajax_set_full('add','<?php echo translate('add_product'); ?>','<?php echo translate('successfully_added!'); ?>','product_add',''); proceed('to_list');"><?php echo translate('create_product');?>
            </button> -->
            <button class="btn btn-green btn-btn pull-right pro_list_btn" 
                style="display:none;"  onclick="ajax_set_list();  proceed('to_add');">
                <i class="fa fa-step-backward"></i>
                <?php echo translate('back_to_customer_product_list');?>
            </button>
        </div>
    </div>
    <div class="tab-pane fade active in" id="list" style="border:1px solid #ebebeb; border-radius:4px;">
        <div class="panel-body" id="demo_s">
            <table id="events-table" class="table table-striped table-bordered customer_uploaded_products"  data-url="<?php echo base_url(); ?>admin/customer_products/list_data" data-side-pagination="server" data-pagination="true" data-page-list="[5, 10, 20, 50, 100, 200]"  data-show-refresh="false" data-search="true"  data-show-export="false" data-pagination-pre-text="Previous" data-pagination-next-text="Next" >
                <thead>
                    <tr>
                        <th data-field="image" data-align="center" data-sortable="true">
                            <?php echo translate('image');?>
                        </th>
                        <th data-field="title" data-align="left" data-sortable="true">
                            <?php echo translate('title');?>
                        </th>
                        <th data-field="uploaded_by" data-sortable="true" data-align="left"> 
                            <?php echo translate('uploaded_by');?>
                        </th>
                        <th data-field="customer_status" data-sortable="false" data-align="left">
                            <?php echo translate('customer_status');?>
                        </th>
                        <th data-field="publish" data-sortable="false" data-align="left">
                            <?php echo translate('publish');?>
                        </th>
                        <th data-field="options" data-sortable="false" data-align="center">
                            <?php echo translate('options');?>
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
<span id="prod" style="display:none;"></span>
<script>

	var base_url = '<?php echo base_url(); ?>';
	var user_type = 'admin';
	var module = 'customer_products';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
    
	function proceed(type){
		if(type == 'to_list'){
			$(".pro_list_btn").show();
		} else if(type == 'to_add'){
			$(".pro_list_btn").hide();
		}
	}

    $(document).ready(function(){
        $('#events-table').bootstrapTable({
            /*
            onAll: function (name, args) {
                console.log('Event: onAll, data: ', args);
            }
            onClickRow: function (row) {
                $result.text('Event: onClickRow, data: ' + JSON.stringify(row));
            },
            onDblClickRow: function (row) {
                $result.text('Event: onDblClickRow, data: ' + JSON.stringify(row));
            },
            onSort: function (name, order) {
                $result.text('Event: onSort, data: ' + name + ', ' + order);
            },
            onCheck: function (row) {
                $result.text('Event: onCheck, data: ' + JSON.stringify(row));
            },
            onUncheck: function (row) {
                $result.text('Event: onUncheck, data: ' + JSON.stringify(row));
            },
            onCheckAll: function () {
                $result.text('Event: onCheckAll');
            },
            onUncheckAll: function () {
                $result.text('Event: onUncheckAll');
            },
            onLoadSuccess: function (data) {
                $result.text('Event: onLoadSuccess, data: ' + data);
            },
            onLoadError: function (status) {
                $result.text('Event: onLoadError, data: ' + status);
            },
            onColumnSwitch: function (field, checked) {
                $result.text('Event: onSort, data: ' + field + ', ' + checked);
            },
            onPageChange: function (number, size) {
                $result.text('Event: onPageChange, data: ' + number + ', ' + size);
            },
            onSearch: function (text) {
                $result.text('Event: onSearch, data: ' + text);
            }
            */
        }).on('all.bs.table', function (e, name, args) {
            //alert('1');
            //set_switchery();
        }).on('click-row.bs.table', function (e, row, $element) {
            
        }).on('dbl-click-row.bs.table', function (e, row, $element) {
            
        }).on('sort.bs.table', function (e, name, order) {
            
        }).on('check.bs.table', function (e, row) {
            
        }).on('uncheck.bs.table', function (e, row) {
            
        }).on('check-all.bs.table', function (e) {
            
        }).on('uncheck-all.bs.table', function (e) {
            
        }).on('load-success.bs.table', function (e, data) {
            set_switchery();
        }).on('load-error.bs.table', function (e, status) {
            
        }).on('column-switch.bs.table', function (e, field, checked) {
            
        }).on('page-change.bs.table', function (e, size, number) {
            //alert('1');
            //set_switchery();
        }).on('search.bs.table', function (e, text) {
            
        });
    });
</script>

