<?php   $row = $product_data[0];    ?>
<style type="text/css">
    .panel_product_view{
        padding: 5px;
    }
    label{
        font-size: 16px;
        font-weight: 500;
        padding: 8px;
    }
    .panel_product_view .row  p{
        font-size: 14px;
        padding: 8px;
    }
    .row_img_des_holder{
        display: flex;
        align-items: center;
    }
    .media .media-body h4{
        padding-left: 8px;
    }
     .media .media-left{
        width: 130px;
     }
     .heading-info{
        font-weight: bold;
        font-size: 16px;
     }
     .table-add-info tr th,
      .table-add-info tr td{
        padding: 0px 5px !important; 
     }
</style>
    <div id="content-container">
        <div class="row row_page_heading">
            <div class="col-md-8">
                <h4 class="page-header text-overflow"><?php echo translate('view_customer_product');?></h4>
            </div>
            <div class="col-md-4">
                <a class="btn btn-green btn-md pull-right" href="<?php echo base_url('admin/customer_products'); ?>">
                    <i class="fa fa-backward"></i>&nbsp;
                    <?php echo translate('back_to_customer_product_list');?>
                </a>
            </div>
        </div>
        <hr style="margin: 10px 0 !important;">
        <div class="panel panel_product_view">
            <div class="panel-body">

                <div class="row row_img_des_holder">
                    <div class="col-md-12">
                        <div class="media">
                            <div class="media-left media-middle">
                               <img class="img-responsive thumbnail" alt="Profile Picture" 
                            src="<?php echo $this->crud_model->file_view('customer_product',$row['customer_product_id'],'','','thumb','src','multi','one'); ?>">
                             </div>
                             <div class="media-body">
                                <h4 class="media-heading"><?php echo translate('description');?></h4>
                                <?php echo $row['description'];?>
                            </div>
                        </div>
                    </div>
                 </div>

                <ul class="list-group">
                    <li class="list-group-item bg-info">
                        <span class="heading-info">
                            <i class="fa fa-file fa-info"></i>
                                <?php echo translate('general_information');?>
                            </span>
                    </li>
                    <li class="list-group-item">

                         <div class="row">
                            <div class="col-md-4">
                                <label><?php echo translate('name');?></label>
                                <p>
                                    <?php echo $row['title']?>
                                </p>
                            </div>
                            <div class="col-md-4">
                                <label><?php echo translate('category');?></label>
                                  <p>
                                    <?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name');?>
                                </p>
                            </div>
                             <div class="col-md-4">
                                <label><?php echo translate('sub-category');?></label>
                                <p>
                                    <?php echo $this->crud_model->get_type_name_by_id('sub_category',$row['sub_category'],'sub_category_name');?>
                                </p>
                            </div>
                        </div>

                        <hr style="margin-bottom: 3px; margin-top: 3px;">

                        <div class="row">
                            <div class="col-md-4">
                                <label><?php echo translate('brand');?></label>
                                <p>
                                    <?php echo $row['brand']; ?>
                                </p>
                            </div>
                              <div class="col-md-4">
                                <label><?php echo translate('seller');?></label>
                                <p>
                                    <?php echo $this->db->get_where('user', array('user_id' => $row['added_by']))->row()->username; ?>
                                </p>
                            </div>
                              <div class="col-md-4">
                                <label><?php echo translate('seller_email');?></label>
                                <p>
                                    <?php echo $this->db->get_where('user', array('user_id' => $row['added_by']))->row()->email; ?>
                                </p>
                            </div>
                        </div>

                        <hr style="margin-bottom: 3px; margin-top: 3px;">

                        <div class="row">
                            <div class="col-md-4">
                                <label><?php echo translate('phone_no');?></label>
                                 <p>
                                   <?php if ($this->db->get_where('user', array('user_id' => $row['added_by']))->row()->phone){
                                                echo $this->db->get_where('user', array('user_id' => $row['added_by']))->row()->phone;
                                            } else {
                                                echo translate("not_given");
                                     }?>
                                </p>
                            </div>
                            <div class="col-md-4">
                                <label><?php echo translate('sale_price');?></label>
                                 <p>
                                    <?php echo currency('','def').' '.$this->cart->format_number($row['sale_price']); ?>
                                </p>
                            </div>
                        </div>
                    </li>
                </ul>
              

                <div class="row">
                    <div class="col-md-12">
                        <ul class="list-group">
                            <li class="list-group-item bg-info">
                                <span class="heading-info">
                                    <i class="fa fa-file fa-info"></i>
                                    <?php echo translate('additional_information');?> 
                                </span>
                            </li>
                            <li class="list-group-item">
                                <?php 
                                    $a = $this->crud_model->get_customer_additional_fields($row['customer_product_id']);
                                ?>
                                <table class="table table-bordered table-hovered table-add-info">
                                    <tbody>
                                    <?php
                                      if(count($a)>0){
                                        foreach ($a as $val) {
                                    ?>
                                        <tr>
                                            <th style="text-align:left; width: 15%;"><label><?php echo $val['name']; ?></label></th>
                                            <td style="text-align:left;"><?php echo $val['value']; ?></td>
                                        </tr>
                                    <?php
                                        }
                                    }else{
                                    ?>
                                     <tr>
                                        <td align="center"><p><?php echo translate('no_data_are_available!');?></p></td>
                                    </tr>
                                    <?php } ?>
                                    </tbody>
                                </table>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>		
            
<style>
.custom_td{
border-left: 1px solid #ddd;
border-right: 1px solid #ddd;
border-bottom: 1px solid #ddd;
}
</style>

<script>
	$(document).ready(function(e) {
		proceed('to_list');
	});
</script>