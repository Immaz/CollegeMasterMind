<style type="text/css">
    .row{
        margin-bottom: 10px;
    }
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
</style>
<div class="container" id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Add Advanced Delivery Charges');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/delivery_charges/advanced'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-backward"></i>&nbsp;
                    <?php echo translate('back_to_delivery_charges_list');?>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 pd-1">
            <?php
                echo form_open(base_url() . 'admin/delivery_charges/add_advanced', array(
                    'class' => 'form-horizontal',
                    'method' => 'post',
                    'id' => 'add_delivery_charges',
                    'enctype' => 'multipart/form-data'
                ));
            ?>
                <div class="row">
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("title"); ?></label>
                        <input type="text" name="title" id="title" class="form-control required">
                    </div>
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("country"); ?></label>
                        <select name="country" id="filter_item_country" style="width: 100% !important" class="form-control filter_select required">
                            <option value=""><?php echo translate("select"); ?></option>
                            <?php
                                foreach ($countries as  $country) {
                            ?>
                            <option value="<?php echo $country['country_id']; ?>">
                                <?php echo $country['country_name']; ?></option>
                            <?php  } ?>
                        </select>
                    </div> 
                </div>
                <div class="row a_s">
                    <button type="button" style="float: right; margin-right: 15px; margin-bottom: 6px;" disabled class="btn btn-purple add_more"><?php echo translate("add more"); ?></button>
                    <label class="my_label" style="padding-left: 15px;"><?php echo translate("Filter"); ?></label>
                    <div class="col-md-12" style="display: flex;justify-content: space-between;">
                        <select name="equal_unequal_0" id="equal_unequal_0" style="width: 28.5%" class="form-control">
                            <option value="="><?php echo translate("equal"); ?></option>
                            <option value="!="><?php echo translate("not equal to"); ?></option>
                        </select>
                        <select name="filter_item_0" id="filter_item_0" disabled style="width: 68.5% !important" class="form-control filter_items select2">
                            <option value=""><?php echo translate("select country first"); ?></option>
                        </select>
                    </div> 
                </div>
                <div class="more_filter"></div>
                <div class="row a_s">
                    <div class="col-md-6">
                        <label class="my_label" ><?php echo translate("Shipping Cost"); ?></label>
                        <input type="text" name="base_cost" id="advance_shipping_cost" class="form-control required">
                    </div> 
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="my_checkbox_container">
                            <input type="checkbox" name="is_active" id="is_active" checked="checked">
                            <span class="my_checkmark"></span>
                            <label for="is_active" style="margin-left: 25px;">Active</label>
                        </div>
                     </div>
                    <div class="col-md-10">
                        <input type="hidden" name="shipping_type" value="a_s">
                        <input type="hidden" name="number_of_filter" id="number_of_filter" value="1">
                        <button class="btn btn-green btn-md pull-right" id="mysubmitbtn" name='submit_button_two'>
                            <?php echo translate("submit"); ?> 
                            <i class="fa fa-upload"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>';
    // var timer = '<?php //$this->benchmark->mark_time(); ?>';
    var user_type = 'admin';
    var module = 'delivery_charges';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';

    $(document).ready(function(){
        $('.select2').select2({
            minimumInputLength: 2
        });
        $('.filter_select').select2({
            minimumInputLength: 2
        });

        $("#mysubmitbtn").click(function(e){
            e.preventDefault();
            if(form_validation("add_delivery_charges")){
                for (let i = 0; i < $('#number_of_filter').val(); i++) {
                    $('#number_of_filter').after('<input type="hidden" name="filter_items_type[]" value="'+$('#filter_item_'+i).find("option:selected").data('type')+'">');
                }
                $(".overlay_holder1").show();
                $("#add_delivery_charges").submit();
            }else{
                e.preventDefault();
            }
        });

        $("#filter_item_country").change(function(e){
            var data = {
                '<?php echo $this->security->get_csrf_token_name() ?>': '<?php echo $this->security->get_csrf_hash() ?>',
                'country': $(e.currentTarget).val()
            };
            
            $.ajax({
                url: "<?php echo base_url('admin/get_data_by_country'); ?>",
                type: "POST",
                data: data,
                success: function(data) {
                    var data = JSON.parse(data);
                    if (data['status'] > 0) {
                        var html = '<option value=""><?php echo translate('select')?></option>';
                        for (let i = 0; i < data['data'].length; i++) {
                            html += '<option value="'+data['data'][i].id+'" data-type="'+data['data'][i].data_type+'">'+data['data'][i].name+'</option>';                                
                        }
                        $('#filter_item_0').html(html);
                        $('#filter_item_0').prop('disabled', false);
                        $('.add_more').prop('disabled', false);
                    }else{
                        Swal.fire({
                            title: '404?',
                            text: "States Not Found For this Country.",
                            type: 'error',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Ok!'
                        });
                    }
                }
            });
        });
        
        var number_of_filter = 1;
        $(".add_more").click(function(e){
            var data = {
                '<?php echo $this->security->get_csrf_token_name() ?>': '<?php echo $this->security->get_csrf_hash() ?>',
                'country': $('#filter_item_country').val()
            };
            $.ajax({
                url: "<?php echo base_url('admin/get_data_by_country'); ?>",
                type: "POST",
                data: data,
                success: function(data) {
                    var data = JSON.parse(data);
                    if (data['status'] > 0) {
                        var html = '<div class="row">';
                            html += '<div class="col-md-12" style="display: flex;justify-content: space-between;">';
                                html += '<select name="equal_unequal_'+number_of_filter+'" id="equal_unequal_'+number_of_filter+'" style="width: 28.5%" class="form-control">';
                                    html += '<option value="="><?php echo translate("equal"); ?></option>';
                                    html += '<option value="!="><?php echo translate("not equal to"); ?></option>';
                                html += '</select>';
                                html += '<select name="filter_item_'+number_of_filter+'" id="filter_item_'+number_of_filter+'" style="width: 68.5%" class="form-control select2">';
                                    html += '<option value=""><?php echo translate('select')?></option>';
                                    for (let i = 0; i < data['data'].length; i++) {
                                        html += '<option value="'+data['data'][i].id+'" data-type="'+data['data'][i].data_type+'">'+data['data'][i].name+'</option>';                                
                                    }
                                html += '</select>';
                            html += '</div>';
                        html += '</div>';
                        $('.more_filter').append(html);
                    }else{
                        Swal.fire({
                            title: '404?',
                            text: "States Not Found For this Country.",
                            type: 'error',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Ok!'
                        });
                    }
                }
            }).then(()=>{
                $('.select2').select2({
                    minimumInputLength: 2
                });
                $('#number_of_filter').val(number_of_filter + 1);
                number_of_filter++;
            })
        });

        // $("#filter_item_state").change(function(e){
        //     var data = {
        //         '<?php //echo $this->security->get_csrf_token_name() ?>': '<?php //echo $this->security->get_csrf_hash() ?>',
        //         'state': $(e.currentTarget).val()
        //     };
        //     $.ajax({
        //         url: "<?php //echo base_url('admin/get_city_by_state'); ?>",
        //         type: "POST",
        //         data: data,
        //         success: function(data) {
        //             var data = JSON.parse(data);
        //             if (data['status'] > 0) {
        //                 var html = '<option value=""><?php //echo translate('select')?></option>';
        //                 for (let i = 0; i < data['data'].length; i++) {
        //                     html += '<option value="'+data['data'][i].city_id+'">'+data['data'][i].city_name+'</option>';
        //                 }
        //                 $('#filter_item_city').html(html);
        //                 $('#filter_item_city').prop('disabled', false);
        //             }else{
        //                 Swal.fire({
        //                     title: '404?',
        //                     text: "City Not Found For this State.",
        //                     type: 'error',
        //                     showCancelButton: true,
        //                     confirmButtonColor: '#3085d6',
        //                     cancelButtonColor: '#d33',
        //                     confirmButtonText: 'Ok!'
        //                 });
        //             }
        //         }
        //     });
        // });
    });
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->