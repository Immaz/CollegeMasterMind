<style type="text/css">
    .sub_category_list_table .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .sub_category_list_table .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .sub_category_list_table thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow">
                <?php echo translate('manage_sub_categories');?>
            </h4>
        </div>
        <div class="col-md-4">
           <button class="btn btn-green btn-md  pull-right" onclick="ajax_modal('add','<?php echo translate('add sub category'); ?>','<?php echo translate('successfully_added!'); ?>','sub_category_add','')"> 
            <i class="fa fa-plus-circle"></i>&nbsp;
                <?php echo translate('create_sub_category');?>
            </button>
        </div>
    </div>
    <table id="demo-table" class="table-bordered table table-striped sub_category_list_table"  data-pagination="false" data-ignorecol="0,3" data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next" data-search="true" data-sort-name="sno" data-sort-order="desc">
        <thead>
            <tr>
                <th data-field="sno"><?php echo translate('no');?></th>
                <th><?php echo translate('name');?></th>
                <th><?php echo translate('banner');?></th>
                <th><?php echo translate('category');?></th>
                <th><?php echo translate('brands');?></th>
                <th data-width="200"><?php echo translate('featured');?></th>
                <th class="text-center"><?php echo translate('options');?></th>
            </tr>
        </thead>                
        <tbody >
        <?php
            $i=0;
            foreach($all_sub_category as $row){
                $i++;
        ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td class="admin_panel_text"><?php echo $row['sub_category_name']; ?></td>
            <td>
                <?php
                    if(file_exists('uploads/sub_category_image/'.$row['banner'])){
                ?>
                <img class="img-md" src="<?php echo base_url(); ?>uploads/sub_category_image/<?php echo $row['banner']; ?>" height="100px" />  
                <?php
                    } else {
                ?>
                <img class="img-md" src="<?php echo base_url(); ?>uploads/sub_category_image/default.jpg" height="100px" />
                <?php
                    }
                ?>
            </td>
            <td class="admin_panel_text"><?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name'); ?></td>
            <?php
                $brands=json_decode($row['brand'],true);
            ?>
            <td class="admin_panel_text">
                <?php 
                    $count  = 1;
                    foreach($brands as $row1){
                        if($count==4){
                            $count  = 1;
                            echo "<br>";
                        }
                ?>
                    <span class="badge badge-info" style="margin-right: 5px; margin-bottom: 5px;">
                        <?php echo $this->crud_model->get_type_name_by_id('brand',$row1,'name');?>
                    </span>
                <?php 
                    $count++; } 
                ?>
            </td>
            <div id="prod"></div>
            <td>
                <input id="feat_<?php echo $row['sub_category_id']; ?>"
                        data-id="<?php echo $row['sub_category_id']; ?>" class='sw13'
                        type="checkbox" name="featured"
                        <?php if($row['is_featured'] == 1){ ?>checked<?php } ?>
                        value="ok" />
            </td>
            <td class="text-center">
                <div class="btn_product_action">
                     <a  data-toggle="tooltip" onclick="ajax_modal('edit','<?php echo translate('edit sub category'); ?>','<?php echo translate('successfully_edited!'); ?>','sub_category_edit','<?php echo $row['sub_category_id']; ?>')" data-original-title="Edit" data-container="body">
                        <i class="ad_gray fa fa-wrench"></i>
                    </a>
                    <a onclick="delete_record('<?php echo base_url('admin/sub_category/delete/'.$row['sub_category_id']); ?>')" data-toggle="tooltip"  data-original-title="Delete" data-container="body">
                        <i class="ad_red fa fa-trash"></i>
                    </a>
                </div>
            </td>
        </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
</div>

<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'sub_category';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
    var this_page = false;
</script>
