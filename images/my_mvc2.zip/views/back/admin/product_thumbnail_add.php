<div>
    <?php
    	echo form_open(base_url() . 'admin/product/add_thumbnail/', array(
			'class' => 'form-horizontal',
			'method' => 'post',
			'id' => 'form_product_thumbnail',
			'enctype' => 'multipart/form-data'
		));
	?>
        <div class="panel-body">
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-2">
                    <?php echo translate('Selet Thumbnail Image');?>
                </label>
                <div class="col-md-12">
                    <input type="file" name="file" id='imgInp' accept="image" class="form-control required">
                </div>
            </div>
            <div class="form-group">
	            <label class="col-md-4 my_label" for="demo-hor-2">
	                <?php echo translate('preview');?>
	            </label>
	            <div class="col-md-12">
	            	<span id='wrap' class="pull-left" >
	            		<?php 
	            		if($thumbnail!="" && $thumbnail!=NULL){
	            			$img = json_decode($thumbnail , true);
	            		?>
	            		 <img src="<?php echo $this->crud_model->get_image("product_variants" , $img[0]);?>"  width="30%" id='blah' class="thumbnail">
	            		<?php }else{ ?>
	                    <img src="<?php echo base_url(); ?>uploads/category_image/default.jpg" 
	                        width="30%" id='blah' class="thumbnail">
	                    <?php } ?>
	                </span>
	        	</div>
            </div>
        </div>
        <input type="hidden" value="<?php echo $product_id; ?>" id="product_id"  name="product_id">
	</form>
</div>

<script>
	// pull-left btn btn-default btn-file
	$(document).ready(function() {
		$("form").submit(function(e){
			event.preventDefault();
		});
	});
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
	
			reader.onload = function(e) {
				$('#wrap').hide('fast');
				$('#blah').attr('src', e.target.result);
				$('#wrap').show('fast');
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
	
	$("#imgInp").change(function() {
		readURL(this);
	});
</script>