<?php
	$physical_system   	 =  $this->crud_model->get_type_name_by_id('general_settings','68','value');
	$digital_system   	 =  $this->crud_model->get_type_name_by_id('general_settings','69','value');
	$status= '';
	$value= '';
	if($physical_system !== 'ok' && $digital_system == 'ok'){
		$status= 'digital';
		$value= 'ok';
	}
	if($physical_system == 'ok' && $digital_system !== 'ok'){
		$status= 'digital';
		$value= NULL;
	}
	if($physical_system !== 'ok' && $digital_system !== 'ok'){
		$status= 'digital';
		$value= '0';
	}
?>
<div>
	<?php
        echo form_open(base_url() . 'admin/coupon/do_add/', array(
            'class' => 'form-horizontal',
            'method' => 'post',
            'id' => 'coupon_add',
            'enctype' => 'multipart/form-data'
        ));
    ?>
        <div class="">
            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-1"><?php echo translate('coupon_title');?></label>
                <div class="col-md-12">
                    <input type="text" name="title" id="demo-hor-1" 
                        placeholder="<?php echo translate('title'); ?>" class="form-control required">
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-1"><?php echo translate('valid_till');?></label>
                <div class="col-md-12">
                    <input type="date" name="till" id="demo-hor-1" class="form-control">
                </div>
            </div>
            
            <!-- <div class="form-group">
                <label class="col-md-12 my_label"><?php echo translate('coupon_discount_on');?></label>
                <div class="col-md-12">
                    <?php
                        $array = array('all_products','category','sub_category','third_sub_category','product');
                        echo $this->crud_model->select_html($array,'set_type','','add','demo-chosen-select required chos'); 
                    ?>
                </div>
            </div> -->
            
            <!-- <div class="form-group category" style="display:none;">
                <label class="col-md-12 my_label"><?php echo translate('category');?></label>
                <div class="col-md-12">
                    <?php
                        echo $this->crud_model->select_html('category','category','category_name','add','demo-cs-multiselect','',$status,$value); 
                    ?>
                </div>
            </div> -->
            
            <!-- <div class="form-group sub_category" style="display:none;">
                <label class="col-md-12 my_label"><?php echo translate('sub_category');?></label>
                <div class="col-md-12">
                    <?php 
                        echo $this->crud_model->select_html('sub_category','sub_category','sub_category_name','add','demo-cs-multiselect','',$status,$value); 
                    ?>
                </div>
            </div> -->
            
            <!-- <div class="form-group third_sub_category" style="display:none;">
                <label class="col-md-12 my_label"><?php echo translate('third_sub_category');?></label>
                <div class="col-md-12">
                    <select class="form-control demo-cs-multiselect" name="third_sub_category" id="third_sub_category" multiple="multiple">
                            <option value=""><?php echo translate("choose options"); ?></option>
                            <?php
                            foreach($third_sub_categories as $third_sub_category){
                            ?>
                                <option value="<?php echo $third_sub_category['third_sub_category_id']; ?>">
                                    <?php echo $third_sub_category['third_sub_ctg_name']; ?>
                                </option>
                            <?php } ?>
                    </select>
                </div>
            </div> -->

            <!-- <div class="form-group product" style="display:none;">
                <label class="col-md-12 my_label"><?php echo translate('product');?></label>
                <div class="col-md-12">
                    <select class="form-control demo-cs-multiselect" name="product[]" id="product" multiple="multiple">
                        <option value=""><?php echo translate("choose options"); ?></option>
                        <?php
                        $product_variants = $this->crud_model->getAllVariantsForCoupon();
                        foreach($product_variants as $product_variant){
                        ?>
                            <option value="<?php echo $product_variant['product_id']; ?>">
                                <?php echo $product_variant['title'];  ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div> -->

            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-1"><?php echo translate('coupon_code');?></label>
                <div class="col-md-12">
                    <input type="text" name="code" id="demo-hor-1" 
                        placeholder="<?php echo translate('code'); ?>" class="form-control required">
                </div>
            </div>
            
            <div class="form-group">
                <label class="col-md-12 my_label"><?php echo translate('discount_type');?></label>
                <div class="col-md-12">
                    <?php
                        $array = array('percent','amount');
                        echo $this->crud_model->select_html($array,'discount_type','','add','demo-chosen-select required'); 
                    ?>
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-1"><?php echo translate('discount_value');?></label>
                <div class="col-md-12">
                    <input type="number" name="discount_value" id="demo-hor-1" 
                        placeholder="<?php echo translate('discount_value'); ?>" class="form-control required">
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-1"><?php echo translate('no_of_apply');?></label>
                <div class="col-md-12">
                    <input type="number" name="no_of_apply" id="no_of_apply" 
                        placeholder="<?php echo translate('no_of_apply'); ?>" class="form-control required" value="1">
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-12">
                    <input type="checkbox" name="coupon_unlimited" id="coupon_unlimited">
                    <label class="my_label" for="demo-hor-1"><?php echo translate('is_unlimited');?></label>
                </div>
            </div>

        </div>
	</form>
</div>
<script src="<?php echo base_url(); ?>template/back/js/custom/brand_form.js"></script>
<script type="text/javascript">
    $(document).ready(function(){

    });
    $('.chos').on('change',function(){
        var a = $(this).val();
        $('.product').hide('slow');
        $('.category').hide('slow');
        $('.sub_category').hide('slow');
        $('.third_sub_category').hide('slow');
        $('.'+a).show('slow');
    });
</script>
