<style type="text/css">
    .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .tbl_blog thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('manage_blog');?></h4>
        </div>
        <div class="col-md-4">
           <a class="btn btn-green btn-labeled fa fa-plus-circle add_pro_btn pull-right"  href="<?php echo base_url("admin/blog/add"); ?>">
            <?php echo translate('create_blog');?>
            </a>
        </div>
    </div>
    <table id="demo-table" class="table table-striped table-bordered tbl_blog"  data-pagination="true" data-ignorecol="0,6"  data-search="true" >
        <thead>
            <tr>
                <th><?php echo translate('sno');?></th>
                <th><?php echo translate('title');?></th>
                <th><?php echo translate('blog_category');?></th>
                <th><?php echo translate('date');?></th>
                <th class="text-center"><?php echo translate('options');?></th>
            </tr>
        </thead>
        <tbody>
        <?php
            $i=0;
            foreach($all_blogs as $row){
                $i++;
        ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $row['title']; ?></td>
            <td><?php echo $row['blog_category_name']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td class="text-center btn_product_action">
                <a  href="<?php echo base_url("admin/blog/edit/".$row['blog_id']); ?>">
                    <i class="ad_gray fa fa-wrench"></i>
                </a>
                <a onclick="delete_record('<?php echo base_url("admin/blog/delete/".$row['blog_id']); ?>')">
                    <i class="ad_red fa fa-trash"></i>
                </a>
            </td>
        </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
</div>
<span id="prod"></span>
<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'blog';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
	function proceed(type){
		if(type == 'to_list'){
			$(".pro_list_btn").show();
			$(".add_pro_btn").hide();
		} else if(type == 'to_add'){
			$(".add_pro_btn").show();
			$(".pro_list_btn").hide();
		}
	}
</script>

