<style type="text/css">
    .row{
        margin-bottom: 10px;
    }
    .w_b_s,
    .s_s_c{
        display: none;
    }
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
</style>
<div class="container" id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Edit Delivery Charges');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/delivery_charges'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-backward"></i>&nbsp;
                    <?php echo translate('back_to_delivery_charges_list');?>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 pd-1">
            <?php
                echo form_open(base_url() . 'admin/delivery_charges/edit/'.$delivery_charge['delivery_charges_id'], array(
                    'class' => 'form-horizontal',
                    'method' => 'post',
                    'id' => 'edit_delivery_charges',
                    'enctype' => 'multipart/form-data'
                ));
            ?>
                <div class="row">
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("title"); ?></label>
                        <input type="text" name="title" value="<?= $delivery_charge['title'];?>" id="title" class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("shipping_type"); ?></label>
                        <select name="shipping_type" style="width: 100%" id="shipping_type" class="form-control select2 required">
                            <option value=""><?php echo translate("-- Select --"); ?></option>
                            <option <?= ($delivery_charge['type'] == "f_r_s")? 'selected' : '';?> value="f_r_s">Flat Rate Shipping</option>
                            <option <?= ($delivery_charge['type'] == "w_b_s")? 'selected' : '';?> value="w_b_s">Weight Base Shipping</option>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 w_b_s">
                        <label class="my_label"><?php echo translate("destination"); ?></label>
                        <select name="destination" style="width: 100%" id="destination" class="form-control select2">
                            <option value=""><?php echo translate("-- Select --"); ?></option>
                            <option <?= ($delivery_charge['destination'] == "all")? 'selected' : '';?> value="all">All Allowed</option>
                            <option <?= ($delivery_charge['destination'] == "specific")? 'selected' : '';?> value="specific">Specific</option>
                            <option <?= ($delivery_charge['destination'] == "all-except-specific")? 'selected' : '';?> value="all-except-specific">All Except Specific</option>
                        </select>
                    </div>
                    <div class="col-md-6 country_div">
                        <label class="my_label"><?php echo translate("country"); ?></label>
                        <select name="country[]" style="width: 100%" id="country" multiple="true" class="form-control select2">
                            <option value=""><?php echo translate("-- Select --"); ?></option>
                            <?php
                                foreach ($countries as  $country) {
                            ?>
                            <option <?php echo (in_array($country['country_id'], explode(',',$delivery_charge['country'])))? "selected": "";?> value="<?php echo $country['country_id']; ?>">
                                <?php echo $country['country_name']; ?></option>
                            <?php  } ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("Base Cost"); ?></label>
                        <input type="number" name="base_cost" value="<?= $delivery_charge['base_cost'];?>" id="base_cost" class="form-control">
                    </div>
                </div>
                <div class="row w_b_s">
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("weight charge"); ?></label>
                        <input type="number" name="weight_charge" value="<?= $delivery_charge['additional_price'];?>" id="weight_charge" class="form-control ">
                    </div> 
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("weight per each"); ?></label>
                        <input type="number" name="weight_per_each" value="<?= $delivery_charge['additional_weight'];?>" id="weight_per_each" class="form-control ">
                    </div>
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("weight over"); ?></label>
                        <input type="number" name="weight_over" value="<?= $delivery_charge['weight_over'];?>" id="weight_over" class="form-control ">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="my_checkbox_container">
                            <input type="checkbox" name="is_active" id="is_active"  <?= ($delivery_charge['active'])? 'checked="checked"': '';?>>
                            <span class="my_checkmark"></span>
                            <label for="is_active" style="margin-left: 25px;">Active</label>
                        </div>
                     </div>
                    <div class="col-md-10">
                        <button class="btn btn-green btn-md pull-right" type="submit">
                            <?php echo translate("submit"); ?> 
                            <i class="fa fa-upload"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>';
    // var timer = '<?php //$this->benchmark->mark_time(); ?>';
    var user_type = 'admin';
    var module = 'delivery_charges';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';
    
    $(document).ready(function(){
        $('.select2').select2();

        $("#edit_delivery_charges").submit(function(e){
            if(form_validation("add_delivery_charges")){
                $(".overlay_holder1").show();
                $("#edit_delivery_charges").submit();
            }else{
                e.preventDefault();
            }
        });

        $("#shipping_type").change(function(e){
            if($(this).val() == 'w_b_s'){
                $('.f_r_s').hide();
                $('.w_b_s').show();
            } else if ($(this).val() == 'f_r_s') {
                $('.w_b_s').hide();
                $('.f_r_s').show();
            }
        });
        $("#shipping_type").trigger("change");
        $("#destination").change(function(e){
            if($(this).val() == 'all-except-specific' || $(this).val() == 'specific'){
                $('.s_s_c').show();
            } else{
                $('.s_s_c').hide();
            }
        });
    });
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->