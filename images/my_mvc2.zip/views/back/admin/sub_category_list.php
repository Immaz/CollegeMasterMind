<style type="text/css">
    .sub_category_list_table .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .sub_category_list_table .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .sub_category_list_table thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div class="panel-body" id="demo_s">
    <table id="demo-table" class="table-bordered table table-striped sub_category_list_table"  data-pagination="true" data-ignorecol="0,3" data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next" data-search="true" >
        <thead>
            <tr>
                <th><?php echo translate('no');?></th>
                <th><?php echo translate('name');?></th>
                <th><?php echo translate('banner');?></th>
                <th><?php echo translate('category');?></th>
                <th><?php echo translate('brands');?></th>
                <th class="text-center"><?php echo translate('options');?></th>
            </tr>
        </thead>				
        <tbody >
        <?php
            $i=0;
            foreach($all_sub_category as $row){
                $i++;
        ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td class="admin_panel_text"><?php echo $row['sub_category_name']; ?></td>
            <td>
                <?php
					if(file_exists('uploads/sub_category_image/'.$row['banner'])){
				?>
				<img class="img-md" src="<?php echo base_url(); ?>uploads/sub_category_image/<?php echo $row['banner']; ?>" height="100px" />  
				<?php
					} else {
				?>
				<img class="img-md" src="<?php echo base_url(); ?>uploads/sub_category_image/default.jpg" height="100px" />
				<?php
					}
				?>
            </td>
            <td class="admin_panel_text"><?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name'); ?></td>
            <?php
            	$brands=json_decode($row['brand'],true);
			?>
            <td class="admin_panel_text">
				<?php 
                    $count  = 1;
					foreach($brands as $row1){
                        if($count==4){
                            $count  = 1;
                            echo "<br>";
                        }
				?>
                    <span class="badge badge-info" style="margin-right: 5px; margin-bottom: 5px;">
                        <?php echo $this->crud_model->get_type_name_by_id('brand',$row1,'name');?>
                    </span>
               	<?php 
					$count++; } 
				?>
          	</td>
            <td class="text-center">
                <div class="btn_product_action">
                     <a  data-toggle="tooltip" onclick="ajax_modal('edit','<?php echo translate('edit_sub-category_(_physical_product_)'); ?>','<?php echo translate('successfully_edited!'); ?>','sub_category_edit','<?php echo $row['sub_category_id']; ?>')" data-original-title="Edit" data-container="body">
                        <i class="ad_gray fa fa-wrench"></i>
                    </a>
                    <a onclick="delete_record('<?php echo base_url('admin/sub_category/delete/'.$row['sub_category_id']); ?>')" data-toggle="tooltip"  data-original-title="Delete" data-container="body">
                        <i class="ad_red fa fa-trash"></i>
                    </a>
                </div>
            </td>
        </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
</div>
           
<div id='export-div'>
    <h1 style="display:none;"><?php echo translate('sub_category');?></h1>
    <table id="export-table" data-name='sub_category' data-orientation='p' style="display:none;">
            <thead>
                <tr>
                    <th><?php echo translate('no');?></th>
                    <th><?php echo translate('name');?></th>
                    <th><?php echo translate('category');?></th>
                </tr>
            </thead>
                
            <tbody >
            <?php
                $i = 0;
                foreach($all_sub_category as $row){
                    $i++;
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><?php echo $row['sub_category_name']; ?></td>
                <td><?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name'); ?></td>
            </tr>
            <?php
                }
            ?>
            </tbody>
    </table>
</div>
           