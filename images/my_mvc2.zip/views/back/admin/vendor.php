
<div id="content-container">

	<div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('manage_vendors');?></h4>
        </div>
    </div>
    <table id="demo-table" class="table table-striped table-bordered"  data-pagination="true"  data-search="true" >
        <thead>
            <tr>
                <th><?php echo translate('name');?></th>
                <th><?php echo translate('email');?></th>
                <th><?php echo translate('country');?></th>
                <th><?php echo translate('Approve');?></th>
                <th><?php echo translate('Edit');?></th>
            </tr>
        </thead>				
        <tbody >
        <?php
            $i = 0;
            foreach($all_vendors as $row){
                $i++;
        ?>                
        <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['country']; ?></td>
            <td>
                <?php echo $row['status'] == "approved" ? "<button class='btn btn-success approved' vendor_id='".$row['vendor_id']."'>Approved</button>" : "<button class='btn btn-danger pending' vendor_id='".$row['vendor_id']."'>Not Approved</button>"; ?>
            </td>
            <td><?php echo "<a href='". base_url('vendor/edit/' . $row['vendor_id']) ."' class='btn btn-warning'><i class='fa fa-wrench'></i> Edit Vendor</a>" ?></td>
        </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
</div>
<script>
     $("body").on("click", ".approved", function() {
        $vendor_id = $(this).attr("vendor_id");
            $ajaxData = {
                vendor_id:$vendor_id, 
                status: "pending",
                csrf_test_name: "<?php echo $this->security->get_csrf_hash(); ?>",
            };

            Swal.fire({
            text: 'Do you want to change the vendor approval status?',
            showDenyButton: true,
            showCancelButton: true,
            confirmButtonText: 'Yes',
            denyButtonText: `No`,
            }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "<?php echo base_url() . 'vendor/changeVendorStatus'?>",
                    data: $ajaxData,
                    method: "POST",
                    success: function(response){
                        window.location.reload();
                    }
                });
            }
            })
        });

     $("body").on("click", ".pending", function() {

            $vendor_id = $(this).attr("vendor_id");
              $ajaxData = {
                vendor_id:$vendor_id, 
                status: "approved",
                csrf_test_name: "<?php echo $this->security->get_csrf_hash(); ?>",
            };
            Swal.fire({
            text: 'Do you want to change the vendor approval status?',
            showDenyButton: true,
            showCancelButton: true,
            confirmButtonText: 'Yes',
            denyButtonText: `No`,
            }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: "<?php echo base_url() . 'vendor/changeVendorStatus'?>",
                    data: $ajaxData,
                    method: "POST",
                    success: function(response){
                        window.location.reload();
                    }
                });
                
            }
            })
        });
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'vendor';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;


</script>
<!-- <script src="https://checkout.stripe.com/checkout.js"></script> -->
