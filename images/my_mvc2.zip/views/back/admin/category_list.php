<style type="text/css">
    .category_list_table .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .category_list_table .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .category_list_table thead tr th{
    	font-size: 14px;
    	padding: 5px;
    }
</style>
	<div class="panel-body">
		<table id="demo-table" class="table table-striped table-bordered category_list_table"  data-pagination="true"  data-ignorecol="0,2"  data-show-columns="false" data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next">
			<thead>
				<tr>
					<th data-width="50"><?php echo translate('no');?></th>
					<th class="admin_panel_text"><?php echo translate('name');?></th>
                    <th data-width="200"><?php echo translate('banner');?></th>
					<th class="text-center" data-width="80"><?php echo translate('options');?></th>
				</tr>
			</thead>
				
			<tbody >
			<?php
				$i = 0;
            	foreach($all_categories as $row){
            		$i++;
			?>
			<tr>
				<td><?php echo $i; ?></td>
                <td><?php echo $row['category_name']; ?></td>
				<td>
                    <?php
						if(file_exists('uploads/category_image/'.$row['banner'])){
					?>
					<img class="img-md" src="<?php echo base_url(); ?>uploads/category_image/<?php echo $row['banner']; ?>" height="100px" />  
					<?php
						} else {
					?>
					<img class="img-md" src="<?php echo base_url(); ?>uploads/category_image/default.jpg" height="100px" />
					<?php
						}
					?> 
               	</td>
				<td class="text-center">
					<div class="btn_product_action">
						  <a  data-toggle="tooltip" 
	                    	onclick="ajax_modal('edit','<?php echo translate('edit_category_(_physical_product_)'); ?>','<?php echo translate('successfully_edited!'); ?>','category_edit','<?php echo $row['category_id']; ?>')" 
	                        	data-original-title="Edit" data-container="body">
	                       <i class="ad_gray fa fa-wrench"></i>
	                    </a>
						<a onclick="delete_record('<?php echo base_url("admin/category/delete/".$row['category_id']); ?>')" data-toggle="tooltip" 
	                    	data-original-title="Delete" data-container="body">
	                      <i class="ad_red fa fa-trash"></i>
	                    </a>
					</div>
				</td>
			</tr>
            <?php
            	}
			?>
			</tbody>
		</table>
	</div>
           
	<div id='export-div'>
		<h1 style="display:none;"><?php echo translate('category'); ?></h1>
		<table id="export-table" data-name='category' data-orientation='p' style="display:none;">
				<thead>
					<tr>
						<th><?php echo translate('no');?></th>
						<th><?php echo translate('name');?></th>
					</tr>
				</thead>
					
				<tbody >
				<?php
					$i = 0;
	            	foreach($all_categories as $row){
	            		$i++;
				?>
				<tr>
					<td><?php echo $i; ?></td>
					<td><?php echo $row['category_name']; ?></td>
				</tr>
	            <?php
	            	}
				?>
				</tbody>
		</table>
	</div>

