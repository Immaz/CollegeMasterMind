<style type="text/css">
    .table_tax th{
        font-size: 14px;
    }
    .table_tax td{
        font-size: 12px;
    }
    .action_btn a{
        margin-left: 2px;
        font-size: 16px;
    }
    .action_btn a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Tax');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/tax/add'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-plus"></i>&nbsp;
                    <?php echo translate('add_tax');?>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 pd-1">
            <table class="table table-hovered table-bordered table_tax">
            <thead>
                <th><?php echo translate("country");  ?></th>
                <th><?php echo translate("state");  ?></th>
                <th><?php echo translate("Tax amount");  ?></th>
                <th class="text-center"><?php echo translate("action");  ?></th>
            </thead>
            <tbody>
                <?php
                    if($taxs){
                    foreach($taxs as $tax){
                ?>
                    <tr>
                        <td><?php echo $tax['country_name'];  ?></td>
                        <td><?php echo $tax['state_name'];  ?></td>
                        <td><?php echo $tax['tax']."%";  ?></td>
                        <td class="text-center">
                            <div class='action_btn'>
                                <a onclick ="delete_record('<?php echo base_url('admin/tax/delete/'.$tax['tax_id']); ?>')"   
                                >
                                <i class='ad_red fa fa-trash'></i>
                            </a>
                            </div>
                        </td>
                    </tr>
                 <?php }} else{ ?>
                    <tr>
                        <td colspan="4" align="center"><?php echo translate('no_data_are_available'); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>            
        </div>
    </div>
</div>

<script>
    var base_url = '<?php echo base_url(); ?>';
    var user_type = 'admin';
    var module = 'tax';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';
    var this_page = false;
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->