<style>
  .logo{
    width: 120px;
  }
  .table_money_sumary tr td:nth-child(1){
   width: 200px;
 }
 @media print {
  .print_btn{
    display:none;   
  }
  #navbar-container{
    display: none;
  }
  #page-title{
    display: none;
  }
  #mapa{
    display: none;
  }
  .panel-heading{
    display: none;
  }
  .print{
    width: 100%;
  }
  .col-md-6{
    width: 50%;
    float: left;
  }
}
.block-ellipsis {
  display: block;
  display: -webkit-box;
  max-width: 100%;
  width: 200px;
  font-size: 14px;
  line-height: 1.5;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}
.row_shipped_details,
.row_delivered,
.row_on_hold,
.row_cancelled,
.row_return,
#submit_email
{
  display: none;
}
.border{
  border: 1px solid red;
}
.disabled{
  background-color: #ccc;
}
</style>
<div id="content-container">
  <div class="tab-base"> 
    <?php
    foreach($sale as $row){
      $info = json_decode($row['shipping_address'],true);
      ?>
      <div class="bordered print">
        <div class="tab-content">
          <div id="full" class="tab-pane fade active in">
            <div class="row">
              <div class="col-lg-12 col-md-12 col-sm-12" style="display: flex; align-items: center; margin-bottom: 5px;">
                <div class="col-lg-6 col-md-6 col-sm-6">
                  <img class="img-responsive logo" src="<?php echo $this->crud_model->logo('home_top_logo'); ?>" alt="Active Super Shop" width="55%">
                  <?php if($row['buyer'] == 'guest'){?>
                  </div>
                  <div class="col-lg-6 col-md-6 col-sm-6 ">
                    <?php if($row['buyer'] == 'guest'){?>
                      <!-- <b class="pull-left">
                      <?php echo translate('invoice_link:');?> <?php echo base_url() ?>home/guest_invoice/<?php echo $row['guest_id']; ?>  
                    </b> -->
                    <b class="pull-right">
                      <?php echo translate('guest_id:');?> :<?php echo $row['guest_id']; ?>  
                    </b>
                    <br>
                  <?php }?>
                  <b class="pull-right">
                    <?php echo translate('invoice_no:');?> :<?php echo $row['sale_code']; ?>  
                  </b>
                  <br>
                <?php }?>
                <b class="pull-right">
                  <?php echo translate('date_:');?> <?php echo date('d M, Y',$row['sale_datetime'] );?>
                </b>
              </div>
            </div>

            <div class="col-lg-12 col-md-12 col-sm-12">
              <div class="col-lg-6 col-md-6 col-sm-6">
                <!--Panel heading-->
                <div class="panel panel-bordered-grey shadow-none">
                  <div class="panel-heading">
                    <h1 class="panel-title"><?php echo translate('client_information');?></h1>
                  </div>
                  <!--List group-->
                  <table class="table">
                    <tbody>
                      <tr>
                        <td><b><?php echo translate('name');?></b></td>
                        <td><?php echo $info['firstname']; ?></td>
                        <td><b><?php echo translate('phone');?></b></td>
                        <td><?php echo $info['phone']; ?>  </td>
                      </tr>
                      <tr>
                        <td><b><?php echo translate('e-mail');?></b></td>
                        <td><?php echo $info['email']; ?></td>
                        <td><b><?php echo translate('zipcode');?></b></td>
                        <td><?php echo $info['zip']; ?></td>
                      </tr>
                      <tr>
                        <td><b><?php echo translate('country');?></b></td>
                        <td><?php echo $this->crud_model->get_type_name_by_id("country",$info['country'],"country_name"); ?></td>
                        <td><b><?php echo translate('state');?></b></td>
                        <td><?php echo $this->crud_model->get_type_name_by_id("state",$info['state'],"state_name"); ?></td>
                      </tr>
                      <tr>
                        <td colspan="1"><b><?php echo translate('city');?></b></td>
                        <td colspan="3"><?php echo $this->crud_model->get_type_name_by_id("city",$info['city'],"city_name"); ?></td>
                      </tr>
                      <tr>
                        <td colspan="1"><b><?php echo translate('address');?></b></td>
                        <td colspan="3"><?php echo $info['address1']; ?></td>
                      </tr>
                    </tbody>
                  </table>    
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-6">
                <!--Panel heading-->
                <div class="panel panel-bordered-grey shadow-none">
                  <div class="panel-heading">
                    <h1 class="panel-title"><?php echo translate('payment_detail');?></h1>
                  </div>
                  <!--List group-->
                  <table class="table">
                    <tbody>
                      <tr>
                        <td><b><?php echo translate('payment_status');?></b></td>
                        <td><i><?php $payment_status = json_decode($row['payment_status'], true);
                        echo translate($payment_status[0]['status']);
                        ?></i></td>
                      </tr>
                      <tr>
                        <td><b><?php echo translate('payment_method');?></b></td>
                        <td>
                          <?php 
                          if($row['payment_type'] == "authorize_net"){
                            echo "Credit Card";
                          }else if($row['payment_type'] == "cash_on_delivery"){
                            echo "Cash On Delivery";
                          }else if($row['payment_type'] == "bank_transfer"){
                            echo "Bank Transfer";
                          }else if($row['payment_type'] == "western_union_xpress_remilty"){
                            echo "Western Union | Xpress | Remilty";
                          }else if($row['payment_type'] == "quick_pay"){
                            echo "QuickPay";
                          }else{
                            echo "Paypal";
                          }
                          ?>
                        </td>
                      </tr>
                      <tr>
                        <td><b><?php echo translate('payment_date');?></b></td>
                        <td><?php echo date('d M, Y',$row['sale_datetime'] );?></td>
                      </tr>
                    </tbody>
                  </table>    
                </div>
              </div>
            </div>
          </div>

          <div class="" id="demo_s" style="padding: 25px 15px; padding-bottom: 0%;">
            <div class="fff panel panel-bordered panel-dark shadow-none">
              <div class="panel-heading">
                <h1 class="panel-title"><?php echo translate('payment_invoice');?></h1>
              </div>
              <div class="table-responsive">
                <table class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th><?php echo translate('no');?></th>
                      <th><?php echo translate('upc');?></th>
                      <th><?php echo translate('seller_sku');?></th>
                      <th><?php echo translate('item');?></th>
                      <th><?php echo translate('quantity');?></th>
                      <th><?php echo translate('unit_cost');?></th>
                      <th><?php echo translate('unit_price');?></th>
                      <th><?php echo translate('total');?></th>
                      <th><?php echo translate('profilt');?></th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $product_details = json_decode($row['product_details'], true);
                    $i =0;
                    $total = 0;
                    $total_profit = "0";
                    foreach ($product_details as $row1) {
                      $i++;
                      ?>
                      <tr>
                        <td><?php echo $i; ?><input type="hidden" value="<?php echo $row1["id"]; ?>"></td>
                        <td><?php echo $this->crud_model->get_type_name_by_id("product_variants",$row1['id'],"upc"); ?></td>
                        <td><?php echo $this->crud_model->get_type_name_by_id("product_variants",$row1['id'],"seller_sku"); ?></td>
                        <td>
                          <div class="block-ellipsis my_tooltip"  title=" <?php echo $row1['name']; ?>">
                            <a target="_blank" href="<?php echo base_url("home/product_view/".$row1['options']['product_id']."/".$this->crud_model->infiltrate_unwated_character($row1['name'])); ?>"><?php echo $row1['name']; ?></a>
                          </div>
                        </td>
                        <td><?php echo $row1['qty']; ?></td>
                        <td>
                          <?php 
                          echo currency($this->crud_model->get_type_name_by_id("product_variants",$row1['id'],"total_cost"));
                          ?>
                        </td>
                        <td><?php echo currency('','def').$this->cart->format_number($row1['price']); ?></td>
                        <td><?php echo currency('','def').$this->cart->format_number($row1['subtotal']); $total += $row1['subtotal']; ?></td>
                        <td>
                          <?php 
                          $total_cost = $this->crud_model->get_type_name_by_id("product_variants",$row1['id'],"total_cost");
                          $discounted_price = $this->crud_model->get_type_name_by_id("product_variants",$row1['id'],"discounted_price");
                          $profit =  (int)$total_cost - (int)$discounted_price;
                          $total_profit  = $total_profit + ($profit * $row1['qty']);
                          echo currency($total_profit);
                          ?>
                        </td>
                      </tr>
                      <?php
                    }
                    ?>
                  </tbody>
                </table>
                <div class="col-lg-4 col-md-4 col-sm-4 pull-right margin-top-20">
                  <div class="panel panel-colorful panel-grey shadow-none">
                    <table class="table table_money_sumary" border="0">
                      <tbody>
                        <tr>
                          <td><b><?php echo translate('sub_total_amount');?></b></td>
                          <td><?php echo currency('','def').$this->cart->format_number($total); ?></td>
                        </tr>
                        <!-- <tr>
                        <td><b><?php echo translate('tax');?></b></td>
                        <td><?php echo currency('','def').$this->cart->format_number($row['vat']); ?></td>
                      </tr> -->
                      <tr>
                        <td><b><?php echo translate('shipping');?></b></td>
                        <td><?php echo currency('','def').$this->cart->format_number($row['shipping']); ?></td>
                      </tr>
                      <tr>
                        <td><b><?php echo translate('discount');?></b></td>
                        <td>
                          <?php 
                          if($row['coupon_amount']>0){
                            echo currency($row['coupon_amount']); 
                          }else{
                            echo currency("0"); 
                          }
                          ?>
                        </td>
                      </tr>
                      <tr>
                        <td><b><?php echo translate('tax');?>
                        <!--(<?php 
                        if($row["vat"]>0 && $row["vat_percent"]>0){
                        echo $row["vat_percent"]."%";     
                        }else{
                        echo "0%";
                        }
                        ?>) -->
                      </b></td>
                      <td>
                        <?php 
                        if($row["vat"]>0 && $row["vat_percent"]>0){
                          echo currency($row["vat"]);     
                        }else{
                          echo currency("0");     
                        }
                        ?>
                      </td>
                    </tr>
                    <tr>
                      <td><b><?php echo translate('grand_total');?></b></td>
                      <td><?php echo currency($row['grand_total']); ?></td>
                    </tr>
                    <?php if($payment_status[0]['status'] == "partial"){ ?>
                      <tr>
                        <td><b><?php echo translate('pan from wallet');?></b></td>
                        <td><?php echo currency($payment_status[0]['panned_from_wallet']); ?></td>
                      </tr>
                    <?php }?>
                    <tr>
                      <td><b><?php echo translate('total_profit');?></b></td>
                      <td>
                        <?php  echo currency($total_profit); ?>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div> 
            </div>  
          </div>
        </div>
      </div>
      <?php if($row['order_status'] != 'pending'){ ?>
      <div class="" id="demo_s" style="padding: 25px 15px; padding-bottom: 0%;">
        <div class="fff panel panel-bordered panel-dark shadow-none" >
          <div class="panel-heading">
            <h1 class="panel-title"><?php echo translate('Previous Order Details');?></h1>
          </div>
          <div class="panel-body" style="padding-top: 1%;">
            <?php if(count($delivery_status) > 0 && $delivery_status['delivery_status']=="shipped"){ ?>
              <div class="row">
                <div class="col-md-12">
                  <label class="my_label">Delivery Status</label>
                  <p><?php echo ucwords(str_replace("_", " ", $delivery_status['delivery_status'])); ?></p>
                </div>
                <div class="col-md-3">
                  <label class="my_label">Carrier</label>
                  <p><?php echo $delivery_status['carrier_name']; ?></p>
                </div>
                <div class="col-md-3">
                  <label class="my_label">Shipment Date</label>
                  <p><?php echo date("Y-m-d",strtotime($delivery_status['shipment_date'])); ?></p>
                </div>
                <div class="col-md-3">
                  <label class="my_label">Tracking No</label>
                  <p><?php echo $delivery_status['tracking_no']; ?></p>
                </div>
                <div class="col-md-3">
                  <label class="my_label">Tracking Url</label>
                  <p><?php echo $delivery_status['tracking_url']; ?></p>
                </div>
              </div>
            <?php }else if(count($delivery_status) > 0 && $delivery_status['delivery_status']=="delivered"){ ?>
              <div class="row">
                <div class="col-md-12">
                  <label class="my_label">Delivery Status</label>
                  <p><?php echo ucwords(str_replace("_", " ", $delivery_status['delivery_status'])); ?></p>
                </div>
                <div class="col-md-3">
                  <label class="my_label">Delivery Date</label>
                  <p><?php echo date("Y-m-d",strtotime($delivery_status['delivery_date'])); ?></p>
                </div>
                <div class="col-md-3">
                  <label class="my_label">Remarks</label>
                  <p><?php echo $delivery_status['delivery_remarks']; ?></p>
                </div>
              </div>
            <?php }else if(count($delivery_status) > 0 && $delivery_status['delivery_status']=="return"){ ?>
              <div class="row">
                <div class="col-md-12">
                  <label class="my_label">Delivery Status</label>
                  <p><?php echo ucwords(str_replace("_", " ", $delivery_status['delivery_status'])); ?></p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label class="my_label">Reason</label>
                  <p><?php echo $delivery_status['return_reason']; ?></p>
                </div>
              </div>
            <?php }else if($row['order_status']=="on_hold"){ ?>
              <div class="row">
                <div class="col-md-12">
                  <label class="my_label">Order Status</label>
                  <p><?php echo ucwords(str_replace("_", " ", $row['order_status'])); ?></p>
                </div>
                <div class="col-md-12">
                  <label class="my_label">Reason</label>
                  <p><?php echo $row['on_hold_reason']; ?></p>
                </div>
              </div>
            <?php }else if($row['order_status']=="cancelled"){ ?>
              <div class="row">
                <div class="col-md-12">
                  <label class="my_label">Order Status</label>
                  <p><?php echo ucwords(str_replace("_", " ", $row['order_status'])); ?></p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <label class="my_label">Reason</label>
                  <p><?php echo $row['cancelled_reason']; ?></p>
                </div>
              </div>
            <?php }else if($row['order_status']=="confirmed"){ ?>
              <div class="row">
                <div class="col-md-12">
                  <label class="my_label">Order Status</label>
                  <p><?php echo ucwords(str_replace("_", " ", $row['order_status'])); ?></p>
                </div>
              </div>
            <?php }else{
              echo 'f';
            }?>
          </div>
        </div>
      </div>
      <?php } ?>
      <div class="" id="demo_s" style="padding: 25px 15px; padding-bottom: 0%;">
        <div class="fff panel panel-bordered panel-dark shadow-none">
          <div class="panel-heading">
            <h1 class="panel-title"><?php echo translate('Order Settings');?></h1>
          </div>
          <div class="panel-body" style="padding-top: 1%;">
           <?php 
           $statuses = array("pending" => 1,"confirmed"=>1,"shipped"=>1,"delivered"=>1,"on_hold"=>1, "cancelled"=>1, "return"=>1);
           if(count($delivery_status)>0){
            foreach($statuses as $key => $status)
            {
              if($key!=trim($delivery_status['delivery_status'])){
                $statuses[$key] = 0;
              }else{
                break;
              }
            }
          }
          // echo "<pre/>".print_r($delivery_status,1);
          ?>
          <form method="post" action="<?php echo base_url("admin/sales/set_delivery_status/".$sales_id); ?>" id="form_set_delivery_status"> 
            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label class="my_label"><?php echo translate("Select Status"); ?></label>
                  <select class="form-control required" name="delivery_status" id="delivery_status" required="required">
                    <optgroup label="Order Status">
                      <option value="pending"><?php echo translate("Pending"); ?></option>
                      <option value="confirmed" <?php echo ($row['order_status']=="confirmed") ? "selected" : "";?>><?php echo translate("confirmed"); ?></option>
                      <option value="on_hold" <?php echo ($row['order_status']=="on_hold") ? "selected" : ""; ?>><?php echo translate("On Hold"); ?></option>
                      <option value="cancelled" <?php echo ($row['order_status']=="cancelled") ? "selected" : ""; ?>><?php echo translate("Cancelled"); ?></option>
                    </optgroup>
                    <?php if($row['order_status'] == "on_hold" || $row['order_status'] == "confirmed"){ ?>
                    <optgroup label="Delivery Status">
                      <option value="shipped" <?php echo (count($delivery_status)>0 && $delivery_status['delivery_status']=="shipped") ? "selected" : "";?>><?php echo translate("Shipped"); ?></option>
                      <option <?= ((count($delivery_status)>0)? ($delivery_status['delivery_status'] != "shipped" && $delivery_status['delivery_status'] != "delivered")? 'disabled="disabled"' : '' : 'disabled="disabled"');?> value="delivered" <?php echo (count($delivery_status)>0 && $delivery_status['delivery_status']=="delivered") ? "selected" : ""; ?>><?php echo translate("Delivered"); ?></option>
                      <option <?= ((count($delivery_status)>0)? ($delivery_status['delivery_status'] != "shipped" && $delivery_status['delivery_status'] != "delivered")? 'disabled="disabled"' : '' : 'disabled="disabled"');?> value="return" <?php echo (count($delivery_status)>0 &&  $delivery_status['delivery_status']=="return") ? "selected" : ""; ?>><?php echo translate("Return"); ?></option>
                    </optgroup>
                    <?php } ?>
                  </select>
                </div>
              </div>
            </div>
              <div class="row row_shipped_details" <?php echo (count($delivery_status) > 0 && $delivery_status['delivery_status']=="shipped") ? "style='display:block;' " : ""; ?>>
                <div class="col-md-3">
                  <div class="form-group">
                    <label class="my_label"><?php echo translate("select_carrrier"); ?></label>
                    <select class="form-control" id="carriers" name="carriers">
                     <option value=""><?php echo translate("-- Select --"); ?></option>
                     <?php 
                     foreach($carriers as $carrier){
                      ?>
                      <option value="<?php echo  $carrier["carrier_id"]; ?>" data-carrier-url="<?php echo  $carrier["url"]; ?>"><?php echo  $carrier["carrier_name"]; ?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label class="my_label"><?php echo translate("shipment_date"); ?></label>
                  <input type="date" class="form-control" id="shipment_date" name="shipment_date">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label class="my_label"><?php echo translate("tracking_no"); ?></label>
                  <input type="text" class="form-control" id="tracking_no" name="tracking_no">
                </div>
              </div>
              <div class="col-md-3">
                <div class="form-group">
                  <label class="my_label"><?php echo translate("tracking_url"); ?></label>
                  <input type="text" class="form-control" id="tracking_url" name="tracking_url">
                </div>
              </div>
            </div>
            <div class="row row_delivered" <?php echo (count($delivery_status) > 0 && $delivery_status['delivery_status']=="delivered") ? "style='display:block;' " : ""; ?>>
              <div class="col-md-4">
                <label class="my_label"><?php echo translate("delivery_date"); ?></label>
                <input type="date" class="form-control" id="delivery_date" name="delivery_date">
              </div>
              <div class="col-md-8">
                <div class="form-group">
                  <label class="my_label"><?php echo translate("remarks"); ?></label>
                  <input type="text" class="form-control" id="delivery_remarks" name="delivery_remarks">
                </div>
              </div>
            </div>
            <div class="row row_on_hold" <?php echo ($row['order_status']=="on_hold") ? "style='display:block;' " : ""; ?>>
              <div class="col-md-12">
                <label class="my_label"><?php echo translate("reason"); ?></label>
                <textarea class="form-control" lass="form-control" id="on_hold_reason" name="on_hold_reason" rows="5"></textarea>
              </div>
            </div>
            <div class="row row_cancelled" <?php echo ($row['order_status']=="cancelled") ? "style='display:block;' " : ""; ?>>
              <div class="col-md-12">
                <label class="my_label"><?php echo translate("reason"); ?></label>
                <textarea class="form-control" id="cancelled_reason"  name="cancelled_reason" rows="5"></textarea>
              </div>
            </div>
            <div class="row row_return" <?php echo (count($delivery_status) > 0 && $delivery_status['delivery_status']=="return") ? "style='display:block;' " : ""; ?>>
              <div class="col-md-4">
                <label class="my_label"><?php echo translate("Return Product Amount"); ?></label>
                <input type="number" class="form-control" name="return_amount" max=<?= ($row['grand_total'] - $row['shipping']);?>>
                <br>
              </div>
              <div class="col-md-12">
                <label class="my_label"><?php echo translate("reason"); ?></label>
                <textarea class="form-control" id="return_reason"  name="return_reason" rows="5"></textarea>
                <br>
              </div>
              <div class="col-md-2">
                <div class="form-check">
                  <input class="form-check-input" name="return_shipping" type="checkbox" value="1" id="returnShipping">
                  <label class="form-check-label" for="returnShipping">
                  <?php echo translate("Return Shipping"); ?>
                  </label>
                  <input type="hidden" name="shipping_amount" value="<?= $row['shipping'];?>">
                  <input type="hidden" name="buyer_id" value="<?= $row['buyer'];?>">
                </div>
                <br>
              </div>
            </div>
            <br />
            <div class="row">
              <div class="col-md-9"></div>
              <div class="col-md-3">
                <div class="btn_holder" style="float: right;">
                  <button class="btn btn-success" name="submit" id="submit" type="submit"><?php echo translate("submit"); ?></button>
                  <button class="btn btn-success"  name="submit_email" id="submit_email" type="submit" <?php echo (count($delivery_status) > 0 && ($delivery_status['delivery_status']=="shipped" || $delivery_status['delivery_status']=="deliverd" || $row['order_status']=="confirmed")) ? "style='display:inline-block;'" : ""; ?>>
                    <?php echo translate("submit & email"); ?></button>
                  </div>
                </div>
              </div> 
              <input type="hidden" value="<?php echo $this->security->get_csrf_hash(); ?>" name="<?php echo $this->security->get_csrf_token_name();?>">
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
<!--End Invoice Footer-->
<?php
}
?>
<script>
  $(document).ready(function(){

    $("#carriers").change(function(){
      var carrier_url = $("#carriers option:selected").attr("data-carrier-url");
      var val = $(this).val();
      if(val!=""){
        $("#tracking_no").val(carrier_url);
      }else{
        $("#tracking_no").val("");
      }
    });

    order_status_form_validation();

    $("#form_set_delivery_status").validate({
      errorElement: "em",
      errorClass: "invalid",
      ignore: ".ignore",
      errorPlacement: function(error, element) {
        $(element).addClass("border");
      },
      submitHandler: function(form) {
        form.submit();
      }
    });
    
    $( ".my_tooltip" ).tooltip();
    function order_status_form_validation()
    {
      $(".row_shipped_details,.row_delivered,.row_on_hold,.row_cancelled, .row_return, #submit_email").hide();
      $("#carriers , #shipment_date , #delivery_date , #delivery_remarks , #on_hold_reason , #cancelled_reason, #return_reason").removeClass("required");
      var delivery_status = $("#delivery_status").val();
      if(delivery_status==""){
        $(this).addClass("required");
      }
      if(delivery_status=="shipped"){
        $(".row_shipped_details  , #submit_email").show();
        $("#carriers , #shipment_date").addClass("required");
      }else if(delivery_status=="delivered"){
        $(".row_delivered  , #submit_email").show();
        $("#delivery_date , #delivery_remarks").addClass("required");
      }else if(delivery_status=="on_hold"){
        $(".row_on_hold").show();
        $("#on_hold_reason").addClass("required");
      }else if(delivery_status=="cancelled"){
        $(".row_cancelled").show();
        $("#cancelled_reason").addClass("required");
      }else if(delivery_status=="return"){
        $(".row_return").show();
        $("#return_reason").addClass("required");
      }else if(delivery_status=="confirmed"){
        $("#submit_email").show();
      }
    }

    $("#delivery_status").change(function(e){
     order_status_form_validation();
   });
  });
  var base_url = '<?php echo base_url(); ?>'
  var user_type = 'admin';
  var module = 'sales';
  var list_cont_func = 'list';
  var dlt_cont_func = 'delete';
  var this_page = false;
  var this_page  = false;
</script>