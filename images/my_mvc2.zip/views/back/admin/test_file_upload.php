<form action="<?php echo base_url('admin/test'); ?>" method="post" enctype="multipart/form-data">
		<input type="file" name="file">
		<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
		<button type="submit">submit</button>
</form>