<style type="text/css">
	.btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .tbl_blog_category thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div id="content-container">
	<div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('manage_blog_categories');?></h4>
        </div>
        <div class="col-md-4">
          	<button class="btn btn-green btn-labeled fa fa-plus-circle pull-right mar-rgt" onclick="ajax_modal('add','<?php echo translate('add_blog_category'); ?>','<?php echo translate('successfully_added!'); ?>','blog_category_add','')">
				<?php echo translate('create_blog_category');?>
	      	</button>
        </div>
    </div>
	<table id="demo-table" class="table table-striped table-bordered tbl_blog_category"  data-pagination="true" data-ignorecol="0,2"  data-show-columns="false" data-search="true" >
		<thead>
			<tr>
				<th data-width="70"><?php echo translate('sno');?></th>
				<th><?php echo translate('name');?></th>
				<th class="text-center" data-width="150"><?php echo translate('options');?></th>
			</tr>
		</thead>
		<tbody>
			<?php
				$i = 0;
            	foreach($all_categories as $row){
            	$i++;
			?>
			<tr>
				<td><?php echo $i; ?></td>
				<td><?php echo $row['name']; ?></td>
				<td class="text-center btn_product_action">
					<a data-toggle="tooltip" onclick="ajax_modal('edit','<?php echo translate('edit_blog_category'); ?>','<?php echo translate('successfully_edited!'); ?>','blog_category_edit','<?php echo $row['blog_category_id']; ?>')" data-original-title="Edit" data-container="body">
							<i class="ad_gray fa fa-wrench"></i>
                    </a>
					<a onclick="delete_record('<?php echo base_url("admin/blog_category/delete/".$row['blog_category_id']); ?>')">
						<i class="ad_red fa fa-trash"></i>
                    </a>
				</td>
			</tr>
            <?php
            	}
			?>
		</tbody>
	</table>
</div>
<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'blog_category';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
</script>

