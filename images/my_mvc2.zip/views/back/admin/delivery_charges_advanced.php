<style type="text/css">
    .table_delivery_charges th{
        font-size: 14px;
    }
    .table_delivery_charges td{
        font-size: 12px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Advanced Delivery Charges');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/delivery_charges/add_advanced'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-plus"></i>&nbsp;
                    <?php echo translate('add_delivery_charges_advanced');?>
            </a>
        </div>
    </div>
    <div class="pd-1">
        <table class="table table-hovered table-bordered table_delivery_charges">
            <thead>
                <th><?php echo translate("title");  ?></th>
                <th><?php echo translate("country");  ?></th>
                <th><?php echo translate("Shipping Charges");  ?></th>
                <th align="center"><?php echo translate("action");  ?></th>
            </thead>
            <tbody>
                <?php
                    if($advanced_delivery_charges){
                    foreach($advanced_delivery_charges as $advanced_delivery_charge){
                ?>
                    <tr>
                        <td><?php echo $advanced_delivery_charge['title'];?></td>
                        <td><?php echo $advanced_delivery_charge['country_name'];?></td>
                        <td><?php echo $advanced_delivery_charge['base_cost'];?></td>
                        <td align="center">
                            <div class='btn_product_action'>
                                <a href="<?php echo base_url('admin/delivery_charges/edit_advanced/'.$advanced_delivery_charge['advanced_delivery_charges_id']); ?>">
                                    <i class='ad_red fa fa-edit'></i>
                                </a>
                                <a onclick ="delete_record('<?php echo base_url('admin/delivery_charges/delete_advanced/'.$advanced_delivery_charge['advanced_delivery_charges_id']); ?>')">
                                    <i class='ad_red fa fa-trash'></i>
                                </a>
                            </div>
                        </td>
                    </tr>
                 <?php }} else{ ?>
                    <tr>
                        <td colspan="7" align="center"><?php echo translate('no_data_are_available'); ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    var base_url = '<?php echo base_url(); ?>';
    // var timer = '<?php //$this->benchmark->mark_time(); ?>';
    var user_type = 'admin';
    var module = 'delivery_charges';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->