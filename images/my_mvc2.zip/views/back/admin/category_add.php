<div>
    <?php
		echo form_open(base_url() . 'admin/category/do_add/', array(
			'class' => 'form-horizontal',
			'method' => 'post',
			'id' => 'category_add',
			'enctype' => 'multipart/form-data'
		));
	?>
        <div class="">
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-1">
                	<?php echo translate('category_name');?>
                </label>
                <div class="col-md-12">
                    <input type="text" name="category_name" id="demo-hor-1" 
                    	class="form-control required" placeholder="<?php echo translate('category_name');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-1">
                	<?php echo translate('meta_keywords');?>
                </label>
                <div class="col-md-12">
                    <input type="text" name="meta_keyword" id="demo-hor-1" 
                    	class="form-control" placeholder="<?php echo translate('meta_keywords');?>" >
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-1">
                    <?php echo translate('meta_description');?>
                </label>
                <div class="col-md-12">
                    <textarea class="form-control" name="meta_description" rows="5"></textarea>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-2">
                    <?php echo translate('category_catelog');?>
                </label>
                <div class="col-md-12">
                    <span class="pull-left btn btn-default btn-file my-btn-file">
                        <?php echo translate('select_category_catelog');?>
                        <input type="file" name="pdf" id='pdfInp' accept=".pdf">
                    </span>
                  </div>
            </div>
			<div class="form-group">
	            <label class="col-md-4 my_label" for="demo-hor-2">
	                <?php echo translate('preview');?>
	            </label>
	            <div class="col-md-12">
	            	<span id='wrap' class="pull-left pdf_preview" >
	                    
	                </span>
	        	</div>
            </div>
			<div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-2">
                    <?php echo translate('category_banner');?>
                </label>
                <div class="col-md-12">
                    <span class="pull-left btn btn-default btn-file my-btn-file">
                        <?php echo translate('select_category_banner');?>
                        <input type="file" name="img" id='imgInp' accept="image">
                    </span>
                  </div>
            </div>
            <div class="form-group">
	            <label class="col-md-4 my_label" for="demo-hor-2">
	                <?php echo translate('preview');?>
	            </label>
	            <div class="col-md-12">
	            	<span id='wrap' class="pull-left" >
	                    <img src="<?php echo base_url(); ?>uploads/category_image/default.jpg" 
	                        width="30%" id='blah' class="thumbnail">
	                </span>
	        	</div>
            </div>
        </div>
	</form>
</div>

<script>
	// pull-left btn btn-default btn-file
	$(document).ready(function() {
		$("form").submit(function(e){
			event.preventDefault();
		});
	});
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
	
			reader.onload = function(e) {
				$('#wrap').hide('fast');
				$('#blah').attr('src', e.target.result);
				$('#wrap').show('fast');
			}
			reader.readAsDataURL(input.files[0]);
		}
	}

	$("#pdfInp").change(function() {
		var value = this.value;
		console.log(value.split("\\"));
		$('.pdf_preview').html(`
		    <span style="font-size: 14px;">${value.split('\\')[2]}</span>
		    <img src="<?php echo base_url(); ?>uploads/category_catelog/default.png" 
		    width="15%" id='blah' class="thumbnail">
		`);
	});
	
	$("#imgInp").change(function() {
		readURL(this);
	});
</script>