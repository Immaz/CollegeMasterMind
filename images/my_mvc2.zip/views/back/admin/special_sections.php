<style type="text/css">
#table1,
#table2 {
 table-layout: fixed;
}

.advance-heading {
 font-size: 25px;
 font-weight: 600;
 font-family: sans-serif;
}

.header_logo {
 width: 100px;
}

#table1 tr td {
 text-align: center;
 vertical-align: middle;
}

input[type='file'] {
 border: 1px solid #ccc;
 padding: 3px;
 border-radius: .25rem;
}

#btn_map {
 float: right;
}

.panel-content-holder {
 padding-top: 0;
}

.download_img_runtime .list-group-item p {
 color: red;
 font-style: italic;
 margin: 0px;
 font-size: 14px;
}

.download_img_runtime .list-group-item {
 display: flex;
}

.panel .panel-title,
.panel .panel-body {
 position: relative;
 display: block;
 padding: 10px 15px;
 margin-bottom: -1px;
 line-height: 1;
 border: none !important;
}

.panel {
 border-color: #e9e9e9;
}

.collapse_btn i.fa.fa-plus {
 display: none;
}

.collapse_btn i.fa.fa-minus {
 display: inline-block;
}

.collapse_btn.collapsed i.fa.fa-plus {
 display: inline-block;
}

.collapse_btn.collapsed i.fa.fa-minus {
 display: none;
}

.img-preview {
 max-height: 65px;
}
</style>
<div id="content-container">
 <div class="row row_page_heading">
  <div class="col-md-8">
   <h4 class="page-header text-overflow"><?php echo translate('special_sections');?></h4>
  </div>
 </div>
 <div class="row">
  <div class="col-md-12 pd-1">
   <div class="tab-pane fade in active">
    <div class="details-wrap">
     <?php if($sections > 0) {?>
     <div class="panel-group" id="accordion">
      <?php for($i = 0; $i < $sections; $i++){ $j = $i + 1; ?>
      <div class="panel">
       <div class="panel-heading">
        <h4 class="panel-title bg-info">
         <span class="heading-info">
          <i class="fa fa-cogs"></i>
          <?php echo translate("section_").$j; ?>
         </span>
         <a class="pull-right collapse_btn collapsed" data-toggle="collapse" data-parent="#accordion"
          href="#collapse_<?php echo $j; ?>"> <i class="fa fa-plus"></i><i class="fa fa-minus"></i></a>
        </h4>
       </div>
       <div id="collapse_<?php echo $j; ?>" class="panel-collapse collapse">
        <div class="panel-body">
         <form method="post" enctype="multipart/form-data" id="section_<?php echo $j; ?>"
          action="<?php echo base_url('admin/special_sections'); ?>">
          <div class="row mt-3 d-flex align-items-center">
           <div class="col-md-8">
            <div class="form-group">
             <label class="my_label"><?php echo translate("top_banner"); ?></label>
             <input type="file" name="top_banner" class="form-control files top_banner" data-id="<?php echo $j; ?>"
             accept="image/jpeg, image/png" required="required">
             <p>Please Upload File In Size 1170x152</p>
            </div>
           </div>
           <div
            class="col-md-4 top_banner_preview_<?php echo $j; ?> <?php echo (isset($section_data[$j]) && !empty($section_data[$j]->top_banner)) ? "" : "hide" ?>">
            <div class="form-group">
             <label class="my_label"><?php echo translate("preview"); ?></label><br>
             <img class="img-thumbnail img-preview"
              <?php echo (isset($section_data[$j]) && !empty($section_data[$j]->top_banner)) ? "src='".base_url('uploads/special_sections/top_banner/' . $section_data[$j]->top_banner)."'" : "" ?>>
            </div>
           </div>
          </div>
          <div class="row mt-3 d-flex align-items-center">
           <div class="col-md-8">
            <div class="form-group">
             <label class="my_label"><?php echo translate("featured_banner"); ?></label>
             <input type="file" name="featured_banner" class="form-control files featured_banner"
              data-id="<?php echo $j; ?>" accept="image/jpeg, image/png" required="required">
              <p>Please Upload File In Size 800x617</p>
            </div>
           </div>
           <div
            class="col-md-4 featured_banner_preview_<?php echo $j; ?> <?php echo (isset($section_data[$j]) && !empty($section_data[$j]->featured_banner)) ? "" : "hide" ?>">
            <div class="form-group">
             <label class="my_label"><?php echo translate("preview"); ?></label><br>
             <img class="img-thumbnail img-preview"
              <?php echo (isset($section_data[$j]) && !empty($section_data[$j]->featured_banner)) ? "src='".base_url('uploads/special_sections/featured_banner/' . $section_data[$j]->featured_banner)."'" : "" ?>>
            </div>
           </div>
          </div>
          <div class="row mt-3 d-flex align-items-center">
           <div class="col-md-4 hide">
            <div class="form-group">
             <label class="my_label"><?php echo translate("title"); ?></label>
             <input type="text" name="title" class="title form-control" maxlength="100"
              value="<?php echo (isset($section_data[$j])) ? $section_data[$j]->title : "" ?>">
            </div>
           </div>
           <div class="col-md-4">
            <div class="form-group">
             <label class="my_label"><?php echo translate("third_sub_category"); ?></label>
             <select class="form-control third_sub_category" name="third_sub_category">
              <option value="0"><?php echo translate("-- select --"); ?></option>
              <?php if(!empty($third_sub_categories)){?>
              <?php foreach ($third_sub_categories as $key => $value) {?>
              <?php $selected = (isset($section_data[$j]) && $value['third_sub_category_id'] == $section_data[$j]->third_sub_category) ? "selected='selected'" : "" ?>
              <option <?php echo $selected; ?> value="<?php echo $value['third_sub_category_id'];?>">
               <?php echo $value['third_sub_ctg_name'];?>
              </option>
              <?php } ?>
              <?php } ?>
             </select>
            </div>
           </div>
           <div class="col-md-4">
            <div class="form-group">
             <label class="my_label"><?php echo translate("minimum_discount"); ?> (%)</label>
             <input type="number" name="discount" class="discount form-control"
              value="<?php echo (isset($section_data[$j])) ? $section_data[$j]->discount : "0" ?>" min="0" max="100"
              onkeyup=minMax(this)>
            </div>
           </div>
           <div class="col-md-4">
            <div class="form-group">
             <label class="my_label"><?php echo translate("active"); ?></label><br>
             <input id="active_<?php echo $j; ?>" value="1" name="active" class="active form-control" type="checkbox"
              data-id="<?php echo $j; ?>"
              <?php echo (isset($section_data[$j]) && $section_data[$j]->active == 1) ? "checked='checked'" : "" ?> />
            </div>
           </div>
          </div>
          <div class="row">
           <div class="col-md-12">
            <button class="btn btn-green btn-md update pull-right" name="update_<?php echo $j; ?>"
             id="update_<?php echo $j; ?>" value="<?php echo $j; ?>"><?php echo translate("update"); ?></button>
           </div>
          </div>
          <input type="hidden" name="id" value="<?php echo $j; ?>">
          <input type="hidden" value="<?php echo $this->security->get_csrf_hash() ?>"
           name="<?php echo $this->security->get_csrf_token_name() ?>">
         </form>
        </div>
       </div>
      </div>
      <hr>
      <?php } ?>
     </div>
     <?php } ?>
    </div>
   </div>
  </div>
 </div>
</div>
<script type="text/javascript">
function minMax(el) {
 if (el.value != "") {
  if (parseInt(el.value) < parseInt(el.min)) {
   el.value = el.min;
  }
  if (parseInt(el.value) > parseInt(el.max)) {
   el.value = el.max;
  }
 } else {
  el.value = el.min;
 }
}
$(document).ready(function() {
 $('.top_banner').change(function() {
  let id = $(this).attr('data-id');
  let preview_sel = '.top_banner_preview_' + id;
  var file = this.files[0];
  if (file) {
   var reader = new FileReader();
   reader.onload = function(event) {
    $(preview_sel).removeClass('hide');
    $(preview_sel + ' .img-preview').attr('src', event.target.result);
   };
   reader.readAsDataURL(file);
  }
 });
 $('.featured_banner').change(function() {
  let id = $(this).attr('data-id');
  let preview_sel = '.featured_banner_preview_' + id;
  var file = this.files[0];
  if (file) {
   var reader = new FileReader();
   reader.onload = function(event) {
    $(preview_sel).removeClass('hide');
    $(preview_sel + ' .img-preview').attr('src', event.target.result);
   };
   reader.readAsDataURL(file);
  }
 });
 $(".active").each(function() {
  new Switchery(document.getElementById('active_' + $(this).data('id')), {
   color: 'rgb(100, 189, 99)',
   secondaryColor: '#cc2424',
   jackSecondaryColor: '#c8ff77'
  });
 });
 $(".update").click(function(e) {
  let id = $(this).val();
  let section_id = "#section_" + id;
  let third_sub_category = $(section_id + ' .third_sub_category').val();
  let discount = $(section_id + ' .discount').val();
  if (third_sub_category <= 0 && discount <= 0) {
   Swal.fire({
    title: 'Fill Third Sub Category or Minimum Discount',
    text: "",
    type: 'error',
    showConfirmButton: true,
    confirmButtonColor: '#3085d6',
   });
   return false;
  }
  Swal.fire({
   title: 'Are you sure?',
   text: "",
   type: 'warning',
   showCancelButton: true,
   confirmButtonColor: '#3085d6',
   cancelButtonColor: '#d33',
   confirmButtonText: 'Edit Section ' + id
  }).then((result) => {
   if (result.value) {
    $(".overlay_holder1").show();
    $(section_id).submit();
   }
  });
  return false;
 });


 $(".update").click(function(e) {
  let id = $(this).val();
  let section_id = "#section_" + id;
  let top_banner = $(section_id + 'top_banner').val();
  let featured_banner = $(section_id + 'featured_banner').val();

  let third_sub_category = $(section_id + ' .third_sub_category').val();
  let discount = $(section_id + ' .discount').val();
  console.log(top_banner);
  if (top_banner.val() == "" || featured_banner.val() == "") {
   Swal.fire({
    title: 'Upload Top Banner or Featured Banner',
    text: "",
    type: 'error',
    showConfirmButton: true,
    confirmButtonColor: '#3085d6',
   });
   return false;
  }
  if (third_sub_category <= 0 && discount <= 0) {
   Swal.fire({
    title: 'Fill Third Sub Category or Minimum Discount',
    text: "",
    type: 'error',
    showConfirmButton: true,
    confirmButtonColor: '#3085d6',
   });
   return false;
  }
  Swal.fire({
   title: 'Are you sure?',
   text: "",
   type: 'warning',
   showCancelButton: true,
   confirmButtonColor: '#3085d6',
   cancelButtonColor: '#d33',
   confirmButtonText: 'Edit Section ' + id
  }).then((result) => {
   if (result.value) {
    $(".overlay_holder1").show();
    $(section_id).submit();
   }
  });
  return false;
 });
});


var base_url = '<?php echo base_url(); ?>';
var user_type = 'admin';
var module = 'special_sections';
var list_cont_func = '';
var dlt_cont_func = '';

document.addEventListener('DOMContentLoaded', function(e) {})
</script>