<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('edit_role');?></h4>
        </div>
        <div class="col-md-4">
            <a class="btn btn-green pull-right" href="<?php echo base_url("admin/role"); ?>">
                <i class="fa fa-chevron-left"></i>&nbsp;
                <?php echo translate('back_to_roles');?>
            </a>
        </div>
    </div>
<?php
    foreach($role_data as $row){
?>
        
        <?php
            echo form_open(base_url() . 'admin/role/update/' . $row['role_id'], array(
                'class' => 'form-horizontal',
                'method' => 'post',
                'id' => 'role_edit'
            ));
        ?>
                <div class="form-group margin-top-15">
                    <label class="col-sm-4 control-label" for="demo-hor-1"><?php echo translate('name'); ?></label>
                    <div class="col-sm-6">
                        <input type="text" name="name" id="demo-hor-1" value="<?php echo $row['name']; ?>" class="form-control required" placeholder="<?php echo translate('name'); ?>" >
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="demo-hor-2"><?php echo translate('description'); ?></label>
                    <div class="col-sm-6">
                        <textarea name="description" class="form-control required" placeholder="<?php echo translate('description'); ?>" ><?php echo $row['description']; ?></textarea>
                    </div>
                </div><div class="form-group">
                    <label class="col-sm-4 control-label" for="demo-hor-3"><?php echo translate('permissions'); ?></label>
                    <div class="col-sm-6">
                        <table class="table table-striped">
                            <?php
                                $permission = json_decode($row['permission']);
                                foreach($all_permissions as $row1){
                                    if($row1['parent_status'] == 'parent'){
                            ?>
                            <tr>
                                <td>
                                     <?php echo ucfirst($row1['name']); ?>
                                </td>
                                <td>
                                    <input id="per_<?php echo $row1['permission_id']; ?>" class='sw2' type="checkbox" name="permission[]"  value="<?php echo $row1['permission_id']; ?>" data-id='<?php echo $row1['permission_id']; ?>' <?php if(in_array($row1['permission_id'],$permission)){ echo 'checked';} ?> />
                                </td>
                            </tr>
                            <?php
                                    }
                                }
                            ?>
                        </table>
                    </div>
                    
                </div>
            </div>
        
            <div class="panel-footer">
                <div class="row">
                    <div class="col-md-11">
                    </div>
                    <div class="col-md-1">
                        <span class="btn btn-green" onclick="form_submit('role_edit','<?php echo translate('successfully_edited!'); ?>')" >
                            <i class=" fa fa-upload"></i>
                                <?php echo translate('save');?>
                        </span>
                    </div>
                </div>
        </form>
<?php
    }
?>    
</div>
<script>
	$(document).ready(function() {
		$("form").submit(function(e){
			return false;
		});
		
		
		$(".sw2").each(function(){
			new Switchery(document.getElementById('per_'+$(this).data('id')), {color:'rgb(100, 189, 99)', secondaryColor: '#cc2424', jackSecondaryColor: '#c8ff77'});
		});
	});
</script>