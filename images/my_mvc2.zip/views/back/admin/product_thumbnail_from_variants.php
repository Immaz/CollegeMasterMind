<style type="text/css">
 .variant_imgs{
 	max-height: 80px;
 	margin: 5px; 
 	display: inline-block;
 }
 .selected{
 	box-shadow: 0px 0px 0px 4px #5d5c5c;
 }
 .variant_imgs:hover{
 	cursor: pointer;
 }
</style>
<div>
    <?php
    	echo form_open(base_url() . 'admin/product/thumbnail_from_variants/', array(
			'class' => 'form-horizontal',
			'method' => 'post',
			'id' => 'form_product_thumbnail_variants',
			'enctype' => 'multipart/form-data'
		));
	?>
        <div class="panel-body">
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-2">
                    <?php echo translate('Selet Thumbnail Image');?>
                </label>
            </div>
            <div class="form-group">
	            <div class="col-md-12">
		            	<?php
		            	 foreach($variant_images as $row){
		            	 	$variant_image_encodeds = $row['images'];
		            	 	if($variant_image_encodeds!=NULL && $variant_image_encodeds!=""){
		            	 		$variant_image_decodeds = json_decode($row['images'] , true);
		            	 		foreach($variant_image_decodeds as $variant_image_decoded){
						?>
						<img src="<?php echo $this->crud_model->get_image("product_variants",$variant_image_decoded); ?>"class="img-responsive variant_imgs" data-img-path = "<?php echo $variant_image_decoded; ?>">
		            	<?php 
		            			}
		            	 	}
		            	 }
		            	?>
	            </div>
            </div>
        </div>
        <input type="hidden" name="selected_vart_img" value="" id="selected_vart_img">
        <input type="hidden" value="<?php echo $product_id; ?>" id="product_id"  name="product_id">
	</form>
</div>

<script>
	// pull-left btn btn-default btn-file
	$(document).ready(function() {
		$(".variant_imgs").click(function(){
			$(".variant_imgs").removeClass("selected");
			$(this).addClass("selected");
			var img_path = $(this).attr("data-img-path");
			$("#selected_vart_img").val(img_path);
		});
		$("form").submit(function(e){
			event.preventDefault();
		});
	});
</script>