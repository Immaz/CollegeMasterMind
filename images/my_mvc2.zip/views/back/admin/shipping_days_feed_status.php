<style type="text/css">
    #demo-table thead tr th{
        font-size: 14px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('shipping_days_feed_status');?></h4>
        </div>
        <div class="col-md-4"></div>
    </div>
    <hr  style="margin: 0px 0px;" />
    <div class="tab-pane fade active in">
        <div class="panel-body" id="demo_s">
            <table id="demo-table" class="table table-striped table-bordered"  data-pagination="true"  data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next">
                <thead>
                    <tr>
                        <th class="text-left" width="40%"><?php echo translate('file_name');?></th>
                        <th class="text-left" width="20%"><?php echo translate('date');?></th>
                        <th class="text-left" width="10%"><?php echo translate('total_rows');?></th>
                        <th class="text-left" width="10%"><?php echo translate('proccessed');?></th>
                        <th class="text-left" width="10%"><?php echo translate('submitted');?></th>
                        <th class="text-left" width="10%"><?php echo translate('pending');?></th>
                        <th class="text-left" width="10%"><?php echo translate('errors');?></th>
                        <th class="text-left" width="10%"><?php echo translate('status');?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if($shipping_days_feed_files){
                    foreach($shipping_days_feed_files as $shipping_days_feed_file){
                    ?>
                    <tr>
                        <td><?php echo $shipping_days_feed_file['file_name']; ?></td>
                        <td><?php echo date("Y-m-d",strtotime($shipping_days_feed_file['created'])); ?></td>
                        <td><?php echo $shipping_days_feed_file['total_row']; ?></td>
                        <td><?php echo $shipping_days_feed_file['processed']; ?></td>
                         <td><span class="badge badge-success"><?php echo $shipping_days_feed_file['submitted']; ?></span></td>
                        <td><span class="badge badge-info"><?php echo $shipping_days_feed_file['pending_row']; ?></span></td>
                        <td><span class="badge badge-danger"><?php echo $shipping_days_feed_file['errors']; ?></span></td>
                        <td>Uploaded</td>
                    </tr>
                   <?php }} ?>
               </tbody>
            </table>
        </div>
    </div>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>'
    var user_type = 'admin';
    var module = 'brand';
    var list_cont_func = 'list';
    var dlt_cont_func = 'delete';
    var this_page  = false;
</script>

