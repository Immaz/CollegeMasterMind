<style type="text/css">
    .row_page_heading{
        display: flex;
        align-items: center;
        padding : 0px 15px 0px 15px;
        margin : 15px 0px 15px 0px;
    }
    .sub_category_digital_table_list .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .sub_category_digital_table_list .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .sub_category_digital_table_list thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('manage_sub_categories_(_digital_product_)');?></h4>
        </div>
        <div class="col-md-4">
                 <button class="btn btn-green btn-md  pull-right"  onclick="ajax_modal('add','<?php echo translate('add_sub-category_(_digital_product_)'); ?>','<?php echo translate('successfully_added!'); ?>','sub_category_add_digital','')">
                    <i class="fa fa-plus-circle"></i>&nbsp;
                    <?php echo translate('create_sub_category');?>
                </button>
        </div>
    </div>
	 <!-- LIST -->
      <div class="tab-pane fade active in" id="list" style="border:1px solid #ebebeb; border-radius:4px;">
            <div class="panel-body" id="demo_s">
                <table id="demo-table" class="table-bordered table table-striped sub_category_digital_table_list"  data-pagination="true" data-ignorecol="0,3"   data-search="true"  data-pagination-pre-text="Previous" data-pagination-next-text="Next" data-sort-name="sno" data-sort-order="desc">
                    <thead>
                        <tr>
                            <th data-width="50" data-field="sno"><?php echo translate('no');?></th>
                            <th><?php echo translate('name');?></th>
                            <th><?php echo translate('banner');?></th>
                            <th><?php echo translate('category');?></th>
                            <th class="text-center" data-width="100"><?php echo translate('options');?></th>
                        </tr>
                    </thead>                
                    <tbody >
                    <?php
                        $i=0;
                        foreach($all_sub_category as $row){
                            $i++;
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $row['sub_category_name']; ?></td>
                        <td>
                            <?php
                                if(file_exists('uploads/sub_category_image/'.$row['banner'])){
                            ?>
                            <img class="img-md" src="<?php echo base_url(); ?>uploads/sub_category_image/<?php echo $row['banner']; ?>" height="100px" />  
                            <?php
                                } else {
                            ?>
                            <img class="img-md" src="<?php echo base_url(); ?>uploads/sub_category_image/default.jpg" height="100px" />
                            <?php
                                }
                            ?>
                        </td>
                        <td><?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name'); ?></td>
                        <td class="text-center">
                            <div class="btn_product_action">
                                <a  data-toggle="tooltip" 
                                    onclick="ajax_modal('edit','<?php echo translate('edit_sub-category_(_digital_product_)'); ?>','<?php echo translate('successfully_edited!'); ?>','sub_category_edit_digital','<?php echo $row['sub_category_id']; ?>')" data-original-title="Edit" data-container="body">
                                    <i class="fa fa-wrench ad_gray"></i>
                                </a>
                                <a onclick="delete_record('<?php echo base_url('admin/sub_category_digital/delete/'.$row['sub_category_id']); ?>','<?php echo translate('really_want_to_delete_this?'); ?>')"  data-toggle="tooltip"  data-original-title="Delete" data-container="body">
                                    <i class="fa fa-trash ad_red"></i>
                                </a>
                            </div>
                         </td>
                    </tr>
                    <?php
                        }
                    ?>
                    </tbody>
                </table>
            </div>
            <div id='export-div'>
                <h1 style="display:none;"><?php echo translate('sub_category');?></h1>
                <table id="export-table" data-name='sub_category' data-orientation='p' style="display:none;">
                        <thead>
                            <tr>
                                <th><?php echo translate('no');?></th>
                                <th><?php echo translate('name');?></th>
                                <th><?php echo translate('category');?></th>
                            </tr>
                        </thead>
                            
                        <tbody >
                        <?php
                            $i = 0;
                            foreach($all_sub_category as $row){
                                $i++;
                        ?>
                        <tr>
                            <td><?php echo $i; ?></td>
                            <td><?php echo $row['sub_category_name']; ?></td>
                            <td><?php echo $this->crud_model->get_type_name_by_id('category',$row['category'],'category_name'); ?></td>
                        </tr>
                        <?php
                            }
                        ?>
                        </tbody>
                </table>
            </div>
      </div>
</div>
<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'sub_category_digital';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
    var this_page = false;
</script>
