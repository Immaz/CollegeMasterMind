<?php  $row =  $all_third_sub_category_data; ?> 
<div>
	<?php
        echo form_open(base_url() . 'admin/third_sub_category/update/' . $row->third_sub_category_id, array(
            'class' => 'form-horizontal',
            'method' => 'post',
            'id' => 'third_sub_category_edit',
            'enctype' => 'multipart/form-data'
        ));
    ?>
        <div class="panel-body">
            <div class="form-group">
                <label class="col-md-12 my_label"><?php echo translate('category');?></label>
                <div class="col-md-12">
                    <?php echo $this->crud_model->select_html('category','category','category_name','edit','demo-chosen-select required', $row->category_id ,'digital',NULL); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-inputemail">
                	<?php echo translate('sub category name');?>
                </label>
                <div class="col-sm-12">
                    <select class="demo-chosen-select required " name="sub_category" data-placeholder = "Choose a sub category" id="sub_category">
                        <?php 
                        $sub_categories = $this->crud_model->getSubCategoryByCategoryId($row->category_id);
                        foreach($sub_categories as $sub_category){
                            if($sub_category->sub_category_id == $row->sub_category_id)
                            {
                                $selected = "selected='selected'";
                            }else{
                                 $selected = "";
                            }
                        ?>
                        <option <?php echo $selected ; ?> value="<?php echo $sub_category->sub_category_id; ?>"><?php echo $sub_category->sub_category_name; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-inputemail">
                    <?php echo translate('third sub category name');?>
                </label>
                <div class="col-md-12">
                     <input type="text" name="third_sub_ctg_name" class="form-control required" value="<?php echo $row->third_sub_ctg_name; ?>">
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-2">
                    <?php echo translate('third sub category banner');?>
                </label>
                <div class="col-md-12">
                    <span class="pull-left btn btn-default btn-file my-btn-file">
                        <?php echo translate('select_sub_category_banner');?>
                        <input type="file" name="img" id='imgInp' accept="image">
                    </span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-2">
                    <?php echo translate('preview');?>
                </label>
                <div class="col-md-12">
                    <span id='wrap' class="pull-left" >
                        <?php
                            if($row->banner!="" && $row->banner !=NULL && file_exists('uploads/third_sub_category_image/'.$row->banner)){
                        ?>
                        <img src="<?php echo base_url(); ?>uploads/third_sub_category_image/<?php echo $row->banner; ?>" width="30%" id='blah' class="thumbnail"/>  
                        <?php
                            } else {
                        ?>
                        <img src="<?php echo base_url(); ?>uploads/third_sub_category_image/default.jpg" class="thumbnail" width="30%" id='blah' />
                        <?php
                            }
                        ?> 
                    </span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-12 my_label"><?php echo translate('brands');?></label>
                <div class="col-md-12">
                    <?php 
                        $selected_brand = json_decode($row->brand,true);
                        $index = 1;
                        foreach($selected_brand as $value){
                            $user_selected_options[$index] = $value;
                            $index ++;
                        }
                    ?>
                    <select name="brand[]" class="demo-cs-multiselect" id="brand" multiple="multiple">
                        <?php
                        foreach($brands as $brand){
                             if(array_search($brand->brand_id , $user_selected_options)){
                                $selected = "selected='selected'";
                             }else{
                                 $selected = "";
                             }
                        ?>
                        <option <?php echo $selected; ?> value="<?php echo $brand->brand_id; ?>">
                            <?php echo $brand->name; ?>
                        </option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
    </form>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $('.demo-chosen-select').chosen();
        $('.demo-cs-multiselect').chosen({width:'100%'});
         $("select[name='category']").change(function(){
            category = $(this).val();
            data = {
                category_id : category,
                '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>',
            }
            $.ajax({
                url : '<?php echo base_url('admin/get_sub_category_by_id'); ?>',
                type : 'POST',
                data : data,
                success : function(response){
                    var converted = JSON.parse(response);
                    var options = "";
                    if(converted){
                        for(var i = 0 ; i<converted.length; i++){
                            options += "<option value='"+converted[i].sub_category_id+"'>";
                                options += converted[i].sub_category_name;
                            options += "</option>";
                        }
                    }
                    $("#sub_category").append(options);
                    $(".demo-chosen-select").trigger("chosen:updated");
                }
            });
        });
    });


	$(document).ready(function() {
		$("form").submit(function(e){
			event.preventDefault();
		});
	});
	
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
	
			reader.onload = function(e) {
				$('#wrap').hide('fast');
				$('#blah').attr('src', e.target.result);
				$('#wrap').show('fast');
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
	
	$("#imgInp").change(function() {
		readURL(this);
	});
</script>	
