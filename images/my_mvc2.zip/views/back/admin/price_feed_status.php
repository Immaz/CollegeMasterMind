<style type="text/css">
    #demo-table thead tr th{
        font-size: 14px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('price_feed_status');?></h4>
        </div>
        <div class="col-md-4">
            <a class="btn btn-green pull-right" href="<?php echo base_url("admin/update_price_in_bulk/add"); ?>"><?php echo translate('update_price');?></a>
        </div>
    </div>
    <table id="demo-table" class="table table-striped table-bordered"  data-pagination="true"  data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next">
        <thead>
            <tr>
                <th class="text-left" width="40%"><?php echo translate('sno');?></th>
                <th class="text-left" width="40%"><?php echo translate('file_name');?></th>
                <th class="text-left" width="40%"><?php echo translate('vendor');?></th>
                <th class="text-left" width="20%"><?php echo translate('date');?></th>
                <th class="text-left" width="10%"><?php echo translate('total_records');?></th>
                <th class="text-left" width="10%"><?php echo translate('proccessed');?></th>
                <th class="text-left" width="10%"><?php echo translate('Updated');?></th>
                <th class="text-left" width="10%"><?php echo translate('pending');?></th>
                <th class="text-left" width="10%"><?php echo translate('ignored');?></th>
                <th class="text-left" width="10%"><?php echo translate('status');?></th>
            </tr>
        </thead>
        <tbody>
            <?php
            if($price_feed_files){
            $sno = 1;
            foreach($price_feed_files as $price_feed_file){
            ?>
            <tr>
                <td><?php echo $sno; ?></td>
                <td><?php echo $price_feed_file['file_name']; ?></td>
                <td><?php echo $price_feed_file['vendor_name']; ?></td>
                <td><?php echo date("Y-m-d",strtotime($price_feed_file['created'])); ?></td>
                <td><?php echo $price_feed_file['total_row']; ?></td>
                <td><?php echo $price_feed_file['processed']; ?></td>
                 <td><span class="badge badge-success"><?php echo $price_feed_file['submitted']; ?></span></td>
                <td><span class="badge badge-info"><?php echo $price_feed_file['pending_row']; ?></span></td>
                <td><span class="badge badge-danger"><?php echo $price_feed_file['errors']; ?></span></td>
                <td>
                    <?php 
                        if($price_feed_file['completed']==0){
                            echo "Pending";
                        }else if($price_feed_file['completed']==1){
                            echo "Completed";
                        }else if($price_feed_file['completed']==2){
                            echo "In Process";
                        }else{
                            echo "-";
                        }
                    ?>
                </td>
            </tr>
           <?php $sno++; }} ?>
       </tbody>
    </table>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>'
    var user_type = 'admin';
    var module = 'brand';
    var list_cont_func = 'list';
    var dlt_cont_func = 'delete';
    var this_page  = false;
</script>

