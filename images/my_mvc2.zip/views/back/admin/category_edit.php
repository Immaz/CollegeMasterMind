<?php
	foreach($category_data as $row){
?>
	<div class="tab-pane fade active in" id="edit">
		<?php
			echo form_open(base_url() . 'admin/category/update/' . $row['category_id'], array(
				'class' => 'form-horizontal',
				'method' => 'post',
				'id' => 'category_edit',
				'enctype' => 'multipart/form-data'
			));
		?>
			<div class="">
				<div class="form-group">
					<label class="col-sm-4 my_label" for="demo-hor-1">
                    	<?php echo translate('category_name');?>
          </label>
					<div class="col-sm-12">
						<input type="text" name="category_name"  
                        	value="<?php echo $row['category_name'];?>" id="demo-hor-1" 
                            	class="form-control required" placeholder="<?php echo translate('category_name');?>" >
					</div>
				</div>
			<div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-1">
                	<?php echo translate('meta_keywords');?>
                </label>
                <div class="col-md-12">
                    <input type="text" name="meta_keyword" id="demo-hor-1" 
                    	class="form-control" placeholder="<?php echo translate('meta_keywords');?>"  value="<?php echo $row['meta_keyword']; ?>">
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-1">
                	<?php echo translate('meta_description');?>
                </label>
                <div class="col-md-12">
                	<textarea class="form-control" name="meta_description" rows="5"><?php echo $row['meta_description']; ?></textarea>
                </div>
            </div>
			<div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-2">
                    <?php echo translate('category_catelog');?>
                </label>
                <div class="col-md-12">
                    <span class="pull-left btn btn-default btn-file my-btn-file">
                        <?php echo translate('select_category_catelog');?>
                        <input type="file" name="pdf" id='pdfInp' accept=".pdf">
                    </span>
                  </div>
            </div>
			<div class="form-group">
	            <label class="col-md-4 my_label" for="demo-hor-2">
	                <?php echo translate('preview');?>
	            </label>
	            <div class="col-md-12">
					<span id='wrap' class="pull-left pdf_preview" >
		                <?php
							if(file_exists('uploads/category_catelog/'.$row['catelog'])){
						?>
			                <?php echo $row['catelog']; ?>  
						<?php
							}
						?>
		            </span>
	        	</div>
            </div>
                <div class="form-group">
                    <label class="col-sm-4 my_label" for="demo-hor-2"><?php echo translate('category_banner');?></label>
                    <div class="col-sm-12">
                        <span class="pull-left btn btn-default btn-file my-btn-file">
                            <?php echo translate('select_category_banner');?>
                            <input type="file" name="img" id='imgInp' accept="image">
                        </span>
                    </div>
                </div>
	            <div class="form-group">
		            <label class="col-md-4 my_label" for="demo-hor-2">
		                <?php echo translate('preview');?>
		            </label>
		            <div class="col-md-12">
		            	 <span id='wrap' class="pull-left" >
		                    <?php
								if(file_exists('uploads/category_image/'.$row['banner'])){
							?>
							<img src="<?php echo base_url(); ?>uploads/category_image/<?php echo $row['banner']; ?>"   width="30%" id='blah' class="thumbnail" id='blah' />  
							<?php
								} else {
							?>
							<img src="<?php echo base_url(); ?>uploads/category_image/default.jpg" width="30%" id='blah' class="thumbnail" id='blah' />
							<?php
								}
							?> 
		                </span>
		        	</div>
	            </div>
			</div>
		</form>
	</div>
<?php
	}
?>

<script>
	$(document).ready(function() {
	    $("form").submit(function(e) {
	        return false;
	    });
	});
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
	
			reader.onload = function(e) {
				$('#wrap').hide('fast');
				$('#blah').attr('src', e.target.result);
				$('#wrap').show('fast');
			}
			reader.readAsDataURL(input.files[0]);
		}
	}

	$("#pdfInp").change(function() {
		var value = this.value;
		console.log(value.split("\\"));
		$('.pdf_preview').html(`
		    <span style="font-size: 14px;">${value.split('\\')[2]}</span>
		    <img src="<?php echo base_url(); ?>uploads/category_catelog/default.png" 
		    width="15%" id='blah' class="thumbnail">
		`);
	});
	
	$("#imgInp").change(function() {
		readURL(this);
	});
	
</script>