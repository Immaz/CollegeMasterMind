<style type="text/css">
    .panel_product_list .panel-body{
        padding-top: 0px;
    }
    .product_list_table .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .product_list_table .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .product_list_table thead tr th{
        font-size: 14px;
        padding: 5px;
    }
    .variant_img{
        max-height: 50px;
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate(' add_stock_cjdropshipping ');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url("admin/update_stock_in_bulk"); ?>" class="btn btn-green btn-md pull-right"><?php echo translate('back_to_list');?></a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 pd-1">
            <form id="update_stock_in_bulk" method="post" action="<?php echo base_url('admin/update_stock_in_bulk/add'); ?>" enctype="multipart/form-data">
                <div class="row">
                    <!-- <div class="col-md-4">
                        <label class="my_label"><?php // echo translate("select vendor");  ?></label>
                        <select class="form-control required" name="vendor">
                            <option value="">-- Select --</option>
                            <?php 
                             // foreach($vendors as $vendor){
                            ?>
                                <option value="<?php // echo $vendor['vendor_id']; ?>"><?php // echo $vendor['name']; ?></option>
                            <?php // } ?>
                        </select>
                    </div> -->
                    <div class="col-md-4">
                        <label class="my_label"><?php echo translate("file");  ?></label>
                        <input type="file" class="form-control" name="file" accept=".csv">
                    </div>
                    <div class="col-md-4">
                        <label class="my_label" style="visibility: hidden;"><?php echo translate("dummy");  ?></label><br />
                        <button type="submit" class="btn btn-success btn-md btn_download" name="btn_download">
                            <?php echo translate("download"); ?>
                            <i class="fa fa-download"></i>
                        </button>
                        <button type="submit" class="btn btn-success btn-md btn_upload" name="btn_upload">
                            <?php echo translate("upload"); ?>
                            <i class="fa fa-upload"></i>
                        </button>
                    </div>
                </div>
        <input type="hidden" value="<?php echo $this->security->get_csrf_hash(); ?>" name="<?php echo $this->security->get_csrf_token_name(); ?>">
        <input type="hidden" name="action_type" value="" id="action_type">
    </form>
        </div>
    </div>
    
</div>
<script>
    var base_url = '<?php echo base_url(); ?>';
	var user_type = 'admin';
	var module = 'update_stock_in_bulk';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
    $(document).ready(function(){
        $(".btn_download").click(function(e){
            e.preventDefault();
            if(form_validation("update_stock_in_bulk")){
                $("#action_type").val("download");
                $("#update_stock_in_bulk").submit();
            }
        });
        $(".btn_upload").click(function(e){
            e.preventDefault();
            if(form_validation("update_stock_in_bulk")){
                $("#action_type").val("upload");
                $("#update_stock_in_bulk").submit();
            }
        });
    });
</script>

