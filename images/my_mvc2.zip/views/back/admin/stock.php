<style type="text/css">
    .row_page_heading{
        display: flex;
        align-items: center;
        padding : 0px 15px 0px 15px;
        margin : 15px 0px 15px 0px;
    }
    .stock_list_table thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div id="content-container">
	<div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('manage_product_stock');?></h4>
        </div>
        <div class="col-md-4">
    		<button class="btn btn-dark btn-mg pull-right" onclick="ajax_modal('destroy','<?php echo translate('destroy_product_entry'); ?>','<?php echo translate('add_stock_entry_taken!'); ?>','stock_destroy','')">
                	<i class="fa fa-minus-square"></i>&nbsp;
                    <?php echo translate('destroy');?>
            </button>           
			<button class="btn btn-green btn-mg  pull-right mar-rgt" onclick="ajax_modal('add','<?php echo translate('add_product_stock'); ?>','<?php echo translate('destroy_entry_taken!'); ?>', 'stock_add', '' )">
					<i class="fa fa-plus-circle"></i>&nbsp;
					<?php echo translate('create_stock');?>
             </button>
        </div>
    </div>
	<!-- LIST -->
	<div class="tab-pane fade active in" id="list" style="border:1px solid #ebebeb; border-radius:4px;">
        <div class="panel-body" id="demo_s">        
            <table id="demo-table" class="stock_list_table table-bordered table table-striped"  data-pagination="true"   data-search="true" data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next" data-sort-name="sno" data-sort-order="desc">
                <thead>
                    <tr>
                        <th style="width:4ex" data-field="sno"><?php echo translate('ID');?></th>
                        <th class="admin_panel_text"><?php echo translate('product_title');?></th>
                        <th class="admin_panel_text"><?php echo translate('entry_type');?></th>
                        <th class="admin_panel_text"><?php echo translate('quantity');?></th>
                        <th class="admin_panel_text"><?php echo translate('note');?></th>
                        <th class="admin_panel_text text-center"><?php echo translate('options');?></th>
                    </tr>
                </thead>                
                <tbody >
                <?php
                    foreach($all_stock as $row){
                ?>
                <tr>
                    <td><?php echo $row['stock_id']; ?></td>
                    <td><?php echo $this->crud_model->get_type_name_by_id('product',$row['product'],'title'); ?></td>
                    <td><?php echo $row['type']; ?></td>
                    <td><?php echo $row['quantity']; ?></td>
                    <td><?php echo $row['reason_note']; ?></td>
                    <td class="text-center">
                        <?php
                            if($row['type'] == 'add'){
                        ?>
                            <a onclick="delete_record('<?php echo base_url('admin/stock/delete/'.$row['stock_id']); ?>')" data-toggle="tooltip" data-original-title="Delete" data-container="body" style="cursor: pointer; font-size: 15px">
                                <i class="ad_red fa fa-trash"></i>
                            </a>
                        <?php
                            } else if($row['type'] == 'destroy') {
                        ?>
                            <a onclick="delete_record('<?php echo base_url('admin/stock/delete/'.$row['stock_id']); ?>')" data-toggle="tooltip"data-original-title="Delete" data-container="body" style="cursor: pointer; font-size: 15px">
                            <i class="ad_red fa fa-trash"></i>      
                            </a>
                        <?php
                            }
                        ?>
                    </td>
                </tr>
                <?php
                    }
                ?>
                </tbody>
            </table>
        </div>
        <div id='export-div' style="padding:40px;">
            <h1 id ='export-title' style="display:none;"><?php echo translate('product_stock'); ?></h1>
            <table id="export-table" class="table" data-name='product_stock' data-orientation='p' data-width='1500' style="display:none;">
                    <colgroup>
                        <col width="50">
                        <col width="150">
                        <col width="150">
                        <col width="150">
                        <col width="150">
                    </colgroup>
                    <thead>
                        <tr>
                            <th><?php echo translate('No');?></th>
                            <th><?php echo translate('product_title');?></th>
                            <th><?php echo translate('entry_type');?></th>
                            <th><?php echo translate('quantity');?></th>
                            <th><?php echo translate('note');?></th>
                        </tr>
                    </thead>
                 <tbody >
                    <?php
                        $i = 0;
                        foreach($all_stock as $row){
                            $i++;
                    ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo $this->crud_model->get_type_name_by_id('product',$row['product'],'title'); ?></td>
                        <td><?php echo $row['type']; ?></td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo $row['reason_note']; ?></td>
                        
                    </tr>
                    <?php
                        }
                    ?>
                    </tbody>
            </table>
        </div>
	</div>
</div>
<script>
	var base_url 		= '<?php echo base_url(); ?>'
	var user_type 		= 'admin';
	var module 			= 'stock';
	var list_cont_func  = 'list';
	var dlt_cont_func 	= 'delete';
    var this_page = false;
</script>


