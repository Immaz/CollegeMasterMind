    <?php
        echo form_open(base_url() . 'admin/sales/delivery_payment_set/' . $sale_id, array(
            'class' => 'form-horizontal',
            'method' => 'post',
            'id' => 'delivery_payment',
            'enctype' => 'multipart/form-data'
        ));
    ?>
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12">
                      <label class="my_label">
                        <?php echo translate('delivery_status'); ?></label>
                        <?php
                            $from = array('on_delivery','delivered');
                            echo $this->crud_model->select_html($from,'delivery_status','','edit','demo-chosen-select',$delivery_status);
                        ?>
                </div>
            </div>
            <br />
            <div class="row">
                <div class="col-md-12">
                       <label class="my_label"><?php echo translate('details_on_delivery_status'); ?></label>
                        <textarea class="form-control textarea" name="comment"><?php echo $comment; ?></textarea>
                </div>
            </div>
        </div>
    </form>
    <script type="text/javascript">

        $(document).ready(function() {
            $('.demo-chosen-select').chosen();
            $('.demo-cs-multiselect').chosen({width:'100%'});
            total();
        });

        function total(){
            var total = Number($('#quantity').val())*Number($('#rate').val());
            $('#total').val(total);
        }

        $(".totals").change(function(){
            total();
        });
    	
    	$(document).ready(function() {
    		$("form").submit(function(e){
    			event.preventDefault();
    		});
    	});
    </script>
    <div id="reserve"></div>

