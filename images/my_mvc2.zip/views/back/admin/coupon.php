<style type="text/css">
    
    .table_coupon_list .panel-body{
        padding-top: 0px;
    }
    .table_coupon_list .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .table_coupon_list .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .table_coupon_list thead tr th{
        font-size: 14px;
        padding: 5px;
    }
    .highlight{
		background-color: #E7F4FA;
	}
	.level2{
		margin-left: 5px;
		margin-bottom: 2px;
	}
	.create_coupon_msg{
		margin-left: 2%;
	}
</style>
<div id="content-container">
	<div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('manage_coupons');?></h4>
        </div>
        <div class="col-md-4">
            <button class="btn btn-green pull-right" onclick="ajax_modal('add','<?php echo translate('add_coupon'); ?>','<?php echo translate('successfully_added!');?>','coupon_add','')">
            		<i class="fa fa-plus-circle"></i>
					<?php echo translate('create_coupon');?>
			</button>
        </div>
    </div>
    <div class="row">
    	<div class="col-md-12 pd-1">
    		<table id="events-table" class="table table-striped table-bordered table_coupon_list"  data-pagination="true" data-show-refresh="false" data-ignorecol="0,4" data-show-toggle="false" data-show-columns="false" data-search="true" data-pagination-pre-text="Previous" data-pagination-next-text="Next">
			<thead>
				<tr>
					<th><?php echo translate('no');?></th>
					<th><?php echo translate('validity_till');?></th>
					<th><?php echo translate('title');?></th>
					<th><?php echo translate('discount_type');?></th>
					<th><?php echo translate('code');?></th>
					<th><?php echo translate('Amount');?></th>
					<th><?php echo translate('no_of_appy');?></th>
					<th><?php echo translate('status');?></th>
					<th><?php echo translate('unlimited');?></th>
					<th class="text-center"><?php echo translate('options');?></th>
				</tr>
			</thead>
				
			<tbody >
			<?php
				$i=0;
            	foreach($all_coupons as $row){
            		$i++;
            		// $specs = ($row['spec'])? json_decode($row['spec']) : '';
            		// $set_type = ucwords(str_replace("_", " ", $specs['set_type']));
            		// $type = json_decode($specs['type']);
			?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $row['till']; ?></td>
                    <td><?php echo $row['title']; ?></td>
                     <td><?php echo ucwords($row['discount_type']); ?></td>
                    <td><?php echo $row['code']; ?></td>
                   <td><?php echo currency($row['discount_value']); ?></td>
                   <td><?php echo $row['no_of_apply']; ?></td>
		            <td>
		                <input id="pub_<?php echo $row['coupon_id']; ?>" class='sw1' type="checkbox" data-id='<?php echo $row['coupon_id']; ?>' <?php if($row['status'] == 'ok'){ ?>checked<?php } ?> />
		            </td>
		            <td>
		            	<?php
		            		if($row['unlimited']==1){
		            			echo "<span class='label label-info'>Yes</span>";
		            		}else{
		            			echo "<span class='label label-warning'>No</span>";
		            		}
		            	?>
		            </td>
                    <td class="text-center">
                    	<div class="btn_product_action">
	                    	<a  data-toggle="tooltip"  onclick="ajax_modal('edit','<?php echo translate('edit_coupon'); ?>','<?php echo translate('successfully_edited!'); ?>','coupon_edit','<?php echo $row['coupon_id']; ?>')" 
	                                data-original-title="Edit" 
	                                    data-container="body">
	                                    <i class="fa fa-wrench ad_gray"></i>
	                        </a>
	                        <a onclick="delete_record('<?php echo base_url('admin/coupon/delete/'.$row['coupon_id']); ?>')"  data-toggle="tooltip" data-original-title="Delete" data-container="body">
                                       <i class="fa fa-trash ad_red"></i>
                       		 </a>
                    	</div>
                     </td>
                </tr>
            <?php
            	}
			?>
			</tbody>
		</table>
    	</div>
    </div>
	<div id="coupn"></div>
</div>
<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'coupon';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
	
	$(document).ready(function(){
		set_switchery();
	});

</script>

