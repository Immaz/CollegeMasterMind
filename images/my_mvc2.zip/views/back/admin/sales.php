<style type="text/css">
	/*.pending{
		background: #D2F3FF  !important;
	}
	.pending:hover{
		background: #9BD8F7 !important;
	}*/
	.btn_product_action  a{
        margin-left: 2px;
        font-size: 16px;
    }
    .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .sales_table .btn_product_action a{
        margin-left: 2px;
        font-size: 16px;
    }
    .sales_table .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
    .sales_table thead tr th{
        font-size: 14px;
        padding: 5px;
    }
</style>
<div id="content-container">
	<div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('manage_sales');?></h4>
        </div>
    </div>
    <div class="row">
    	<div class="col-md-12">
		    <table id="demo-table" class="table table-striped table-bordered sales_table" data-search="true">
				<thead>
		            <tr>
		                <th style="width:4ex"><?php echo translate('ID');?></th>
		                <th><?php echo translate('Invoice_no');?></th>
		                <th><?php echo translate('buyer');?></th>
		                <th><?php echo translate('date');?></th>
		                <th><?php echo translate('total');?></th>
		                <th width="200"><?php echo translate('payment_type');?></th>
		                <th><?php echo translate('delivery_status');?></th>
		                <th class="text-center"><?php echo translate('options');?></th>
		            </tr>
		        </thead>
		        <tbody>
		        <?php
		            $i = 0;
		            foreach($all_sales as $row){
		            $i++; 
		        ?>
		        <tr class="<?php if($row['viewed'] !== 'ok'){ echo 'pending'; } ?>" >
		            <td><?php echo $i; ?></td>
		            <td>#<?php echo $row['sale_code']; ?></td>
		            <td><?php if($row['buyer'] == 'guest'){ echo '<b class="text-info">Guest</b>';} else{echo $this->db->get_where('user', array('user_id' => $row['buyer']))->row()->username;} ?></td>
		            <td><?php echo date('d-m-Y',$row['sale_datetime']); ?></td>
		            <td><?php echo currency('','def').$this->cart->format_number($row['grand_total']); ?></td>
		            <td>
		            	<?php 
		            		$payment_type =  ucwords(str_replace("_", " ", $row["payment_type"]));
		            		if($row["payment_type"] == "authorize_net"){
		            			echo "Credit Card";
		            		}else if($row["payment_type"] == "bank_transfer"){
		            			echo "Bank Transfer";
		            		}
		            		else if($row["payment_type"] == "cash_on_delivery"){
		            			echo "Cash On Delivery";
		            		}else if($row["payment_type"] == "western_union_xpress_remitly"){
		            			echo "Western Union | Xpress | Remitly";
		            		}
		            		else if($row["payment_type"] == "quick_pay"){
		            			echo "Quick Pay";
		            		}
		            		else{
		            			echo "Paypal";
		            		}
		            		// if($payment_type=="Authorize Net"){
		            		// 	echo "Credit Card";
		            		// }else{
		            		// 	echo "Paypal";
		            		// }
						?>
		            </td>
		            <td>
						<?php echo (ucwords(str_replace("_", " ", $row['delivery_status']))!="" ? ucwords(str_replace("_", " ", $row['delivery_status'])) : ucwords(str_replace("_", " ", $row['order_status']))); ?>
					</td>
		            <td class="text-center">
			            <div class='btn_product_action'>

			            	<a class="my_tooltip"  title="View Full Invoice"  href="<?php echo base_url('admin/sales/view/'.$row['sale_id']); ?>">
			                    <i class="fa fa-file-text ad_gray"></i>
			                </a>
							
			                <a class="my_tooltip" title="Delete Sales" onclick="delete_record('<?php echo base_url('admin/sales/delete/'.$row['sale_id']); ?>')">
			                    <i class="fa fa-trash ad_red"></i>
			                </a>

			            </div>
		            </td>
		        </tr>
		        <?php
		            }
		        ?>
		        </tbody>
		    </table>
    	</div>
    </div>
</div>
<script>
	$(document).ready(function(){
		$( ".my_tooltip" ).tooltip();
	});
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'sales';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
</script>

