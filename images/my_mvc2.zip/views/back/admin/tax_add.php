<style type="text/css">
    .row{
        margin-bottom: 10px;
    }
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
</style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Add Tax');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/tax'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-backward"></i>&nbsp;
                    <?php echo translate('back_to_tax_list');?>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 pd-1">
             <?php
            echo form_open(base_url() . 'admin/tax/add/'.$product_id, array(
                'class' => 'form-horizontal',
                'method' => 'post',
                'id' => 'tax_add',
                'enctype' => 'multipart/form-data'
            ));
        ?>
        <div class="row">
            <div class="col-md-4">
                <label class="my_label"><?php echo translate("country"); ?></label>
                <select type="text" name="country" id="country" class="form-control required">
                    <option value=""><?php echo translate("-- Select --"); ?></option>
                    <?php
                        foreach ($countries as  $country) {
                    ?>
                    <option value="<?php echo $country['country_id']; ?>">
                        <?php echo $country['country_name']; ?></option>
                    <?php  } ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="my_label"><?php echo translate("state"); ?></label>
                <select type="text" name="state" id="state" class="form-control required">
                    <option value=""><?php echo translate("-- Select --"); ?></option>
                    <?php
                        foreach ($states as  $state) {
                    ?>
                    <option value="<?php echo $state['state_id']; ?>">
                        <?php echo $state['state_name']; ?></option>
                    <?php  } ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="my_label"><?php echo translate("Tax"); ?></label>
                <div class="input-group">
                    <span class="input-group-addon">%</span>
                    <input type="text" name="tax" id="tax" class="form-control required" maxlength="4">
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-2">
                <div class="my_checkbox_container">
                    <input type="checkbox" name="is_active" id="is_active" checked="checked">
                    <span class="my_checkmark"></span>
                    <label for="is_active" style="margin-left: 25px;">Active</label>
                </div>
             </div>
            <div class="col-md-10">
                <button class="btn btn-green btn-md pull-right" type="submit">
                    <?php echo translate("submit"); ?> 
                    <i class="fa fa-upload"></i>
                </button>
            </div>
        </div>
    </form>
        </div>
    </div>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>';
    var user_type = 'admin';
    var module = 'tax';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';
    var this_page = false;
    $(document).ready(function(){
        $("#tax_add").submit(function(e){
            if(form_validation("tax_add")){
                $(".overlay_holder1").show();
                $("#tax_add").submit();
            }else{
                e.preventDefault();
            }
        });
    });
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->