<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow">
                <?php echo translate('manage_ticket');?>
            </h4>
        </div>
    </div>
    <div class="col-md-12">
        <button class="btn btn-info btn-labeled fa fa-step-backward pull-right pro_list_btn" 
            style="display:none;"  onclick="ajax_set_list();  proceed('to_add');"><?php echo translate('back_to_ticket_list');?>
        </button> 
    </div>         
    <table id="demo-table" class="table table-striped table-bordered" data-pagination="true"  data-ignorecol="0,2"  data-search="true" >
        <thead>
            <tr>
                <th><?php echo translate('no');?></th>
                <th><?php echo translate('from');?></th>
                <th><?php echo translate('subject');?></th>
                <th><?php echo translate('date');?></th>
                <th class="text-center"><?php echo translate('options');?></th>
            </tr>
        </thead>
        <tbody >
        <?php
            $i = 0;
            foreach($tickets as $row){
                $i++;
        ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td>
                <?php 
                    $from = json_decode($row['from_where'],true);
                    if($from['type'] == 'user'){
                ?>
                <a class="btn btn-mint btn-xs btn-labeled fa fa-location-arrow" data-toggle="tooltip" 
                onclick="ajax_modal('view_user','<?php echo translate('view_profile'); ?>','<?php echo translate('successfully_viewed!'); ?>','user_view','<?php echo $from['id']; ?>')" data-original-title="View" data-container="body">
                    <?php echo $this->db->get_where('user',array('user_id'=>$from['id']))->row()->username; ?>
                </a>
                <?php   
                    } else {
                ?>
                    <?php echo translate('admin');?> 
                <?php
                    }
                ?>
            </td>
            <td>
                <?php echo $row['subject'] .'    '; ?>
                <?php
                    $num = $this->crud_model->ticket_unread_messages($row['ticket_id'],'admin');
                    if($num > 0){
                ?>
                <span class="btn btn-mint btn-xs btn-labeled " style="margin:2px; margin-left:10px;"><?php echo translate('new').' '.'('.' ';
                echo $num .' '.')'; ?></span>
                <?php
                    }
                ?>
            </td>
            <td><?php echo date('d M,Y h:i:s',$row['time']); ?></td>
            <td class="text-center">
                <a href="<?php echo base_url("admin/ticket/view/".$row['ticket_id']); ?>">
                    <i class="fa fa-location-arrow"></i>
                </a>
                <a onclick="delete_record('<?php echo base_url('admin/ticket/delete/'.$row['ticket_id']); ?>')">
                    <i class="fa fa-trash ad_red"></i>
                </a>
            </td>
        </tr>
        <?php
            }
        ?>
        </tbody>
    </table>
</div>
<span id="prod" style="display:none;"></span>
<script>
    var base_url = '<?php echo base_url(); ?>';
    var user_type = 'admin';
    var module = 'ticket';
    var list_cont_func = 'list';
    var dlt_cont_func = 'delete';
    var this_page = false;

    function proceed(type) {
        if (type == 'to_list') {
            $(".pro_list_btn").show();
        } else if (type == 'to_add') {
            $(".pro_list_btn").hide();
        }
    }
	function set_summer(){
        $('.summernotes').each(function() {
            var now = $(this);
            var h = now.data('height');
            var n = now.data('name');
            now.closest('div').append('<input type="hidden" class="val" name="'+n+'">');
            now.summernote({
                height: h,
                onChange: function() {
                    now.closest('div').find('.val').val(now.code());
                }
            });
            now.closest('div').find('.val').val(now.code());
        });
	}
</script>

