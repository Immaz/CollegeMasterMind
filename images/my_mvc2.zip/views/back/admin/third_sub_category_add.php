<div>
    <?php
		echo form_open(base_url() . 'admin/third_sub_category/do_add/', array(
			'class' => 'form-horizontal',
			'method' => 'post',
			'id' => 'third_sub_category_add',
			'enctype' => 'multipart/form-data'
		));
	?>
        <div class="panel-body">
            <div class="form-group">
                <label class="col-md-4 my_label"><?php echo translate('category');?></label>
                <div class="col-md-12">
                    <?php echo $this->crud_model->select_html('category','category','category_name','add','demo-chosen-select required ','','digital',NULL); ?>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-1">
                	<?php echo translate('sub category name');?>
                </label>
                <div class="col-md-12">
                    <select class="demo-chosen-select required " name="sub_category" data-placeholder = "Choose a sub category" id="sub_category">
                        <option value=""><?php echo translate('-- Select --');?></option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-1">
                    <?php echo translate('third sub category name');?>
                </label>
                <div class="col-md-12">
                     <input type="text" class="form-control required" name="third_sub_ctg_name">
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-12 my_label" for="demo-hor-2">
                    <?php echo translate('third sub category banner');?>
                </label>
                <div class="col-md-12">
                    <span class="pull-left btn btn-default btn-file my-btn-file">
                        <?php echo translate('select third sub category banner');?>
                        <input type="file" name="img" id='imgInp' accept="image">
                    </span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 my_label" for="demo-hor-2">
                    <?php echo translate('preview');?>
                </label>
                <div class="col-md-12">
                    <span id='wrap' class="pull-left" >
                        <img src="<?php echo base_url(); ?>uploads/sub_category_image/default.jpg" 
                            width="30%" id='blah' class="thumbnail"> 
                    </span>
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 my_label"><?php echo translate('brands');?></label>
                <div class="col-md-12">
                    <select name="brand[]" id="brand" class="form-control  demo-cs-multiselect" multiple="multiple">
                        <?php
                        if($brands){
                            foreach($brands as $brand){
                        ?>
                            <option value="<?php echo $brand->brand_id; ?>"><?php echo $brand->name; ?></option>
                         <?php }} ?>
                    </select>
                </div>
            </div>
        </div>
	</form>
</div>

<script>
	$(document).ready(function() {
          $('.demo-chosen-select').chosen();
          $('.demo-cs-multiselect').chosen({width:'100%'});

          $("select[name='category']").change(function(){
            category = $(this).val();
            data = {
                category_id : category,
                '<?php echo $this->security->get_csrf_token_name(); ?>' : '<?php echo $this->security->get_csrf_hash(); ?>',
            }
            $.ajax({
                url : '<?php echo base_url('admin/get_sub_category_by_id'); ?>',
                type : 'POST',
                data : data,
                success : function(response){
                    var converted = JSON.parse(response);
                    var options = "";
                    if(converted){
                        for(var i = 0 ; i<converted.length; i++){
                            options += "<option value='"+converted[i].sub_category_id+"'>";
                                options += converted[i].sub_category_name;
                            options += "</option>";
                        }
                    }
                    $("#sub_category").append(options);
                    $(".demo-chosen-select").trigger("chosen:updated");
                }
            });
        });
	});
	
	$(document).ready(function() {
		$("form").submit(function(e){
			event.preventDefault();
		});
	});
	function readURL(input) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
	
			reader.onload = function(e) {
				$('#wrap').hide('fast');
				$('#blah').attr('src', e.target.result);
				$('#wrap').show('fast');
			}
			reader.readAsDataURL(input.files[0]);
		}
	}
	
	$("#imgInp").change(function() {
		readURL(this);
	});
</script>


