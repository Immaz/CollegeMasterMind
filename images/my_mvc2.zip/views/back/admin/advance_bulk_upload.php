    <style type="text/css">
        #table1,
        #table2{
            table-layout: fixed;
        }
        .advance-heading{
            font-size: 25px;
            font-weight: 600;
            font-family: sans-serif;
        }
        .header_logo{
            width: 100px;
        }
        #table1 tr td
       {
            text-align: center;
            vertical-align: middle;
        }
        input[type='file']{
            border: 1px solid #ccc;
            padding: 3px;
            border-radius: .25rem;
        }
        #btn_map{
            float: right;
        }
        .panel-content-holder{
            padding-top: 0;
        }
        .download_img_runtime .list-group-item p{
            color: red;
            font-style: italic;
            margin:  0px;
            font-size: 14px;
         }
        .download_img_runtime .list-group-item{
            display: flex;
        }
    </style>
<div id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('product Bulk Upload');?></h4>
        </div>
    </div>
<div class="row">
    <div class="col-md-12 pd-1">
        <div class="tab-pane fade in active" >
            <div class="details-wrap">
                 <form method="post" enctype="multipart/form-data" id="advance_bulk_upload" action="<?php echo base_url('admin/advance_bulk_upload'); ?>">
                        <div class="list-group">
                            <div class="list-group-item bg-info">
                                <span class="heading-info">
                                    <i class="fa fa-cogs"></i>
                                    <?php echo translate("special_fields"); ?>
                                </span>
                            </div>
                            <div class="list-group-item">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="my_label"><?php echo translate("excel file"); ?></label>
                                            <br>
                                            <input type="file" name="file" id="excel_file" accept=".csv" class="form-control">
                                            <input type="hidden" value="0" id="is_excel_field_fetch">
                                        </div>
                                     </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="my_label">Select Category</label>
                                            <select class="form-control required excel_columns" id="category" name="category">
                                                <option value=""><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="my_label">Select Sub Category</label>
                                            <select class="form-control required excel_columns" id="sub_category" name="sub_category">
                                                <option value=""><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3 d-flex align-items-center row_first">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="my_label">Select Third Sub Category</label>
                                            <select class="form-control excel_columns" id="third_sub_category" name="third_sub_category">
                                                <option value=""><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="my_label">Select Brand</label>
                                            <select class="form-control required excel_columns" id="brand" name="brand">
                                                <option value=""><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="my_label">Select Product Group</label>
                                            <select class="form-control required excel_columns" id="product_group" name="product_group">
                                                <option value=""><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label class="my_label">Vendor</label>
                                                <select class="form-control required" id="vendor" name="vendor">
                                                    <option value=""><?php echo translate("-- select --"); ?></option>
                                                    <?php
                                                    foreach($vendors as $vendor){
                                                    ?>
                                                    <option value="<?php echo $vendor['vendor_id']; ?>"><?php echo $vendor['name']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>
                        <hr>
                        <div class="list-group">
                            <div class="list-group-item bg-info">
                                <span class="heading-info">
                                    <i class="fa fa-cogs"></i>
                                     <?php echo translate("Variants Details"); ?>
                                </span>
                            </div>
                            <div class="list-group-item">
                                <!-----file for excel excel variant selection--->
                                <div class="row">
                                     <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("UPC"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="upc" name="upc" >
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("ASIN"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="asin" name="asin" >
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Seller Sku"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="seller_sku" name="seller_sku">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Supplier Sku"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="supplier_sku" name="supplier_sku">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Gender"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="gender" name="gender">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Stock Status"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="stock_status" name="stock_status">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Cost"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="cost" name="cost">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Shipping Cost"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="shipping_cost" name="shipping_cost">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Total Cost"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="total_cost" name="total_cost">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Selling Price"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="selling_price" name="selling_price">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Discount"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="discount" name="discount">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Weight"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="weight" name="weight">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Product Name"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="product_name" name="product_name">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Collection"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="collection" name="collection">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Style"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="style" name="style">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("USE"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="use" name="use">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                     <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="my_label"><?php echo translate("Features"); ?></label>
                                            <select class="form-control excel_columns" id="features" name="features[]" multiple="multiple">
                                                <option value=""><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Material"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="material" name="material">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Construction"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="construction" name="construction">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Country Of Origin"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="country_of_origin" name="country_of_origin">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Primary Style"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="primary_style" name="primary_style">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="my_label"><?php echo translate("Color"); ?></label>
                                            <select class="form-control excel_columns" id="color" name="color[]" multiple="multiple">
                                                <option value=""><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Actual Size"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="actual_size" name="actual_size">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Shape"); ?>
                                            </label>
                                            <select class="form-control excel_columns" id="shape" name="shape">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Description"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="description" name="description">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="my_label"><?php echo translate("video"); ?></label>
                                            <select class="form-control excel_columns" id="video_link" name="video_link">
                                                <option value=""><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="my_label">
                                                <?php echo translate("Variants Multiple Images"); ?>
                                            </label>
                                            <select class="form-control required excel_columns" id="variants_mult_imgs" name="variants_mult_imgs[]" multiple="multiple">
                                                <option value="" selected="selected"><?php echo translate("-- select --"); ?></option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button class="btn btn-green btn-md" name="map" id="btn_map"><?php echo translate("map"); ?></button>
                            </div>
                        </div>
                        <input type="hidden" value="<?php echo $this->security->get_csrf_hash() ?>" name="<?php echo $this->security->get_csrf_token_name() ?>">
                    </form>
                </div> <!----panel --/--->
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        set_switchery();
        $("#variants_mult_imgs").select2({
             placeholder: "Select Options",
             containerCssClass : "container_variants_mult_imgs"
        });
        $("#color").select2({
             placeholder: "Select Options",
             containerCssClass : "container_variants_mult_colors"
        });
        $("#features").select2({
             placeholder: "Select Options",
        });
        
         $("#btn_map").click(function(e){
            e.preventDefault();
            Swal.fire({
              title: 'Are you sure?',
              text: "",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, import!'
            }).then((result) => {
                if (result.value) {
                    if(form_validation('advance_bulk_upload')){
                        $("#advance_bulk_upload").submit();
                        $(".overlay_holder1").show();  
                    } 
                }
            });
        });
        $("#excel_file").change(function(){
            $("#is_excel_field_fetch").val(1);
            $("#advance_bulk_upload").submit();
        });

        $("#advance_bulk_upload").submit(function(e){
            if($("#is_excel_field_fetch").val()==1){
                $(".overlay_holder1").show();
                e.preventDefault();
                $.ajax({
                    url : '<?php echo base_url('admin/get_excel_fields'); ?>',
                    type : "POST",
                    cache: false,
                    contentType: false,
                    processData: false,
                    data : new FormData($("#advance_bulk_upload")[0]),
                    success : function(response){
                        var converted = JSON.parse(response);
                        console.log(converted);
                        if(converted.status !="error"){
                            if(converted.data!=null && converted.data!=""){
                                var options = "<option value=''>-- Select --</option>";
                                $.each(converted.data,function(index , value){
                                    options += "<option value="+index+">"+value+"</option>";
                                });
                                $(".excel_columns").html(options);
                                $("#is_excel_field_fetch").val(0);
                            }else{
                                alert("An error occured");
                            }
                        }else{
                            alert(converted.msg);
                            $(".excel_columns").html("<option value=''>-- Select --</option>");
                            $("#variants_mult_imgs").val();
                            $("#excel_file").val("");
                        }
                        $(".overlay_holder1").hide();
                    } /* success block */
                });
            }
        });
    }); /* end of jquery */

    var base_url = '<?php echo base_url(); ?>';
    var user_type = 'admin';
    var module = 'advance_bulk_upload';
    var list_cont_func = '';
    var dlt_cont_func = '';

    document.addEventListener('DOMContentLoaded',function(e){
    })

</script>

