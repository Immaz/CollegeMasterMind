<style type="text/css">
	.btn_product_action  a{
        margin-left: 2px;
        font-size: 16px;
    }
    .btn_product_action a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
</style>
<div id="content-container">
	<div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Manage_roles');?></h4>
        </div>
        <div class="col-md-4">
            <a class="btn btn-green pull-right" href="<?php echo base_url("admin/role/add"); ?>">
            	<i class="fa fa-plus-circle"></i>
            	<?php echo translate('create_role');?>
            </a>
        </div>
    </div>
    <div class="row">
    	<div class="col-md-12 pd-1">
		    <table class="table table-striped table-bordered"  data-pagination="true" data-ignorecol="0,2" data-show-toggle="false">
				<thead>
		            <tr>
		                <th width="10%"><?php echo translate('no');?></th>
		                <th width="80%"><?php echo translate('name');?></th>
		                <th class="text-center" width="20%"><?php echo translate('options');?></th>
		            </tr>
		        </thead>
		            
		        <tbody >
		        <?php
		            $i = 0;
		            foreach($all_roles as $row){
		                $i++;
		        ?>
		        <tr>
		            <td><?php echo $i; ?></td>
		            <td><?php echo $row['name']; ?></td>
		            <td class="text-center btn_product_action">
		                <?php if($row['role_id'] != '1'){ ?>
		                <a href="<?php echo base_url("admin/role/edit/".$row['role_id']); ?>">
		                    <i class="fa fa-wrench"></i>
		                </a>
		                <a onclick="delete_record('<?php echo base_url("admin/role/delete/".$row['role_id']); ?>')">
		                    <i class=" fa fa-trash ad_red"></i>
		                </a>
		                <?php } ?>
		            </td>
		        </tr>
		        <?php
		            }
		        ?>
		        </tbody>
		    </table>
    	</div>
    </div>
</div>

<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'role';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
	function proceed(type){
		if(type == 'to_list'){
			$(".pro_list_btn").show();
			$(".add_pro_btn").hide();
		} else if(type == 'to_add'){
			$(".add_pro_btn").show();
			$(".pro_list_btn").hide();
		}
	}
</script>
