	<style>
	.btn_actions a{
        margin-left: 2px;
        font-size: 16px;
    }
    .btn_actions a:hover{
        cursor: pointer;
        color: black;
        transition: all 0.2s;
    }
	</style>
	<div id="content-container">
		<div class="row row_page_heading">
	        <div class="col-md-8">
	            <h4 class="page-header text-overflow">
	                <?php echo translate('manage_users');?>
	            </h4>
	        </div>
        </div>
	    <table id="demo-table" class="table table-bordered table table-striped"  data-pagination="true" data-search="true" >
	        <thead>
	            <tr>
	                <th><?php echo translate('no');?></th>
	                <th><?php echo translate('image');?></th>
	                <th><?php echo translate('name');?></th>
	                <th><?php echo translate('e-mail');?></th>
	                <th><?php echo translate('country');?></th>
	                <th><?php echo translate('state');?></th>
	                <th><?php echo translate('city');?></th>
	                <th><?php echo translate('total_purchase');?></th>
	                <th class="text-center"><?php echo translate('options');?></th>
	            </tr>
	        </thead>				
	        <tbody >
	        <?php
	            $i = 0;
	            foreach($all_users as $row){
	                $i++;
	        ?>                
	        <tr>
	            <td><?php echo $i; ?></td>
	            <td>
	                <img class="img-sm img-circle img-border"
	                    <?php if(file_exists('uploads/user_image/user_'.$row['user_id'].'.jpg')){ ?>
	                        src="<?php echo base_url(); ?>uploads/user_image/user_<?php echo $row['user_id']; ?>.jpg"
	                    <?php } else if($row['fb_id'] !== NULL){ ?>
	                        src="https://graph.facebook.com/<?php echo $row['fb_id']; ?>/picture?type=large" data-im='fb'
	                    <?php } else if($row['g_id'] !== NULL){ ?>
	                    	src="<?php echo $row['g_photo']; ?>" data-im='fb'
						<?php } else { ?>
	                        src="<?php echo base_url(); ?>uploads/user_image/default.jpg"
	                    <?php } ?>  />
	            </td>
	            <td><?php echo $row['username']; ?></td>
	            <td><?php echo $row['email']; ?></td>
	            <td><?php echo $this->crud_model->get_type_name_by_id("country",$row['country'],"country_name");  ?></td>
	            <td><?php echo $this->crud_model->get_type_name_by_id("state",$row['state'],"state_name");  ?></td>
	            <td><?php echo $this->crud_model->get_type_name_by_id("city",$row['city'],"city_name");  ?></td>
	            <td class="text-left"><?php echo currency('','def').$this->crud_model->total_purchase($row['user_id']); ?></td>
	            <td class="text-center">
	            	<div class="btn_actions">
		            	<a  data-toggle="tooltip" 
		                    onclick="ajax_modal('view','<?php echo translate('view_profile'); ?>','<?php echo translate('successfully_viewed!'); ?>','user_view','<?php echo $row['user_id']; ?>')" data-original-title="View" data-container="body">
		                    <i class="fa fa-location-arrow"></i>
		                </a>
		                <a onclick="delete_record('<?php echo base_url("admin/user/delete/".$row['user_id']); ?>')">
		                    <i class="fa fa-trash ad_red"></i>
		                </a>
	            	</div>
	            </td>
	        </tr>
	        <?php
	            }
	        ?>
	        </tbody>
	    </table>
	</div>
<script>
	var base_url = '<?php echo base_url(); ?>'
	var user_type = 'admin';
	var module = 'user';
	var list_cont_func = 'list';
	var dlt_cont_func = 'delete';
	var this_page = false;
</script>
