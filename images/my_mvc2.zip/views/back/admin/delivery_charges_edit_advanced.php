<style type="text/css">
    .row{
        margin-bottom: 10px;
    }
    input[type=number]::-webkit-inner-spin-button, 
    input[type=number]::-webkit-outer-spin-button { 
      -webkit-appearance: none; 
      margin: 0; 
    }
</style>
<div class="container" id="content-container">
    <div class="row row_page_heading">
        <div class="col-md-8">
            <h4 class="page-header text-overflow"><?php echo translate('Edit Advanced Delivery Charges');?></h4>
        </div>
        <div class="col-md-4">
            <a href="<?php echo base_url('admin/delivery_charges/advanced'); ?>" class="btn btn-green btn-md pull-right pro_list_btn">
                    <i class="fa fa-backward"></i>&nbsp;
                    <?php echo translate('back_to_delivery_charges_list');?>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 pd-1">
            <?php
                echo form_open(base_url() . 'admin/delivery_charges/edit_advanced/'.$advanced_delivery_charge['advanced_delivery_charges_id'], array(
                    'class' => 'form-horizontal',
                    'method' => 'post',
                    'id' => 'edit_delivery_charges',
                    'enctype' => 'multipart/form-data'
                ));
            ?>
                <div class="row">
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("title"); ?></label>
                        <input type="text" name="title" value="<?= $advanced_delivery_charge['title'];?>" id="title" class="form-control required">
                    </div>
                    <div class="col-md-6">
                        <label class="my_label"><?php echo translate("country"); ?></label>
                        <select name="country" id="filter_item_country" style="width: 100% !important" class="form-control select2 required">
                            <option value=""><?php echo translate("select"); ?></option>
                            <?php
                                foreach ($countries as $country) {
                            ?>
                            <option <?= ($advanced_delivery_charge['country'] == $country['country_id'])? "selected":""; ?> value="<?php echo $country['country_id']; ?>">
                                <?php echo $country['country_name']; ?></option>
                            <?php  } ?>
                        </select>
                    </div> 
                </div>
                <div class="row a_s">
                    <button type="button" style="float: right; margin-right: 15px; margin-bottom: 6px;" class="btn btn-purple add_more"><?php echo translate("add more"); ?></button>
                    <label class="my_label" style="padding-left: 15px;"><?php echo translate("Filter"); ?></label>
                </div>
                <div class="more_filter">
                    <script>
                        var filter_item = [];
                    </script>
                    <?php $i = 0;foreach (json_decode($advanced_delivery_charge['filters']) as $filter) { ?>
                        <script>
                            filter_item.push(<?= $filter->filter_item;?>);
                            var filter_item_length = <?= $i;?>;
                        </script>
                        <div class="row" data-id="<?= $i;?>">
                            <div class="col-md-12" style="display: flex;justify-content: space-between;">
                                <select name="equal_unequal[]" id="equal_unequal_<?= $i;?>" style="width: 27.5%" class="form-control">
                                    <option <?= (($filter->condition == "=")? "selected" : "");?> value="="><?php echo translate("equal"); ?></option>
                                    <option <?= (($filter->condition == "!=")? "selected" : "");?> value="!="><?php echo translate("not equal to"); ?></option>
                                </select>
                                <select name="filter_item[]" id="filter_item_<?= $i;?>" style="width: 67.5% !important;" class="form-control select2">
                                </select>
                                <button class="btn btn-danger btn_remove_variant">X</button>
                            </div> 
                        </div>
                    <?php $i++; }?>
                </div>
                <div class="row a_s">
                    <div class="col-md-6">
                        <label class="my_label" ><?php echo translate("Shipping Cost"); ?></label>
                        <input type="text" name="base_cost"  value="<?= $advanced_delivery_charge['base_cost'];?>" id="advance_shipping_cost" class="form-control required">
                    </div> 
                </div>
                <div class="row">
                    <div class="col-md-2">
                        <div class="my_checkbox_container">
                            <input type="checkbox" name="is_active" id="is_active"  <?= ($advanced_delivery_charge['active'])? 'checked="checked"': '';?>>
                            <span class="my_checkmark"></span>
                            <label for="is_active" style="margin-left: 25px;">Active</label>
                        </div>
                     </div>
                    <div class="col-md-10 submit_btn_div">
                        <input type="hidden" name="shipping_type" id="shipping_type" value="a_s">
                        <button class="btn btn-green btn-md pull-right" id="mysubmitbtn" name='submit_button_two'>
                            <?php echo translate("submit"); ?> 
                            <i class="fa fa-upload"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    var base_url = '<?php echo base_url(); ?>';
    // var timer = '<?php //$this->benchmark->mark_time(); ?>';
    var user_type = 'admin';
    var module = 'delivery_charges';
    var this_page = false;
    var list_cont_func = '';
    var dlt_cont_func = '';
    
    $(document).ready(function(){
        $('.select2').select2();

        $("#mysubmitbtn").click(function(e){
            e.preventDefault();
            if(form_validation("edit_delivery_charges")){
                $("select[name='filter_item[]']").each(function(index, element) {
                    $('.submit_btn_div').append('<input type="hidden" name="filter_items_type[]" value="'+$(element).find("option:selected").data('type')+'">');
                });
                $(".overlay_holder1").show();
                $("#edit_delivery_charges").submit();
            }else{
                e.preventDefault();
            }
        });

        $("#filter_item_country").change(function(e){
            var data = {
                '<?php echo $this->security->get_csrf_token_name() ?>': '<?php echo $this->security->get_csrf_hash() ?>',
                'country': $(e.currentTarget).val()
            };
            $.ajax({
                async: false,
                url: "<?php echo base_url('admin/get_data_by_country'); ?>",
                type: "POST",
                data: data,
                success: function(data) {
                    var data = JSON.parse(data);
                    if (data['status'] > 0) {
                        for (let i2 = 0; i2 < (window['filter_item_length'] + 1); i2++) {
                            var html = '<option value=""><?php echo translate('select')?></option>';
                            for (let i = 0; i < data['data'].length; i++) {
                                if (filter_item[i2] == data['data'][i].id) {
                                    html += `<option selected="selected" value="`+data['data'][i].id+`" data-type="`+data['data'][i].data_type+`">`+data['data'][i].name+`</option>`;
                                }else{
                                    html += `<option value="`+data['data'][i].id+`" data-type="`+data['data'][i].data_type+`">`+data['data'][i].name+`</option>`;
                                }
                            }
                            $('#filter_item_'+i2).html(html);
                        }
                    }else{
                        Swal.fire({
                            title: '404?',
                            text: "States Not Found For this Country.",
                            type: 'error',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Ok!'
                        });
                    }
                }
            })
        });

        var number_of_filter = filter_item_length + 1;
        $(".add_more").click(function(e){
            var data = {
                '<?php echo $this->security->get_csrf_token_name() ?>': '<?php echo $this->security->get_csrf_hash() ?>',
                'country': $('#filter_item_country').val()
            };
            $.ajax({
                url: "<?php echo base_url('admin/get_data_by_country'); ?>",
                type: "POST",
                data: data,
                success: function(data) {
                    var data = JSON.parse(data);
                    if (data['status'] > 0) {
                        var html = '<div class="row">';
                            html += '<div class="col-md-12" style="display: flex;justify-content: space-between;">';
                                html += '<select name="equal_unequal[]" id="equal_unequal_'+number_of_filter+'" style="width: 27.5%" class="form-control">';
                                    html += '<option value="="><?php echo translate("equal"); ?></option>';
                                    html += '<option value="!="><?php echo translate("not equal to"); ?></option>';
                                html += '</select>';
                                html += '<select name="filter_item[]" id="filter_item_'+number_of_filter+'" style="width: 67.5%" class="form-control select2">';
                                    html += '<option value=""><?php echo translate('select')?></option>';
                                    for (let i = 0; i < data['data'].length; i++) {
                                        html += '<option value="'+data['data'][i].id+'" data-type="'+data['data'][i].data_type+'">'+data['data'][i].name+'</option>';                                
                                    }
                                html += '</select>';
                                html += '<button class="btn btn-danger btn_remove_variant">X</button>';
                            html += '</div>';
                        html += '</div>';
                        $('.more_filter').append(html);
                    }else{
                        Swal.fire({
                            title: '404?',
                            text: "States Not Found For this Country.",
                            type: 'error',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Ok!'
                        });
                    }
                }
            }).then(()=>{
                $('.select2').select2();
                number_of_filter++;
            })
        });

        $(document).on('click', '.btn_remove_variant',function(e) {
            e.preventDefault();
            var variant_id = $(this).parent().parent().data('id');
            Swal.fire({
              title: 'Are you sure?',
              text: "Do you want to delete this.",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Delete!'
            }).then((result) => {
                if($(this).parent().parent().parent().children('.row').length == 1) {
                  Swal.fire({
                    text: "One Condition is Required.",
                    type: 'error',
                    showCancelButton: false,
                  })
                }else {
                    $(this).parent().parent().remove();
                    number_of_filter = number_of_filter - 1; 
                }
            });
        });

        $("#filter_item_country").change();
    });
</script>
<!--Bootstrap Tags Input [ OPTIONAL ]-->