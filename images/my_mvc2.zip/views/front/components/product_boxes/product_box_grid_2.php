<?php
$variant_image = "default.jpg";
if ($front_image != "" && $front_image != NULL) {
    $img = json_decode($front_image, true);
    $variant_image = $img[0];
} else {
    $img = json_decode($images, true);
    if (count($img) > 0) {
        $variant_image = $img[0];
    }
}
$is_discounted = ($this->crud_model->get_type_name_by_id('product_variants', $product_variants_id, 'discount')) > 0 ? true : false;
$product_price = currency($this->crud_model->get_product_price($product_variants_id));
$product_price_raw = (float)substr("$product_price",1);
?>
<style type="text/css">
.btn_add_to_cart {
  padding: 12px 0 0 0px !important;
  font-size: 15px !important;
  margin: -1px 0 0 -8px;
  height: 45px;
  text-align: center;
}

.added_to_cart {
  padding: 12px 0 0 0px !important;
  margin: -1px 0 0 -8px;
  background-color: #0e0558;
  border-color: #0e0558;
  color: #ffffff;
}
.cartimg{
  height: 20px !important; 
  width: 20px !important; 
}
.added_to_cart:hover {
  color: #040404 !important;
  border: 1px solid #0e0558 !important;
}

.home_page_price span {
  color: #0e0558;
  font-weight: bold;
  font-size: 20px;
}

.home_page_price del {
  font-size: 14px;
}

.home_page_price {
  /*border: 1px solid #ccc;*/
}

.box-style-2 .home_page_price div[class*="col-"] {
  margin-top: 5px !important;
}

.product-box-block-ellipsis {
  display: block;
  display: -webkit-box;
  max-width: 100%;
  margin: 0 auto;
  font-size: 14px;
  line-height: 1.5;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  text-overflow: ellipsis;
}

.box-style-2 .discounted_price {
  color: gray;
  margin-top: -5px;
  text-decoration: line-through;
}

.thumbnail.box-style-2 .caption-title {
  /* display: table;
        width: 100%;*/
}

.thumbnail.box-style-2 .caption-title a {
  font-size: 13px;
}

.thumbnail.box-style-2 .media-link {
  display: flex;
  align-items: center;
}

</style>
<div id="div" class="thumbnail product_box box-style-2  "
  style="padding-right: 8px; padding-left: 8px; border-radius: 5px;">
  <div class="media">
    <a target="_blank"
      href="<?php echo base_url("home/product_view/" . $product_id . "/" . $this->crud_model->infiltrate_unwated_character($title)); ?>">
      <div class="cover"></div>
    </a>
    <div style="background-color: #f3402d; width: fit-content; padding: 3px 12px; border-radius: 2rem; font-size: 11px; color: white; position: absolute; top:3%; left:2%; z-index: 2; " class="discount-top <?php echo $is_discounted ? "" : 'd-none'; ?>">
    <?php echo $is_discounted ? "-" . ceil(($product_price_raw * 100)/$selling_price) . "%" : ""; ?>
  </div>
    <div class="media-link image_delay">
      <img src="<?php echo $this->crud_model->get_image("product_variants", $variant_image); ?>" class="img-responsive"
        data-src="<?php echo $this->crud_model->get_image("product_variants", $variant_image); ?>">
      <?php
            if ($stock_status <= 0) {
                ?>
      <div class="sticker red" data-stock-status="<?php echo $stock_status; ?>">
        <?php echo translate('out_of_stock'); ?>
      </div>
      <?php
            }
            ?>
      <?php
            $discount = $this->db->get_where('product_variants', array('product_variants_id' => $product_variants_id))->row()->discount;
            if ($discount > 0) {
                ?>

      <!--- Discount Sticker --->

      <!--             <div class="sticker green">
                <?php
                echo $this->crud_model->get_product_variants_save_off_price($product_variants_id) . "%";
                ?> 
            </div> -->

      <?php } ?>
      <!-- <div class="quick-view-sm hidden-xs hidden-sm">
                <a href="<?php echo base_url("home/product_view/" . $product_id . "/" . $this->crud_model->infiltrate_unwated_character($title)); ?>" target="_blank">
                    <span class="icon-view left" data-toggle="tooltip" data-original-title="<?php echo translate('quick_view'); ?>">
                        <strong><i class="fa fa-eye"></i></strong>
                    </span>
                </a>
                <span class="icon-view middle" data-toggle="tooltip" 
                    data-original-title="<?php if ($this->crud_model->is_compared($product_id) == "yes") {
                        echo translate('compared');
                    } else {
                        echo translate('compare');
                    } ?>"
                        onclick="do_compare(<?php echo $product_variants_id; ?>,event)">
                    <strong><i class="fa fa-exchange"></i></strong>
                </span>
                <span class="icon-view right" data-toggle="tooltip" 
                    data-original-title="<?php if ($this->crud_model->is_wished($product_id) == "yes") {
                        echo translate('added_to_wishlist');
                    } else {
                        echo translate('add_to_wishlist');
                    } ?>"
                        onclick="to_wishlist(<?php echo $product_variants_id; ?>,event)">
                    <strong><i class="fa fa-heart"></i></strong>
                </span>  
            </div> -->
    </div>
  </div>
  <?php
    $title_data = str_replace('"', "", $title);
    ?>
  <div class="caption">
    <div class="captionbox">
      <p class="product-box-block-ellipsis caption-title" id="captiont" data-variant-title='<?php echo $title; ?>'
        title="<?php echo $title_data; ?>" <?php ?>>
        <a
          href="<?php echo base_url("home/product_view/" . $product_id . "/" . $this->crud_model->infiltrate_unwated_character($title)); ?>">
          <?php echo substr($title,0,30) . '...'; ?>
        </a>
      </p>
    </div>
    <?php $rating = $this->crud_model->rating($product_id); ?>
    <div class="rateit mt-2" data-rateit-value="<?= $rating ?>" data-rateit-ispreset="true" data-rateit-readonly="true">
    </div>
    <div class="row home_page_price"
      style="margin-top:0!important; padding: 0 0 5px 0px; display: flex; align-items: center; color: #1f1d1e;">
      <div class="col-md-6 col-sm-6 col-xs-6">
        <?php

                if ($is_discounted) {
                    ?>
        <span style="color: #1f1d1e">
          <?php echo $product_price; ?>
        </span>
        <span class="discounted_price" style="font-size: 13px;">
          <?php echo currency($selling_price); ?>
        </span>
        <?php } else { ?>
        <span style="color: #1f1d1e">
          <?php echo currency($selling_price); ?>
        </span>
        <?php } ?>
      </div>
      <div class="col-md-6 col-sm-6 col-xs-6">
        <div class="cart">
          <a data-show-cart-popup="true" data-view-in-cart="true" id="add_to_cart" class="  <?php if ($this->crud_model->is_added_to_cart($product_variants_id)) {
                            echo "added_to_cart";
                        } ?>" data-placement="left"
            <?php if ($this->crud_model->is_added_to_cart($product_variants_id)) { ?>
            href='<?php echo base_url('home/cart_checkout'); ?>' <?php } else { ?>
            onclick="to_cart(<?php echo $product_variants_id; ?>,event)" <?php } ?>>
            <?php
                        if ($this->crud_model->is_added_to_cart($product_variants_id)) {
                            echo translate('view_in_cart');
                        } else {?>
            <img class="cartimg" src="<?php echo base_url(); ?>/uploads/others/cart_white.png" alt="" height="20px" width="20px">
            <?php } ?>

          </a>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
#captiont a {
  font-weight: 600;
}

#captiont {
  height: fit-content;
}

#add_to_cart {
  display: flex;
  justify-content: end;
  align-items: center;
  padding-top: 0px;
  background-color: #f3402d;
  width: fit-content;
  padding: 8px;
  border-radius: 0.5em;
  margin-left: 65%;
  cursor: pointer;

}
#add_to_cart:hover {
  background-color: #242424;
}

.captionbox {
  border-bottom: 2px solid #ccc;
  padding-bottom: 10px;
}
/* for mobo only */
@media (max-width: 768px) {
  .quick-view-sm {
    display: none;
  }
  .cartimg{
    max-width: none !important;
  }
  #add_to_cart{
    margin-left: 0px;
  }
  .cart {
    display: flex;
    justify-content: end;
  }
}

/* xs */
.quick-view-sm {
  display: none;
}

/* sm */
@media (min-width: 768px) {
  .quick-view-sm {
    display: none;
  }
  .cartimg{
    max-width: none !important;
  }
}


/* md */
@media (min-width: 992px) {
  .quick-view-sm {
    display: block;
  }
}

/* lg */
@media (min-width: 1200px) {
  .quick-view-sm {
    display: block;
  }
}

@media (max-width: 480px) {
  .responsive_cart {
    display: none !important;
  }

  .home_page_price span {
    font-size: 15px;
  }

  .media-left {
    margin: 0 0 35px 0;
  }
}
</style>
<script type="text/javascript">
$(document).ready(function() {
  $(".caption-title").tooltip();
});
</script>