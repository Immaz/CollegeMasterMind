<style type="text/css">
    .top_bar_right_holder{
        width: 160px;
        height: 100%;
        text-align: center;
        margin-top: 5px;
    }
    .user_register,
    .user_sign_in
    {   
        display: inline-block;
        font-size: 17px;
    }
    .user_name a span:nth-child(2){
        height: auto;
    }
    .block-ellipsis {
        font-size: 14px !important;
        display: block;
        display: -webkit-box;
        max-width: 100%;
        margin: 0 auto;
        line-height: 1.2 !important;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
<div class="top_bar_right_holder">
    <?php if($this->session->userdata('user_login')!='yes'){  ?>
        <div class="user_sign_in">
            <a href="<?php echo base_url(); ?>home/login_set/login"> 
                <span><?php echo translate('Sign In');?></span>
            </a>
        </div>
        /
        <div class="user_register">
            <a href="<?php echo base_url(); ?>home/login_set/registration">
                <span><?php echo translate('Register');?></span>
            </a>
        </div>
     <?php } ?>
     <div class="user_name">
          <?php if($this->session->userdata('user_login')=='yes'){  ?>
            <a href="<?php echo base_url(); ?>home/profile/">
                <span class="block-ellipsis">
                    <i class="fa fa-user" style="font-size: 18px;"></i><br>
                    <?php echo ucfirst($this->session->userdata()['user_name']);?>
                </span>
            </a>
        <?php } ?>
     </div>
</div>

<!-- <ul class="list-inline">
    <?php
        if($this->session->userdata('user_login')!='yes'){ 
    ?>
    <li class="icon-user" style="font-size: 17px;">
        <i class="fa fa-user" aria-hidden="true" style="font-size: 18px;"></i>
        <a href="<?php echo base_url(); ?>home/login_set/login"> 
            <span><?php echo translate('Sign In');?></span>
        </a>
    </li>
    <span>/</span>
    <li class="icon-user" style="font-size: 17px;">
        <a href="<?php echo base_url(); ?>home/login_set/registration">
            <span><?php echo translate('Register');?></span>
        </a>
    </li>
    <br />
    <div style="text-align: center; font-size: 14px;">Welcome Guest</div>
    <?php } else { ?>
    <li class="icon-user" style="font-size: 15px;">
        <i class="fa fa-user" aria-hidden="true" style="font-size: 17px;"></i>
        <a href="<?php echo base_url(); ?>home/profile/">
            <span>
                <?php echo  "Welcome ".ucfirst($this->session->userdata()['user_name']);?>
            </span>
        </a>
    </li>
    <?php }?>
</ul> -->