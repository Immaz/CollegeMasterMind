<style type="text/css">
    
    .widget-recent-blog #tabs li.active a{
        color: white;
        text-align: left;
        font-size: 20px;
    }
    .widget-recent-blog .tab-content {
         border: 2px solid #ccc;
    }
    .special-blogs #tabs{
        background-color: #57709a;
        color: white;
        text-align: left;
    }
    .special-blogs ul li > a{
        color: white !important;
        margin: 0px;
        font-size: 14px;
        padding-left: 3px;
        padding-right: 3px;
        text-align: left;
        letter-spacing: 2px;
    }
    .special-blogs .tab-content {
        border: 1px solid #ccc !important;
    }
    .special-blogs #tabs{
        padding: 6px 12px;
        border-radius: 3px;
        margin-bottom: 0px;
    }
    .special-blogs .tab-content{
        border-radius: 3px;
        padding: 18px 8px !important;
    }
    .media_special_blog a{
        max-width: 70px;
    }
    .media_special_blog a img{
       border-radius: 3px;
    }
     .media_special_blog .media-body .media-heading a{
        padding: 3px 0;
        color: rgba(0,0,0,.75);
        font-size: 14px;
        font-weight: 500;
    }
</style>
<div class="col-md-12" style="margin-top: 0px;">
	<div class="widget widget-tabs widget-recent-blog">
        <div class="widget-content special-blogs">
            <ul id="tabs">
                <li class="active">
                    <a href="#tab-s1" data-toggle="tab">
                        <?php echo translate('recent_post');?>
                    </a>
                </li>
                <!-- <li>
                    <a href="#tab-s2" data-toggle="tab">
                        <?php echo translate('popular');?>
                    </a>
                </li> -->
            </ul>
            <div class="tab-content">
                <!-- tab 1 -->
                <div class="tab-pane fade in active" id="tab-s1">
                    <div class="special-blog-list">
                    <?php
                    	$this->db->limit(3);
						$this->db->order_by("blog_id", "desc");
						$latest=$this->db->get('blog')->result_array();
						foreach($latest as $row){
					?>
                        <div class="media media_special_blog">
                            <a class="pull-left media-link" href="<?php echo $this->crud_model->blog_link($row['blog_id']); ?>">
                                <img class="img-responsive" src="<?php echo $this->crud_model->file_view('blog',$row['blog_id'],'','','thumb','src','',''); ?>" alt=""/>
                            </a>
                            <div class="media-body">
                                <h6 class="media-heading">
                                    <a href="<?php echo $this->crud_model->blog_link($row['blog_id']); ?>">
                                    	<?php echo ucwords($row['title']); ?>
                                    </a>
                                </h6>
                            </div>
                        </div>
                        <hr />
                    <?php
						}
					?>
                    </div>
                </div>
                <!-- tab 2 -->
                <!-- <div class="tab-pane fade" id="tab-s2">
                    <div class="product-list">
                        <?php
                    	$this->db->limit(3);
						$this->db->order_by("number_of_view", "desc");
						$popular=$this->db->get('blog')->result_array();
						foreach($popular as $row){
					?>
                        <div class="media">
                            <a class="pull-left media-link" href="<?php echo $this->crud_model->blog_link($row['blog_id']); ?>">
                                <img class="img-responsive" src="<?php echo $this->crud_model->file_view('blog',$row['blog_id'],'','','thumb','src','',''); ?>" alt=""/>
                                <i class="fa fa-eye"></i>
                            </a>
                            <div class="media-body">
                                <h6 class="media-heading">
                                    <a href="<?php echo $this->crud_model->blog_link($row['blog_id']); ?>">
                                    	<?php echo $row['title']; ?>
                                    </a>
                                </h6>
                                <div class="date">
                                	<ins><?php echo $row['date']; ?></ins>
                                </div>
                            </div>
                        </div>
                    <?php
						}
					?>
                    </div>
                </div> -->
            </div>
        </div>
    </div>
</div>