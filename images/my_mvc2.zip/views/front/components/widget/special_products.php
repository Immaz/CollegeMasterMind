<style type="text/css">
     #tabs{
        border-bottom: 1px solid #3C3B6E;
     }
    #tabs li.active a{
        background-color: #f3402d;
        color: white;
    }
    .nav-tabs>li>a:hover{
        background-color: #f3402d;
        color: white;
    }
       .nav-tabs>li>a{
        font-size: 14px;
    }
    .popular_prod_title{
        font-size: 12px;
    }
    .media{
        border: 0px solid !important;
    }
    .img{
        max-height: 100px;
        height: 100%;
        max-width: 50px;
    }
    .product-list .media-link{
        width: 50px;
    }  
    #tab-s1 .media , #tab-s2 .media{
        padding-top: 0px;
    }
    .block-ellipsis-special-prod-title {
        display: block;
        display: -webkit-box;
        max-width: 100%;
        margin: 0 auto;
        font-size: 14px;
        line-height: 1.1;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        height: 30px !important; 
    }
</style>
<ul id="tabs" class="nav nav-tabs">
    <li class="active" style="width: 110px;"> 
        <a href="#tab-s1" data-toggle="tab">
            <?php echo translate('popular');?>
        </a>
    </li>
    <li style="width: 110px;">
        <a href="#tab-s2" data-toggle="tab">
            <?php echo translate('latest');?>
        </a>
    </li>
</ul>
<div class="tab-content">
    <!-- tab 1 -->
    <div class="tab-pane fade in active" id="tab-s1">
        <div class="product-list">
            <br />
            <?php
            $most_viewed = $this->crud_model->getSpecialProducts("most_viewed");
            if($most_viewed){
                foreach($most_viewed as $row){
                    $images = json_decode($row['images'] ,true);
                    $img = $images[0];
            ?>
            <div class="media" data-toggle="tooltip" title="<?php echo $row['title']; ?>" >
                <a class="pull-left media-link" target="_blank" href="<?php echo  base_url("home/product_view/".$row['product_id']."/".$this->crud_model->infiltrate_unwated_character($row['title'])); ?>">
                    <img class="media-object img-responsive img" src="<?php echo $this->crud_model->get_image('product_variants',$img);?>" alt="">
                    <i class="fa fa-eye"></i>
                </a>
                <div class="media-body">
                    <h4 class="media-heading popular_prod_title block-ellipsis-special-prod-title special_prod_title" >
                        <a target="_blank" href="<?php echo  base_url("home/product_view/".$row['product_id']."/".$this->crud_model->infiltrate_unwated_character($row['title'])); ?>">
                            <?php echo $row['title']; ?>
                        </a>
                    </h4>
                    <div class="price">
                        <?php if($this->crud_model->get_type_name_by_id('product_variants' , $row['product_variants_id'],'discount') > 0){ ?> 
                            <ins><?php echo currency($this->crud_model->get_product_price($row['product_variants_id'])); ?></ins><del><?php echo currency($row['selling_price']); ?></del>
                        <?php } else { ?>
                            <ins><?php echo currency($row['selling_price']); ?></ins> 
                        <?php }?>
                    </div>
                </div>
            </div>
                <?php
                }
            }
            ?>
        </div>
    </div>

    <!-- tab 2 -->
    <div class="tab-pane fade" id="tab-s2">
        <div class="product-list"><br />
            <?php
            $latest = $this->crud_model->getSpecialProducts("latest");
            if($latest){
                foreach($latest as $row){
                    $images = json_decode($row['images'] ,true);
                    $img = $images[0];
            ?>
            <div class="media" title="<?php echo $row['title']; ?>" data-toggle="tooltip">
                <a class="pull-left media-link" target="_blank" href="<?php echo  base_url("home/product_view/".$row['product_id']."/".$this->crud_model->infiltrate_unwated_character($row['title'])); ?>">
                    <img class="media-object img-responsive img" src="<?php echo $this->crud_model->get_image('product_variants',$img);?>" alt="">
                    <i class="fa fa-eye"></i>
                </a>
                <div class="media-body">
                    <h4 class="media-heading block-ellipsis-special-prod-title special_prod_title">
                        <a data-toggle="tooltip"  target="_blank" href="<?php echo  base_url("home/product_view/".$row['product_id']."/".$this->crud_model->infiltrate_unwated_character($row['title'])); ?>">
                            <?php echo $row['title']; ?>
                        </a>
                    </h4>
                    <div class="price">
                        <?php if($this->crud_model->get_type_name_by_id('product_variants',$row['product_variants_id'],'discount') > 0){ ?> 
                            <ins><?php echo currency($this->crud_model->get_product_price($row['product_variants_id'])); ?> </ins> 
                            <del><?php echo currency($row['selling_price']); ?></del>
                        <?php } else { ?>
                            <ins><?php echo currency($row['selling_price']); ?></ins> 
                        <?php }?>
                    </div>
                </div>
            </div>	
            <?php
                }
            }
            ?>
        </div>
    </div>
</div>