<style type="text/css">

    :root {
        --main-color: #f3402d;
    }
    .media{
        margin-top: 0px;
    }
    .btn_cart_checkout  ,
    .btn_cart_checkout:focus
     {
        background-color: var(--main-color);
        border:1px solid var(--main-color);
        color: white;
    }
    .btn_cart_checkout:hover{
        color: white;
        background-color: var(--main-color);
    }
    .media_cart_item:hover{
        background-color: #f5f5f5;
        transition: all 0.2s;
    }
    .item-image{
        display: block;
        max-width:100px;
        max-height:60px;
        width: auto;
        height: auto;
    }
    .item-title{
        height: 22px;
        margin-left: 0px;
    }
</style>
<div class="modal fade popup-cart" id="popup-cart" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog">
        <div class="container">
            <div class="cart-items">
                <div class="cart-items-inner">
                    <span class="top_carted_list">
                    </span>
                    <center><img src="<?php echo base_url();?>/template/front/img/preloader.gif" id="cart_loader"> </center>
                    <div class="media">
                        <p class="pull-right item-price shopping-cart__total"></p>
                        <div class="media-body">
                            <h4 class="media-heading item-title summary">
                                <?php echo translate('subtotal');?>
                            </h4>
                        </div>
                    </div>
                    <div class="media">
                        <div class="media-body">
                            <div>
                                <a href="<?php echo base_url(); ?>home/cart_checkout" class="btn btn-block  btn-default btn_cart_checkout">
                                    <i class="fa fa-shopping-cart"></i>
                                    <?php echo translate('checkout');?>
                                </a>
                                <span class="btn btn-block  btn-default" data-dismiss="modal">
                                    <i class="fa fa-times"></i>
                                    <?php echo translate('close');?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $('body').click(function (event) 
        {
            $("#popup-cart").modal("hide");
        });
    });
</script>