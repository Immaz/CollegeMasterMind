<div class="content_holder" style="width: 50%; margin: 0 auto; background: #25d3c9; padding: 20px;">
    <center>
        <h3 style="font-size: 25px; font-family: Roboto,RobotoDraft,Helvetica,Arial,sans-serif; margin-top: 0px; margin-bottom: 0px; color: #fff;"><?= $subject;?></h3>
    </center>
</div>