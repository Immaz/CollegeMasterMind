<style type="text/css">
    .checkout-down-icon{
        z-index: 0 !important;
    }
    .checkout_form_done_gif{
        top: -2%;
        position: absolute;
        width: 40px;
        display: inline-block;
        left: 95%;
        display: none;
    }
    .btn_next_address{
        background-color: #42ca65;
        color: #fff;
        border: 2px solid #42ca65;
        border-radius: 10px;
        /* max-width: 0; */
        /* background: green; */
        height: 40px;
        font-size: 18px;
    }
    .btn_next_address:hover{
        background-color: #42ca65;
        color: #fff;
        border-radius: 10px;
        /* max-width: 0; */
        height: 40px;
        font-size: 18px;
    }
     .btn_next_cancel{
        background-color: #d4ba05 !important;
        color: #fff !important;
        border: 1px solid !important;
        border-radius: 10px;
        height: 40px !important;
        font-size: 18px !important;
        float: left !important;
    }
    .btn_next_cancel:hover{
        background-color: #d4ba05 !important;
        color: #fff !important;
        border-radius: 10px;
    }
    .btn_next_cancel:focus , .btn_next_address:focus{
        color:white;
    }
    em.invalid{
        color: red;
    }
</style>
        <?php
        echo form_open(base_url() . 'home/cart_finish/go', array(
                    'method' => 'post', 
                    'enctype' => 'multipart/form-data', 
                    'id' => 'cart_form' 
                )
            );
        ?>
    <!-- <script src="https://checkout.stripe.com/checkout.js"></script> -->
    <!-- PAGE -->
    <section class="page-section color">
        <div class="container box_shadow">
            <?php if($checkout_errors = $this->session->flashdata("errors")){ ?>
                <div class="alert alert-warning">
                    <a href="javascript:void(0)" class="close" data-dismiss="alert">&times;</a>
                    <?php echo $checkout_errors; ?>
                </div>
            <?php } ?>
            <h3 class="block-title alt done-color">
                <i class="fa fa-shopping-cart"></i>
                <!-- <?php echo translate('');?>.  -->
                <?php echo translate('Checkout');?>
                <img src="<?php echo base_url('')?>\uploads\others\correct.gif" class="done-gif checkout_form_done_gif">
            </h3>
            <div class="row orders" style="margin-bottom: 0px;">
                
            </div>
           
        </div>
    </section>
<!-- /PAGE -->
</form>
<script>       
    $(document).ready(function(){ 

        $("#cart_form").validate({
            errorElement: "em",
            errorClass: "invalid",
            ignore: ".ignore",
            onkeyup: function() {
                if($("#cart_form").valid()){
                    // if($("#is_shipping_avlb").val()==1){
                        $('#order_place_btn').removeAttr("disabled");
                    // }
                }else {
                    $('#order_place_btn').attr("disabled",true);
                }
            },
            onclick: function() {
              if($("#cart_form").valid()){
                // if($("#is_shipping_avlb").val()==1){
                    $('#order_place_btn').removeAttr("disabled");
                // }
              } else {
                $('#order_place_btn').attr("disabled",true);
              }
            },
            errorPlacement: function(error, element) {
                if($(element).hasClass('checkbox-inline')){
                    $(".credit_card_box , .paypal_box").addClass("border");
                }else if($(element).attr('id')=="cardNumber"){
                    $("#cardNumber").addClass("border");
                }else if($(element).attr('id')=="phone"){
                    $("#phone").addClass("border");
                }else{
                    $(element).addClass("border");
                }
            },
            submitHandler: function(form) {
                // if($("#is_shipping_avlb").val()==1){
                    form.submit();
                // }
            }
        });

        $("#cart_form input[type='submit']").click(function(){
            $("#cart_form").valid();
        });
       
        var top = Number(200);  
		$('.orders').html('<div style="text-align:center;width:100%;height:'+(top*2)+'px; position:relative;top:'+top+'px;"><i class="fa fa-refresh fa-spin fa-3x fa-fw"></i></div>');             
        var state = check_login_stat('state');
        state.success(function (data) {
            if(data == 'hypass'){
                load_orders();
            } else {
                //signin('guest_checkout');
				$.ajax(
				{
					url : '<?php echo base_url('home/check_guestAccount'); ?>',
					type : 'POST',
					data :  {'<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>'},
					success : function(response)
					{
							if(response == 1)
							{
								$('.orders').load('<?php echo base_url(); ?>home/cart_checkout/orders');
							}else{
								signin('guest_checkout');
							}
						//console.log(response);
					}   
				});	
			}
       });
    });
    function load_orders(){
		var top = Number(200);
		$('.orders').html('<div style="text-align:center;width:100%;height:'+(top*2)+'px; position:relative;top:'+top+'px;"><i class="fa fa-refresh fa-spin fa-3x fa-fw"></i></div>');
        $('.orders').load('<?php echo base_url(); ?>home/cart_checkout/orders');
    }
    $(document).find('.delivery_address').on("keydown",".required",function(){
        $(this).css({"border" : "0px solid","border-bottom" : "1px solid #B22234"});
    });
    function radio_check(id){
        $(".credit_card_box , .paypal_box , .cash_on_delivery_box").css({"border" : "1px solid #555"});
        $.ajax({
            url : '<?php echo base_url("home/guess_account_delivery_set");  ?>',
            type : "POST",
            data : $("#cart_form").serialize(),
            success : function(res)
            {

            }
        });
        $( "#visa" ).prop( "checked", false );
        $( "#authorize_net" ).prop( "checked", false );
        $( "#mastercardd" ).prop( "checked", false );
        $( "#mastercard" ).prop( "checked", false );
        $( "."+id ).prop( "checked", true );
        if(id == 'authorize_net')
        {
            $("#cardNumber , #expityMonth , #expityYear , #cvCode").removeClass("ignore");
            $('#authorize_card_div').show();
        }else{
            $("#cardNumber , #expityMonth , #expityYear , #cvCode").addClass("ignore");
            $('#authorize_card_div').hide();
        }
        if(id == 'cash_on_delivery' || id == 'bank_transfer' || id == 'western_union_xpress_remitly'){
            $('#order_place_btn').html(`<i class="fa fa-shopping-cart"></i> Complete Shopping`);
        }else{
            $('#order_place_btn').html(`<i class="fa fa-shopping-cart"></i> Proccess With Payment`);
        }
        if(id == 'bank_transfer'){
            $('#bank-transfer-details').removeClass('bank-transfer-details-hide');
            $('#bank-transfer-details').addClass('bank-transfer-details-show');
        }else{
            $('#bank-transfer-details').removeClass('bank-transfer-details-show');
            $('#bank-transfer-details').addClass('bank-transfer-details-hide');
        }
    }
</script>
<?php include('shopping_cart_cal_script.php'); ?>