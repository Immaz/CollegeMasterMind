<head>
<style>
    .footer{
        width: 50%;
        margin: 0 auto;
        padding: 20px;
        background: #25d3c9;
    }
</style>
</head>
<div class="footer content_holder">
    <center>
       <h2 style="color: #fff;">Get in Touch</h2>
    </center>
    <center style="text-align: center;">
        <ul style="list-style: none; padding: 0px;" class="social_nav">
            <li style="display: inline-block;  padding: 0px 5px;">
                <a target="_blank" href="https://www.facebook.com/profile.php?id=61551879336938" style="text-decoration: none;color: #c3c3c3;">
                    <img src="<?php echo base_url("uploads/others/e_fb_icon.png"); ?>" style="width: 25px;">
                </a>
            </li>
            <li style="display: inline-block;  padding: 0px 5px;">
                <a target="_blank" href="https://www.instagram.com/bemartlyofficial/" style="text-decoration: none;color: #c3c3c3;">
                    <img src="<?php echo base_url("uploads/others/e_inst_icon.png"); ?>" style="width: 25px;">
                </a>
            </li>
        </ul>
        <p style="margin-top: 10px; text-decoration: none;color: #fff;">This email was sent by : info@bemartly.com</p>
        <p style="margin-top: 10px;text-decoration: none;color: #fff;">For any questions please send an email to:<a style="text-decoration: none;color: #fff;">info@bemartly.com</a></p>
        <br />
    </center>
</div>