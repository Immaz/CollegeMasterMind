<link rel="stylesheet" type="text/css" href="<?= base_url('') ?>template/front/css/intlTelInput/intlTelInput.css">
<?php 
$is_login = $this->session->userdata('user_login');
if($is_login == "yes" || $is_login == "guest")
{
    $user = $this->session->userdata('user_id'); 
    // echo"<pre>";var_dump($_SESSION);die();
    if($is_login == 'guest')
    {
        $user_data  = $this->session->userdata('guest_deta');

        
        if ($user_data) {
            $firstname  = $user_data->firstname;
            $lastname   = $user_data->lastname;
            $email      = $user_data->email; 
            $phone      = $user_data->phone; 
            $address1   = $user_data->address1; 
            // $langlat    = $user_data->langlat; 
            $address    = $address1;
            $zip        = $user_data->zip; 
            $country = $user_data->country; 
            $state = $user_data->state; 
            $city = $user_data->city; 
            $state_del = ($state)? $this->crud_model->getStateById($state) : '';
            $city_del = ($city)? $this->crud_model->getCityById($city) : '';
            $billing_check = (isset($user_data->billing_check) ? $user_data->billing_check : "1");
            $bill_firstname   = (isset($user_data->bill_firstname) ? $user_data->bill_firstname : "");
            $bill_lastname   = (isset($user_data->bill_lastname) ? $user_data->bill_lastname : "");
            $bill_email   = (isset($user_data->bill_email) ? $user_data->bill_email : "");
            $bill_phone   = (isset($user_data->bill_phone) ? $user_data->bill_phone : "");
            $bill_address   = (isset($user_data->bill_address) ? $user_data->bill_address : "");
            $bill_country   = (isset($user_data->bill_country) ? $user_data->bill_country : "");
            $bill_state   = (isset($user_data->bill_state) ? $user_data->bill_state : "");
            $bill_state_del   =(($bill_state) ? $this->crud_model->getStateById($bill_state) : "");
            $bill_city   = (isset($user_data->bill_city) ? $user_data->bill_city : "");
            $bill_city_del   = (($bill_city) ? $this->crud_model->getCityById($bill_city) : "");
            $bill_zip   = (isset($user_data->bill_zip) ? $user_data->bill_zip : "");
        }
    }else{
        $user_data  = $this->db->get_where('user',array('user_id'=>$user))->row(); 
        $firstname   = $user_data->username;
        $lastname   = $user_data->surname;
        $email      = $user_data->email; 
        $phone      = $user_data->phone; 
        $address1   = $user_data->address1; 
        // $langlat    = $user_data->langlat; 
        $address    = $address1;
        $zip   = $user_data->zip;
        $country = $user_data->country; 
        $state = $user_data->state; 
        $city = $user_data->city;  
        $state_del = $this->crud_model->getStateById($state);
        $city_del = $this->crud_model->getCityById($city);
        $billing_check = "1";
    }
} 
// echo"<pre>";var_dump($phone);die();
?>
<?php 
$system_title = $this->db->get_where('general_settings',array('type' => 'system_title'))->row()->value;
if (isset($country) && $country == '3913') { //For Pakistan
    $cod = $this->db->get_where('general_settings',array('type' => 'cod'))->row()->value;
}else {
    $cod = 'no';
}
$total = $this->cart->total(); 
// if ($this->crud_model->get_type_name_by_id('business_settings', '3', 'value') == 'product_wise') { 
//     $shipping = $this->crud_model->cart_total_it('shipping'); 
// } elseif ($this->crud_model->get_type_name_by_id('business_settings', '3', 'value') == 'fixed') { 
//     $shipping = $this->crud_model->get_type_name_by_id('business_settings', '2', 'value'); 
// } 
// $tax = $this->crud_model->cart_total_it('tax'); 
// $grand = $total + $shipping + $tax; 
$grand = $total; 
?>
<?php
$allow_paypal = $this->db->get_where('business_settings',array('type'=>'paypal_set'))->row()->value; 
$allow_autorize_net = $this->db->get_where('business_settings',array('type'=>'authorize_net'))->row()->value; 
$allow_cod = $this->db->get_where('business_settings',array('type'=>'cash_set'))->row()->value; 
$allow_bank_tranfer = $this->db->get_where('business_settings',array('type'=>'allow_bank_transfer_payment'))->row()->value; 
$allow_quickpay = $this->db->get_where('business_settings',array('type'=>'allow_quickpay_payment'))->row()->value;
$allow_western_union = $this->db->get_where('business_settings',array('type'=>'allow_western_union'))->row()->value;
?> 
<style type="text/css">
    .customer_info_form_inputs{
        border:1px solid;
        /*border-bottom: 1px solid #B22234;*/
        border-radius: 3px;
    }
    .customer_info_form_inputs:focus{
        background-color: #f0f0f0;
    }
    .admin-label{
        font-size: 12px;
    }
    .product_checkout{
        border: 1px solid #00000052;
        border-radius: 5px;
        box-shadow: 0px 3px 4px #00000052;
        padding: 5px 0 5px 8px;
        margin: 0px 0 10px 0;
    }
    .mul{
        font-size: 17px;
        margin: 0 0 0 20px;
    }
    .cart_price{
        display: inline-block;
        font-size: 12px;
        font-weight: 700;
        margin: 0 0 0 10px;
    }
    .cancle{
        display: inline-block;
        float: right;
        margin: -11% 2% 0 0;
        font-size: 18px;
    }
    .cart_item_img {
        display: block;
        max-width:80px;
        max-height:80px;
        width: auto;
        height: auto;
    }
    .coupon_btn{
        background-color: #f3402d ;
        color:white;
        border: 1px solid #f3402d ;
    }
    .coupon_btn:hover{
        background-color: #f3402d ;
        color:white;
    }
    .coupon_success_msg{
        margin-bottom: -4px;
    }
    .discounted{
        color: gray;
        font-weight: lighter;
    }
    .order_set_discount_label{
        margin-left: 8px;
    }
    .order_set_product_title{
        font-size: 14px;
        width: 328px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .authorize_card_div .col-md-4,
    .authorize_card_div
    {
        margin-top: 0px !important;
    }
    .authorize_card_div .panel-heading{
        padding: 0px;
        padding-left: 5px;
    }
    .authorize_card_div .panel-heading .panel-title{
     font-size: 14px;
 }
 .heading-font{
    font-size: 26px;
}
.authorize_card_div_heading{
    font-size: 22px;
    margin-left: 10px;
}
.authorize_card_div .panel .panel-body{
 padding: 16px;
}
.authorize_card_div .panel-heading{
    background-color: #b22234;
    color :white;
}
.payment_method_selection label
{
    /*margin-left: 1%;*/
    font-size: 15px;
    font-weight: 500;
    text-transform: none;
}
.payment_method_selection{
    /*margin-top: 5px !important;*/
    padding-left: 0px;
}
.payment_method_selection img{
    height: auto;
}
.img_credit_card{
    margin-left: 28%;
}
.img_paypal{
    margin-right: 10px;
    float: right;
}
.img_western_union_xpress_remitly {
    margin-right: 10px;
    float: right;
}

.row_authorize_card_div{
    /*margin-top: 23px;*/
}
.side-cart{
    height: auto;
    /*width: 35%;*/
    /*position: fixed;*/
    z-index: 1;
}
.box-div{
    max-height: 300px;
    overflow: auto;
    overflow-x: hidden;
}
#authorize_card_div{
    display: none;
    margin-left: 10px; 
    margin-top: 15px!important;
}
.credit_card_box{
    background-color: #fff;
    padding: 10px 0 10px 0;
    margin: 40px 4px 0px 25px;
    border: 1px solid #555;
    border-radius: 5px;
}
.paypal_box{
    background-color: #fff;
    padding: 5px 0 5px 0;
    margin: 0px 4px 0px 25px;
    border: 1px solid #555;
    border-radius: 5px;
}
.western_union_box{
    background-color: #fff;
    padding: 5px 0 5px 0;
    margin: 0px 4px 0px 25px;
    border: 1px solid #555;
    border-radius: 5px;
}
.cash_on_delivery_box{
    background-color: #fff;
    padding: 5px 0 5px 0;
    margin: 0px 4px 0px 25px;
    border: 1px solid #555;
    border-radius: 5px;
}
.label_authorize_net,
.label_paypal,
.label_western_union_xpress_remitly
{
    margin-left: 0px !important;
    font-size: 16px;
    font-weight: bold;
}
.payment_type_err{
    margin-top: 3%;
    margin-left: 4%;
    color: red;
    font-style: italic;
    font-size: 14px;
}
.border{
    border: 1px solid red;
}
.btn_remove_coupon{
 border-radius: 50px;
}
.btn_remove_coupon:hover{
    cursor: pointer;
}
.bank_transfer_box {
    background-color: #fff;
    padding: 5px 0 5px 0;
    margin: 0px 4px 0px 25px;
    border: 1px solid #555;
    border-radius: 5px;
}

.bank-transfer-details-hide{
    margin-left: 49px;
    margin-right: 49px; 
    color: gray; 
    text-align: justify;
    width: 78%;
    height: 44px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 1.3rem;
    background: white;
}

.bank-transfer-details-show{
    margin-left: 49px;
    margin-right: 49px; 
    color: gray; 
    text-align: justify;
    font-size: 1.3rem;
    background: white;
}

</style>
<div class="col-md-7" style="margin-top:10px!important;">
   <!-- Left-aligned -->
   <div class="row ">
    <div class="col-md-12" style="margin-top:0px!important;">
        <h3 class="block-title">
            <span>
                <?php echo translate('Shipping_detail');?>
            </span>
        </h3>
    </div>    
    <div class="col-md-6" style="margin-top:20px!important;">
        <div class="form-group">    
            <div class="form-group">
                <input class="form-control required customer_info_form_inputs" value="<?php echo isset($firstname)? $firstname : '';?>" name="firstname" type="text" placeholder="Name">
            </div>
        </div>
    </div>
    <div class="col-md-6" style="margin-top:20px!important;">
        <div class="form-group">    
            <div class="form-group">
                <input class="form-control required customer_info_form_inputs" value="<?php echo isset($lastname)? $lastname : '' ;?>" name="lastname" type="text" placeholder="Last Name">
            </div>
        </div>
    </div>
    <div class="col-md-6" style="margin-top:0px!important;">
        <div class="form-group">    
            <div class="form-group">
                <input class="form-control required customer_info_form_inputs" type="email" value="<?php echo isset($email)? $email : '' ;?>" name="email"  placeholder="Email" data-rule-email="true">
            </div>
        </div>
    </div>
    <div class="col-md-6" style="margin-top:0px!important;">
        <div class="form-group">    
            <div class="form-group">
                <input class="form-control required customer_info_form_inputs" id="phone" value="<?php echo isset($phone)? $phone : ''  ;?>" name="phone" type="text" placeholder="Phone Number">
            </div>
        </div>
    </div>
    <div class="col-md-12" style="margin-top:0px!important;">
        <div class="form-group">    
            <div class="form-group">
                <input class="form-control required address customer_info_form_inputs" name="address1" value="<?php echo isset($address1)? $address1 : ''; ?>" type="text"  placeholder="Shipping Address">
            </div>
        </div>
    </div>
    <div class="col-md-4" style="margin-top:0px!important;">
        <div class="form-group">    
            <div class="form-group">
                <select class="form-control required customer_info_form_inputs" id="country" name="country">
                    <option value=""><?php echo translate("-- Select Country --"); ?></option>
                    <?php 
                    $country_det = $this->crud_model->getCountryById($country);
                    foreach($countries as $country){
                        $selected = "";
                        if($country_det['country_id'] == $country['country_id']){
                            $selected = "selected='selected' ";
                        }
                        ?>
                        <option value="<?php echo $country['country_id']; ?>" <?php echo $selected; ?>> 
                            <?php echo $country['country_name']; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="margin-top:0px!important;">
            <div class="form-group">    
                <div class="form-group">
                    <select class="form-control required customer_info_form_inputs" id="state" name="state">
                        <option value=""><?php echo translate("-- Select State --"); ?></option>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="margin-top:0px!important;">
            <div class="form-group">    
                <div class="form-group">
                    <select class="form-control required customer_info_form_inputs" id="city" name="city">
                        <option value=""><?php echo translate("-- Select City--"); ?></option>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-md-4" style="margin-top:0px!important;">
            <div class="form-group">    
                <div class="form-group">
                    <input class="form-control customer_info_form_inputs"  name="zip" type="text" value="<?php echo isset($zip)? $zip : ''; ?>" maxlength="15" placeholder="Zip Code"  data-rule-minlength="5" data-rule-maxlength="15">
                </div>
            </div>
        </div>  
        <div class="col-md-12 mt-0" id="check_bill_address">
			<label for="bill_check"  style="display: flex; align-items: center; margin-bottom: 4px; margin-top: 4px;">
				
				<div class="my_checkbox_container">
					<input type="checkbox" name="billing_check" checked='checked' id="bill_check" style="height: 20px; width: 20px;">
					<span class="my_checkmark"></span>
				</div>
				<span style="text-transform: none; font-size: 14px; font-weight: 100;">
					Billing Address Same As Shipping Address
				</span>
			</label>
		</div>
    </div>
    <div class="row billing_address mt-4" style="display: none;">
		<div class="col-md-12 mt-0">
			<h3 class="block-title">
				<span>
					<?php echo translate('Billing_detail');?>
				</span>
			</h3>
		</div>
		<div class="col-md-6" style="margin-top:20px!important;">
			<div class="form-group">
				<input class="form-control billValidate customer_info_form_inputs" value="<?php echo (isset($bill_firstname) ? $bill_firstname  : ""); ?>" name="bill_firstname" id="bill_firstname" type="text" placeholder="First Name*">
			</div>
		</div>
		<div class="col-md-6" style="margin-top:20px!important;">
			<div class="form-group">
				<input class="form-control billValidate customer_info_form_inputs" value="<?php echo (isset($bill_lastname) ? $bill_lastname : ""); ?>" name="bill_lastname" id="bill_lastname" type="text" placeholder="Last Name*">
			</div>
		</div>
		<div class="col-md-6 mt-0">
			<div class="form-group">
				<input class="form-control billValidate customer_info_form_inputs" type="email" value="<?php echo (isset($bill_email) ? $bill_email : ""); ?>" name="bill_email" id="bill_email"  placeholder="Email*" data-rule-email="true">
			</div>
		</div>
		<div class="col-md-6 mt-0">
			<div class="form-group">
				<input class="form-control billValidate customer_info_form_inputs" id="bill_phone" value="<?php echo (isset($bill_phone) ? $bill_phone : ""); ?>" name="bill_phone" type="text" placeholder="Phone Number*">
			</div>
		</div>
		<div class="col-md-12 mt-0" style="">
			<div class="form-group">
				<input class="form-control billValidate address customer_info_form_bill_inputs" name="bill_address" id="bill_address" value="<?php echo (isset($bill_address ) ? $bill_address : ""); ?>" type="text"  placeholder="Shipping Address*">
			</div>
		</div>
		<div class="col-md-4 mt-0" style="">
			<div class="form-group">
				<select class="form-control billValidate customer_info_form_inputs country" id="bill_country" name="bill_country">
					 <option value=""><?php echo translate("-- Select Country* --"); ?></option>
					<?php
						foreach($countries as $country){
							$selected = "";
						?>
						<option value="<?php echo $country['country_id']; ?>" <?php echo $selected; ?>>
						<?php echo $country['country_name']; ?></option>
					<?php } ?>
				</select>
			</div>
		</div>
		<div class="col-md-4 mt-0" style="">
			<div class="form-group">
				<select class="select2 form-control billValidate customer_info_form_inputs state" id="bill_state" name="bill_state">
					<option value=""><?php echo translate("-- Select State* --"); ?></option>
				</select>
			</div>
		</div>
		<div class="col-md-4 mt-0" style="">
			<div class="form-group">
				<select class=" select2 form-control billValidate customer_info_form_inputs city" id="bill_city" name="bill_city">
					<option value=""><?php echo translate("-- Select City* --"); ?></option>
				</select>
			</div>
		</div>
		<div class="col-md-4 mt-0">
			<div class="form-group">
				<input class="form-control customer_info_form_inputs"  name="bill_zip" id="bill_zip" type="text" value="<?php echo (isset($bill_zip ) ? $bill_zip : ""); ?>"  placeholder="Zip Code*"  data-rule-minlength="5" data-rule-maxlength="10">
			</div>
		</div>
	</div>

    <div class="row">
        <?php if($allow_autorize_net == "ok"){ ?>
            <div class="cc-selector col-sm-12 payment_method_selection" style="margin-top: 18px;">
                <h3 class="block-title">
                    <span>
                        <?php echo translate('payment_Method');?>
                    </span>
                </h3>
                <div class="form-group credit_card_box">
                    <label class="checkbox-inline" for="chk_payment_method_1">
                        <div class="my_radio_container">
                            <input type="radio" required="required" name="payment_type" id="chk_payment_method_1" value="authorize_net" class="checkbox-inline chk_payment_type" onclick="radio_check('authorize_net')">
                            <span class="my_radio_checkmark"></span>
                        </div>
                    </label>
                    <span class="label_authorize_net">Credit / Debit Card</span>
                    <img src="<?= base_url('uploads/payment_img/payment_card_img.png') ?>" alt="AUthorize NET" class="img_credit_card" style="width: 209px;margin: 12px 10px 0 20%;float: right;"/>
                    <div style="margin-left: 49px;color: gray;">Pay with Visa , Amex, Master Card</div>
                    <div style="margin-left: 49px; color: gray;">Discover and many other credit cards and debit cards</div>
                </div>
            </div>    
            <div id="authorize_card_div" class="cc-selector col-sm-12 payment_method_selection">
                <div class="row row_authorize_card_div">
                    <div class="col-md-12 authorize_card_div">
                        <div class="">
                            <div class="panel-body ">       
                                <div class="row">
                                    <div class="col-md-12" style="margin-top: 0px!important;">
                                        <div class="form-group">
                                            <label for="cardNumber">
                                                <?php echo translate("card_number"); ?>
                                            </label>
                                            <div class="input-group input_group_card_number">
                                                <input type="number" class="form-control ignore" id="cardNumber" name="card_number" title="Card Number" placeholder="Card Number"
                                                value="" autofocus required="required"  data-rule-minlength="13"/>
                                                <span class="input-group-addon" style="border: 1px solid #555;"><span class="glyphicon glyphicon-lock"></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>                                              
                                <div class="row">
                                    <div class="col-md-4">
                                        <label for="expityMonth">
                                            <?php echo translate("Month"); ?></label>
                                            <input type="text" class="form-control ignore" id="expityMonth" name="expirymonth"  title="Expiry Month" placeholder="MM" value="" required="required" data-rule-minlength="2" data-rule-maxlength="2"/>
                                        </div>        
                                        <div class="col-md-4">
                                            <label for="expiryyear">
                                                <?php echo translate("Year"); ?></label>
                                                <select  class="form-control ignore" id="expityYear" name="expiryyear" required="required">
                                                    <option value=""><?php echo translate("Select"); ?></option>
                                                    <option value="<?php echo date("Y"); ?>"><?php echo date("Y");?></option>
                                                    <?php 
                                                    for($i=1; $i<=20; $i++){
                                                        ?>
                                                        <option value="<?php echo (date("Y")+$i);?>"><?php echo (date("Y")+$i);?></option>
                                                    <?php } ?>
                                                    <option value="<?php echo (date("Y")+$i);?>"><?php echo (date("Y")+$i);?></option>
                                                </select>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="cvCode">
                                                    <?php echo translate("CVC / CVV"); ?></label>
                                                    <input type="password" class="form-control ignore" id="cvCode" name="cv_code"  title="CVC / CVV"  value=""  placeholder="CVC / CVV" required required="required" data-rule-minlength="3"/>
                                                </div>
                                            </div>  
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }?>


                    <?php 
			if($allow_paypal)
			{
		?>
		<div class="cc-selector col-sm-12 payment_method_selection" style="margin-top: 25px!important;">
			<div class="form-group paypal_box">
				<div>
					<label class="checkbox-inline payment_labels" for="chk_payment_method_2">
						<div class="my_radio_container">
							<input type="radio" name="payment_type" id="chk_payment_method_2" required="required" value="paypal" class="checkbox-inline chk_payment_type" onclick="radio_check('visa')">
							<span class="my_radio_checkmark"></span>
						</div>
					<span class="label_paypal">PayPal</span>
					<img src="<?= base_url('uploads/payment_img/paypal_payment.png') ?>"  alt="<?php echo translate('paypal');?>" class="img_paypal" width="100"/>
					<div style="font-weight:normal;color: gray;">Pay easily, fast and secure with PayPal</div>
					</label>
				</div>
			</div>
			<div class="form-group">
				<div class="payment_type_err"></div>
			</div>
		</div>
		<?php } ?>



                <?php if($allow_cod == "ok"){?>
                    <div class="cc-selector col-sm-12 payment_method_selection" style="margin-top: 10px !important;">
                        <div class="form-group cash_on_delivery_box">
                            <div  style=""> 
                             <label class="checkbox-inline" for="chk_payment_method_3">
                                <div class="my_radio_container">
                                    <input type="radio" name="payment_type" id="chk_payment_method_3" required="required" value="cash_on_delivery" class="cash_on_delivery checkbox-inline chk_payment_type" onclick="radio_check('cash_on_delivery')">
                                    <span class="my_radio_checkmark"></span>
                                </div>
                            </label>
                            <span class="label_paypal">COD</span>
                            <img src="<?= base_url('uploads/payment_img/cod_img.png') ?>"  class="img_paypal" width="100"/>
                            <div style="margin-left: 49px; color: gray;">
                                Pay with cash upon delivery. For COD Orders above Rs.15,000, you will need to submit 25% Advance Payment. Payment details will be send to you via email.
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="payment_type_err"></div>
                    </div>
                </div>
            <?php }?>

            <?php if($allow_bank_tranfer == "ok"){?>
                <div class="cc-selector col-sm-12 payment_method_selection" style="margin-top: 10px !important;">
                    <div class="form-group bank_transfer_box">
                        <div  style=""> 
                         <label class="checkbox-inline" for="chk_payment_method_4">
                            <div class="my_radio_container">
                                <input type="radio" name="payment_type" id="chk_payment_method_4" required="required" value="bank_transfer" class="bank_transfer checkbox-inline chk_payment_type" onclick="radio_check('bank_transfer')">
                                <span class="my_radio_checkmark"></span>
                            </div>
                        </label>
                        <span class="label_paypal">Bank Tranfer</span>
                        <img src="<?= base_url('uploads/payment_img/transfer.png') ?>"  class="img_paypal" width="50"/>
                        <div id="bank-transfer-details" class="bank-transfer-details-hide">
                            Dear Customer,<br>Thanks for placing an order at Femina Attire and Showing interest in our Wardrobe. If you like to continue with your order, Make your payment directly into our bank account. Bank Account details will be shown once you complete this Order. Please use your Order ID as the payment reference. Your order will not be shipped until the funds have cleared in our account.<br>Please find below Mode of Payment Details:<br>Note: As per Pakistan’s Law Customer has to pay 5 % extra withholding tax of Total Invoice Amount if he/she likes to Transfer Amount in Company Account.<hr>Note: If Customer likes to send payment as Family Remittance this account can be used for it, as no tax will be applied on invoice amount. This is Authorized Account of Company’s Corporate Head Mr. Nabeel Ahmed Khan.<br>In case of any queries please what app at +92-311-2900343, our Customer Care will guide you properly!<br>Regards,Team Femina Attire
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="payment_type_err"></div>
                </div>
            </div>
        <?php }?>

        <?php if($allow_quickpay == "ok"){?>
            <div class="cc-selector col-sm-12 payment_method_selection" style="margin-top: 10px !important;">
                <div class="form-group cash_on_delivery_box">
                    <div  style=""> 
                     <label class="checkbox-inline" for="chk_payment_method_5">
                        <div class="my_radio_container">
                            <input type="radio" name="payment_type" id="chk_payment_method_5" required="required" value="quick_pay" class="checkbox-inline chk_payment_type" onclick="radio_check('quick_pay')">
                            <span class="my_radio_checkmark"></span>
                        </div>
                    </label>
                    <span class="label_paypal">Quick Pay</span>
                    <img src="<?= base_url('uploads/payment_img/quick_pay.png') ?>"  class="img_paypal" width="100"/>
                    <div style="margin-left: 49px; color: gray;">Quick Pay</div>
                </div>
            </div>
            <div class="form-group">
                <div class="payment_type_err"></div>
            </div>
        </div>
    <?php }?>
        <?php if($allow_western_union == "ok"){?>
            <div class="cc-selector col-sm-12 payment_method_selection" style="margin-top: 10px!important;">
                <div class="form-group western_union_box">
                    <div  style=""> 
                        <label class="checkbox-inline" for="chk_payment_method_5">
                            <div class="my_radio_container">
                                <input type="radio" name="payment_type" id="chk_payment_method_5" required="required" value="western_union_xpress_remitly" class="western_union_xpress_remitly checkbox-inline chk_payment_type" onclick="radio_check('western_union_xpress_remitly')">
                                <span class="my_radio_checkmark"></span>
                            </div>
                        </label>
                        <span class="label_western_union_xpress_remitly">Western Union | Xpress Money | Remitly Details</span>
                        <img src="<?= base_url('uploads/payment_img/western_union_xpress_remitly.png') ?>"  alt="<?php echo translate('Western Union|Xpress|Remitly');?>" class="img_western_union_xpress_remitly" width="200"/>
                        <div style="margin-left: 49px; color: gray;">
                            Pay easily, fast and secure.
                            <br>
                            Name: Nabeel Ahmed Khan
                            <br>
                            Bank Name: United Bank Limited
                            <br>
                            Account no: 0147-2335-4774-3
                            <br>
                            IBAN #: PK94-UN IL-0109-0002-3354-7743
                            <br>
                            Swift Code: UNILPKKA
                            <br>
                            Branch Address: 295-296 PECHS Karachi, Pakistan
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="western_union_type_err"></div>
                </div>
            </div>
        <?php }?>
</div>
<input type="hidden" id="first" value="yes"/>
<div class="row">
    <div class="col-md-12" style="margin-top: 0px;">
        <button class="btn btn-md btn_next_address btn-block" disabled id="order_place_btn" type="submit"> 
            <i class="fa fa-shopping-cart"></i>
            <?php echo translate('proccess_with_payment');?>
        </button>
    </div>
</div>
<div class="row">
    <div class="col-md-12" style="margin-top: 10px;">
        <a class="btn pull-right btn_next_cancel btn-block" href="<?php echo base_url('home'); ?>">
            <i class="fa fa-repeat"></i>
            <?php echo translate('continue_shopping');?>
        </a>
    </div>
</div>
</div>
<div class="col-md-5" style="margin-top: 10px">
    <div class="side-cart"> 
        <h3 class="block-title">
            <span>
                <?php echo translate('shopping_cart');?>
            </span>
        </h3>
        <div class="shopping-cart" style="background: #fff;margin-top: 28px;">
            <div class="box-div">
               <?php 
               $coupon_data = $this->session->userdata("coupon_data");
               $carted = $this->cart->contents(); 
               $cart_count = 1;
               foreach ($carted as $items){ 
                $variant_images = json_decode($items['options']['image']);
                $product_id = $items['options']['product_id'];
                ?>
                <div class="media product_checkout" id="cart_item_media_<?php echo $cart_count; ?>">
                    <div class="media-left">
                        <a class="media-link" href="<?php echo  base_url("home/product_view/".$product_id."/".$this->crud_model->infiltrate_unwated_character($items['name'])); ?>" target="_blank">
                            <i class="fa fa-plus"></i>
                            <img src="<?php echo $this->crud_model->get_image('product_variants' , $variant_images[0])?>" class="media-object cart_item_img" style="width:40px">
                        </a>  
                    </div>
                    <div class="media-body">
                        <?php
                        $title = str_replace("'", "", $items['name']);
                        $title = str_replace('"', "", $title );
                        ?>
                        <h4 class="order_set_product_title my_tooltip" title="<?php echo $title; ?>">
                            <a href="<?php echo  base_url("home/product_view/".$product_id."/".$this->crud_model->infiltrate_unwated_character($items['name'])); ?>" target="_blank">
                                <?php echo $title; ?>
                            </a>
                        </h4>
                        <div class="" style="height: 42px;margin: -5px 0 0 -9px;">  
                            <div class="quantity cart_price ">
                                <?php
                                if($items['options']['discount']>0){
                                    ?>
                                    <span class="without_discounted">
                                        <?php echo currency($this->crud_model->get_product_price($items['id'])); ?>
                                    </span>
                                    <span class="discounted">
                                       <strike><?php echo currency($this->crud_model->get_type_name_by_id("product_variants",$items['id'],"selling_price")); ?></strike>
                                   </span>
                               <?php  } else{?>
                                   <span class="without_discounted">
                                    <?php echo currency($items['price']); ?>
                                </span>
                            <?php } ?>
                        </div>
                        <?php $variant_color =  $items['options']['color'];?>
                        <span style="margin-left: 5px; font-size: 12px;">
                            X
                            <strong class="prod_size_label"><?php echo translate("Qty : "); ?></strong>
                            <span class="prod_size_val"><?php echo $items['qty']; ?></span>&nbsp;
                            <?php if($items['options']['actual_size']!=""){?>
                                <strong class="prod_size_label"><?php echo translate("Size : "); ?></strong>
                                <span class="prod_size_val"><?php echo $items['options']['actual_size']; ?></span>
                            <?php } ?>
                            &nbsp;
                            <?php if($variant_color!="" ){?>
                                <strong class="prod_color_label"><?php echo translate("Color : "); ?></strong>
                                <span class="prod_color_val">
                                    <?php echo $variant_color; ?>
                                </span>
                            <?php } ?>
                        </span>
                    </div>     
                    <div class="total" style="margin-top: -5%;">
                        <span class="close cancle order_set_remove_item" style="color:#f00; opacity: 1!important" data-rowid="<?php echo $items['rowid']; ?>" data-media-id="cart_item_media_<?php echo $cart_count; ?>">
                            <i class="fa fa-times"></i>
                        </span>
                    </div>
                </div>
            </div>
            <?php  $cart_count++; } ?>
        </div>
        <?php 
        if(!$coupon_data || ($coupon_data && $coupon_data['set_coupon'] != 1)){ 
            ?>
            <div class="coupon_enter_area" style="border-top: 2px solid #B22234; border-bottom: 2px solid #B22234; margin: 13px 0 8px 0; padding: 7px 0 15px 0;">
                <h5>
                    <?php echo translate('enter_your_coupon_code_if_you_have_one');?>.
                </h5>
                <div class="form-group">
                    <input type="text" class="form-control coupon_code ignore" placeholder="Enter your coupon code">
                </div>
                <span class="btn btn-block btn-default coupon_btn">
                    <?php echo translate('apply_coupon');?>
                </span>
            </div>
        <?php } else { ?>
            <p style="border-top: 2px solid #B22234; border-bottom: 2px solid #B22234; margin: 13px 0 8px 0; padding: 7px 0 7px 0;">
              <?php echo translate('coupon_already_activated'); ?>
            </p>
        <?php } ?>
      <table>
        <tr>
            <td><?php echo translate('subtotal');?>:</td>
            <td id="total"></td>
        </tr>
        <tr>
            <td><?php echo translate('Discount Coupon');?>:</td>
            <td  id="discount_coupon">
                <?php
                if(!$this->session->has_userdata("coupon_data")){
                 echo "-"; 
             }else{
                echo $coupon_data['discount_amount_for_user'];
            }
            ?>
            <?php
            if($this->session->has_userdata("coupon_data")){
               ?>
               &nbsp;<span class="label label-danger btn_remove_coupon" title="Remove Coupon">&times;</span>
           <?php  } ?>
       </td>
        </tr>
        <tr>
         <td colspan="2"><h6 style="font-weight: 900 !important; margin: 0;"><?php echo translate('Shipping_charges');?></h6></td>
        </tr>
        <tr>
         <td id="shipping_title"></td>    
         <td id="shipping_charges"></td>    
         <input type="hidden" name="hdd_shipping_charges" id="hdd_shipping_charges">
        </tr>   
        <tr>
            <td><?php echo translate('No of Items');?>:</td>
            <td  id="total_item"></td>
        </tr>
<tfoot>
    <tr>
        <td><?php echo translate('total');?>:</td>
        <td class="grand_total" id="grand"></td>
        <input type="hidden" name="hdd_grand_amount" id="hdd_grand_amount">
    </tr>
    <?php if($this->wallet_model->user_balance() > 0){?>
        <tr>
            <td>Balance : </td>
            <td id="user_balance"></td>
            <input type="hidden" name="hdd_user_balance" id="hdd_user_balance">
            <input type="hidden" name="hdd_panned_balance" id="hdd_panned_balance">
        </tr>
        <tr>
            <td colspan="2" class="grand_total" id="grand">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="1" id="pan_from_wallet" name="pan_from_wallet" id="flexCheckIndeterminateDisabled">
                    <label class="form-check-label" for="flexCheckIndeterminateDisabled"> <?php echo translate('pan from wallet');?></label>
                </div>
            </td>
        </tr>
    <?php };?>

    <!-- <tr class="<?php //echo ($this->crud_model->CheckAllowedTax()) ? 'show' : 'hide'?>"> -->
        <!-- <td><?php //echo translate('tax');?> -( <span class="tax_percent">0</span>% ):</td> -->
        <!-- <td class="tax" id="tax">0</td> -->
    <!-- </tr> -->
    <!-- <tr>
        <td><?php //echo translate('net_total');?>:</td>
        <td class="net_total" id="net_total"></td>
    </tr> -->
</tfoot>
</table>
</div>
</div>
</div>
<?php
echo form_open('', array(
    'method' =>
    'post', 'id' => 'coupon_set' )); 
    ?> 
    <input type="hidden" id="coup_frm" name="code">
</form>
<script type="text/javascript">
    $(document ).ready(function() {
        $(document).on("click",".btn_remove_coupon",function(){
            $(".overlay_holder1").show();
            window.location.href = '<?php echo base_url("home/remove_coupon"); ?>';
        });
        $(".coupon_code").keydown(function(e){
            if(e.keyCode==13){
                $(".coupon_btn").trigger("click");
            }
        });

        $("#chk_payment_method_1").click(function() {
            $("#authorize_card_div").show();
        });

        $('#bill_check').click(function() {
            if ($(this).prop("checked")) {
                $(".billing_address").hide();
                $(".billValidate").removeClass("required");
                $(".billValidate").addClass("ignore");
			}else{
                $(".billing_address").show();
                $(".billValidate").addClass("required");	
                $(".billValidate").removeClass("ignore");							
			}
		// 	var form = $("#cart_form");
		// 	if(form.valid()){
  //               if($("#is_shipping_avlb").val() == 1){
  //                   $('#order_place_btn').removeAttr("disabled");
  //               }
  //           } 
  //           else {
  //              $('#order_place_btn').attr("disabled",true);
  //           }
		});

        if ('<?php echo $billing_check?>'==1) {
		    // $("#bill_check").trigger("click");
		    $("#bill_check").prop("checked", true);
		    $(".billing_address").hide();
            $(".billValidate").removeClass("required");
            $(".billValidate").addClass("ignore");
		    // $('#bill_check').trigger('click');
	    }else{
	    	$("#bill_check").prop("checked", false);
	    	$(".billing_address").show();
            $(".billValidate").addClass("required");	
            $(".billValidate").removeClass("ignore");
	    }

        var country = $("#country").val();
        var state = $("#state").val();


        whole_cart_total();
        // set_cart_map();
        $("#country").change(function(){
            var  country_id = $(this).val();
            if(country_id!=""){
                if (country_id != "3913") {  //For Pakistan
                    $('.cash_on_delivery_box').parent().hide();
                    if ($('.cash_on_delivery').is(':checked')) {
                        $('.cash_on_delivery').prop('checked', false);
                        $('#order_place_btn').html(`<i class="fa fa-shopping-cart"></i> Proccess With Payment`);
                        $('#order_place_btn').prop('disabled', true);
                    }

                }else{
                    $('.cash_on_delivery_box').parent().show();
                }
                var data = {
                    country_id: country_id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
                };
                $.ajax({
                    url : '<?php echo base_url('home/get_state_by_country_id'); ?>',
                    type : 'POST',
                    data : data,
                    success : function(response){
                        var converted = JSON.parse(response);
                        if(converted.status == "1"){
                            var state_opt = "";
                            $.each(converted.data,function(ind , val){
                                if(val.state_id == '<?php echo (isset($state_del) && $state_del)? $state_del['state_id'] : ''; ?>'){
                                    state_opt +="<option value='"+val.state_id+"' selected='selected'>"+val.state_name+"</option>";
                                }else{
                                    state_opt +="<option value='"+val.state_id+"'>"+val.state_name+"</option>";
                                } 
                            });
                            $("#state").html(state_opt);
                            $("#state").trigger('change');                            
                        }else{
                            $('#state').html(`<option value=""><?php echo translate("-- Select State --"); ?></option>`);
                            $("#city").html("<option value=''>-- Select City --</option>");
                        }
                       whole_cart_total();
                    }   
                });
            }else{
                $("#state").html("<option value=''>-- Select --</option>");
                $("#city").html("<option value=''>-- Select --</option>");
                $(".overlay_holder1").hide();
            }
        });

        // bill country change mechanism
        $("#bill_country").change(function(){
			// console.log($(this).attr('id'));
            var country_id = $(this).val();
            if(country_id!=""){
                var data = {
                    country_id: country_id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
				};
                $.ajax({
                    url : '<?php echo base_url('home/get_state_by_country_id'); ?>',
                    type : 'POST',
                    data : data,
                    success : function(response){
                        var converted = JSON.parse(response);
                        if(converted.status == "1"){
                            var state_opt = "";
                            $.each(converted.data,function(ind , val){
                                if(val.state_id == '<?php echo (isset($bill_state_del) && $bill_state_del)? $bill_state_del['state_id'] : ''; ?>'){
                                    state_opt +="<option value='"+val.state_id+"' selected='selected'>"+val.state_name+"</option>";
                                }else{
                                    state_opt +="<option value='"+val.state_id+"'>"+val.state_name+"</option>";
                                } 
                            });
                            $("#bill_state").html(state_opt);
                            $("#bill_state").trigger('change');                            
                        }else{
                            $('#bill_state').html(`<option value=""><?php echo translate("-- Select State --"); ?></option>`);
                            $("#bill_city").html("<option value=''>-- Select City --</option>");
                        }
                    }   
                });
			}else{
                $("#bill_state").html("<option value=''>-- Select State*--</option>");
                $("#bill_city").html("<option value=''>-- Select City*--</option>");
                $(".overlay_holder1").hide();
			}
		});
        $("#state").change(function(){
            var  state_id = $(this).val();
            if(state_id!=""){
                var data = {
                    state_id: state_id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
                };
                $.ajax({
                    url : '<?php echo base_url('home/get_city_by_state_id'); ?>',
                    type : 'POST',
                    data : data,
                    success : function(response){
                        var converted = JSON.parse(response);
                        if(converted.status == "1"){
                           var city_opt = "";
                            $.each(converted.data,function(ind , val){
                                if(val.city_id == '<?php echo (isset($city_del) && $city_del)? $city_del['city_id'] : ''; ?>'){
                                    city_opt +="<option value='"+val.city_id+"' selected='selected'>"+val.city_name+"</option>";   
                                }else{
                                    city_opt +="<option value='"+val.city_id+"'>"+val.city_name+"</option>";   
                                }
                            });
                           $("#city").html(city_opt);
                           whole_cart_total();
                        }
                        else{
                            $("#city").html("<option value=''>-- Select --</option>");
                        }
                    }
                });
            }else{
                $("#city").html("<option value=''>-- Select --</option>");
            }
        });
        $("#bill_state").change(function(){
			
			var  state_id = $(this).val();
            if(state_id != ""){
                var data = {
                    state_id: state_id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
				};
                $.ajax({
                    url : '<?php echo base_url('home/get_city_by_state_id'); ?>',
                    type : 'POST',
                    data : data,
                    success : function(response){
                        var converted = JSON.parse(response);
                        if(converted.status == "1"){
                           var city_opt = "";
                            $.each(converted.data,function(ind , val){
                                if(val.city_id == '<?php echo (isset($bill_city_del) && $bill_city_del)? $bill_city_del['city_id'] : ''; ?>'){
                                    city_opt +="<option value='"+val.city_id+"' selected='selected'>"+val.city_name+"</option>";   
                                }else{
                                    city_opt +="<option value='"+val.city_id+"'>"+val.city_name+"</option>";   
                                }
                            });
                           $("#bill_city").html(city_opt);
                        }
                        else{
                            $("#bill_city").html("<option value=''>-- Select --</option>");
                        }
                    }
                });
			}else{              
                $("#bill_city").html("<option value=''>-- Select City* --</option>");			
			}
		});

        $('#city').change(function(){
            whole_cart_total();
        });

        $('#pan_from_wallet').change(function(){
            whole_cart_total();
        });
        
        $(".my_tooltip").tooltip();
        $('body').on('click','.order_set_remove_item', function(){
            $(".overlay_holder1").show();
            var here = $(this);
            var rowid = here.attr('data-rowid');
            var media_id = here.attr('data-media-id');
            var list1 = $('#total');
            $.ajax({
                url: base_url+'home/cart/remove_one/'+rowid,
                beforeSend: function() {
                    list1.html('...');
                },
                success: function(data) {
                    list1.html(data).fadeIn();
                    notify('Item Removed Successfully','success','bottom','right');
                    //sound('cart_product_removed');
                    $("#"+media_id).remove();
                    reload_header_cart();
                    whole_cart_total();
                    if(data == 0){
                        location.replace('<?php echo base_url();?>');   
                    }
                    $(".overlay_holder1").hide();
                },
                error: function(e) {
                    console.log(e)
                }
            });
        });


        $("#cardNumber , #expityMonth , #expityYear , #cvCode").keyup(function(e){
            $(this).parent().next(".credit_card_error").remove();
            $(this).next(".credit_card_error").remove();
        });
        if(country!=""){
            $("#country").trigger('change');
        }
        // $("input[name='zip']").mask('99999-9999');
    });
</script>

<script src="<?= base_url('') ?>template/front/js/intlTelInput/intlTelInput.js"></script>
<script src="<?= base_url('') ?>template/front/js/intlTelInput/intlTelInput-jquery.js"></script>

<script>
    var input = document.querySelector("#phone");
    window.intlTelInput(input, {
      allowDropdown: true,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
    //   geoIpLookup: function(callback) {
    //     $.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
    //       var countryCode = (resp && resp.country) ? resp.country : "";
    //       callback(countryCode);
    //     });
    //   },
      // hiddenInput: "full_number",
      initialCountry: "tr",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['pk','us'],
      // placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
      separateDialCode: true,
      utilsScript: "template/front/js/intlTelInput/utils.js",
  });
  var input2 = document.querySelector("#bill_phone");
    window.intlTelInput(input2, {
      allowDropdown: true,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
    //   geoIpLookup: function(callback) {
    //     $.get("https://ipinfo.io", function() {}, "jsonp").always(function(resp) {
    //       var countryCode = (resp && resp.country) ? resp.country : "";
    //       callback(countryCode);
    //     });
    //   },
      // hiddenInput: "full_number",
      initialCountry: "tr",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['pk','us'],
      // placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
      separateDialCode: true,
      utilsScript: "template/front/js/intlTelInput/utils.js",
  });
</script>