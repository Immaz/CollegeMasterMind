<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style type="text/css">
            @media only screen and (max-width: 1024px)
            {
                *{
                    -webkit-font-smoothing: antialiased;
                }
                .content_holder{
                    width: 80% !important;
                }
            }
            @media only screen and (max-width: 800px)
            {
                *{
                    -webkit-font-smoothing: antialiased;
                }
                .content_holder{
                    width: 90% !important;
                }
                .intro_txt{
                    font-size: 12px;
                }
                .order_no,
                .label_customer_info,
                .label_item_desc,
                .label_paymt_detail
                {
                    font-size: 14px !important;
                }
                .tbl_customer_info,
                .tbl_order_summary
                {
                    font-size: 12px;
                }
                .prod_title,
                .paymt_spec
                {
                    font-size: 10px !important;
                }
                .prod_specs{
                    font-size: 8px !important;
                }
                .sub_total,
                .qty
                {
                    font-size: 12px !important;
                }
                .related_prod_holder{
                    width: 100% !important;
                }
                .related_prod_holder .grid{
                    height: auto !important;
                    width: 40% !important;
                }
                .related_prod_holder .grid .img_cover{
                    width: 90% !important;
                    height: 35vw !important;
                }
                .related_prod_holder .grid .price{
                    font-size: 12px;
                }
                .related_prod_holder .grid .title{
                    font-size: 13px !important
                }
            }
        </style>
    </head>
    <body>
        <?php 
            $sale_details = $this->db->get_where('sale',array('sale_id'=>$sale_id))->row_array();
            $featured_products = $this->crud_model->getFeaturedProducts();
            $info = json_decode($sale_details['shipping_address'],true);
            $product_details = json_decode($sale_details['product_details'], true);
        ?>
        <div style="width: 50%; margin: auto;" class="content_holder">
            <center>
                <img src="<?php echo $this->crud_model->logo('home_top_logo'); ?>" alt=""  style="width: 150px;">
                <h3 style="font-size: 24px; font-weight: bolder; margin-top: 20px; margin-top: 50px; color: #4e4e4e;">New Order Confirmation</h3>
            </center>
            <hr style="border:0.5px solid #ccc; margin:30px 0px;" />
            <p style="color: gray;">
                Hey Admin,<br /><br />
                This email is to confirm that you have a new order at Faminattire.<br /><br />
                The Order Details are as follows.
            </p>
            <p  style="color: gray;">
                Thanks,<br />
                Team Faminattire.com
            </p>
            <hr style="border:0.5px solid #ccc; margin:30px 0px;" />
            <strong style="font-size: 20px;color: #4e4e4e;font-weight: bolder;" class="order_no">ORDER NO. <?php echo $sale_details['sale_code']; ?></strong><br />
            <p style="color: gray; font-size: 12px; margin-top: 5px;"><?php echo date('d M, Y',$sale_details['sale_datetime'] );?></p>
            <strong style="font-size: 20px;color: #4e4e4e;font-weight: bolder;" class="label_customer_info">Customer Info</strong><br />
            <table style="margin: 15px 0px; width: 100%;" cellspacing="0" class="tbl_customer_info">
                <tr>
                    <td  style=" padding: 2px 8px; color: gray;"><strong><?php echo translate('name');?></strong> </td>
                    <td style=" padding: 2px 8px; text-align: right;  color: gray;">
                        <?php echo $info['firstname']." ".$info['lastname']; ?>
                    </td>
                </tr>
                <tr>
                    <td style=" color: gray; padding:2px 8px;">
                         <b><?php echo translate('phone');?> </b>
                    </td>
                    <td style=" color: gray; padding:2px 8px; text-align: right;">
                        <?php echo $info['phone']; ?>
                    </td>
                </tr>
                <tr>
                    <td style=" color: gray; padding: 2px 8px; ">
                       <b> <?php echo translate('e-mail');?></b> 
                    </td> 
                    <td style=" color: gray; padding:2px  8px; text-align: right;">
                        <?php echo $info['email']; ?>
                    </td>   
                </tr>
                <tr>
                    <td style=" padding:2px 8px; color: gray;;">
                        <b><?php echo translate('address');?></b> 
                    </td>
                    <td style=" padding: 2px 8px; text-align: right;  color: gray;">
                        <?php echo $info['address1']; ?> 
                    </td>
                </tr>
                <tr>
                    <td style=" color: gray; padding:2px 8px; ">
                       <b> <?php echo translate('city');?></b> 
                    </td> 
                    <td style=" color: gray; padding: 2px 8px; text-align: right;">
                        <?php echo  $this->crud_model->get_type_name_by_id('city', $info['city'] , 'city_name')?>
                    </td>   
                </tr>
                <tr>
                    <td style=" color: gray; padding: 2px 8px; ">
                       <b> <?php echo translate('state');?></b> 
                    </td> 
                    <td style=" color: gray; padding:2px 8px; text-align: right;">
                        <?php echo $this->crud_model->get_type_name_by_id('state', $info['state'] , 'state_name')?>
                    </td>   
                </tr>
                <tr>
                    <td style=" padding: 2px 8px;  color: gray;">
                        <b><?php echo translate('Zip Code');?></b> 
                    </td>
                    <td style=" color: gray; padding:2px 8px; text-align: right;">
                        <?php echo $info['zip']; ?> 
                    </td>
                </tr>
                <tr>
                    <td style=" color: gray; padding: 2px 8px; ">
                       <b> <?php echo translate('country');?></b> 
                    </td> 
                    <td style=" color: gray; padding:2px 8px; text-align: right;">
                        <?php echo $this->crud_model->get_type_name_by_id('country', $info['country'], 'country_name') ?>
                    </td>   
                </tr>
            </table>
            <strong style="font-size: 20px;color: #4e4e4e;font-weight: bolder;" class="label_item_desc">Item Description</strong><br />
            <hr style="border:0.5px solid #ccc;" />
            <?php
                    //echo "<pre>";print_r($this->cart->contents());echo "</pre>";
                    $total = 0;
                    $color_arr = array();
                    $img_arr = array();
                    foreach ($product_details as $row1) {
                    $total += $row1['subtotal'];
                    if( $row1["options"]["color"]!=""){
                        $color_arr = json_decode($row1["options"]["color"],true);
                    }
                    if( $row1["options"]["image"]!=""){
                        $img_arr = json_decode($row1["options"]["image"],true);
                    }
                ?> 
                    <div style="width: 100%; display: flex !important; padding: 10px 0px;  align-items: center;">
                        <div style="width: 10%; display: inline-block;  padding: 0px 10px;">
                            <?php if(isset($img_arr[0])){?>
                                <center>
                                    <img src="<?php echo base_url("uploads/product_variants_image/".$img_arr[0]); ?>" style="width: 100%;">
                                </center>
                            <?php }else{ ?>
                                <center>
                                    <img src="<?php echo base_url("uploads/product_variants_image/default.jpg"); ?>" style="width: 100%;">
                                </center>
                            <?php } ?>
                        </div>
                        <div style="width: 60%; display: inline-block;  padding: 0px 10px;">
                            <p style="margin: 2px 0px; font-size: 16px; margin-left: 10%;" class="prod_title"><?php echo $row1["name"]; ?></p>
                            <?php 
                            if($row1["options"]["actual_size"]!=""){
                            ?>
                            <strong style="color: gray;  font-size: 14px; margin-left: 10%;" class="prod_specs"><?php echo $row1["options"]["actual_size"]; ?> / </strong>
                            <?php } ?>
                            <?php if(count($color_arr)>0){?>
                                <?php foreach($color_arr as $color){?>
                                    <strong style="color: gray; font-size: 14px;" class="prod_specs"><?php echo $color; ?></strong>
                                <?php } ?>
                            <?php }?>
                        </div>
                        <div style="width: 10%; display: inline-block; padding: 0px 10px;  text-align: center;" class="qty">
                            &times;<?php echo  $row1["qty"]; ?>
                        </div>
                        <div style="width: 20%;  display: inline-block; padding: 0px 10px; text-align: center;" class="sub_total">
                            <div style="margin-left: 20%;"><?php echo currency($row1['subtotal']); ?></div>
                        </div>
                   </div>
                   <hr style="border:0.5px solid #ccc;" />
            <?php  } ?>
            <table style="width: 100%;" class="tbl_order_summary">
                <tr>
                    <td style="padding: 5px; color: #4e4e4e;"><b><?php echo translate('sub_total_amount');?> :</b></td>
                    <td style="text-align: right;     color: #4e4e4e;">
                        <?php echo $total = currency(str_replace(",", "", $total)); ?>
                    </td>
                </tr>
                <tr>
                    <td style="padding: 5px;     color: #4e4e4e;"><b><?php echo translate('shipping');?> :</b></td>
                    <td  style="text-align: right;     color: #4e4e4e;">
                        <?php 
                            // if($shipping>0){
                            //     echo currency($shipping);
                            // }else{
                            //     echo currency("0");
                            // }
                            if($sale_details['shipping']>0){
                                echo currency($sale_details['shipping']);
                            }else{
                                echo currency("0");
                            }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td style="padding: 5px;     color: #4e4e4e;">
                        <b><?php echo translate('Tax');?>  
                        <!-- (
                            <?php
                                if($sale_details['vat_percent']!="" && $sale_details['vat_percent']!=NULL){
                                    echo $tax_percent = $sale_details['vat_percent']."%";
                                }else{
                                    echo "0%";
                                }
                            ?>
                        ) :  -->
                        </b>
                    </td>
                    <td style="text-align: right;     color: #4e4e4e;">
                        <?php
                            if($sale_details['vat']!="" && $sale_details['vat']!=NULL){
                                echo currency($sale_details['vat']);
                            }else{
                                echo "0%";
                            }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td style="padding: 5px;     color: #4e4e4e;"> <b><?php echo translate('discount');?> : </b></td>
                    <td  style="text-align: right;     color: #4e4e4e;">
                        <?php 
                            if($sale_details['coupon_amount']!="" && $sale_details['coupon_amount']!=NULL){
                                echo currency($sale_details['coupon_amount']);
                            }else{
                                echo "RS 0.00";
                            }
                        ?>    
                    </td>
                </tr>
                <tr>
                    <td style="padding: 5px; "><b><?php echo translate('grand_total');?> :</b></td>
                    <td  style="text-align: right;">    
                        <?php echo $grand_total = currency(str_replace(",", "", $sale_details['grand_total'])); ?>
                    </td>
                </tr>
            </table>
            <p style="font-size: 20px;" class="label_paymt_detail"> <strong>Payment Details </strong> </p>
            <hr style="border:0.5px solid #ccc;" />
            <p style="color: gray;" class="paymt_spec">
                <strong>Payment Method : </strong>
                <?php 
                    $payment_type = $info['payment_type']; 
                    if($payment_type == "authorize_net"){
                         echo translate("credit_card");
                    }else if($payment_type=="cash_on_delivery"){
                        echo "Cash On Delivery";
                    }else if($payment_type=="bank_transfer"){
                        echo "Bank Transfer";
                    }else if($payment_type=="quick_pay"){
                        echo "Quickpay";
                    }else{
                        echo "Paypal";
                    }
                ?></p>
                <?php if($payment_type == "authorize_net"){ ?>
                <p style="color:gray;"><strong>Card Number : </strong><?php echo $info['card_number']; ?></p>
                <?php } ?>
                 <br />
            <?php if($featured_products){ ?>
            <center>
                <h4 style="font-size: 22px; font-weight: bolder;" class="you_may_also_like">YOU MAY ALSO LIKE</h4>
            </center>
            <div class="related_prod_holder" style="width: 80%; margin: auto;">
                <center>
                <?php 
                $counter = 0; 
                $img_src = base_url("uploads/product_variants_image/default.jpg");
                foreach($featured_products as $featured_product){ 
                    if($featured_product['images']!="" && $featured_product['images']!="[]"){
                        $img_dec = json_decode($featured_product['images'],true);
                        if(is_array($img_dec) && count($img_dec)>0){
                            if(file_exists("uploads/product_variants_image/".$img_dec[0])){
                                $img_src = base_url("uploads/product_variants_image/".$img_dec[0]);
                            }
                        }
                    }
                    $counter++; 
                    if($counter>8){
                        break;
                    }
                ?>
                    <div class="grid" style="width: 45%; margin: auto; border:1px solid #ccc; display: inline-block; height: 250px; padding: 5px; margin-bottom: 5px;" >

                        <a style="text-decoration: none; color: #333333;" target="_blank"  href="<?php echo  base_url("home/product_view/".$featured_product['product_id']."/".$this->crud_model->infiltrate_unwated_character($featured_product['title'])); ?>" >

                             <div class="img_cover" style="width: 100%; height: 85%; background-image: url('<?php echo $img_src; ?>'); background-size: contain;background-position: center; background-repeat: no-repeat;"></div>

                            <div class="title" style="height:13px; padding: 2px 0px; font-size: 13px; display: block; display: -webkit-box; width: 100%; margin: 0 auto; line-height: 1.1; -webkit-line-clamp: 1;  -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis;"><?php echo $featured_product['title']; ?></div>
                            <div class="price"><?php echo $this->crud_model->get_product_price($featured_product['product_variants_id']); ?></div>
                            
                        </a>
                    </div>
                <?php 
                    } 
                ?>
                </center>
            </div>
            <br />
             <?php } ?>
            <div class="footer">
                <center>
                    <ul style="list-style: none; padding: 0px;">
                        <li style="display: inline-block; border-right: 1px solid #c3c3c3;  padding: 10px 20px;">
                            <a target="_blank" href="<?php echo base_url(); ?>" style="text-decoration: none;color: #c3c3c3;">Shop Now</a></li>

                        <li  style="display: inline-block; padding: 10px 15px;"><a target="_blank" href="<?php echo base_url('home/contact'); ?>" style="text-decoration: none; color: #c3c3c3;">Contact us</a></li>
                    </ul>
                </center>
                <center>
                    <ul style="list-style: none; padding: 0px;" class="social_nav">
                        <li style="display: inline-block;  padding: 10px 20px;">
                            <a target="_blank" href="https://www.facebook.com/faminattire/" style="text-decoration: none;color: #c3c3c3;">
                                <img src="<?php echo base_url("uploads/others/e_fb_icon.png"); ?>" style="width: 15px;"></a></li>

                        <li style="display: inline-block;  padding: 10px 20px;">
                            <a target="_blank" href="https://twitter.com/faminattire" style="text-decoration: none;color: #c3c3c3;">
                                <img src="<?php echo base_url("uploads/others/e_twt_icon.png"); ?>" style="width: 15px;"></a></li>
                        
                        <li style="display: inline-block;  padding: 10px 20px;">
                            <a target="_blank" href="https://www.instagram.com/faminattire/" style="text-decoration: none;color: #c3c3c3;">
                                <img src="<?php echo base_url("uploads/others/e_inst_icon.png"); ?>" style="width: 15px;">
                            </a></li>

                        <li style="display: inline-block; padding: 10px 20px;">
                            <a target="_blank" href="https://www.linkedin.com/company/faminattire/about/" style="text-decoration: none;color: #c3c3c3;">
                                <img src="<?php echo base_url("uploads/others/e_in_icon.png"); ?>" style="width: 15px;">
                            </a></li>

                    </ul>
                    <h4 style="margin-top: 3%;"><a style="text-decoration: none;color: #c3c3c3;">Faminattire.com</a></h4>
                    <br />
                </center>
            </div>
            <br />
        </div>
    </body>
</html>