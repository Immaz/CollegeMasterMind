<?php
$total_ship = 0;
foreach ($this->cart->contents() as $cart_content) {
    $total_ship += $cart_content['options']['shipping_charges'];
}

?>
<script>
    function whole_cart_total()
    {
        $('#total').html("- --- -");
        $('#shipping_charges').html("- --- -");
        $('#grand').html("- --- -");
        $('#net_total').html("- --- -");
        $('#total_item').html("- --- -");
        $('#tax').html("- --- -");
        var country_id = "";
        var state_id = "";
        var country_name = "";
        var city_name = "";
        var pan_from_wallet = 0;
        <?php if($this->session->userdata('user_login') == "yes"){ ?>
            pan_from_wallet = ($("#pan_from_wallet").is(":checked"))? 1 : 0;
        <?php };?>
        if($("#country").val()!=""){
            country_id = $("#country").val();
            state_id = $("#state").val();
            city_id = $("#city").val();
            pan_from_wallet = ($("#pan_from_wallet").is(":checked"))? 1 : 0;
            country_name = $("#country option:selected").text().trim().replace(" ", "_").toLowerCase();
            city_name = $("#city option:selected").text().trim().replace(" ", "_").toLowerCase();
        }else{
            country_id = "";
            state_id = "";
            city_id = "";
            country_name = '';       
            city_name = "";
        }
         var data = {
            country_id : country_id,
            country_name : country_name,
            state_id : state_id,
            city_name : city_name,
            city_id : city_id,
            pan_from_wallet : pan_from_wallet,
            '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
        };
        $.ajax({
            url: '<?php echo base_url("home/whole_cart_cal"); ?>',
            type : 'POST',
            data : data,
            success : function(response)
            {   
                converted = JSON.parse(response);
                console.log(converted);
                // if(converted.shipping_available==0){
                //     Swal.fire({
                //         type: 'error',
                //         title: 'Oops...',
                //         text: 'Shipping not available in your area!',
                //     });
                //     $("#order_place_btn").attr("disabled","disabled");
                // }
                $('#total').html('<?php echo currency(); ?>'+(converted.total).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
                // $('#shipping_charges').html( '<?php // echo currency(); ?>'+ (converted.ship).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
                converted.grand -= converted.ship; 
                converted.grand += <?php echo $total_ship; ?>; 
                converted.ship = '<?php echo $total_ship; ?>';
                $('#shipping_charges').html( '<?php echo $total_ship; ?>');
                $('#shipping_title').html("Freight Charges");
                $('#hdd_shipping_charges').val(converted.ship);
                $('#hdd_tax_percent').val(converted.tax_percent);
                $('.tax_percent').html(converted.tax_percent);
                $('#hdd_tax_amount').val(converted.tax_amount);
                $('#grand').html('<?php echo currency(); ?>'+(converted.grand).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
                $('#hdd_grand_amount').val(converted.grand);
                $('#total_item').html(converted.no_of_item_in_cart);
                $('#tax').html('<?php echo currency(); ?>'+converted.tax_amount);
                $('#net_total').html('<?php echo currency(); ?>'+(converted.grand).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
                $('#user_balance').html('<?php echo currency(); ?>'+(converted.user_balance).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
                $('#hdd_user_balance').val(converted.user_balance);
                $('#hdd_panned_balance').val((Object.hasOwn(converted, 'panned_from_wallet'))? converted.panned_from_wallet : 0);
            }
        });
    }

    $('body').on('click','.coupon_btn',function(){
        $(".overlay_holder1").show();
        var txt = $(this).html();
        var code = $('.coupon_code').val()
        var grand_total = $('#hdd_grand_amount').val();
        $('#coup_frm').val(code);
        var form = $('#coupon_set');
        var formdata = false;
        if (window.FormData){
            formdata = new FormData(form[0]);
            formdata.append("hdd_grand_amount", grand_total);
        }
        var datas = formdata ? formdata : form.serialize();
        $.ajax({
            url: base_url+'home/apply_coupon/',
            type        : 'POST', // form submit method get/post
            dataType    : 'html', // request type html/json/xml
            data        : datas, // serialize form data 
            cache       : false,
            contentType : false,
            processData : false,
            beforeSend: function() {
                $(this).html(applying);
            },
            success: function(result){
                $(".overlay_holder1").hide();
                var converted = JSON.parse(result);
                if(converted.status==1){
                    $("#hdd_grand_amount").val(converted.grand_total);
                    $("#grand , #net_total").html('<?php echo currency(); ?>'+(converted.grand_total).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,'));
                    $("#discount_coupon").text(converted.discount_amount_for_user);
                    $("#hdd_discount_coupon").val(converted.discounted_amount);
                    $('.coupon_code').val("");
                    var coupon_apply_msg = "";
                    coupon_apply_msg += '<p class="coupon_success_msg">';
                        coupon_apply_msg += 'Coupon Activated Sucessfully.';
                    coupon_apply_msg  +=  '</p>';
                    $(".coupon_enter_area").html(coupon_apply_msg);
                    $("#discount_coupon").append('&nbsp;<span class="label label-danger btn_remove_coupon" title="Remove Coupon">&times;</span>');
                    notify(converted.msg,'success','bottom','right');
                }else{
                    $('.coupon_code').val("");
                    notify(converted.msg,'error','bottom','right');
                }
            }
        });
    }); 
</script>