<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style type="text/css">
            @media only screen and (max-width: 1024px)
            {
                *{
                    -webkit-font-smoothing: antialiased;
                }
                .content_holder{
                    width: 80% !important;
                }
            }
            @media only screen and (max-width: 800px)
            {
                *{
                    -webkit-font-smoothing: antialiased;
                }
                .content_holder{
                    width: 90% !important;
                }
                .intro_txt{
                    font-size: 12px;
                }
                .order_no,
                .label_customer_info,
                .label_item_desc,
                .label_paymt_detail
                {
                    font-size: 14px !important;
                }
                .tbl_customer_info,
                .tbl_order_summary
                {
                    font-size: 12px;
                }
                .prod_title,
                .paymt_spec
                {
                    font-size: 10px !important;
                }
                .prod_specs{
                    font-size: 8px !important;
                }
                .sub_total,
                .qty
                {
                    font-size: 12px !important;
                }
                .related_prod_holder{
                    width: 100% !important;
                }
                .related_prod_holder .grid{
                    height: auto !important;
                    width: 40% !important;
                }
                .related_prod_holder .grid .img_cover{
                    width: 90% !important;
                    height: 35vw !important;
                }
                .related_prod_holder .grid .price{
                    font-size: 12px;
                }
                .related_prod_holder .grid .title{
                    font-size: 13px !important
                }
            }
            .content_holder{
                border: 1px solid #f5f5f5;
                padding-inline: 20px;
            }
        </style>
    </head>
    <body>
        <?php 
            $featured_products = $this->crud_model->getFeaturedProducts();
            $this->db->select("s.* , ds.*");
            $this->db->from("sale s");
            $this->db->join("delivery_status ds","ds.sales_id = s.sale_id","left");
            $this->db->join("carriers c","c.carrier_id = ds.carrier","left");
            $this->db->where("s.sale_id", $sale_id);
            $sale_details = $this->db->get()->row_array();
            $info = json_decode($sale_details['shipping_address'],true);
            $product_details = json_decode($sale_details['product_details'], true);
            $delivery_charges = $this->crud_model->getDeliveryChargesByCountryState($info['country'] , $info['state'], $info['city']);
        ?>
        <?php include 'email_header.php';?>
        <div style="width: 50%; margin: auto; padding: 0 20px;" class="content_holder">
            <center>
                <img src="<?php echo $this->crud_model->logo('home_top_logo'); ?>" alt=""  style="width: 150px;">
            </center>
            <p style="color: gray;">
                Hey <?php echo ucwords($info['firstname']); ?>,<br /><br />
                Thank you for your purchase! This email is to confirm that your order with Faminattire, has been Delivered<br /><br />
                We look forward to see you again soon at Faminattire.com.<br /><br />
            </p>
            <p  style="color: gray;">
                Thanks,<br />
                Team faminattire.com
            </p>
            <strong style="font-size: 24px;color: #ff515f;font-weight: bolder;" class="order_no">[Order #<?php echo $sale_details['sale_id']; ?> (<?php echo date('d M, Y',$sale_details['sale_datetime'] );?>)</strong></br>
            </br>
            <?php
                    //echo "<pre>";print_r($this->cart->contents());echo "</pre>";
                    $total = 0;
                    $color_arr = array();
                    $img_arr = array();
                    foreach ($product_details as $row1) {
                    $total += $row1['subtotal'];
                    if( $row1["options"]["color"]!=""){
                        $color_arr = json_decode($row1["options"]["color"],true);
                    }
                    if( $row1["options"]["image"]!=""){
                        $img_arr = json_decode($row1["options"]["image"],true);
                    }
                ?> 
                    <div style="width: 100%; display: flex !important; padding: 10px 0;  align-items: center;">
                        <div style="width: 18%; display: inline-block;  padding: 0px 10px;">
                            <?php if(isset($img_arr[0])){?>
                                <center>
                                    <img src="<?php echo base_url("uploads/product_variants_image/".$img_arr[0]); ?>" style="width: 100%;">
                                </center>
                            <?php }else{ ?>
                                <center>
                                    <img src="<?php echo base_url("uploads/product_variants_image/default.jpg"); ?>" style="width: 100%;">
                                </center>
                            <?php } ?>
                        </div>
                        <div style="width: 60%; display: inline-block;  padding: 0px 10px;">
                            <p style="margin: 2px 0px; font-size: 16px; margin-left: 10%;" class="prod_title"><?php echo $row1["name"]; ?>
                            <?php 
                                if($row1["options"]["actual_size"]!=""){
                            ?>
                                - <?php echo $row1["options"]["actual_size"]; ?> 
                            <?php } ?>
                            </p>
                            <p style="margin-left: 10%;">Quantity: <?php echo $row1['qty'];?></p>
                        </div>
                        <div style="width: 22%;  display: inline-block; padding: 0px 10px; text-align: center;" class="sub_total">
                            <div style="float: right;">
                                <?php echo currency($row1['subtotal']); ?>
                            </div>
                        </div>
                   </div>
            <?php  } ?>
            <table style="width: 100%;" class="tbl_order_summary">
                <tr>
                    <td style="padding: 5px 0; color: #4e4e4e;"><b><?php echo translate('sub_total_amount');?> :</b></td>
                    <td style="text-align: right;color: #4e4e4e;">
                        <?php echo $total = currency(str_replace(",", "", $total)); ?>
                    </td>
                </tr>
                <tr>
                    <td style="padding: 5px 0;color: #4e4e4e;"><b><?php echo translate('shipping');?> :</b></td>
                    <td  style="text-align: right;color: #4e4e4e;">
                        <?php 
                            if($sale_details['shipping']>0){
                                echo currency($sale_details['shipping']);
                            }else{
                                echo currency("0");
                            }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td style="padding: 5px 0;color: #4e4e4e;"> <b><?php echo translate('discount');?> : </b></td>
                    <td  style="text-align: right;color: #4e4e4e;">
                        <?php 
                            if($sale_details['coupon_amount']!="" && $sale_details['coupon_amount']!=NULL){
                                echo currency($sale_details['coupon_amount']);
                            }else{
                                echo "RS 0.00";
                            }
                        ?>    
                    </td>
                </tr>
                <?php 
                $payment_status = json_decode($sale_details['payment_status'], true)[0];
                if ($this->session->userdata('user_login') == 'yes' && $payment_status['panned_from_wallet'] > 0) {?>
                <tr>
                    <td style="padding: 5px 0; color: #4e4e4e;"><b><?php echo translate('pan from wallet');?> :</b></td>
                    <td  style="text-align: right;color: #4e4e4e;">    
                        <?php echo currency(str_replace(",", "", $payment_status['panned_from_wallet'])); ?>
                    </td>
                </tr>
                <?php } ?>
                <tr>
                    <td style="padding: 5px 0; color: #4e4e4e; font-size: 20px;"><b><?php echo translate('grand_total');?> :</b></td>
                    <td  style="text-align: right; font-size: 20px;">    
                        <?php echo $grand_total = currency(str_replace(",", "", $sale_details['grand_total'])); ?>
                    </td>
                </tr>
            </table>
            <div style="color: gray; padding: 5px 0;" class="paymt_spec">
                <b style="color: #4e4e4e; font-size: 20px; ">Payment Method:</b><br />
                <p style="margin:0;margin-top: 8px;" class="paymt_spec">
                <?php 
                    $payment_type = $info['payment_type']; 
                    if($payment_type == "western_union_xpress_remitly"){
                         echo translate("western_union|xpress|remitly");
                    }else if($payment_type=="cash_on_delivery"){
                        echo "Cash On Delivery";
                    }else if($payment_type=="bank_transfer"){
                        echo "Bank Transfer";
                    }
                ?></p>
                </div>
                <?php if($payment_type == "authorize_net"){ ?>
                <p style="color:gray;"><strong>Card Number : </strong><?php echo $info['card_number']; ?></p>
                <?php } ?>
                
                <div style="color: gray; padding: 5px 0;" class="shipping_spec">
                    <b style="color: #4e4e4e; font-size: 20px;">Shipping Details: </b>
                    <p style="margin: 0;margin-top: 8px;"><?php echo $delivery_charges['title']; ?></p>
                </div>
                <br/>
                <br/>
                <div style="width: 100%; display: inline-flex;">
                    <div class="billing_address" style="width: 50%;">
                        <b style="font-size: 20px;color: #4e4e4e;" class="label_customer_info">Billing Address</b><br />
                        <div style="color: gray;">
                            <p><?php echo (($info['bill_firstname'])? $info['bill_firstname'] : $info['firstname'])." ".(($info['bill_lastname'])? $info['bill_lastname'] : $info['lastname']); ?></p>
                            <p><?php echo ($info['bill_phone'])? $info['bill_phone'] : $info['phone']; ?></p>
                            <p><?php echo ($info['bill_email'])? $info['bill_email'] : $info['email']; ?></p>
                            <p><?php echo ($info['bill_address'])? $info['bill_address'] : $info['address1']; ?></p>
                            <p><?php echo $this->crud_model->get_type_name_by_id('country', (($info['bill_country'])? $info['bill_country'] : $info['country']), 'country_name')?></p>
                            <p><?php echo $this->crud_model->get_type_name_by_id('state', (($info['bill_state'])? $info['bill_state'] : $info['state']) , 'state_name')?></p>
                            <p><?php echo  $this->crud_model->get_type_name_by_id('city', (($info['bill_city'])? $info['bill_city'] : $info['city']) , 'city_name')?></p>
                            <p><?php echo (($info['bill_zip'])? $info['bill_zip'] : $info['zip']); ?></p>
                        </div>
                    </div>
                    <div class="shipping_address" style="width: 50%;">
                        <b style="font-size: 20px;color: #4e4e4e;" class="label_customer_info">Shipping Info</b><br />
                        <div style="color: gray;">
                            <p><?php echo $info['firstname']." ".$info['lastname']; ?></p>
                            <p><?php echo $info['phone']; ?></p>
                            <p><?php echo $info['email']; ?></p>
                            <p><?php echo $info['address1']; ?></p>
                            <p><?php echo $this->crud_model->get_type_name_by_id('country', $info['country'], 'country_name')?></p>
                            <p><?php echo $this->crud_model->get_type_name_by_id('state', $info['state'] , 'state_name')?></p>
                            <p><?php echo  $this->crud_model->get_type_name_by_id('city', $info['city'] , 'city_name')?></p>
                            <p><?php echo $info['zip']; ?></p>
                        </div>
                    </div>
                </div>
        </div>
        <?php include 'email_footer.php';?>
    </body>
</html>