<section class="page-section invoice">
    <div class="container">
    	<?php
			$sale_details = $this->db->get_where('sale',array('sale_id'=>$sale_id))->result_array();
            //echo "<pre>";print_r($sale_details);die();
			foreach($sale_details as $row){
                $info = json_decode($row['shipping_address'],true);
                $delivery_charges = $this->crud_model->getDeliveryChargesByCountryState($info['country'] , $info['state'], $info['city']);
		?>
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="invoice_body">
                    <div class="invoice-title">
                        <div class="invoice_logo hidden-xs">
                        	<?php
								$home_top_logo = $this->db->get_where('ui_settings',array('type' => 'home_top_logo'))->row()->value;
							?>
							<img src="<?php echo base_url(); ?>uploads/logo_image/logo_<?php echo $home_top_logo; ?>.png" alt="SuperShop" style="max-width: 350px; max-height: 80px;"/>
                        </div>
                        <div class="invoice_info">
                            <?php if($this->session->userdata('user_login') != "yes") {?>
                            <p><b><?php echo translate('guest_id'); ?> # :</b><?php echo $row['guest_id']; ?></p>
                            <?php }?>
                            <p><b><?php echo translate('invoice'); ?> # :</b><?php echo $row['sale_code']; ?></p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <address>
                                <strong>
                                    <h4>
                                        <?php echo translate('billed_to'); ?> :
                                    </h4>
                                </strong>
                                <?php
								?>
                                <p>
                                    <b><?php echo translate('name'); ?> :</b>
                                    <b><?php echo ($info['bill_firstname'])? $info['bill_firstname'] : $info['firstname']; ?></b>
                                </p>
                                <p>
                                    <b><?php echo translate('address'); ?> :
                                    <?php echo ($info['bill_address'])? $info['bill_address'] : $info['address1']; ?></br>
                                    <b><?php echo translate('zip');?></b> : <?php echo ($info['bill_zip'])? $info['bill_zip'] : $info['zip']; ?> <br>
                                    <b><?php echo translate('phone');?></b> : <?php echo ($info['bill_phone'])? $info['bill_phone'] : $info['phone']; ?> <br>
                                    <b><?php echo translate('e-mail');?></b> : <a href=""><?php echo (($info['bill_email'])? $info['bill_email'] : $info['email']); ?></a>
                                </p>
                            </address>
                        </div>
                        
                        <div class="col-md-6 col-sm-6 col-xs-6 hidden-xs">
                            <address>
                                <strong>
                                    <h4>
                                        <?php echo translate('shipped_to'); ?> :
                                    </h4>
                                </strong>
                                <p>
                                    <b><?php echo translate('first_name'); ?> :</b>
                                    <?php echo $info['firstname']; ?>
                                </p>
                                <p>
                                    <b><?php echo translate('address'); ?> :
                                    <?php echo $info['address1']; ?> </br>
									<b><?php echo translate('zip');?></b> : <?php echo $info['zip']; ?> <br>
                                    <b><?php echo translate('phone');?> </b>: <?php echo $info['phone']; ?> <br>
                                    <b><?php echo translate('e-mail');?></b> : <a href=""><?php echo $info['email']; ?></a>
                                </p>
                            </address>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-6 ">
                            <address>
                                <strong>
                                    <h4>
                                        <?php echo translate('payment_details'); ?> :
                                    </h4>
                                </strong>
                                <p>
                                    <b><?php echo translate('payment_status'); ?> :</b>
                                    <i><?php echo translate($this->crud_model->sale_payment_status($row['sale_id'])); ?></i>
                                </p>
                                <p>
                                    <b><?php echo translate('payment_method'); ?> :</b>
                                    <?php
                                    // echo "<pre/>".print_r($info,1);
                                        if($info['payment_type']=="authorize_net"){
                                            echo "Credit Card";
                                        }else if($info['payment_type']=="cash_on_delivery"){
                                            echo "Cash On Delivery";
                                        }else if($info['payment_type']=="bank_transfer"){
                                            echo "Bank Transfer";
                                        }else if($info['payment_type']=="western_union_xpress_remitly"){
                                            echo "Western Union|Xpress|Remitly";
                                        }else if($info['payment_type']=="quick_pay"){
                                            echo "Quickpay";
                                        }else{
                                            echo "Paypal";
                                        }
                                    ?>
                                </p>
                            </address>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-6">
                            <address>
                                <strong>
                                    <h4>
                                        <?php echo translate('order_date'); ?> :
                                    </h4>
                                    <p>
                                        <?php echo date('d M, Y',$row['sale_datetime'] );?>
                                    </br>
                                    </br>
                                    </p>
                                </strong>
                            </address>
                        </div>
                    </div>
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title"><strong><?php echo translate('payment_invoice');?></strong></h3>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-condensed">
                                    <thead>
                                        <tr>
                                            <td><strong><?php echo translate('image');?></strong></td>
                                            <td class="text-center"><strong><?php echo translate('item');?></strong></td>
                                            <td class="text-center"><strong><?php echo translate('quantity');?></strong></td>
                                            <td class="text-center"><strong><?php echo translate('size');?></strong></td>
                                            <td class="text-center"><strong><?php echo translate('weight');?></strong></td>
                                            <td class="text-right"><strong><?php echo translate('total');?></strong></td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
											$product_details = json_decode($row['product_details'], true);
											$total = 0;
                                            $img_arr = array();
											foreach ($product_details as $row1) {
                                                if( $row1["options"]["image"]!=""){
                                                    $img_arr = json_decode($row1["options"]["image"],true);
                                                }
										?>
                                        <tr>
                                            <td style="width: 15%;">
                                                <?php if(isset($img_arr[0])){?>
                                                    <img src="<?php echo base_url("uploads/product_variants_image/".$img_arr[0]); ?>" style="width: 100%;">
                                                <?php }else{ ?>
                                                    <img src="<?php echo base_url("uploads/product_variants_image/default.jpg"); ?>" style="width: 100%;">
                                                <?php } ?>
                                            </td>
                                            <td style="width: 20%;" class="text-center"><?php echo $row1['name']; ?></td>
                                            <td style="width: 15%;" class="text-center"><?php echo $row1['qty']; ?></td>
                                            <td style="width: 20%;" class="text-center">
												<?php echo $row1["options"]['actual_size']; ?>
                                            </td>
                                            <td style="width: 15%;" class="text-center">
												<?php echo $row1["options"]['weight']; ?>kg
                                            </td>
                                            <td style="width: 15%;" class="text-right">
												<?php echo currency($row1['price']); 
													$total += $row1['price']; 
												?>
                                            </td>
                                        </tr>
                                        <?php
											}
										?>
                                        <tr>
                                        	<td class="thick-line" colspan="4"></td>
                                            <td class="thick-line text-right">
                                            	<strong>
                                            		<?php echo translate('sub_total_amount');?> :
                                                </strong>
                                            </td>
                                            <td class="thick-line text-right">
                                            	<?php echo currency($total);?>
                                            </td>
                                        </tr>
                                        <tr>
                                        	<td class="no-line" colspan="4"></td>
                                            <td class="no-line text-right">
                                            	<strong>
                                            		<?php echo translate('shipping');?> :
                                                </strong>
                                            </td>
                                            <td class="no-line text-right">
                                                <?php 
                                                    if($row['shipping']!=NULL && $row['shipping']!=""){
                                                        echo currency(str_replace(",", "", $row['shipping']));
                                                        echo '</br><p style="color: gray; font-weight: 200; margin: 5px 0;">';
                                                        echo '('.$delivery_charges['title'].')';
                                                        echo '</p>';
                                                    }else{
                                                        echo "RS 0.00";
                                                    }
                                                ?>
                                            </td>
                                        </tr>

                                        <?php if($this->crud_model->CheckAllowedTax()){ ?>
                                        <tr>
                                            <td class="no-line" colspan="4"></td>
                                            <td class="no-line text-right">
                                                <strong>
                                                    <?php echo translate('Tax');?> :
                                                </strong>
                                            </td>
                                            <td class="no-line text-right">
                                                <?php
                                                    if($row['vat_percent']!="" && $row['vat_percent']!=NULL){
                                                        echo $shipping = $row['vat_percent']."%";
                                                    }else{
                                                        echo "0%";
                                                    }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                        

                                        <tr>
                                            <td class="no-line" colspan="4"></td>
                                            <td class="no-line text-right">
                                                <strong>
                                                    <?php echo translate('discount');?> :
                                                </strong>
                                            </td>
                                            <td class="no-line text-right">
                                                <?php 
                                                    if($row['coupon_amount']!="" && $row['coupon_amount']!=NULL){
                                                        echo currency($row['coupon_amount']);
                                                    }else{
                                                        echo "RS 0.00";
                                                    }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                        	<td class="no-line" colspan="4"></td>
                                            <td class="no-line text-right">
                                            	<strong>
                                            		<?php echo translate('grand_total');?> :
                                                </strong>
                                            </td>
                                            <td class="no-line text-right">
                                            	<?php 
                                                    echo $grand_total = currency(str_replace(",", "", $row['grand_total']));
                                                ?>
                                            </td>
                                        </tr>
                                        <?php 
                                        $payment_status = json_decode($row['payment_status'], true)[0];
                                        if ($this->session->userdata('user_login') == 'yes' && $payment_status['panned_from_wallet'] > 0) {?>
                                        <tr>
                                        	<td class="no-line" colspan="4"></td>
                                            <td style="border-top: 1px solid #ccc" class="no-line text-right">
                                            	<strong>
                                            		<?php echo translate('Pan From Wallet');?> :
                                                </strong>
                                            </td>
                                            <td style="border-top: 1px solid #ccc" class="no-line text-right">
                                            	<?php 
                                                    echo currency(str_replace(",", "", $payment_status['panned_from_wallet']));
                                                ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-10 col-md-offset-1 btn_print hidden-xs" style="margin-top:10px;">
            	<!-- <span class="btn btn-info pull-right" onClick="print_invoice()">
					<?php echo translate('print'); ?>
               	</span> -->
                <?php if($this->session->userdata('user_login') == "yes") {?>
                <a class="btn btn-danger pull-right" href="<?=base_url()?>home/profile/part/order_history" style="margin-right: 5px;"><?php echo translate('back_to_profile'); ?></a>
                <?php }?>
            </div>
        </div>
        <?php
			}
		?>
    </div>
</section>
<script>
function print_invoice(){
	window.print();
}
</script>
<style type="text/css">    
    @media print {
        .top-bar{
            display: none !important;
        }
        header{
            display: none !important;
        }
        footer{
            display: none !important;
        }
        .to-top{
            display: none !important;
        }
        .btn_print{
            display: none !important;
        }
        .invoice{
            padding: 0px;
        }
        .table{
            margin:0px;
        }
        address{
            margin-bottom: 0px;
			border:1px solid #fff !important;
        }
    }
</style>

