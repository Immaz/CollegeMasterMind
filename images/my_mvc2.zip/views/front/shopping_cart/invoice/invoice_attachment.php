<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="<?= base_url('template/front/css/bs/bootstrap.min.css');?>">   -->
    <style type="text/css">
        *{
            -webkit-font-smoothing: antialiased;
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }
        body {
            margin: 0;
            font-family: var(--bs-font-sans-serif);
            font-size: 1rem;
            font-weight: 400;
            line-height: 1.5;
            color: #212529;
            background-color: #fff;
            -webkit-text-size-adjust: 100%;
            -webkit-tap-highlight-color: transparent;
        }
        .container{
            padding: 50px;
        }
        table {
            caption-side: bottom;
            border-collapse: collapse;
            width: 100%;
            margin-bottom: 1rem;
            color: #212529;
            vertical-align: top;
            border-color: #dee2e6;
        }
        th {
            color: #fff;
            background: #373b3e;
        }
        td{
            border: 0;
            padding: 0.5rem 0.5rem;
        }
        p{
            margin: 0;
        }
        .bordered-td{
            border-top: 1px solid #dee2e6 !important;
        }
        .bordered-td-black{
            border-top: 1px solid black !important;
        }
        .bordered-td-top-down-2{
            font-weight: bold;
            border-top: 2px solid black !important;
            border-bottom: 2px solid black !important;
        }
        .text-center{
            text-align: center;
        }
    </style>
</head>
<body>
<?php 
    $sale_details = $this->db->get_where('sale',array('sale_id'=>$sale_id))->row_array();
    $featured_products = $this->crud_model->getFeaturedProducts();
    $info = json_decode($sale_details['shipping_address'],true);
    $product_details = json_decode($sale_details['product_details'], true);
    $delivery_charges = $this->crud_model->getDeliveryChargesByCountryState($info['country'] , $info['state'], $info['city']);
?>
    <div class="container">
        <img src="<?php echo $this->crud_model->logo('home_top_logo'); ?>" alt=""  style="width: 150px;">
        <br/>
        <br/>
        <h2 style="font-weight: bold;">INVOICE</h2>
        <br/>
        <div style="width: 100%;">
            <div style="width: 48%; float: left;">
                <p><?php echo ucwords(($info['bill_firstname'])? $info['bill_firstname'] : $info['firstname']).' '.ucwords(($info['bill_lastname'])? $info['bill_lastname'] : $info['lastname']); ?></p>
                <p><?php echo ucwords(($info['bill_address'])? $info['bill_address'] : $info['address1']);?></p>
                <p><?php echo $this->crud_model->get_type_name_by_id('country', (($info['bill_country'])? $info['bill_country'] : $info['country']), 'country_name') ?></p>
                <p><?php echo $this->crud_model->get_type_name_by_id('state', (($info['bill_state'])? $info['bill_state'] : $info['state']), 'state_name') ?></p>
                <p><?php echo $this->crud_model->get_type_name_by_id('city', (($info['bill_city'])? $info['bill_city'] : $info['city']), 'city_name') ?></p>
                <p><?php echo ucwords(($info['bill_zip'])? $info['bill_zip'] : $info['zip']);?></p>
                <p><?php echo ucwords(($info['bill_email'])? $info['bill_phone'] : $info['email']);?></p>
                <p><?php echo ucwords(($info['bill_phone'])? $info['bill_phone'] : $info['phone']);?></p>
            </div>
            <div style="width: 50%; float: right;">
                <div style="width: 100%;">
                    <div style="width: 50%; float: left;">
                        <p>Invoice Number:</p>
                        <p>Invoice Date:</p>
                        <p>Order Number:</p>
                        <p>Order Date:</p>
                        <p>Payment Method:</p>
                    </div>
                    <div style="width: 50%; float: right;">
                        <p><?php echo $sale_details['sale_code']; ?></p>
                        <p><?php echo date('M d, Y', strtotime($sale_details['created'])); ?></p>
                        <p><?php echo $sale_details['sale_id']; ?></p>
                        <p><?php echo date('M d, Y', strtotime($sale_details['created'])); ?></p>
                        <p><?php 
                            $payment_type = $info['payment_type']; 
                            if($payment_type == "authorize_net"){
                                 echo translate("credit_card");
                            }else if($payment_type=="cash_on_delivery"){
                                echo "Cash On Delivery";
                            }else if($payment_type=="bank_transfer"){
                                echo "Bank Transfer";
                            }else if($payment_type=="western_union_xpress_remitly"){
                                echo "Western Union|Xpress|Remitly";
                            }else{
                                echo "Paypal";
                            }?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <br/>
        <div>
            <table class="table">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th class="text-center">Product</th>
                        <th class="text-center">Quantity</th>
                        <th class="text-center">Size</th>
                        <th class="text-center">Price</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $total = 0;
                $total_weight = 0;
                $total_quantity = 0;
                $img_arr = array();
                foreach ($product_details as $row1) {
                    $total += $row1['subtotal'];
                    $total_weight += $row1['options']['weight'];
                    $total_quantity += $row1['qty'];
                    if( $row1["options"]["image"]!=""){
                        $img_arr = json_decode($row1["options"]["image"],true);
                    }?> 
                    <tr>
                        <td>
                            <?php if(isset($img_arr[0])){?>
                                <img src="<?php echo base_url("uploads/product_variants_image/".$img_arr[0]); ?>" style="width: 100px;">
                            <?php }else{ ?>
                                <img src="<?php echo base_url("uploads/product_variants_image/default.jpg"); ?>" style="width: 100px;">
                            <?php } ?>
                        </td>
                        <td class="text-center"><?php echo  $row1["name"]; ?><br/><span style="font-size: 14px;font-weight: normal;">Weight: <?=$row1['options']['weight'];?>kg</span></td>
                        <td class="text-center"><?php echo  $row1["qty"]; ?></td>
                        <td class="text-center"><?php echo  $row1["options"]["actual_size"]; ?></td>
                        <td class="text-center"><?php echo  currency(str_replace(",", "", $row1["subtotal"])); ?></td>
                    </tr>
                    <?php } ?>
                    <tr>
                        <td class="bordered-td-black"></td>
                        <td colspan="2" class="bordered-td-black">Quantity Weight: <?= $total_weight;?>Kg</td>
                        <td colspan="2" class="bordered-td-black">Total Quantity: <?= $total_quantity;?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="2" class="bordered-td">Sub Total :</td>
                        <td colspan="2" class="bordered-td"><?= currency(str_replace(",", "", $total));?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="2" class="bordered-td">Discount :</td>
                        <td colspan="2" class="bordered-td">
                        <?php 
                            if($sale_details['coupon_amount']!="" && $sale_details['coupon_amount']!=NULL){
                                echo currency($sale_details['coupon_amount']);
                            }else{
                                echo "RS 0.00";
                            }
                        ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="2" class="bordered-td">Shipping :</td>
                        <td colspan="2" class="bordered-td">
                        <?php 
                            if($sale_details['shipping']>0){
                                echo currency($sale_details['shipping']).' ('.$delivery_charges['title'].')';
                            }else{
                                echo currency("0");
                            }?>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td colspan="2" class="bordered-td-top-down-2">Grand Total :</td>
                        <td colspan="2" class="bordered-td-top-down-2">
                            <?php echo currency(str_replace(",", "", $sale_details['grand_total']));?>
                        </td>
                    </tr>
                    <?php 
                        $payment_status = json_decode($sale_details['payment_status'], true)[0];
                        if ($this->session->userdata('user_login') == 'yes' && $payment_status['panned_from_wallet'] > 0) {?>
                        <tr>
                        	<td></td>
                            <td class="bordered-td-top-down-2">
                            	<strong>
                            		<?php echo translate('Pan From Wallet');?> :
                                </strong>
                            </td>
                            <td class="bordered-td-top-down-2">
                            	<?php echo currency(str_replace(",", "", $payment_status['panned_from_wallet']));?>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>