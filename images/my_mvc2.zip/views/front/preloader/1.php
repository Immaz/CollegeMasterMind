

<style>

#loading-center{
	width: 100%;
	height: 100%;
	position: relative;
}
#loading-center-absolute {
	position: absolute;
	left: 50%;
	top: 48%;
	height: 200px;
	width: 200px;
	margin-top: -100px;
	margin-left: -100px;
}
.logo_gif {
	margin: -60% 0 0 -40%;
}

</style>

<div id="loading">
    <div id="loading-center">
        <div id="loading-center-absolute">
        	<div class="logo_gif"> 
        		<img src="<?php echo base_url()?>uploads/logo_image/loading.gif" style="max-width: 100%;    margin: 25% 0 0 12%;"> 
        	</div>
        </div>
    </div>
 
</div>


