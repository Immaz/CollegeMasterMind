<style type="text/css">
    .post-header{
        margin-bottom: 10px !important;
    }
    .post-title{
        width: 100%;
        text-align: center;
        padding: 18px 78px;
    }
    .post-date{
        text-align: center;
        font-style: oblique;
        padding: 3px 0px;
        width: 100%;
    }
</style>
<section class="page-section with-sidebar">
    <div class="container">
        <div class="row">
            <div class="col-md-9 content" id="content" style="margin-top: 0px;">
            	<?php
                	foreach($blog as $row){
				?>
            	<article class="post-wrap post-single">
                    <div class="post-media">
                        <h2 class="post-title">
                            <?php echo ucwords($row['title']); ?>
                        </h2>
                        <div class="post-date">
                            <?php echo $row['date']; ?>
                        </div>
                        <img class="img-responsive" src="<?php echo $this->crud_model->file_view('blog',$row['blog_id'],'','','no','src','',''); ?>" alt=""/>
                    </div>
                    <div class="buttons">
                        <ul class="social-nav model-2" style="float: left;">
                            <li style="border-top: none;"><a href="https://facebook.com/share?" target="_blank" class="facebook social_a"><i class="fa fa-facebook"></i></a></li>
                            <li style="border-top: none;"><a href="https://twitter.com/share?" target="_blank" class="twitter social_a"><i class="fa fa-twitter"></i></a></li>
                             <li style="border-top: none;"><a href="https://www.linkedin.com/shareArticle?mini=true&amp" target="_blank" class="linkedin social_a"><i class="fa fa-linkedin"></i></a></li>
                             <li style="border-top: none;"><a href="https://pinterest.com/pin/create/button/?" target="_blank" class="pinterest social_a"><i class="fa fa-pinterest"></i></a></li>
                             <li style="border-top: none;"><a href="https://www.tumblr.com/widgets/share/tool" target="_blank" class="twitter social_a"><i class="fa fa-tumblr"></i></a></li>
                             <li style="border-top: none;"><a href="https://www.Instagram.com/" target="_blank" class="youtube social_a"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                        <div class="clear"></div>
                    </div>
                    <div class="post-body">
                        <div class="post-excerpt">
                            <p class="text-xl">
                        		<?php echo ucwords($row['summery']); ?>
                            </p>
                            <p>
                            	<?php echo ucwords($row['description']); ?>
                            </p>
                        </div>
                    </div>
                </article>
               <hr class="page-divider"/>
                <?php
					}
				?>
                <div class="row">
                	<div class="col-md-12">
                		<?php
							$discus_id = $this->db->get_where('general_settings',array('type'=>'discus_id'))->row()->value;
							$fb_id = $this->db->get_where('general_settings',array('type'=>'fb_comment_api'))->row()->value;
							$comment_type = $this->db->get_where('general_settings',array('type'=>'comment_type'))->row()->value;
						?>
						<?php if($comment_type == 'disqus'){ ?>
                        <div id="disqus_thread"></div>
                        <script type="text/javascript">
                            /* * * CONFIGURATION VARIABLES * * */
                            var disqus_shortname = '<?php echo $discus_id; ?>';
                            
                            /* * * DON'T EDIT BELOW THIS LINE * * */
                            (function() {
                                var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
                                dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
                                (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
                            })();
                        </script>
                        <script type="text/javascript">
                            /* * * CONFIGURATION VARIABLES * * */
                                var disqus_shortname = '<?php echo $discus_id; ?>';
                            
                            /* * * DON'T EDIT BELOW THIS LINE * * */
                            (function () {
                                var s = document.createElement('script'); s.async = true;
                                s.type = 'text/javascript';
                                s.src = '//' + disqus_shortname + '.disqus.com/count.js';
                                (document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s);
                            }());
                        </script>
                        <noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript" rel="nofollow">comments powered by Disqus.</a></noscript>
                        <?php
                            }
                            else if($comment_type == 'facebook'){
                        ?>
            
                            <div id="fb-root"></div>
                            <script>(function(d, s, id) {
                              var js, fjs = d.getElementsByTagName(s)[0];
                              if (d.getElementById(id)) return;
                              js = d.createElement(s); js.id = id;
                              js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4&appId=<?php echo $fb_id; ?>";
                              fjs.parentNode.insertBefore(js, fjs);
                            }(document, 'script', 'facebook-jssdk'));</script>
                            <div class="fb-comments" data-href="<?php echo $this->crud_model->product_link($row['product_id']); ?>" data-numposts="5"></div>
            
                        <?php
                            }
                        ?>
                	</div>
                </div>
            </div>
            <?php 
                $this->load->view('front/blog/sidebar');
            ?>
            <!-- /CONTENT -->
        </div>
    </div>
</section>