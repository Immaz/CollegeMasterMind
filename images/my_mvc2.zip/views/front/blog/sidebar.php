<style type="text/css">
    .cat_heading{
        color: white !important;
        margin: 0px;
        font-size: 20px;
        padding: 6px 12px;
        text-align: left;
        letter-spacing: 2px;
        width: 100%;
        background-color: #57709a;
        border-radius: 3px;
    }
    .blog_category{
        border: 1px solid #ccc !important;
        border-radius: 3px;
    }
    .blog_category .widget-content{
        padding: 0px !important;
        border: 0px solid !important;
    }   
    .widget.shop-categories ul {
        padding: 0px !important;
        margin:0px !important;
    }
    .widget.shop-categories ul li{
        padding: 2px 10px !important;
        text-align: left !important;
    }
    .widget.shop-categories ul li a{
        text-align: left !important;
        font-weight: 500;
    }
</style>
<aside class="col-md-3 hidden-sm hidden-xs" id="sidebar" style="float: right!important; margin-top: 0px;">
    <div class="row">
        <div class="col-md-12" style="margin-top: 0px;">
            <form method="get" action="<?php echo base_url("home/blog"); ?>" id="form_blog_search">
                <input type="text" name="bs" id="bs" class="form-control" placeholder="Search Blog" value="<?php echo (isset($_GET['bs']) ? $_GET['bs'] : ""); ?>">
            </form>
        </div>
    </div>
    <br />
    <div class="row">
        <?php
            echo $this->html_model->widget('special_blogs');
        ?>
    </div>
     <br />
    <!-- widget shop categories -->
    <div class="widget shop-categories blog_category">
        <div class="widget-content">
            <div class="cat_heading"> Categories </div>
            <ul>
                <?php
                    $blogs=$this->db->get('blog_category')->result_array();
                    foreach($blogs as $row){
                ?>
                    <li>
                        <a href="<?php echo base_url('home/blog/'.$row['blog_category_id']); ?>">
                            <?php echo ucwords($row['name']); ?> 
                        </a>
                    </li>
                <?php 
                    }
                ?>
            </ul>
        </div>
    </div>
    <!-- /widget shop categories -->
</aside>
