<style type="text/css">
    .blog_box .caption-title a{
        line-height: 1.5;
        color: #333 !important; 
        font-weight: 500 !important; 
        font-size: 20px  !important; 
    }
    .blog_box .caption-text{
        margin: 4px 0px;
        line-height: 1.8;
        font-size: 14px;
    }
    .no_blog_search{
        width: 100%;
        height: 60px;
        border-left: 1px solid #ccc;
        border-top: 3px solid #57709a;
        border-radius: 4px;
        border-right: 1px solid #ccc;
        border-bottom: 1px solid #ccc;
        margin-top: 1%;
        padding-left: 2%;
        padding-top: 2%;
    }
    .no_blog_search p{
        font-size: 15px;
        color: #555;
    }
    #myCarousel .carousel-inner .item{
        height: 350px;
    }
     #myCarousel .carousel-inner .item img{
        height: 100%;
        width: 100%;
    }
    .blog_slider_overlay{
        width: 100%;
        height: 60px; 
        background-color: rgba(0,0,0,.6);
        z-index: 10;
        position: absolute;
        top: calc(100% - 60px);
       padding: 8px 28px;
    }
    .blog_slider_overlay h4{
        color: white;
    }
    .well-blog-search-keyword{
        margin-top: 1%;
        margin-bottom: 1%;
        padding: 4px 12px;
    }
    .well-tab-blog{
       overflow: auto;
        height: 520px;
        margin-top: 1%;
        margin-bottom: 1%;
        padding: 0px 0px;
        border-top: 3px solid #57709a;
        overflow-x: hidden;
    }
    .well-tab-blog .nav-tabs>li>a{
        border: 0px solid #ccc;
        border-right: 1px solid #ccc;
        border-radius: 0px;
        font-size: 18px;
        margin: 0px;
        color: #666;
        letter-spacing: 2px;
    }
    .well-tab-blog .nav-tabs>li.active>a, .nav-tabs>li.active>a:focus, .nav-tabs>li.active>a:hover{
        background-color: #57709a;
        border: 0px solid #ccc;
        color: white;
        transition: all 0.2s;
    }
    .well-tab-blog .tab-content{
        padding: 15px 18px;
    }
    .well-tab-blog .tab-content .media{
        margin: 8px 0px;
    }
    .well-tab-blog .tab-content .media .media-body{
        color: #666;
        font-size: 14px;
    }
    .well-tab-blog .tab-content .media .media-body p{
        margin-bottom: 0px;
    }
    .block-ellipsis-tab-blog-first-blog {
        display: block;
        display: -webkit-box;
        max-width: 100%;
        margin: 0 auto;
        line-height: 1.5;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-top: 2%;
    }
    .block-ellipsis-tab-blog-first-blog-p{
        display: block;
        display: -webkit-box;
        max-width: 100%;
        margin: 0 auto;
        line-height: 1.5;
        -webkit-line-clamp: 5;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
        margin-top: 2%;
    }
</style>
<?php  
    $tab_blog_arr = array();
    foreach($tab_blogs as $tab_blog){
        $tab_blog_arr[trim($tab_blog['blog_category_name'])][] = $tab_blog;
    }
    //echo "<pre>";print_r($get_blog_slider_images); 
?>
<input type="hidden" value="<?php echo $category; ?>" id="blog_cat" />
<!-- PAGE WITH SIDEBAR -->
<section class="page-section with-sidebar">
    <div class="container">
        <div class="row">
            <?php 
                include 'sidebar.php';
            ?>
            <div class="col-md-9 content" id="content" style="margin-top: 0px;">
                <?php  if($get_blog_slider_images){ ?>
                    <div id="myCarousel" class="carousel slide" data-ride="carousel">
                          <!-- Wrapper for slides -->
                      <div class="carousel-inner">
                        <?php 
                            foreach($get_blog_slider_images as $get_blog_slider_image){
                        ?>
                        <div class="item">
                            <a href="<?php echo $this->crud_model->blog_link($get_blog_slider_image['blog_id']); ?>">
                                <img src="<?php echo $this->crud_model->file_view('blog',$get_blog_slider_image['blog_id'],'','','thumb','src','',''); ?>" alt=""/>
                                <div class="blog_slider_overlay">
                                    <h4><?php echo ucwords($get_blog_slider_image['title']); ?></h4>
                                </div>
                            </a>
                        </div>
                        <?php } ?>
                      </div>
                      <!-- End Carousel Inner -->
                        <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                        </a>
                        <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                        </a>
                    </div><!-- End Carousel --> 
                <?php } ?>
                <div class="well well-md well-tab-blog">
                    <ul class="nav nav-tabs">
                        <?php 
                        //echo "<pre>";print_r($tab_blog_arr); 
                        $count = 0;
                        foreach($tab_blog_arr as $key => $tab_blog){
                            $count++;
                             if($child_count>5){
                                break;
                            }
                        ?>
                            <li><a data-toggle="tab" href="#tab-blog-<?php echo $count; ?>"><?php echo $key; ?></a></li>
                        <?php } ?>
                    </ul>
                    <div class="tab-content">
                        <?php 
                            $count = 1;
                            foreach($tab_blog_arr as $key => $tab_blogs2){
                            if($count>5){
                                break;
                            }
                        ?>
                            <div id="tab-blog-<?php echo $count; ?>" class="tab-pane">
                                <div class="row">
                                    <div class="col-md-6" style="margin-top: 0px;">
                                        <?php 
                                            $last_blog_of_category = $tab_blog_arr[$key][count($tab_blog_arr[$key])-1];
                                        ?>
                                        <a href="<?php echo $this->crud_model->blog_link($last_blog_of_category['blog_id']); ?>">
                                            <img src="<?php echo $this->crud_model->file_view('blog',$last_blog_of_category['blog_id'],'','','thumb','src','',''); ?>" style="width: 100%;">
                                        </a>
                                        <h4 style="color: #000!important; height: 80px;" class="block-ellipsis-tab-blog-first-blog"><?php echo ($last_blog_of_category['summery']); ?></h4>
                                        <p style="color: #666; margin-top: 2%;" class="block-ellipsis-tab-blog-first-blog-p"><?php echo ucwords(strip_tags($last_blog_of_category['description'])); ?></p>
                                    </div>
                                    <div class="col-md-6"  style="margin-top: 0px;">
                                    <?php 
                                        $child_count = 1;
                                        foreach( $tab_blogs2 as  $tab_blog_child){
                                            if($child_count>4){
                                                break;
                                            }
                                    ?>
                                    <div class="media">
                                        <div class="media-left">
                                            <a href="<?php echo $this->crud_model->blog_link($tab_blog_child['blog_id']); ?>">
                                                <img src="<?php echo $this->crud_model->file_view('blog',$tab_blog_child['blog_id'],'','','thumb','src','',''); ?>" class="media-object" style="height: 100%; max-height: 60px; width: 70px;">
                                             </a>
                                        </div>
                                        <div class="media-body">
                                            <p><?php echo ucwords($tab_blog_child['title']); ?></p>
                                        </div>
                                    </div>
                                    <hr  style="margin: 10px 0px;" />
                                    <?php  $child_count++;} ?>
                                    </div>
                                </div>
                            </div>
                        <?php  $count++; }?>
                    </div>
                </div>
               <?php
                    if(isset($_GET['bs'])){ 
                ?>
                <div class="well well-blog-search-keyword">
                    <h4><strong>Search : </strong><i><?php echo $this->input->get("bs"); ?></i></h4>
                </div>
                <?php }?>
                <div id="blog-content">
                <?php
                if($all_blogs){
                    foreach($all_blogs as $row){
                ?>
                <div class="thumbnail blog_box">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12" style="margin-top: 0px;">
                            <div class="media">
                                <a class="" href="<?php echo $this->crud_model->blog_link($row['blog_id']); ?>" >
                                    <img src="<?php echo $this->crud_model->file_view('blog',$row['blog_id'],'','','thumb','src','',''); ?>" alt="" style="max-height: 100%;"/>
                                </a>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12" style="margin-top: 0px;">
                            <div class="caption" style="padding-top: 0px;">
                                <h4 class="caption-title">
                                    <a href="<?php echo $this->crud_model->blog_link($row['blog_id']); ?>">
                                        <?php echo ucwords($row['title']); ?>
                                    </a>
                                </h4>
                                <div class="caption-text">
                                    <?php echo ucwords($row['summery']); ?>
                                </div>
                            </div>
                             <a class="btn btn-theme-blue" href="<?php echo $this->crud_model->blog_link($row['blog_id']); ?>"> View More </a>
                        </div>
                    </div>
                </div>
                <?php
                    }
                }else{
                ?>
                    <div class="no_blog_search">
                        <p>No blog found</p>
                    </div>
                <?php }?>
                </div>
            </div>
            <!-- /CONTENT -->
        </div>
    </div>
</section>
<!-- /PAGE WITH SIDEBAR -->
<script>
	$(document).ready(function(){
        $(".well-tab-blog .tab-content .tab-pane").eq(0).addClass("fade in active");
        $(".well-tab-blog .nav-tabs li").eq(0).addClass("active");;
        $("#myCarousel .carousel-inner .item").eq(0).addClass("active");
        $('#myCarousel').carousel({
            interval:   2000,
        });
        $("#bs").keydown(function(e){
            if(e.keyCode==13){
               var blog_search = $("#bs").val();
               if(blog_search!=""){
                $(".overlay_holder1").show();
                $("#form_blog_search").submit();
               }
            }
        });
    });
</script>
<style type="text/css">
   .btn-theme-blue{
    background-color: #57709a;
    border-color: #57709a;
    color: #ffffff;
    border-width: 3px;
    padding: 12px 20px;
    font-size: 14px;
    font-weight: 600;
    line-height: 1;
    text-transform: uppercase;
    -webkit-transition: all 0.2s ease-in-out;
    transition: all 0.2s ease-in-out;
   }
  .btn-theme-blue:hover{
    background-color: #3a5c94;
    border-color: #3a5c94;
    color: #ffffff;
    border-width: 3px;
    padding: 12px 20px;
    font-size: 14px;
    font-weight: 600;
    line-height: 1;
    text-transform: uppercase;
    -webkit-transition: all 0.2s ease-in-out;
    transition: all 0.2s ease-in-out;
   }
</style>