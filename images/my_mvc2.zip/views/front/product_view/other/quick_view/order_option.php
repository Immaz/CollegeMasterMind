<style type="text/css">
    .stock_quick{
        font-size: 18px;
        color: #3C3B6E;
        font-weight: bold;
        padding: 5px 0px;
        /*float: right;*/
    }
    .social-nav{
        margin-top: 0px !important;
        margin-bottom: 5px;
    }
</style>
<!-- https://smhttp-ssl-45336.nexcesscdn.net/media/catalog/product/cache/2/image/9df78eab33525d08d6e5fb8d27136e95/1/0/105205-camo_1.jpg -->
    <div class="order fix-length">	
        <div class="buttons">
            <div class="item_count">
                <?php 
                    $style = "";
                    if($single_variant['stock_status']>0){
                        $style = "style='display : block;'";
                    }else{
                        $style = "style='display : none;'";
                    }
                ?>
                <div class="quantity product-quantity" <?php echo $style; ?>>
                    <span class="btn" name='subtract' onclick='decrease_val();'>
                        <i class="fa fa-minus"></i>
                    </span>
                    <input  type="number" class="form-control qty quantity-field cart_quantity" readonly min="1" max="<?php echo $single_variant['stock_status']; ?>" name='qty' value="<?php if($a = $this->crud_model->is_added_to_cart($single_variant['product_variants_id'],'qty')){echo $a;} else {echo '1';} ?>" id='qty'/>
                    <span class="btn" name='add' onclick='increase_val();'>
                        <i class="fa fa-plus">
                    </i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="buttons" style="display:inline-flex;">
        <?php 
            $style = "";
            if($single_variant['stock_status']>0){
                $style = "style='display:block;'";
            }else{
                $style = "style='display:none;'";
            }
         ?>
        <span class="btn btn-add-to cart btn_add_to_cart_quick_view" onclick="to_cart(<?php echo $single_variant['product_variants_id']; ?>,event)" data-show-cart-popup="false" <?php echo $style; ?>>
            <i class="fa fa-shopping-cart"></i>
			<?php if($this->crud_model->is_added_to_cart($single_variant['product_id'])=="yes"){ 
                echo translate('added_to_cart');  
                } else { 
                echo translate('add_to_cart');  
                } 
            ?>
        </span>
        <?php 
            $wish = $this->crud_model->is_wished($single_variant['product_id']); 
        ?>
        <span class="btn btn-add-to <?php if($wish == 'yes'){ echo 'wished';} else{ echo 'wishlist';} ?>" onclick="to_wishlist(<?php echo $single_variant['product_id']; ?>,event)">
            <i class="fa fa-heart"></i>
            <span class="hidden-xs hidden-sm">
				<?php if($wish == 'yes'){ 
                    echo translate('_added_to_wishlist'); 
                    } else { 
                    echo translate('_add_to_wishlist');
                    } 
                ?>
            </span>
        </span>
        <?php 
            $compare = $this->crud_model->is_compared($single_variant['product_id']); 
        ?>
        <span class="btn btn-add-to compare btn_compare"  onclick="do_compare(<?php echo $single_variant['product_id']; ?>,event)">
            <i class="fa fa-exchange"></i>
            <span class="hidden-xs hidden-sm">
				<?php if($compare == 'yes'){ 
                    echo translate('_compared'); 
                    } else { 
                    echo translate('_compare');
                    } 
                ?>
            </span>
        </span>
    </div> 
</form> 
<div id="pnopoi"></div>
<div class="buttons">
    <ul class="social-nav model-2" style="float: left;margin-top: 10px">
        <li style="border-top: none;"><a href="https://facebook.com/share?" target="_blank" class="facebook social_a"><i class="fa fa-facebook"></i></a></li>
        <li style="border-top: none;"><a href="https://twitter.com/share?" target="_blank" class="twitter social_a"><i class="fa fa-twitter"></i></a></li>
         <li style="border-top: none;"><a href="https://www.linkedin.com/shareArticle?mini=true&amp" target="_blank" class="linkedin social_a"><i class="fa fa-linkedin"></i></a></li>
         <li style="border-top: none;"><a href="https://pinterest.com/pin/create/button/?" target="_blank" class="pinterest social_a"><i class="fa fa-pinterest"></i></a></li>
         <li style="border-top: none;"><a href="https://www.tumblr.com/widgets/share/tool" target="_blank" class="twitter social_a"><i class="fa fa-tumblr"></i></a></li>
         <li style="border-top: none;"><a href="https://www.Instagram.com/" target="_blank" class="youtube social_a"><i class="fa fa-instagram"></i></a></li>
    </ul>
</div>
<hr class="page-divider small"/>
<script>
$(document).ready(function() {
	$('#popup-7').find('.closeModal').on('click',function(){
		$('#pnopoi').remove();
	});
	check_checkbox();
	set_select();
	// $('#share').share({
	// 	urlToShare: '<?php //echo $this->crud_model->product_link($row['product_id']); ?>',
	// 	networks: ['facebook','googleplus','twitter','linkedin','tumblr','in1','stumbleupon','digg'],
	// 	theme: 'square'
	// });
});
function check_checkbox(){
	$('.checkbox input[type="checkbox"]').each(function(){
        if($(this).prop('checked') == true){
			$(this).closest('label').find('.cr-icon').addClass('add');
		}else{
			$(this).closest('label').find('.cr-icon').addClass('remove');
		}
    });
}
function check(now){
	if($(now).find('input[type="checkbox"]').prop('checked') == true){
		$(now).find('.cr-icon').removeClass('remove');
		$(now).find('.cr-icon').addClass('add');
	}else{
		$(now).find('.cr-icon').removeClass('add');
		$(now).find('.cr-icon').addClass('remove');
	}
}
function decrease_val(){
	var value=$('.quantity-field').val();
	if(value > 1){
		var value=--value;
	}
	$('.quantity-field').val(value);
}
function increase_val(){
	var value=$('.quantity-field').val();
	var max_val =parseInt($('.quantity-field').attr('max'));
	if(value < max_val){
		var value=++value;
	}
	$('.quantity-field').val(value);
}
</script>