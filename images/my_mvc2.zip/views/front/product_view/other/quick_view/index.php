<!-- PAGE -->
<link rel="stylesheet" href="<?php echo base_url(); ?>template/front/js/share/jquery.share.css">
<script src="<?php echo base_url(); ?>template/front/js/share/jquery.share.js"></script>
<style>
    .rate_it{
        display:none;
    }
    .product-single .fix-length{
        height: auto !important; 
        overflow:auto;
        margin-top: 15px;
    }
    .color_label ,
    .sold_by,
    .product-sizes,
    .price_label{
        margin-top: 15px;
        margin-bottom: 15px;
        font-size: 15px;
        font-weight: 600;
    }
    .color_names
    {
        margin-top: 5px;
        font-size: 12px;
    }
    .btn_variant_size,
    .color_names
    {
        border-radius: 6px;
        padding: 2px 18px;
        margin-top: 5px;
    }
    .product-single .col-md-5,
    .product-single .col-md-7{
        margin-top: 15px !important;
    }
    .btn:hover{
        border-radius: 6px;
    }
    .added_by_names{
        margin-top: 5px;
        font-size: 16px;
    }
    .product_variant_colors{
        margin-top: 10px !important;
    }
    .product_variant_price{
        font-weight: bold !important;
        margin-top: 15px;
        color: #B22234;
    }
    .custom_btn{
        color: black;
        background-color: #fff;
        border-color: #ccc;
        border-radius: 6px;
        box-shadow: 2px 3px 5px #3333336e !important; 
        margin: 10px 7px 10px 0px;
    }
    .added-by{
        margin-bottom: 10px;
    }
    #set_image{
        display: block;
        margin: auto;
        max-height: 100%;
        width: auto;
    }
    .img{
        height: 100%;
        display: block;
        margin: auto;
    }
    .without_discount_price{
        color: gray;
    }
    .discount_price{
        font-weight: bold;
    }
    .main_img_holder{
        box-shadow: 0px 1px 5px #ccc;
        display: flex;
        width: 100%;
        border: 1px solid #ccc;
        height: 400px;
    }
     .variant_other_img_holder{
        height: 80px;
        width: 100%;
        overflow-y: hidden;
        overflow-x: scroll;
        padding: 5px;
        white-space: nowrap;
    }
    .shipping_price_div{
        margin: 10px 0px;
    }
    .shipping_price_div span:nth-child(1){
        font-size: 15px;
        color: black;
        font-weight: bold;
    }
    .shipping_price_div span:nth-child(2){
        color: #007e4b;
        font-size: 18px;
        font-weight: 500;
        margin-left: 6px;
    }
    .shipping_price_div  i{
        color: #b22234;
        margin-right: 10px;
        font-size: 20px;
    }
    .stock_status_div{
        margin: 18px 0px;
    }
    .stock_status_div span:nth-child(1){
        font-size: 14px;
        font-weight: bold;
        color: gray;
    }
    .stock_status_div span:nth-child(2){
        font-weight: bold;
    }
    .selected{
        background-color: rgb(214, 214, 214);
    }
</style>
<?php
    $single_variant = $variants[0];
    $id_wise_variants = array();
    $sizes = array(); 
    $sizes_without_quotes = array(); 
    foreach($variants as $variant){

        $actual_size = str_replace("'", "", $variant['actual_size']);
        $actual_size = str_replace('"', "", $actual_size);

        $description  = preg_replace("/[^a-zA-Z]/", " ", $variant['description']);
        $material  = preg_replace("/[^a-zA-Z]/", " ", $variant['material']);
        $features  = preg_replace("/[^a-zA-Z]/", " ", $variant['features']);
        $title  = preg_replace("/[^a-zA-Z]/", " ", $variant['title']);

        $id_wise_variants[$variant['product_variants_id']] =  $variant;
        $id_wise_variants[$variant['product_variants_id']]['actual_size'] = $actual_size;
        $id_wise_variants[$variant['product_variants_id']]['images'] = json_decode($variant['images'],true);
        $id_wise_variants[$variant['product_variants_id']]['front_image'] = json_decode($variant['front_image'],true);
        $id_wise_variants[$variant['product_variants_id']]['color'] = json_decode($variant['color'],true);
        $id_wise_variants[$variant['product_variants_id']]['selling_price'] = currency($this->crud_model->get_product_price($variant['product_variants_id']));
        $id_wise_variants[$variant['product_variants_id']]['description'] = $description;
        $id_wise_variants[$variant['product_variants_id']]['features'] = $features;
        $id_wise_variants[$variant['product_variants_id']]['material'] = $material;
        $id_wise_variants[$variant['product_variants_id']]['title'] = $title;
        $id_wise_variants[$variant['product_variants_id']]['without_discounted'] = currency($variant['selling_price']);
        $colors = json_decode($variant['color'],true);
        foreach($colors as $color){
            $sizes[$variant['product_id']."@@".$variant['actual_size']."@@".$actual_size][] = $color."@@".$variant['product_variants_id'];
            $sizes_without_quotes[$variant['product_id']."@@".$actual_size][] = $color."@@".$variant['product_variants_id'];
        }
    }
?>
<section class="page-section">
    <form id="single_product_add_to_cart">
        <div class="row product-single" style="margin-top: 0px;">
            <div class="col-md-5 hidden-xs hidden-sm">
                <div class="row">
                    <div class="col-md-12">
                        <div class="main_img_holder">
                           <img class="img-responsive  pic_zoom" id="set_image" src="" alt=""/>
                            <div id="set_video"></div> 
                         </div>
                         <br />
                        <div class="variant_other_img_holder">
                            <?php 
                                $first = "";
                                if($single_variant['front_image']!="" && $single_variant['front_image']!=NULL){
                                    $img =  json_decode($single_variant['front_image'], true);
                                    $first = $img[0];
                                }
                                $thumbs = $this->crud_model->get_image('product_variants', $first);
                            ?>
                            <?php if($first != ""){ ?>
                             <div class="related-product">
                                <img class="img-responsive img"  src="<?php echo $thumbs; ?>" alt=""/>
                            </div>
                            <?php  }
                                $i=1;
                                $product_variants_imgs = json_decode($single_variant['images'], true);
                                if(count($product_variants_imgs)>0){
                                    foreach($product_variants_imgs as $product_variants_imgs){
                                    $thumbs = $this->crud_model->get_image('product_variants', $product_variants_imgs);
                                ?>
                                    <div class="related-product" id="main<?php echo $i; ?>">
                                        <img class="img-responsive img" data-src="<?php echo $thumbs; ?>" src="<?php echo $thumbs; ?>" alt=""/>
                                    </div>
                                <?php
                                    $i++;
                                    }     
                                }  else{         
                            ?>
                            <div class="related-product" id="main1">
                                <img class="img-responsive img " data-src="<?php echo $this->crud_model->get_image('product_variants', 'default.jpg'); ?>" src="<?php echo $this->crud_model->get_image('product_variants', 'default.jpg'); ?>" alt=""/>
                            </div>
                        <?php } ?>
                        <?php 
                         if( $single_variant['video']!="" && $single_variant['video']!=NULL ){
                            $video_path = explode("/",$single_variant['video']);
                            $video_name =  $video_path[count($video_path)-1];
                        ?>
                        <div class="related-product variant_video_link" height="50" data-src="<?php echo $this->crud_model->get_video('product_variants', $video_name); ?>">
                            <video width="100%">
                              <source src="<?php echo $this->crud_model->get_video('product_variants', $video_name); ?>" type="video/mp4">
                            </video>  
                        </div>
                        <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-7">
                <h3 class="product-title">
                    <span class="product_variant_title">
                        <?php 
                            if($single_variant['title']!="" && $single_variant['title']!=NULL){
                                 echo $single_variant['title'];
                            }else{
                                echo "Not Available";
                            }
                        ?>
                    </span>

                 </h3>   

                <!-- Sold By  -->
                <!-- <hr style="margin-top: 10px;margin-bottom: 10px;"> -->
                <?php if ($this->db->get_where('general_settings', array('general_settings_id' => '58'))->row()->value == 'ok'and $this->db->get_where('general_settings', array('general_settings_id' => '81'))->row()->value == 'ok'){ ?>
                    <!-- <div class="added-by">
                        <span class="sold_by">
                              <?php //echo translate('sold_by:');?>
                        </span>
                        <span class="added_by_names">
                            <?php //echo $this->crud_model->product_by($single_variant['product_id'],'with_link');?>
                        </span>
                    </div> -->
                <?php } ?>

                

                <!-- Rating stars -->
                <!-- <hr style="margin-top: 10px;margin-bottom: 10px;"> -->
                <!-- <div class="product-rating clearfix" style="margin-top: 10px;">
                    <?php //$rating = $this->crud_model->rating($single_variant['product_id']); ?>
                    <div  class="rateit" data-rateit-value="<?//= $rating ?>" data-rateit-ispreset="true" data-rateit-readonly="true" style="margin-bottom: 5px;"></div>
                    <div style="display: none" class="rating ratings_show" data-original-title="<?php //echo $rating = $this->crud_model->rating($single_variant['product_id']); ?>"
                        data-toggle="tooltip" data-placement="left">
                        <?php
                           // $r = $rating;
                            //$i = 6;
                            //while($i>1){
                                //$i--;
                        ?>
                            <span class="star <?php //if($i<=$rating){ echo 'active'; } $r++; ?>"></span>
                        <?php
                           // }
                        ?>
                    </div>
                    
                    <div class="rating inp_rev list-inline" style="display:none;" data-pid='<?php //echo $row['product_id']; ?>'>
                        <span class="star rate_it" id="rating_5" data-rate="5"></span>
                        <span class="star rate_it" id="rating_4" data-rate="4"></span>
                        <span class="star rate_it" id="rating_3" data-rate="3"></span>
                        <span class="star rate_it" id="rating_2" data-rate="2"></span>
                        <span class="star rate_it" id="rating_1" data-rate="1"></span>
                    </div>
                    <br>
                    <a class="reviews ratings_show" href="javascript:void(0)">
                        <?php //echo $single_variant['rating_num']; ?>
                        <?php //echo translate('review(s)'); ?> 
                    </a>   
                    <?php   
                        // if($this->session->userdata('user_login') == 'yes'){
                        //     $user_id = $this->session->userdata('user_id');
                        //     $user_products = $this->db->select('product_details')->from('sale')->where('buyer', $user_id)->get()->result_array();

                        //         foreach ($user_products as $user_prod) {
                        //             foreach($user_prod as $prods){
                        //                 $prods = json_decode($prods, true);
                        //                 foreach($prods as $prod){
                        //                     //echo $prod['id'];
                        //                     if($prod['id'] == $product_id){
                        //                         //echo $prod['id'];
                        //                         $is_review = 'yes';
                        //                     }
                        //                 }
                        //             }
                        //         }
                        //     $rating_user = json_decode($row['rating_user'],true);
                        //     if(!in_array($user_id,$rating_user)){
                        //         if ($is_review == 'yes') {
                    // ?>
                     <a style="display: none;" class="add-review rev_show ratings_show" href="#">
                         | <?php// echo translate('add_your_review');?> 
                    </a>
                    <?php 
                                // }
                            // }
                        // }
                    // ?>
                </div> -->
                <?php 
                if ($this->db->get_where('product', array('product_id' => $product_id))->row()->is_bundle == 'no') {
                ?>
                    <div class="product-info" style="font-size: 15px;">
                        <p>
                            <a href="<?php echo base_url(); ?>home/category/<?php echo $single_variant['category']; ?>">
                                <?php echo $this->crud_model->get_type_name_by_id('category',$single_variant['category'],'category_name');?>
                            </a>
                        </p>
                        |
                        <p>
                            <a href="<?php echo base_url(); ?>home/category/<?php echo $single_variant['category']; ?>/<?php echo $single_variant['sub_category']; ?>">
                                <?php echo $this->crud_model->get_type_name_by_id('sub_category',$single_variant['sub_category'],'sub_category_name');?>
                            </a>
                        </p>
                        |
                        <p>
                            <a href="<?php echo base_url(); ?>home/category/<?php echo $single_variant['category']; ?>/<?php echo $single_variant['sub_category']; ?>-<?php echo $single_variant['brand']; ?>">
                            <?php echo $this->crud_model->get_type_name_by_id('brand',$single_variant['brand'],'name');?>
                            </a>
                        </p>
                    </div>
                <?php
                }
                ?>
                <?php
                if ($this->db->get_where('product', array('product_id' => $product_id))->row()->is_bundle == 'yes') {
                ?>
                <div style="padding: 5px">
                    <?php echo translate('products_:');?> <br>
                    <?php
                        $products = json_decode($row['products'], true);
                        foreach ($products as $product) { ?>
                            <a style="text-decoration:underline; font-size: 12px; padding-left: 15px;" href="<?php echo $this->crud_model->product_link($product['product_id']); ?>">
                                <?php echo $this->db->get_where('product', array('product_id' => $product['product_id']))->row()->title . '<br>';?>
                            </a>
                    <?php
                        }
                    ?>
                </div>
                <?php
                }
                ?>
                <hr style="margin-top: 0px; margin-bottom:  12px;" />
                 <h3 class="product_variant_price">
                    <?php if($single_variant['discount'] > 0){   ?> 
                        <span class="discount_price">
                             <?php echo translate('Price : ');?>
                            <?php echo currency($this->crud_model->get_product_price($single_variant['product_variants_id'])); ?>
                        </span> &nbsp;&nbsp;
                        <del class="without_discount_price"><?php echo currency($single_variant['selling_price']); ?></del>
                    <?php } else { ?>
                            <?php echo translate('Price : ');?>
                            <?php  echo currency($single_variant['selling_price']); ?>
                    <?php }?>        
                </h3>
                <!-- <div class="shipping_price_div">
                    <span><i class="fa fa-truck"></i><?php //echo translate("shipping_price : "); ?></span>
                    <span>
                        <?php 
                            // if($single_variant['shipping_type'] == "free" || $single_variant['shipping_type'] == "" || $single_variant['shipping_type'] == NULL){
                            //     echo "Free";
                            // }else if($single_variant['shipping_type']=="flat"){
                            //     echo currency($single_variant['flat_rate']);
                            // }else if($single_variant['shipping_type']=="weight"){
                            //     echo "Weight Wise Applied.";
                            // }
                        ?>
                    </span>
                </div> -->
                <div class="stock_status_div">
                    <span><?php echo translate("Stock : "); ?></span>
                    <span>
                        <?php
                            if($single_variant['stock_status']>0){
                                echo $single_variant['stock_status']." ".translate("available");
                            }else{
                                echo translate("out_of_stock");
                            }
                        ?>
                    </span>
                </div>
                <div class="product-colors">
                    <span class="color_label" style="font-size: 15px !important"><?php echo translate('Colors:');?> </span>
                  <div class="row">
                    <div class="col-md-12 product_variant_colors">
                        <?php 
                            foreach($sizes as $size){
                               foreach($size as $color_id){
                                    $color_id_arr = explode("@@" , $color_id);
                        ?>
                        <button class="custom_btn btn btn-md btn-default variant_color" data-selected="false" data-variant-id="<?php echo $color_id_arr[1]; ?>" data-variant-color="<?php echo $color_id_arr[0]; ?>">
                            <?php echo $color_id_arr[0]; ?>
                        </button>
                        <?php } break;  } ?>
                    </div>
                  </div>
                  <input type="hidden" name="single_color" id="single_color" value="">
                </div>
                <!-- <hr style="margin-top: 10px;margin-bottom: 10px;"> -->
                <div class="product-sizes" style="max-height: 175px; overflow: auto;">
                    <span class="size_label">
                        <?php echo translate('Sizes :');?>
                    </span><br>
                    <?php 
                        foreach($sizes as $key => $size){
                            $variant_size = explode("@@" , $key);
                    ?>
                    <buttton class="custom_btn btn btn-default btn-xs btn_variant_size" data-product-id="<?php echo $variant_size[0]; ?>" data-selected="false" data-variant-size="<?php echo $variant_size[2]; ?>">
                        <?php echo $variant_size[1]; ?></buttton>
                    <?php } ?>
                </div>

                <!-- Order Option  -->
                <?php
                    include 'order_option.php';
                ?>
                <h4>
                    <a style="color: #b50000;" href="<?php echo $this->crud_model->product_link($single_variant['product_id']); ?>">
                        <?php echo translate('view_details');?>
                    </a>
                </h4>
            </div>
        </div>
    </form>
</section>

<!-- /PAGE -->

         

<script>
    $(document).ready(function(){
            
        var variant_id = $(".variant_color").eq(0).attr("data-variant-id");
        var variant_color = $(".variant_color").eq(0).attr("data-variant-color");
        $("#single_color").val(variant_color);

        $(".cart").attr("onclick","to_cart("+variant_id+",event)");

        $(".btn_variant_size").eq(0).addClass("selected");
        $(".btn_variant_size").eq(0).attr("data-selected","true");

        $(".variant_color").eq(0).addClass("selected");
        $(".variant_color").eq(0).attr("data-selected","true");

        $("#single_product_add_to_cart").submit(function(e){
            e.preventDefault();
        }); 

    });

    var  id_wise_variants = '<?php echo json_encode($id_wise_variants); ?>';
    id_wise_variants = JSON.parse(id_wise_variants);

    var sizes_without_quotes  = '<?php echo json_encode($sizes_without_quotes); ?>';
    sizes_without_quotes  = JSON.parse(sizes_without_quotes);

    $(document).on("click",".variant_color",function(){
        $(".variant_color").attr("data-selected","false");
        $(".variant_color").removeClass("selected");
        $(this).attr("data-selected","true");
        $(this).addClass("selected");
        var variant_id  = $(this).attr("data-variant-id");
        var variant_color = $(this).attr("data-variant-color");
        $("#single_color").val(variant_color);
        var single_variant = id_wise_variants[variant_id];
        $(".cart").attr("onclick","to_cart("+single_variant.product_variants_id+",event)");
        setup_product_details(single_variant);
    });

    $(".btn_variant_size").click(function(){
        $(".btn_variant_size").removeClass("selected");
        $(".btn_variant_size").attr("data-selected","false");
        $(this).addClass("selected");
        $(this).attr("data-selected","true");
        var product_id = $(this).attr("data-product-id");
        var variant_size = $(this).attr("data-variant-size");
        color_by_size = sizes_without_quotes[product_id+"@@"+variant_size];
        var colors = color_by_size;
        var get_color = "";
        $.each(colors,function(ind , val){
            var color_id = val.split('@@');
            get_color += '<button class="custom_btn btn btn-md btn-default variant_color" data-selected="false" data-variant-id="'+color_id[1]+'" data-variant-color="'+color_id[0]+'" data-selected="false">';
                get_color += color_id[0];
            get_color += "</button>";
        });
        $(".product_variant_colors").html(get_color);
        $(".variant_color").eq(0).addClass("selected");
        $(".variant_color").eq(0).attr("data-selected","true");
        var variant_id = $(".variant_color").eq(0).attr("data-variant-id");
        var variant_color = $(".variant_color").eq(0).attr("data-variant-color");
        $("#single_color").val(variant_color);
        $(".cart").attr("onclick","to_cart("+variant_id+",event)");
        var single_variant = id_wise_variants[variant_id];
        setup_product_details(single_variant);
    });

    $(document).on("click",".variant_video_link",function(){
        var src = $(this).data('src');
        var video = "";
        video += '<video width="100%" height="400" controls autoplay>';
             video += '<source src="'+src+'" type="video/mp4">';
        video += '</video>';
        $("#set_video").html(video);
        $(".related-product").removeClass("selected");
        $(this).closest(".related-product").addClass("selected");
        $("#set_image").hide();
    });
	$(document).on("click",".img",function(){
        $("#set_video").html("");
        $("#set_image").show();
		var src = $(this).data('src');
		$("#set_image").attr("src", src);
		$(".related-product").removeClass("selected");
		$(this).closest(".related-product").addClass("selected");
	});
	$(document).ready(function() {
		$("#main1").addClass("selected");
		var src = $("#main1").find(".img").data('src');
		$("#set_image").attr("src", src);
	});
	
	$(function(){
		if($('#main1').length > 0){
			$('#main1').click();
		}
	});
    $('.closeModal').on('click', function(){
        $('.magnifier').remove();
        $('.cursorshade').remove();
        $('.statusdiv').remove();
        $('.tracker').remove();
        $('.main-img').remove();
    });
    $('body').on('click', '.rev_show', function(){
        $('.ratings_show').hide('fast');
        $('.inp_rev').show('slow');
    });


    function setup_product_details( data )
    {
        var title = "Not Available";
        if(data.title!=null && data.title!=""){
            title = data.title;
        }
        $(".product_variant_title").text(title);
        if(data.stock_status > 0){
            $(".stock_status_div span:nth-child(2)").text(data.stock_status+' <?php echo translate("available"); ?>');
            $(".quantity-field").attr("max",data.stock_status);
            $(".quantity-field").val(1);
            $(".out_of_stock").hide();
            $(".product-quantity , .stock_quick , .btn_add_to_cart_quick_view").show();
        }else{
            $(".stock_status_div span:nth-child(2)").text('<?php echo translate("out_of_stock"); ?>');
            $(".product-quantity , .stock_quick , .btn_add_to_cart_quick_view").hide();
            $(".out_of_stock").show();
        }
        if(data.description!="" && data.description!=null){
            $(".description").text(data.description);
            $(".col_description").show();
        }else{
             $(".col_description").hide();
        }
        var features = "";
        if(data.features!="" && data.features!=null){
            features_arr = data.features.split("@@@");
            for(var i=0; i<features_arr.length; i++){
                features += "<p>"+features_arr[i]+"</p>";
            }
            $(".col_features").show();
        }else{
             $(".col_features").hide();
        }
       
        $(".stock_status").text(data.stock_status);
        $(".cart_quantity").attr("max",data.stock_status);
        $(".stock").text(data.stock_status+" "+'<?php echo translate('available');?>');
        

        var actual_price = "";
        if(data.discount>0){
            actual_price += '<span class="discount_price">';
                actual_price+= '<?php echo translate('Price : ');?> ';
                actual_price += data.selling_price;
            actual_price += '</span>&nbsp;&nbsp;'

            actual_price +='&nbsp;&nbsp;<del class="without_discount_price">';
                actual_price +=  data.without_discounted;
            actual_price +='</del>';
        }else{
            actual_price += '<?php echo translate('Price : ');?>&nbsp;';
            actual_price += '<?php  echo currency($single_variant['selling_price']); ?>';
        }
        $(".product_variant_price").html(actual_price);
        
        other_images = "";
        variant_img =  data.images ;
        var count = 1;
        var variant_selected = "";
        var variant_first_img  = "";
        if(variant_img.length>0){
            $.each(variant_img, function(index, value){
                if(count==1){
                    variant_first_img = value;
                    variant_selected = "selected";
                }else{
                    variant_selected = "";   
                }
                base_url = "<?php echo base_url('uploads/product_variants_image'); ?>";
                other_images +="<div class='related-product "+variant_selected+"' id='main"+count+"'>";
                    other_images += "<img class='img-responsive img' data-src='"+base_url+"/"+value+"' src='"+base_url+"/"+value+"'>";
                other_images += "</div>";
                count++;
            });
            $("#set_image").attr("src", base_url+"/"+variant_first_img);
        }
        else{
            variant_first_img = "<?php echo $this->crud_model->get_image('product_variants', 'default.jpg'); ?>";
            $("#set_image").attr("src", variant_first_img);
        }
        $(".variant_other_img_holder").html(other_images);
    }
</script>
<script type="text/javascript" src="<?php echo base_url()?>template/front/plugins/Image_zoom/Zoom.js"></script>
<script>
        $(".pic_zoom").imagezoomsl({
        zoomrange: [3, 3]});
</script> 