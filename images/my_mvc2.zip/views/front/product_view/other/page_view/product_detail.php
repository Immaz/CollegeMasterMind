<?php recache(); ?>

<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.carousel.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/assets/owl.theme.default.min.css" rel="stylesheet">
<?php
$facebook = $this->db->get_where('social_links', array('type' => 'facebook'))->row()->value;
$googleplus = $this->db->get_where('social_links', array('type' => 'google-plus'))->row()->value;
$twitter = $this->db->get_where('social_links', array('type' => 'twitter'))->row()->value;
$skype = $this->db->get_where('social_links', array('type' => 'skype'))->row()->value;
$youtube = $this->db->get_where('social_links', array('type' => 'youtube'))->row()->value;
$pinterest = $this->db->get_where('social_links', array('type' => 'pinterest'))->row()->value;
$instagram = $this->db->get_where('social_links', array('type' => 'instagram'))->row()->value;
$tiktok = $this->db->get_where('social_links', array('type' => 'tiktok'))->row()->value;

    $countrries_data = $this->db->get("country")->result();
    $countries_data_html = "";
    foreach($countrries_data as $cd){
        $selected = ($cd->short_country_code == 'US') ? 'selected' : '';
        $countries_data_html .= "<option {$selected} value='{$cd->short_country_code}'>{$cd->country_name}</option>";
    }
?>
<!-- PAGE -->
<style type="text/css">
    .btn_variant_size,
    .color_names
    {
        padding: 2px 18px;
        margin-top: 5px;
    }
    .btn_variant_size:hover{
        color: #333;
        border: 1px solid #6e6e6e;
        background: #eee;
    }
    .product_variant_price{
        font-weight: bold;
        /*margin-top: 15px;*/
    }
    .color_label ,
    .size_label,
    .sold_by,
    .product-sizes,
    .price_label{
        margin-top: 5px;
        margin-bottom: 5px;
        font-size: 13px;
        color: #828282;
        font-weight: normal;
    }
    .added_by_names{
        font-size: 16px;
    }
    .product_specification_row{
        margin-top: 0%;
        padding: 0px 30px 10px 30px;
    }
    .product_specification_row div[class*="col-"]{
        margin-top: 5px;
    }
    .description{
        font-size: 14px;
    }
    .main_img_col{
        height: 500px;
    }
    .btn_product_view_add_to_cart{
        margin-top: 5px;
    }
    .btn_product_view_add_to_cart:hover{
        background-color: #B22234;
        transition: all 0.2s;
        border:1px solid #B22234;
        border-radius: 3px;
    }
    .cart_quantity{
        text-align: center;
    }
    .related_product_owl_col_2{
        margin-bottom: 10px;
        margin-top: 0px !important;
    }
    .col_term_policy .jumbotron{
        background: #f5f5f5;
        padding: 5px 15px;
        margin: auto;
        margin-top: 10px;
    }
    .col_term_policy .jumbotron:nth-child(1){
        background: #f5f5f5;
    }
    .col_term_policy .jumbotron:nth-child(5),
    .col_term_policy .jumbotron:nth-child(6)
    {
       padding: 0px;
    }
    .col_term_policy .jumbotron:nth-child(6){
       background-color: white;

    }
    .col_term_policy .jumbotron p{
        line-height: 16px;
        font-size: 11px;
    }
    .col_term_policy .jumbotron h4{
        font-weight: bolder !important;
        font-size: 13px;
        height: 15px;
        color: #6e6e6e;
        margin-top: 4px;
    }   

    .col_term_policy .jumbotron i{
        font-size: 18px;
        margin: 0px 1px;
    }
    .seller_sku{
        padding-left: 5px;
    }
    .btn-default:hover{
        border: 1px solid #242424;
        color: #fff;
        background: #f3402c;

    }
    .custom_btn{
        display: inline-block;
      /* background: #FFF; */
       border: 1px solid #ddd; 
        text-decoration: none;
        margin: 0px 3px 6px 0px;
        color: #333;
        text-align: center;
        min-width: 80px;
    }
    .added-by{
        margin-bottom: 10px;
    }
    #set_image{
        display: block;
        margin: auto;
        max-height: 100%;
    }
    .img{
        height: 100%;
        display: block;
        margin: auto;
    }
    .main_product_variant_show{
        animation-duration: 1s;
    }
    .main_product_variant_show .col-md-1,
    .main_product_variant_show .col-md-4,
    .main_product_variant_show .col-md-3
    {
        margin-top: 25px !important;
    }
    .without_discount_price{
        color: gray;
        font-size: 20px;
    }
    .without_discount_price ,
    .discount_price{
        float: right;
        font-weight: lighter;
    }
    .discount_price{
        color: #242424;
    }
    .product_variant_price{
        color: #B22234;
    }
    .main_img_holder{
        display: flex;
        width: 100%;
        border: 1px solid #ccc;
        height: 300px;
    }
    .variant_other_img_holder{
        height: 70px;
        width: 238px;
        /*overflow-y: hidden;
        overflow-x: scroll;*/
        overflow:hidden;
        padding: 5px;
        white-space: nowrap;
        margin: auto;
       /* border: 1px solid black;*/
    }
    .shipping_price_div{
        margin: 3px 0px;
        font-weight: normal;
        display: inline-block;
        width: 100%;
        color: #6e6e6e;
        font-size: 13px;
    }
    .shipping_price_div span:nth-child(1),
    .shipping_price_div span:nth-child(2)
    {
        display: inline-block;
    }
    .shipping_price_div span:nth-child(2){
       
    }
    .col_features , .col_description{
        display: none;
    }
    .stock_status_div,
    .shipping_div
    {
        margin: -4px  0px;
        font-weight: normal;
        color: #6e6e6e;
        font-size: 13px;
    }
    .stock_status_div span:nth-child(2),
    .shipping_div span:nth-child(2),
    {
        font-size: 13px;
    }
    .selected{
        border: 1px solid #242424 !important;
        color: #fff !important;
        background: #f3402c !important;
        cursor: default;
    }
    .btn_compare{
        background: #5f5e92;
        color: #fff;
        border-radius: 5px;
        display: none;
        /*margin: 0 0 10px 0;*/
    }
    .btn_compare:hover{
        background: #3C3B6E;
        color: #fff;
        border-radius: 5px;
        /*margin: 0 0 10px 0;*/
    }
    .product_variant_price .price{
        font-weight: normal;
        display: inline-block;
        color: #6e6e6e;
    }
    .product_view_bc{
        margin-bottom: 0px;
        padding: 3px 1%;
        display: block;
        margin:  auto;
        border-radius: 0px;
        background: #F0F0F0;
        border-top: solid 1px #ddd;
        border-bottom: solid 1px #ddd;
    }
    .product_view_bc  .product_view_bc_span{
        color:  #777;
        font-weight: 500;
        font-size: 11px;
    }
    .product_view_bc  .product_view_bc_span i{
        color: #777;
        font-size: 8px;
        margin: 0px 6px;
    }
    .product_view_bc  .product_view_bc_span:hover{
        color: #B22234;
    }
    .content-area{
        background-color: #eef0f5;;
    }
    .page-section{
        padding-top: 0px;
    }
    .block-ellipsis {
        display: block;
        display: -webkit-box;
        max-width: 100%;
        margin: 0 auto;
        font-size: 14px;
        line-height: 1.5;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .single_product_label_save_of{
        text-align: center;
        color: gray;
    }
    .row_product_price_discount_save{
        display: flex;
        align-items: center;
    }
    .row_product_price_discount_save div[class*="col-"]{
        margin-top: 5px;
    }
    .row_product_price_discount_save .col-md-6:nth-child(1){
        padding-right: 30px;
    }
    .imagezoom-view{
        top: 157px !important;
        border: 2px solid black !important;
        height: 300px !important; 
    }
    .row_prod_rating div[class*="col-"]{
        margin-top: 25px;
    }
    .row_prod_view_bc{
        display: flex;
        align-items: center;
    }
    .row_prod_view_bc div[class*="col-"]{
        margin-top: 30px !important;
    }
    .perce_rating
    {
        display: flex;
        align-items: center;
    }
    .perce_rating div:nth-child(1),
    .perce_rating div:nth-child(3)
    {
        font-size: 12px;
    }
    .perce_rating > div:nth-child(1),
    .perce_rating > div:nth-child(3)
    {
        padding-left: 15px;
        padding-right: 15px;
    }
    .perce_rating div:nth-child(2)
    {
       width: 250px;
    }
    .overall_customer_rating .perce_rating .progress{
        margin-bottom: 0px; 
    }
    .overall_customer_rating .perce_rating .progress .progress-bar{
        background: linear-gradient(to bottom,#ffce00,#ffa700);
    }
    .overall_customer_rating .perce_rating{
        margin-bottom: 15px;
    }
    .btn_wish{
        background: #f3402d;
        color: #fff;
        border-radius: 1px;
        display: block;
        /*margin: 0 0 10px 0;*/
    }
    .btn_wish:hover{
        background: #242424;
        color:white!important;
        border-radius: 5px;
    }
    .rate_it{
        display:none;   
    }
    .product-single .badges div{
        padding: 0 5px !important;
    }
    .product-price del {
        font-weight: 400;
        font-size: 24px;
    }
    .variant_other_img_holder img ,
    .variant_other_img_holder div
    {
      -webkit-user-select: none; /* Safari 3.1+ */
      -moz-user-select: none; /* Firefox 2+ */
      -ms-user-select: none; /* IE 10+ */
      user-select: none; /* Standard syntax */
    }
    .holder_arrow .left_arrow{
        left: 0%;
    }
    .holder_arrow .right_arrow{
        right: 0%;
    }
    .right_arrow:hover ,  .left_arrow:hover{
        cursor: pointer;
    }
    .sld_lft_arr_bg{
        background-color:#f5f5f5 !important;
    }
    .holder_arrow{
        position: relative;
        width: 280px;
        margin:auto;
    }
    .holder_arrow .left_arrow,
    .holder_arrow .right_arrow
    {
        top: 0%;
        height: 100%;
        width: 20px;
        position: absolute;
        background-color: #eee;
        padding-top: 8%;
        padding-left: 5px;
    }
    .holder_arrow .left_arrow i,
    .holder_arrow .right_arrow i
    {
        color: #ccc;
    }
    .rateit:hover{
        cursor: pointer;
    }
    .rateit_holder{
        width: 90px;
        position: relative;
    }
    .rateit_holder .rateit_tooltip{
         width: 380px;
        height: 220px;
        border: 1px solid;
        position: absolute;
        left: 120%;
        top: -150%;
        border: 1px solid #ccc;
        background-color: #f9f9f9;
        z-index: 1;
        display: none;
    }
    .rateit_holder .rateit_tooltip .overall_customer_rating .perce_rating{
        margin-bottom: 10px;
    }
    .rateit_holder .rateit_tooltip h5{
        margin-left: 9%;
        margin-bottom: 3%;
        font-size: 22px;
        color: gray;
    }
    .rateit_tooltip_arrow{
        width: 20px;
        height: 21px;
        position: absolute;
        top: 15%;
        border-right: 20px solid #eee;
        border-top: 9px solid transparent;
        border-bottom: 11px solid transparent;
        left: -5%;
    }
    .rateit_holder .rateit_tooltip .perce_rating div:nth-child(2){
        width: 200px;
    }
    .rateit_holder .rateit_tooltip .overall_customer_rating{
        padding: 0px 28px;
    }
    .rateit_holder .rateit_tooltip .perce_rating > div:nth-child(1), 
    .rateit_holder .rateit_tooltip .perce_rating > div:nth-child(3) {
        padding-left: 15px;
        padding-right: 15px;
        color: #ff1515;
        text-shadow: 0px -1px 5px #ccc;
    }
    .rateit_holder:hover .rateit_tooltip{
        display: block !important;
    }
    .social-nav li a{
        width: 25px ;
        border-radius: 50px;
        height: 25px;
        line-height: 25px;
    }
    .social-nav li a i{
        font-size: 14px !important;
    }
    .color_size_holder_box{
        /*background: #f5f5f5;*/
        padding: 0px 15px 15px 15px;
        clear: both;
        /*margin-top: 5px;*/
        position: relative;
        width: 100%;
    }
    .prod_page_first_box{
        height: auto;
        width: 25%;
        float: left;
    }
    .prod_page_middle_box{
        height: auto;
        width: 55%;
        float: left;
        padding-left: 20px;
        padding-right: 20px;
    }
    .prod_page_last_box
    {
        height: auto;
        width: 20%;
        float: left;
    }
    @media (max-width: 480px){
    .prod_page_first_box {
        width: 100%;
        }
    }
    @media (max-width: 480px){
    .prod_page_middle_box  {
        width: 100%;
        padding: 20px;
        }
    }  
    @media (max-width: 480px){
    .prod_page_last_box {
        width: 100%;
        }
    } 
    .col_features .features,
    .description
    {
        color: #999;
    }
    .features p{
        margin-bottom: 5px;
    }
    .block-ellipsis-seller-sku {
        height: 12px;
        font-size: 14px !important;
        display: block;
        display: -webkit-box;
        max-width: 60%;
        margin: 0 auto;
        line-height: 1.2 !important;
        -webkit-line-clamp: 1;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }
    .brand_name{
        height: 16px;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
    }
</style>
<?php

    $single_variant = $variants[0];

    $id_wise_variants = array();
    $sizes = array(); 
    $sizes_without_quotes = array(); 
    foreach($variants as $variant){    
        $actual_size = str_replace("'", "", $variant['actual_size']);
        $actual_size = str_replace('"', "", $actual_size);

        
        $description  = base64_encode($variant['description']);
        $material  = preg_replace("/[^a-zA-Z]/", " ", $variant['material']);
        $features  = preg_replace("/[^a-zA-Z]/", " ", $variant['features']);
        $title  = preg_replace("/[^a-zA-Z0-9\s\.]/", " ", $variant['title']);
        $brand_name = preg_replace("/[^a-zA-Z]/", " ", $variant['brand_name']);
        
        $id_wise_variants[$variant['product_variants_id']] =  $variant;
        $id_wise_variants[$variant['product_variants_id']]['brand_name'] = $brand_name;
        $id_wise_variants[$variant['product_variants_id']]['actual_size'] = $actual_size;
        $id_wise_variants[$variant['product_variants_id']]['images'] = json_decode($variant['images'],true);
        $id_wise_variants[$variant['product_variants_id']]['rating_user'] = json_decode($variant['rating_user'],true);
        $id_wise_variants[$variant['product_variants_id']]['front_image'] = ($variant['front_image'])?json_decode($variant['front_image'],true) : [];
        $id_wise_variants[$variant['product_variants_id']]['color'] = json_decode($variant['color'],true);
        $id_wise_variants[$variant['product_variants_id']]['selling_price'] = currency($this->crud_model->get_product_price($variant['product_variants_id']));
        $id_wise_variants[$variant['product_variants_id']]['description'] = $description;
        $id_wise_variants[$variant['product_variants_id']]['features'] = $features;
        $id_wise_variants[$variant['product_variants_id']]['material'] = $material;
        $id_wise_variants[$variant['product_variants_id']]['save_off'] = $this->crud_model->get_product_variants_save_off_price($variant['product_variants_id']);
        $id_wise_variants[$variant['product_variants_id']]['title'] = $title;
        // $id_wise_variants[$variant['product_variants_id']]['color'] = preg_replace('/[^a-zA-Z0-9]/', ' , ', $color);
        $id_wise_variants[$variant['product_variants_id']]['without_discounted'] = currency($variant['selling_price']);

        $colors = json_decode($variant['color'],true);
        foreach($colors as $color){
            // $sizes[$variant['product_id']."@@".$variant['actual_size']."@@".$actual_size][] = preg_replace('/[^a-zA-Z0-9]/', ' , ', $color)."@@".$variant['product_variants_id'];
            // $sizes_without_quotes[$variant['product_id']."@@".$actual_size][] = preg_replace('/[^a-zA-Z0-9]/', ' , ', $color)."@@".$variant['product_variants_id'];
            $sizes[$variant['product_id']."@@".$variant['actual_size']."@@".$actual_size][] = $color."@@".$variant['product_variants_id'];
            $sizes_without_quotes[$variant['product_id']."@@".$actual_size][] = $color."@@".$variant['product_variants_id'];
        }
    }
//   echo "<pre>"; print_r($sizes); echo "</pre>"; die();
?>
<div class="well well-md product_view_bc">
        <div class="row row_prod_view_bc">
            <div class="col-md-11" style="margin-top: 0px!important;">
                  <a  class="product_view_bc_span" href="<?php echo base_url(); ?>">
                <?php echo translate("home"); ?>
                <i class="fa fa-chevron-right"></i>
            </a>
            <a class="product_view_bc_span" href="<?php echo base_url("home/category?category=".$product_view_bc['bc_category_id']); ?>">
                <?php 
                    if($product_view_bc['bc_category_name']!="" && $product_view_bc['bc_category_name']!=NULL){
                        echo ucwords($product_view_bc['bc_category_name'])."&nbsp;";
                    }else{
                        echo " -- &nbsp;";
                    }
                ?>
                <i class="fa fa-chevron-right"></i>
            </a>
            <a  class="product_view_bc_span" href="<?php echo base_url("home/category?category=".$product_view_bc['bc_category_id']."&sub_category=".$product_view_bc['bc_sub_category_id']); ?>">
                <?php 
                    if($product_view_bc['bc_sub_category_name']!="" && $product_view_bc['bc_sub_category_name']!=NULL){
                        echo ucwords($product_view_bc['bc_sub_category_name'])."&nbsp;";
                    }else{
                        echo " -- &nbsp;";
                    }
                ?>
              <i class="fa fa-chevron-right"></i>
            </a>
            <a class="product_view_bc_span" href="<?php echo base_url("home/category?category=".$product_view_bc['bc_category_id']."&sub_category=".$product_view_bc['bc_sub_category_id'])."&third_sub_category_id=".$product_view_bc['bc_third_sub_category_id']; ?>">
                <?php 
                    if($product_view_bc['bc_third_sub_ctg_name']!="" && $product_view_bc['bc_third_sub_ctg_name']!=NULL){
                        echo ucwords($product_view_bc['bc_third_sub_ctg_name'])."&nbsp;";
                    }else{
                        echo " -- &nbsp;";
                    }
                ?>
                <i class="fa fa-chevron-right"></i>
            </a>
            <a class="product_view_bc_span" href="<?php echo base_url("home/category?category=".$product_view_bc['bc_category_id']."&sub_category=".$product_view_bc['bc_sub_category_id'])."&third_sub_category_id=".$product_view_bc['bc_third_sub_category_id']."&brand=".$product_view_bc['bc_brand_id']; ?>">
                <?php 
                    if($product_view_bc['tc_brand_name']!="" && $product_view_bc['tc_brand_name']!=NULL){
                        echo ucwords($product_view_bc['tc_brand_name'])."&nbsp";
                    }else{
                        echo " -- &nbsp;";
                    }
                ?>
              </a>
            </div>
             <div class="col-md-1" style="margin-top: 0px!important;">
                <?php if($this->session->has_userdata('admin_login')=="yes"){ ?>
                <a target="_blank" href ="<?php echo base_url("admin/product/edit/".$single_variant['product_id']);  ?>" class="btn btn-xs btn-info">
                    <i class="fa fa-edit"></i>
                    <?php echo translate("edit"); ?></a>
                <?php } ?>
            </div>
        </div>
          
</div>
<section class="page-section light">
    <form id="single_product_add_to_cart">
        <div class="container">
            <div class="row product-single main_product_variant_show" style="margin-top: 0px;">
                <div class="col-md-12" style="margin-top: 20px;">
                    <div class="prod_page_first_box main_img_col">
                        <div class="main_img_holder">
                            <!-- <div class="badges"> -->
                                <?php //if($row['featured'] == 'ok'){ ?>
                                <!-- <div class="hot"><?php //echo translate('featured'); ?></div> -->
                                <?php //} ?>
                                <?php //if($row['deal'] == 'ok'){ ?>
                                <!-- <div class="new"><?php //echo translate("today's_deal"); ?></div> -->
                                <?php //} ?>
                            <!-- </div> -->
                            <img class="img-responsive" id="set_image" src="" alt="" data-imagezoom="true" data-zoomviewsize="[600,400]" data-magnification="5"/>
                        </div><br>
                        <div class="holder_arrow">
                            <div class="left_arrow"><i class="fa fa-chevron-left"></i></div>
                            <div class="variant_other_img_holder">
                                <?php
                                    $i=1;
                                    $product_variants_imgs = json_decode($single_variant['images'], true);                        
                                    if(count($product_variants_imgs)>0){
                                        foreach($product_variants_imgs as $product_variants_imgs){
                                        $thumbs = $this->crud_model->get_image('product_variants', $product_variants_imgs); 
                                    ?>
                                        <div class="related-product" id="main<?php echo $i; ?>">
                                            <img class="img-responsive img" data-src="<?php echo $thumbs; ?>" src="<?php echo $thumbs . '?v=' . time(); ?>" alt=""/>
                                        </div>
                                    <?php
                                        $i++;
                                        }           
                                    }    else{     
                                    ?>
                                   <div class="related-product" id="main1">
                                        <img class="img-responsive img" data-src="<?php echo $this->crud_model->get_image('product_variants', 'default.jpg'); ?>" src="<?php echo $this->crud_model->get_image('product_variants', 'default.jpg'); ?>" alt=""/>
                                </div> 
                                <?php } ?>
                            </div>
                            <div class="right_arrow"><i class="fa fa-chevron-right"></i></div>
                        </div>
                    </div>
                    <div class="prod_page_middle_box single_product_middle_col">
                        
                    <h3 class="product-title">
                        <span class="product_variant_title">
                            <?php
                                if($single_variant['title']!="" && $single_variant['title']!=NULL){
                                    $title  = preg_replace("/[^a-zA-Z0-9\s\.]/", " ", $single_variant['title']);
                                    echo  $title;
                                }else{
                                    echo "Not Available";
                                }
                            ?>
                        </span>
                    </h3>
                    <?php
                    //if ($this->db->get_where('product', array('product_id' => $row['product_id']))->row()->is_bundle == 'yes') {
                    ?>
                    <!-- <div style="padding: 5px"> -->
                        <!-- <?php //echo translate('products_:');?> <br> -->
                        <?php
                            // $products = json_decode($row['products'], true);
                            // foreach ($products as $product) { ?>
                                <!-- echo $product['product_id'].'<br>'; -->
                                <!-- <a style="text-decoration:underline; font-size: 12px; padding-left: 15px;" href="<?php //echo $this->crud_model->product_link($product['product_id']); ?>"> -->
                                    <?php //echo $this->db->get_where('product', array('product_id' => $product['product_id']))->row()->title . '<br>';?>
                                <!-- </a> -->
                        <?php
                            // }
                        ?>
                    <!-- </div> -->
                    <?php
                    //}
                    ?>

                    <!-- Sold By  -->
            <!--    <hr style="margin-top: 10px;margin-bottom: 10px;"> -->
                <?php //if ($this->db->get_where('general_settings', array('general_settings_id' => '58'))->row()->value == 'ok'and $this->db->get_where('general_settings', array('general_settings_id' => '81'))->row()->value == 'ok'){ ?>
                    <!-- <div class="added-by">
                        <span class="sold_by">
                              <?php //echo translate('sold_by:');?>
                        </span>
                        <span class="added_by_names">
                            <?php //echo $this->crud_model->product_by($single_variant['product_id'],'with_link');?>
                        </span>
                    </div> -->
                <?php //} ?>

                <?php if($review_allowed == "ok"){ ?>
                <div class="row row_prod_rating">
                    <div class="col-md-12" style="margin-top: 0px!important;">
                        <div class="product-rating clearfix">
                            <?php  $rating = $this->crud_model->rating($single_variant['product_id']); ?>
                            <div class="rateit_holder">
                                <div class="rateit"  data-rateit-value="<?= $rating ?>"data-rateit-ispreset="true" data-rateit-readonly="true"></div>
                                <!----rateit tooltip ----->
                                <div class="rateit_tooltip">
                                    <h5><?php echo translate("customer_rating"); ?></h5>
                                    <div class="overall_customer_rating">
                                        <div class="perce_rating">
                                            <div><?php echo translate("5_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_5"]."%"; ?>">
                                                </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_5"]."%"; ?></div>
                                        </div>
                                        <div class="perce_rating">
                                            <div><?php echo translate("4_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_4"]."%"; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_4"]."%"; ?></div>
                                        </div>
                                         <div class="perce_rating">
                                            <div><?php echo translate("3_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_3"]."%"; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_3"]."%"; ?></div>
                                        </div>
                                        <div class="perce_rating">
                                            <div><?php echo translate("2_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_2"]."%"; ?>">
                                                </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_2"]."%"; ?></div>
                                        </div>
                                        <div class="perce_rating">
                                            <div><?php echo translate("1_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_1"]."%"; ?>">
                                                </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_1"]."%"; ?></div>
                                        </div>
                                    </div>
                                    <div class="rateit_tooltip_arrow"></div>
                                </div>
                                  <!----rateit tooltip  end----->
                            </div>
                            <div class="rating ratings_show" style="display:none;" data-original-title="<?php echo $rating = $this->crud_model->rating($single_variant['product_id']); ?>" data-toggle="tooltip" data-placement="left">
                                <?php
                                    $r = $rating; 
                                    $i = 6;
                                    while($i>1){
                                        $i--;
                                ?>
                                    <span class="star <?php if($i<=$rating){ echo 'active'; } $r++; ?>"></span>
                                <?php
                                    }
                                ?>
                            </div>
                            <div class="rating inp_rev list-inline" data-pid='<?php echo $single_variant['product_id']; ?>'>
                                <span class="star rate_it" id="rating_5" data-rate="5"></span>
                                <span class="star rate_it" id="rating_4" data-rate="4"></span>
                                <span class="star rate_it" id="rating_3" data-rate="3"></span>
                                <span class="star rate_it" id="rating_2" data-rate="2"></span>
                                <span class="star rate_it" id="rating_1" data-rate="1"></span>
                            </div>
                            <a class="reviews ratings_show" href="#">
                            </a>  
                            <?php  
                                if($is_user_add_rating){
                            ?>
                                <a style="" class="add-review rev_show ratings_show" href="#">
                                 <?php echo translate('add_your_review');?>
                                </a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php }?>
                <hr  style="margin-top: 0px; margin-bottom:  12px;"/>    
                <div class="row row_product_price_discount_save">
                    <div class="col-md-6" style="border-right: 1px solid #ccc;">
                        <h3 class="product_variant_price" style="font-weight: 600!important;">
                            <?php if($single_variant['discount'] > 0){ ?> 
                                <span class="price" style="font-size: 15px;">
                                    <?php echo translate('discounted_price:');?>
                                </span>
                                <span class="discount_price">
                                    <?php echo currency($this->crud_model->get_product_price($single_variant['product_variants_id'])); ?>
                                </span> <br />
                                <span class="price" style="font-size: 15px;">
                                    <?php echo translate('price:');?>
                                </span>
                                <del class="without_discount_price">
                                    <?php echo currency($single_variant['selling_price']); ?></del>
                            <?php } else {?>
                                <span class="price" style="font-size: 15px;">
                                    <?php echo translate('price:');?>
                                </span>
                                 <span class="discount_price">
                                <?php echo currency($single_variant['selling_price']); ?></span>
                            <?php }?>
                        </h3>
                    </div>
                    <!-- <div class="col-md-6">
                        <div class="form-group">
                        <label for="qty">Quantity: </label>
                            <select class="form-control qty" >
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                            </select>
                        </div>
                    </div> -->
                    <div class="col-md-3" style="margin-top: 0px !important;">
                        <?php
                            if($single_variant['discount']>0){
                        ?>
                        <div class="single_product_label_save_of">
                            <span><?php echo translate("You Save");  ?></span><br />
                            <div style="font-size: 20px; font-weight: 400; margin-top: -8px;">
                                <?php 
                                    echo $this->crud_model->get_product_variants_save_off_price($single_variant['product_variants_id'])."%";
                                ?>
                            </div>
                        </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="jumbotron" style="padding: 10px 0px 5px 0px!important; margin: 5px 0 0 0; border-radius: 0px!important;background: #f5f5f5!important;"> 
                <div class="color_size_holder_box">
                    <div class="shipping_price_div d-none" >
                        <span><?php echo translate("shipping : "); ?></span>
                        <span style="margin-left: 1%;">
                            <?php 
                                if($single_variant['shipping_type'] == "free" || $single_variant['shipping_type'] == "" || $single_variant['shipping_type'] == NULL){
                                     echo "Free";
                                }else if($single_variant['shipping_type']=="flat"){
                                    echo currency($single_variant['flat_rate']);
                                }else if($single_variant['shipping_type']=="weight"){
                                    echo "Weight Wise Applied.";
                                }
                            ?>
                        </span>
                        <p style="width: 100%; margin: 0px; font-size: 13px; margin-left: 12%;">
                            <?php
                                $shipping_days =  $single_variant['shipping_days'];
                                if($shipping_days!="" && is_numeric($shipping_days)){
                                    $shipping_date =  date('Y-m-d', strtotime(date('Y-m-d')." +" . $shipping_days . " day")); 
                                    echo "Order now and receive by ".date("D, F d",strtotime($shipping_date));
                                }
                            ?>
                        </p>
                    </div>
                    <div class="stock_status_div">
                        <span><?php echo translate("Stock : "); ?></span>
                        <span style="margin-left: 4.2%;">
                            <?php
                                if($single_variant['stock_status']>0){
                                    echo $single_variant['stock_status']." ".translate("available");
                                }else{
                                    echo translate("out_of_stock");
                                }
                            ?>
                        </span>
                    </div>
                </div>
             
                
                <?php if(count($sizes)>0){ ?>
                <div class="color_size_holder_box">
                    <?php if(count($sizes)>0){ ?>
                    <div class="product-sizes hidden" style="max-height: 175px; overflow: auto;">
                        <div class="size_label">
                            <?php echo translate('Select Size :');?>
                        </div>
                        <?php 
                            foreach($sizes as $key => $size){
                                $variant_size = explode("@@" , $key);
                        ?>
                        <buttton class="custom_btn btn btn-default btn-xs btn_variant_size" data-product-id="<?php echo $variant_size[0]; ?>" data-selected="false" data-variant-size="<?php echo $variant_size[2]; ?>">
                            <?php echo $variant_size[1]; ?></buttton>
                        <?php } ?>
                    </div>
                     <?php } ?>

                     <?php if(count($sizes)>0){ ?>
                        <div class="product-colors">
                            <span class="color_label"><?php echo translate('Select Variant :');?> </span>
                          <br>
                          <div class="row">
                            <div class="col-md-12 product_variant_colors" style="margin-top: 0px !important;">
                                <?php 
                                    foreach($sizes as $size){
                                       foreach($size as $color_id){
                                            $color_id_arr = explode("@@" , $color_id);
                                ?>
                                <button class="custom_btn btn btn-sm btn-default variant_color" data-selected="false" data-variant-id="<?php echo $color_id_arr[1]; ?>" data-variant-color="<?php echo $color_id_arr[0]; ?>">
                                    <?php echo $color_id_arr[0]; ?>
                                </button>
                                <?php } break;  } ?>
                            </div>
                        </div>
                          <input type="hidden" name="single_color" id="single_color" value="">
                          <input type="hidden" name="shipping_cost" id="shipping_cost">
                        </div>
                    <?php } ?>
                </div>
                  <?php } ?>
                  <?php 
                   if(count($sizes)==0){
                  ?>
                  <input type="hidden" class="variant_color" value="<?php echo $single_variant["product_variants_id"]; ?>" data-variant-id="<?php echo $single_variant["product_variants_id"]; ?>">
                    <?php } ?>
                <div class="row" style="margin-top: 2%;">
                    <div class="col-md-12" style="margin-top: 0px!important; margin-left: 5px!important;">
                        <?php include 'order_option.php'; ?>
                    </div>
                </div>
            </div>
                
                    </div>
                    <div class="prod_page_last_box col_term_policy">
                    <div class="jumbotron" style="margin-top: 0px;">
                        
                        <!-- <h4 style="margin-top: 6px;">
                            <img src="<?php echo base_url("uploads/others/store.png"); ?>" style="max-width: 8%; margin-right: 2%;">
                            <span style="display: inline-block;margin-left: 2%;margin-top: 1px;color: #242424;"><?php echo translate("Sold By"); ?></span>&nbsp;:&nbsp;<span style="font-weight: lighter;margin-left: 1%;"><?php echo translate("famina_attire");  ?></span>
                        </h4> -->
                        <h4 title="<?php echo $variant['brand_name']; ?>" data-toggle="tooltip" style="display: flex; margin-top: 6px;">
                            <img src="<?php echo base_url("uploads/others/brand_img.png"); ?>" style="max-width: 9%; margin-right: 2%;">
                            <span style="display: inline-block;margin-left: 2%;margin-top: 1px;color: #242424;"><?php echo translate("brand"); ?></span>&nbsp;:<div style="margin-left: 8%;font-weight: lighter; display: inline-block;margin-top: 1px;" class="brand_name"><?php echo ucwords($variant['brand_name']); ?></div>
                        </h4>
                        <h4 style="text-transform:uppercase; margin-bottom: 0px; margin-top: 0px;" title="<?php echo $variant['seller_sku']; ?>" data-toggle="tooltip">
                            <img src="<?php echo base_url("uploads/others/seller_sku.png"); ?>" style="max-width: 8%;margin-bottom: 1px; margin-right: 2%;">
                            <div style="display: inline-block;margin-left: 2%;color: #242424;"><?php echo translate("SKU"); ?></div> : <div style="font-weight: lighter;margin-left: 8%; display: inline-block;" class="seller_sku block-ellipsis-seller-sku"><?php echo $variant['seller_sku']; ?></div> 
                        </h4>
                    </div>
                    <div class="jumbotron">
                        <h4>
                            <div style="display: flex; align-items: center;">
                                <div><i class="fa fa-recycle" style="margin-right: 3px; color : green;"></i></div>
                                <div style="margin-left: 3%; color: #242424;"><?php echo translate("Return Policy*"); ?></div>
                            </div>
                        </h4>
                        <p>
                            We provide transparent return and exchange policy, please refer to terms and conditions for details
                        </p>
                    </div>
                    <div class="jumbotron">
                        <h4>
                            <div style="display: flex; align-items: center;">
                                <div><i class="fa fa-truck" style="margin-right: 3px; color : green;"></i></div>
                                <div style="margin-left: 3%; color: #242424;"><?php echo translate("Shipping Cost"); ?></div>
                            </div>
                        </h4>
                        <div>
                            <select class="form-control shipping_country" >
                                <option value="">Select Destination</option>
                                <?= $countries_data_html; ?>
                            </select>
                        </div>
                        <div class="mt-3 shipping-info-box">
                            <p style="color: green; font-weight: bold;" class="shipping_method_name text-center"> China Packet Plus</p>
                            <p style="color: #666; margin-bottom: 4px;" >Estimated Processing Time: <span class="process_time" style="color: black; font-weight: bold;">3 days</span></p>
                            <p style="color: #666; margin-bottom: 4px;" >Estimated Delivery Time: <span class="shipping_duration" style="color: black; font-weight: bold;">15-30 days</span></p>
                            <p style="color: #666; margin-bottom: 4px;" >Shipping Fee: <span class="shipping_charges" style="color: black; font-weight: bold;">$10.62-11.41</span></p>
                            <p style="color: #666; margin-bottom: 4px;" >Service Fee: <span class="service_fees" style="color: black; font-weight: bold;">$1.45-1.56</span></p>
                            
                        </div>
                        <div class="modal fade" id="select_shipping_method" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLongTitle">Select Shipping Method</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body modal-body-shipping-data" >
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th></th>
                                            <th class='text-center'>Shipping Method</th>
                                            <th class='text-center'>Shipping Fee</th>
                                            <th class='text-center'>Delivery Time</th>
                                        </tr>
                                        </thead>
                                        <tbody class="shipping_table_data">
                                       
                                       
                                        </tbody>
                                    </table>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary shipping-select">Select</button>
                                </div>
                                </div>
                            </div>
                        </div>
                        <p class="d-none">
                            <?php if($product_details[0]['shipping_cost_to'] != '0.00'){ ?>
                            <span class="shipping_cost"><?=currency($product_details[0]['shipping_cost'])?></span>-
                            <span class="shipping_cost_to"><?=currency($product_details[0]['shipping_cost_to'])?></span>
                            <?php }else{ ?>
                                <span class="shipping_cost"><?=currency($product_details[0]['shipping_cost'])?></span>
                                <?php } ?>
                        </p>
                    </div>
                    <div class="jumbotron">
                        <div style="display: flex; align-items: center;">
                            <div><i class="fa fa-check" style="margin-right: 3px; color : green;"></i></div>
                            <div><h4 style="margin-bottom: 6px; margin-left: 2%; width: 100%; color: #242424;"><?php echo translate("100% Genuine Products"); ?></h4></div>
                        </div>
                        <p>
                            We do not sell anything which is counterfeited or tempered-with in manner, so you can be at ease that purchased product is 100% genuine.
                        </p>
                    </div>
                    <div class="jumbotron">   
                          <?php 
                            $style = "";
                            if($single_variant['stock_status']>0){
                                $style = "style='display:block;'";
                            }else{
                                $style = "style='display:none;'";
                            }
                         ?>
                        <?php 
                           $wish = $this->crud_model->is_wished($single_variant['product_id']); 
                        ?>
                        <span class="btn btn-add-to btn_wish <?php if($wish == 'yes'){ echo 'wished';} else{ echo 'wishlist';} ?>" onclick="to_wishlist(<?php echo $single_variant['product_id']; ?>,event)">
                            <i class="fa fa-heart"></i>
                            <span class="hidden-sm hidden-xs">
                                <?php if($wish == 'yes'){ 
                                    echo translate('wishlist'); 
                                    } else { 
                                    echo translate('wishlist');
                                    } 
                                ?>
                            </span>
                       </span>
                        <?php 
                            $compare = $this->crud_model->is_compared($single_variant['product_id']); 
                        ?>
                       <span class="btn btn-add-to compare btn_compare" onclick="do_compare(<?php echo $single_variant['product_variants_id']; ?>,event)">
                            <i class="fa fa-exchange"></i>
                            <span class="hidden-sm hidden-xs">
                                <?php if($compare == 'yes'){ 
                                    echo translate('_compared'); 
                                    } else { 
                                    echo translate('_compare');
                                    } 
                                ?>
                            </span>
                        </span>     
                    </div>
                    <div class="jumbotron">
                        <ul class="social-nav model-2" style="float: left;margin-top: 10px; margin-left: 6%;">
                        <li style="border-top: none;"><a href="<?php echo $facebook; ?>" class="facebook social_a"
                    target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                <li style="border-top: none;"><a href="<?php echo $twitter; ?>" class="twitter social_a"
                    target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                <li style="border-top: none;"><a href="<?php echo $youtube; ?>" class="youtube social_a"
                    target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                <li style="border-top: none;"><a href="<?php echo $instagram; ?>" class="instagram social_a"
                    target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                <li style="border-top: none;"><a href="<?php echo $tiktok; ?>" class="tiktok social_a"
                    target="_blank"><i class="fa-brands fa-tiktok"></i></a></li>
                        </ul>
                        <div class="clear"></div>
                    </div>
                                    
                    </div>
                </div>
            </div>
            <div class="row product-single">
                <div class="row product_specification_row">
                    <div class="col-md-12 col_description">
                        <div class="tabs-wrapper content-tabs">
                            <ul class="nav nav-tabs">
                                <li  class="active"  ><a href="#tab1" data-toggle="tab"><?php echo translate('Description'); ?></a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="tab1">
                                    <div class="description">
                                        <?php 
                                            echo trim($single_variant['description']);
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                         <?php include 'product_specification.php'; ?>
                    </div>
                    <div class="col-md-12 col_features" style="font-size: 14px;">
                        <div class="tabs-wrapper content-tabs">
                            <ul class="nav nav-tabs">
                                <li  class="active"  ><a href="#features_tab" data-toggle="tab"><?php echo translate('Features'); ?></a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="features_tab">
                                    <div class="features">
                                        <?php 
                                            if($single_variant['features'] !="" && $single_variant['features']!=NULL){
                                                echo strip_tags(str_replace("@@@", " ", $single_variant['features']));
                                            }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php if($review_allowed == "ok"){ ?>
                    <div class="col-md-12">
                        <div class="tabs-wrapper content-tabs">
                            <ul class="nav nav-tabs">
                                <li  class="active"><a href="#overall_customer_rating_tab" data-toggle="tab"><?php echo translate('customer_rating'); ?></a></li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane fade in active" id="overall_customer_rating_tab">
                                    <div class="overall_customer_rating">
                                        <div class="perce_rating">
                                            <div><?php echo translate("5_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_5"]."%"; ?>">
                                                </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_5"]."%"; ?></div>
                                        </div>
                                        <div class="perce_rating">
                                            <div><?php echo translate("4_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_4"]."%"; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_4"]."%"; ?></div>
                                        </div>
                                         <div class="perce_rating">
                                            <div><?php echo translate("3_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_3"]."%"; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_3"]."%"; ?></div>
                                        </div>
                                        <div class="perce_rating">
                                            <div><?php echo translate("2_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_2"]."%"; ?>">
                                                </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_2"]."%"; ?></div>
                                        </div>
                                        <div class="perce_rating">
                                            <div><?php echo translate("1_star"); ?></div>
                                            <div>
                                                <div class="progress">
                                                  <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo $percentage_rating["rating_1"]."%"; ?>">
                                                </div>
                                                </div>
                                            </div>
                                            <div><?php echo $percentage_rating["rating_1"]."%"; ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php }?>
                </div>
            </div>
            <?php
                $recommends = $this->crud_model->getRelatedProduct($para_product_id);
                if(count($recommends)>0){
            ?>
            <div class="row">
                <div class="col-md-12 ">
                    <div class="recommendation">
                        <h3 class="title">
                            <?php echo translate('related_products');?>
                        </h3>
                    </div>
                </div>
                <div class="col-md-12 related_product_owl_col_2">
                    <div class="owl_slider_related_product">
                        <?php
                            foreach($recommends as $rec){
                                $product_variants_img = json_decode($rec['images'] , true);
                                $rec['title'] = str_replace('"', "", $rec['title']);
                                $rec['title'] = str_replace("'", "", $rec['title']);
                        ?>
                            <div class="recommend_box_1">
                                <a class="link" href="<?php echo  base_url("home/product_view/".$rec['product_id']."/".$this->crud_model->infiltrate_unwated_character($title));?>">
                                    <div class="image-box" style="background-image:url('<?php echo $this->crud_model->get_image("product_variants" , $product_variants_img[0]); ?>');background-size:cover; background-position:center;">
                                    </div>
                                    <h4 class="block-ellipsis caption-title " style="height: 41px; margin-top: 10px;" title="<?php echo $rec['title']; ?>">
                                        <b><?= ucfirst($rec['title']);?></b>
                                    </h4>
                                    <?php $rating = $this->crud_model->rating($rec['product_id']); ?>
                                    <?php if($review_allowed == "ok"){ ?>
                                    <div  class="rateit" data-rateit-value="<?= $rating ?>" data-rateit-ispreset="true" data-rateit-readonly="true"></div>
                                    <?php }?>
                                    <div class="price clearfix">
                                        <?php if($rec['discount'] > 0){ ?> 
                                            <ins>
                                                <?php echo currency($this->crud_model->get_product_price($rec['product_variants_id'])); ?>
                                            </ins>
                                            <del><?php echo currency($rec['selling_price']); ?></del>
                                        <?php 
                                        }
                                        else{
                                        ?>
                                        <ins>
                                            <?php echo currency($rec['selling_price']); ?>
                                        </ins>
                                        <?php
                                        }
                                        ?>
                                    </div>
                                </a>
                            </div>
                        <?php
                            }
                            ?>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    </form>
</section>
<!-- /PAGE -->
<script>
        $(".shipping-info-box").hide();
        var no_of_img = $(".variant_other_img_holder .related-product").length-3;
        var total_no_of_img = $(".variant_other_img_holder .related-product").length;
        var slider_img_cal_width = 78;
        var scroll_from_left = 0;
        var no_of_scroll_to_right = 0;
        function show_hide_pro_spec()
        {
            if($(".table_product_info .weight td").text().trim()=="")
            {
                $(".table_product_info .weight").hide();
            }
            if($(".table_product_info  .shape td").text().trim()=="")
            {
                $(".table_product_info .shape").hide();
            }
            if($(".table_product_info .material td").text().trim()=="")
            {
                $(".table_product_info .material").hide();
            }
            if($(".table_product_info .collection td").text().trim()=="")
            {
                $(".table_product_info .collection").hide();
            }
            if($(".table_product_info .style td").text().trim()=="")
            {
                $(".table_product_info .style").hide();
            }
            if($(".table_product_info .primary_style td").text().trim()=="")
            {
                $(".table_product_info .primary_style").hide();
            }
            if($(".table_product_info .construct_by td").text().trim()=="")
            {
                $(".table_product_info .construct_by").hide();
            }
            if($(".table_product_info .use td").text().trim()=="")
            {
                $(".table_product_info .use").hide();
            }
            if($(".table_product_info .origin td").text().trim()=="")
            {
                $(".table_product_info .origin").hide();
            }
        }

        function selectDefaultShipping() {

                $shipping_country_start = "CN";
                $shipping_country_end = "US";
                shipping_data = "";
                if($shipping_country_end == ""){
                    return;
                }
                $selected_variant_id = $('button.variant_color[data-selected="true"]').attr('data-variant-id');
                
                // Getting CJ Variant ID
                $.ajax({
                    url: "<?php echo base_url(); ?>/home/getCjVariantId/"+$selected_variant_id,
                    type: "GET",
                    success: function(response){
                            cj_variant_id = response;
                            variant_qty = $(".qty").val();
                            const requestData = {
                                startCountryCode: $shipping_country_start,
                                endCountryCode: $shipping_country_end,
                                products: [
                                    {
                                        quantity: `${variant_qty}`,
                                        vid: `${cj_variant_id}`
                                    }
                                ]
                            };
                        // Api Data Ajax
                            $.ajax({
                            url: 'https://developers.cjdropshipping.com/api2.0/v1/logistic/freightCalculate',
                            type: 'POST',
                            contentType: 'application/json',
                            headers: {
                                'CJ-Access-Token': "<?=CJ_ACCESS_TOKEN?>"
                            },
                            data: JSON.stringify(requestData),
                            success: function(response) {
                                if(response.result){
                                    item = response.data[0];

                                    $shipping_method = item.logisticName;
                                    $shipping_price = item.logisticPrice;
                                    $shipping_duration = item.logisticAging;
                                    $("#shipping_cost").val($shipping_price);
                                    $(".shipping_method_name").text($shipping_method);
                                    $(".shipping_duration").text($shipping_duration+" days");
                                    $(".shipping_charges").text("$"+$shipping_price);
                                    $(".shipping-info-box").show();
                                }
                            }
                            });
                    }
                });

        }

        $(document).ready(function(){
            
            $( ".shipping_country" ).on( "change", function() {
                $shipping_country_start = "CN";
                $shipping_country_end = $(this).val();
                shipping_data = "";
                console.log($shipping_country_end);
                if($shipping_country_end == ""){
                    return;
                }
                $selected_variant_id = $('button.variant_color[data-selected="true"]').attr('data-variant-id');
                
                // Getting CJ Variant ID
                $.ajax({
                    url: "<?php echo base_url(); ?>/home/getCjVariantId/"+$selected_variant_id,
                    type: "GET",
                    success: function(response){
                        cj_variant_id = response;
                        variant_qty = $(".qty").val();
                        console.log(variant_qty);
                        const requestData = {
                            startCountryCode: $shipping_country_start,
                            endCountryCode: $shipping_country_end,
                            products: [
                                {
                                    quantity: `${variant_qty}`,
                                    vid: `${cj_variant_id}`
                                }
                            ]
                        };
                    // Api Data Ajax
                        $.ajax({
                        url: 'https://developers.cjdropshipping.com/api2.0/v1/logistic/freightCalculate',
                        type: 'POST',
                        contentType: 'application/json',
                        headers: {
                            'CJ-Access-Token': "<?=CJ_ACCESS_TOKEN?>"
                        },
                        data: JSON.stringify(requestData),
                        success: function(response) {
                            if(response.result){
                                response.data.forEach((item , index) => {
                                    console.log(item);
                                    shipping_data += `
                                    <tr>
                                        <td class="text-center"><input type="radio" name="ship_method" ship_name="${item.logisticName}" ship_price="$${item.logisticPrice}" ship_duration="${item.logisticAging} days"></td>
                                        <td class='text-center'>${item.logisticName}</td>
                                        <td class='text-center'>$${item.logisticPrice}</td>
                                        <td class='text-center'>${item.logisticAging} days</td>
                                    </tr>`;
                                })
                                $('.shipping_table_data').html(shipping_data);
                            }else{
                                $('.modal-body-shipping-data').html("Shipping Not Available for this product");
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error:', error);
                        }
                    });

                    }
                });
              

                
                
                
                    $("#select_shipping_method").modal("show");
                    $(".modal-backdrop").addClass("d-none");
            } );
            $('.shipping-select').click(function(){
                $selected = $('input[name="ship_method"]:checked');
                $shipping_method = $('input[name="ship_method"]:checked').attr('ship_name');
                $shipping_price = $('input[name="ship_method"]:checked').attr('ship_price');
                $shipping_duration = $('input[name="ship_method"]:checked').attr('ship_duration');
                $(".shipping_method_name").text($shipping_method);
                $(".shipping_duration").text($shipping_duration);
                $(".shipping_charges").text($shipping_price);
                $("#shipping_cost").val(Number($shipping_price.substring(1)));
                $(".shipping_charges").text($shipping_price);
                $(".shipping-info-box").show();
                $("#select_shipping_method").modal("hide");
            })
            
            var left_padding = $(".main_product_variant_show ").position();
            $(".row_prod_view_bc .col-md-11").css({"padding-left" : left_padding.left+"px"});
            $(".row_prod_view_bc .col-md-1").css({"padding-right" : left_padding.left+40+"px"});

            var variant_id = $(".variant_color").eq(0).attr("data-variant-id");
            var variant_color = $(".variant_color").eq(0).attr("data-variant-color");
            $("#single_color").val(variant_color);

             var  id_wise_variants = '<?php echo json_encode($id_wise_variants); ?>';
            //console.log(id_wise_variants);  
            id_wise_variants = JSON.parse(id_wise_variants);
            //console.log(id_wise_variants);
            var sizes_without_quotes  = '<?php echo json_encode($sizes_without_quotes); ?>';
            sizes_without_quotes  = JSON.parse(sizes_without_quotes);
            //console.log(sizes_without_quotes);

       
            $(".cart").attr("onclick","to_cart("+variant_id+",event)");
            $(".btn_compare").attr("onclick","do_compare("+variant_id+",event)");
            $(".btn_wish").attr("onclick","to_wishlist("+variant_id+",event)"); 
           
            $(".btn_variant_size").eq(0).addClass("selected");
            $(".btn_variant_size").eq(0).attr("data-selected","true");

            $(".variant_color").eq(0).addClass("selected");
            $(".variant_color").eq(0).attr("data-selected","true");
            
            if($(".col_features .features").text().trim()!=""){
                $(".col_features").show();
            }
             if($(".col_description .description").text().trim()!=""){
                $(".col_description").show();
            }
            
            $(".main_product_variant_show").addClass("animated zoomIn");
            $("#single_product_add_to_cart").submit(function(e){
                e.preventDefault();
            }); 

            $('#share').share({
                networks: ['facebook','googleplus','twitter','linkedin'],
                theme: 'square'
            });
            if ($(window).width() < 900) {    
                $(".owl_slider_related_product").owlCarousel({
                    items: 2,
                    loop: true,
                    margin: 10,
                    autoplay: true,
                    slideTransition: 'linear',
                    autoplayTimeout: 100,
                    autoplaySpeed: 3000,
                    autoplayHoverPause: true           
                });
            }else{
                $(".owl_slider_related_product").owlCarousel({
                    items: 4,
                    loop: true,
                    margin: 10,
                    autoplay: true,
                    slideTransition: 'linear',
                    autoplayTimeout: 100,
                    autoplaySpeed: 3000,
                    autoplayHoverPause: true           
                });
            }
            
          

           $(document).on("click",".variant_color",function(){
                $(".variant_color").attr("data-selected","false");
                $(".variant_color").removeClass("selected");
                $(this).attr("data-selected","true");
                $(this).addClass("selected");
                var variant_id  = $(this).attr("data-variant-id");
                var variant_color = $(this).attr("data-variant-color");
                $("#single_color").val(variant_color);
                var single_variant = id_wise_variants[variant_id];
                $(".cart").attr("onclick","to_cart("+single_variant.product_variants_id+",event)");
                $(".btn_compare").attr("onclick","do_compare("+single_variant.product_variants_id+",event)");
                $(".btn_wish").attr("onclick","to_wishlist("+single_variant.product_variants_id+",event)");
                setup_product_details(single_variant);
            });

            $(".btn_variant_size").click(function(){
                $(".btn_variant_size").removeClass("selected");
                $(".btn_variant_size").attr("data-selected","false");
                $(this).addClass("selected");
                $(this).attr("data-selected","true");
                var product_id = $(this).attr("data-product-id");
                var variant_size = $(this).attr("data-variant-size");
                color_by_size = sizes_without_quotes[product_id+"@@"+variant_size];
                var colors = color_by_size;
                var get_color = "";
                $.each(colors,function(ind , val){
                    var color_id = val.split('@@');
                    get_color += '<button class="custom_btn btn btn-sm btn-default variant_color" data-selected="false" data-variant-id="'+color_id[1]+'" data-variant-color="'+color_id[0]+'" data-selected="false">';
                        get_color += color_id[0];
                    get_color += "</button>";
                });
                $(".product_variant_colors").html(get_color);
                $(".variant_color").eq(0).addClass("selected");
                $(".variant_color").eq(0).attr("data-selected","true");
                var variant_id = $(".variant_color").eq(0).attr("data-variant-id");
                var variant_color = $(".variant_color").eq(0).attr("data-variant-color");
                $("#single_color").val(variant_color);
                $(".cart").attr("onclick","to_cart("+variant_id+",event)");
                $(".btn_compare").attr("onclick","do_compare("+variant_id+",event)");
                 $(".btn_wish").attr("onclick","to_wishlist("+variant_id+",event)");
                var single_variant = id_wise_variants[variant_id];
                //console.log(id_wise_variants)
                setup_product_details(single_variant);
            });
            
            $(".caption-title").tooltip();
            var width = $("#set_image").outerWidth();
            $(".imagezoom-view").css({"left" : width+"px"});

            $(document).on("click",".img",function(){
                var src = $(this).data('src');
                $("#set_image").attr("src", src);
                $(".related-product").removeClass("selected");
                $(this).closest(".related-product").addClass("selected");
            });

            $("#main1").addClass("selected");
            var src=$("#main1").find(".img").data('src');
            $("#set_image").attr("src", src);
        
            var meta_title = $(".product_variant_title").text().trim();
            var meta_image = $("#set_image").attr("src");
            var  meta_url = '<?php echo base_url($this->uri->uri_string()); ?>';

            $(".rateit").click(function(){
                var n = ($(document).height()/2);
                $('html, body').animate({ scrollTop: n-300 }, 1500);
            });


            /* horizontal slider js */
            $(".right_arrow").click(function(){
               if(total_no_of_img>2){
                    $(".left_arrow").removeClass("sld_lft_arr_bg");
                    if(no_of_scroll_to_right!=no_of_img){
                        $(this).removeClass("sld_lft_arr_bg");
                        no_of_scroll_to_right++;
                        scroll_from_left = scroll_from_left + slider_img_cal_width;
                        console.log(scroll_from_left)
                        $(".variant_other_img_holder").animate({
                            scrollLeft : scroll_from_left
                        },200);
                    }else{
                        $(this).addClass("sld_lft_arr_bg");
                    }
                }
            });
            $(".left_arrow").click(function(){
                    $(".right_arrow").removeClass("sld_lft_arr_bg");
                    if(scroll_from_left!=0){
                        $(this).removeClass("sld_lft_arr_bg");
                        scroll_from_left = scroll_from_left - slider_img_cal_width;
                    }
                    if(scroll_from_left == 0){
                        $(this).addClass("sld_lft_arr_bg");
                        scroll_from_left = 0;
                        no_of_scroll_to_right = 0;
                    }
                    console.log(scroll_from_left)
                    $(".variant_other_img_holder").animate({
                        scrollLeft : scroll_from_left
                    },200);
            });
            $(document).on("click",".variant_other_img_holder .related-product",function(e){
                img_src = $("img",this).attr("src");
                $(".set_img img").attr("src",img_src);
                    var img_position = $(this).position();
                    console.log(img_position)
                    if(img_position.left>=160){
                        $(".left_arrow").removeClass("sld_lft_arr_bg");
                        if(no_of_scroll_to_right!=no_of_img){
                            no_of_scroll_to_right++;
                            scroll_from_left = scroll_from_left + slider_img_cal_width;
                            console.log(scroll_from_left)
                            $(".variant_other_img_holder").animate({
                                scrollLeft : scroll_from_left
                            },200);
                        }else{
                            $(".right_arrow").addClass("sld_lft_arr_bg");
                        }
                    }
                    if(img_position.left<=30){
                        $(".right_arrow , .left_arrow").removeClass("sld_lft_arr_bg");
                        if(scroll_from_left!=0){
                            scroll_from_left = scroll_from_left - slider_img_cal_width;
                        }else{
                            $(".left_arrow").addClass("sld_lft_arr_bg");
                            scroll_from_left = 0;
                            no_of_scroll_to_right = 0;
                        }
                        console.log(scroll_from_left)
                        $(".variant_other_img_holder").animate({
                            scrollLeft : scroll_from_left
                        },200)
                    }
            });
            $('body').on('click', '.rev_show', function(){
                $('.ratings_show , .rateit').hide();
                $('.inp_rev').show();
            });

    selectDefaultShipping();
    }); /* end of jquery */
    
    function setup_product_details(data)
    {
        console.log(data);
        var title = "Not Available";
        if(data.title!=null && data.title!=""){
            title = data.title;
        }
        $(".product_variant_title").text(title);
        $(".seller_sku").html(data.seller_sku);
        if(data.save_off>0){
            $(".single_product_label_save_of  span:nth-child(2)").text(data.save_off+"%");
            $(".single_product_label_save_of").show();
        }else{
            $(".single_product_label_save_of").hide();
        }
        
        if(data.stock_status > 0){
            $(".stock_status_div span:nth-child(2)").text(data.stock_status+' <?php echo translate("available"); ?>');
            $(".quantity-field").attr("max",data.stock_status);
            $(".quantity-field").val(1);
             $(".quantity-field , .btn_add_to_cart_quick_view , span[name='add'] , span[name='subtract']").removeAttr("disabled","disabled");
            $(".btn_add_to_cart_quick_view , span[name='add'] , span[name='subtract']").css({
                "pointer-events" : "auto",
                "cursor" : "pointer",
            });
            $(".btn_add_to_cart_quick_view").html("<i></i>&nbsp;ADD TO CART");
        }else{
            $(".stock_status_div span:nth-child(2)").text('<?php echo translate("out_of_stock"); ?>');
            $(".quantity-field , .btn_add_to_cart_quick_view , span[name='add'] , span[name='subtract']").attr("disabled","disabled");
            $(".btn_add_to_cart_quick_view , span[name='add'] , span[name='subtract']").css({
                "pointer-events" : "none",
                "cursor" : "no-drop",
            });
            $(".btn_add_to_cart_quick_view").text("OUT OF STOCK");
        }
        if(data.description!="" && data.description!=null){
            $(".description").html(atob(data.description));
            $(".col_description").show();
        }else{
             $(".col_description").hide();
        }
        var features = "";
        if(data.features!="" && data.features!=null){
            features_arr = data.features.split("@@@");
            for(var i=0; i<features_arr.length; i++){
                features += "<p>"+features_arr[i]+"</p>";
            }
            $(".col_features").show();
        }else{
             $(".col_features").hide();
        }
        $(".features").html(features);
        $(".weight td").text(data.weight+" unit");
        $(".shape  td").text(data.shape);
        $(".material td").text(data.material);
        $(".stock_status").text(data.stock_status);
        $(".cart_quantity").attr("max",data.stock_status);
        $(".stock").text(data.stock_status+" "+'<?php echo translate('available');?>');
        $(".collection td").text(data.collection);
        $(".style td").text(data.style);
        $(".primary_style td").text(data.primary_style);
        $(".construct_by td").text(data.contruction);
        $(".use td").text(data.use);
        $(".origin td").text(data.origin);

        var actual_price = "";
        var saving_label ="";
        if(data.discount>0){
            actual_price += '<span class="price" style="font-size:15px;">';
                actual_price+= '<?php echo translate('discounted_price:');?> ';
            actual_price += '</span>';
             actual_price += '<span class="discount_price">';
                actual_price += data.selling_price;
            actual_price += '</span>';
                 actual_price += '<br />';
             actual_price += '<span class="price" style="font-size:15px;">';
                actual_price+= '<?php echo translate('price:');?> ';
            actual_price += '</span>';
           actual_price +='<del class="without_discount_price">';
                actual_price +=  data.without_discounted;
            actual_price +='</del>';
        }else{
            actual_price += '<span class="price" style="font-size:15px;">';
                actual_price += '<?php echo translate('price:');?>&nbsp;';
            actual_price += '</span>';
            actual_price += '<span class="discount_price">';
                actual_price += data.selling_price;
            actual_price += '</span>';
        }
        $(".product_variant_price").html(actual_price);
        
        other_images = "";

        variant_img =  data.images ;
        var count = 1;
        var variant_selected = "";
        var variant_first_img  = "";
        if(variant_img.length>0){
            $.each(variant_img, function(index, value){
                if(count==1){
                    variant_first_img = value;
                    variant_selected = " selected";
                }else{
                    variant_selected = "";   
                }
                base_url = "<?php echo base_url('uploads/product_variants_image'); ?>";
                other_images +=" <div class='related-product"+variant_selected+"' id='main"+count+"'>";
                    other_images += "<img class='img-responsive img' data-src='"+base_url+"/"+value+"' src='"+base_url+"/"+value+"'>";
                other_images += "</div>";
                count++;
            });
            $("#set_image").attr("src", base_url+"/"+variant_first_img);
        }
        else{
            variant_first_img = "<?php echo $this->crud_model->get_image('product_variants', 'default.jpg'); ?>";
            $("#set_image").attr("src", variant_first_img);
        }
        $(".variant_other_img_holder").html(other_images);
        no_of_img = $(".variant_other_img_holder .related-product").length-3;
        total_no_of_img = $(".variant_other_img_holder .related-product").length;
        scroll_from_left = 0;
        no_of_scroll_to_right = 0;
        $(".variant_other_img_holder").scrollLeft(0);

        show_hide_pro_spec();
    }
    show_hide_pro_spec();
</script>
<script type="text/javascript" src="<?php echo base_url()?>template/front/js/owl-carousel.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>template/front/plugins/Image_zoom/Zoom.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>template/front/js/image_zoom.js"></script>