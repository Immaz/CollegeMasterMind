<?php
    $discus_id = $this->db->get_where('general_settings',array('type'=>'discus_id'))->row()->value;
    $fb_id = $this->db->get_where('general_settings',array('type'=>'fb_comment_api'))->row()->value;
    $comment_type = $this->db->get_where('general_settings',array('type'=>'comment_type'))->row()->value;
?>
<style>
    .review-comment{
        margin: 1em;
        padding: 1em;
    }
    .table_product_info th ,  .table_product_info td{ 
        padding:10px !important;
    }
    .table_product_info th{
        color:#6e6e6e;
        width: 20%;
        font-size: 12px;
    }
    .table_product_info td{
        color:   #6e6e6e;
        font-size: 13px;
    }
    .description{
        color:#6e6e6e;
    }
</style>
<!-- PAGE -->
        <div class="tabs-wrapper content-tabs">
            <ul class="nav nav-tabs">
                <li  class="active"  ><a href="#tab1" data-toggle="tab"><?php echo translate('Product Info'); ?></a></li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane fade in active" id="tab1">
                    <table class="table table-striped table-hovered table_product_info">
                            <tr class="weight">
                                <th><?php echo translate('Weight'); ?></th>
                                <td>
                                    <?php 
                                        echo $single_variant['weight']." lbs";
                                    ?>
                                </td>
                            </tr>
                            <tr class="shape">
                                <th><?php echo translate('Shape'); ?></th>
                                <td>
                                    <?php 
                                        echo $single_variant['shape'];
                                    ?>
                                </td>
                            </tr>
                            <tr class="material">
                                <th><?php echo translate('Material'); ?></th>
                                <td >
                                    <?php 
                                         echo $single_variant['material'];
                                    ?>
                                </td>
                            </tr>
                            <tr class="collection">
                                <th><?php echo translate('Collection'); ?></th>
                                 <td >
                                    <?php 
                                        echo $single_variant['collection'];
                                    ?>
                                </td>
                            </tr>
                            <tr class="style">
                                <th><?php echo translate('Style'); ?></th>
                                <td>
                                    <?php 
                                        echo $single_variant['style'];
                                    ?>
                                </td>
                            </tr>
                            <tr class="primary_style">
                                <th><?php echo translate('Primary Style'); ?></th>
                                 <td>
                                    <?php 
                                        echo $single_variant['primary_style'];
                                    ?>
                                </td>
                            </tr>
                            <tr class="construct_by">
                                <th><?php echo translate('Construct By'); ?></th>
                                 <td>
                                    <?php 
                                        echo $single_variant['construction'];
                                    ?>
                                </td>
                            </tr>
                            <tr class="use">
                                <th><?php echo translate('Use'); ?></th>
                                <td>
                                    <?php 
                                        echo $single_variant['use'];
                                    ?>
                                </td>
                            </tr>
                            <tr class="origin">
                                <th><?php echo translate('Origin'); ?></th>
                                 <td>
                                    <?php 
                                        echo $single_variant['origin'];
                                    ?>
                                </td>
                            </tr>
                    </table>
                </div>
            </div>
        </div>
<!-- /PAGE -->
<style>
@media(max-width: 768px) {
	.specification .nav-tabs>li{
		float: none;
		display: block;
		text-align: center;
	}
}
</style>


<script type="text/javascript">
    $(document).ready(function(){
    });
    /*
    $(function () {
        var rateit_product_by_user =  $("#rateit_product_by_user");
        var edit_my_rating =  $("#edit_my_rating");
        var submit_my_rating =  $("#submit_my_rating");
        var my_rating_span =  $("#my_rating_span");
        var my_rating_edit_span =  $("#my_rating_edit_span");

        var set_product_rating =  $("#set_product_rating");
        var set_product_rating_comment =  $("#set_product_rating_comment");
        var set_product_id =  $("#set_product_id");
        var set_product_type =  $("#set_product_type");

        var given_rating_star =  $("#given_rating_star");
        var given_rating_comment =  $("#given_rating_comment");

        rateit_product_by_user.rateit(
            { max: 5, min:0, step: 0.5, backingfld: '#backing_rateit_product_by_user' }
        );
        rateit_product_by_user.bind('rated', function (event, value) {
            set_product_rating.val(value);
        });
        rateit_product_by_user.bind('reset', function () {
            set_product_rating.val(1);
        });
        rateit_product_by_user.bind('over', function (event, value) {
        });

        edit_my_rating.on('click',function (e) {
            my_rating_span.hide();
            my_rating_edit_span.show();
        });

        submit_my_rating.on('click',function (e) {
            var rating = set_product_rating.val();
            var comment = set_product_rating_comment.val();
            var product_id = set_product_id.val();
            var product_type = set_product_type.val();

            ajaxRequest = $.ajax({
                url: "<?= base_url()?>home/ajax_post_user_rating",
                type: "post",
                data:
                    {
                        "rating":rating,
                        "comment":comment,
                        "product_id":product_id,
                        "product_type":product_type,
                    }
            });

           //  request cab be abort by ajaxRequest.abort()

            ajaxRequest.done(function (response, textStatus, jqXHR){
                // show successfully for submit message

                given_rating_star.rateit('value', rating);

                given_rating_comment.html(comment);
                if(comment != "" && comment != null){
                    given_rating_comment.show();
                }else{
                    given_rating_comment.hide();
                }

                my_rating_span.show();
                my_rating_edit_span.hide();
            });

             //On failure of request this function will be called 
            ajaxRequest.fail(function (){
                alert("error");
                my_rating_span.show();
                my_rating_edit_span.hide();
            });
        });
    })*/
</script>