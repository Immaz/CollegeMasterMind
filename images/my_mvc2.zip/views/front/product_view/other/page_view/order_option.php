    <div class="order">	
   <div class="buttons">
             <div class="item_count">
                <?php 
                    $style = "";
                    $disabled = "";
                    if($single_variant['stock_status']>0){
                        $style = "style='display : block; height: 37px;!important'";
                    }else{
                        $disabled = "disabled='disabled' ";
                        $style = "style='pointer-events : none; cursor : no-drop; height: 37px;!important' ";
                    }
                ?>
                <div style="height: 33px;" class="quantity product-quantity">
                    <span style="height: 33px;" class="btn" name='subtract' onclick='decrease_val();' <?php echo $disabled; ?> <?php echo $style; ?>>
                        <i class="fa fa-minus"></i>
                    </span>
                    <input <?php echo $disabled; ?> style="height: 33px;" type="number" class="form-control qty quantity-field cart_quantity"  min="1" max="<?php echo $single_variant['stock_status']; ?>" name='qty' value="<?php if($a = $this->crud_model->is_added_to_cart($single_variant['stock_status'],'qty')){echo $a;} else {echo '1';} ?>" id='qty'/>
                    <span style="height: 33px;" class="btn" name='add' onclick='increase_val();' <?php echo $style; ?> <?php echo $disabled; ?>>
                        <i class="fa fa-plus">
                    </i></span>
                </div>
             </div>
        </div>
        <!-- <input type="hidden" name='qty' value="1" /> -->
        <div class="buttons">
             <?php 
                    $style = "";
                    $disabled = "";
                    if($single_variant['stock_status']>0){
                        $style = "style='display: block; margin: -10px 0 9px 4px; width: 50%; font-size:16px;text-transform: uppercase; margin: -10px 0 9px 4px;'";
                    }else{
                        $disabled = "disabled='disabled' ";
                        $style = "style='pointer-events: none; cursor : no-drop;  margin: -10px 0 9px 4px; width: 50%; font-size:16px; margin: -10px 0 9px 4px;'";
                    }
                ?>
            <span data-is-quick-view="true" class="col-md-6 btn btn-add-to cart btn_add_to_cart_quick_view" onclick="to_cart(<?php echo $single_variant['product_variants_id']; ?>,event)" <?php echo $style; ?> <?php echo $disabled; ?> data-show-cart-popup="true">
                <i></i>&nbsp;
                <?php if($this->crud_model->is_added_to_cart($single_variant['product_id'])=="yes"){ 
                    echo translate('added_to_cart');  
                    } else { 
                        if($single_variant['stock_status']>0){
                            echo translate('add_to_cart');  
                        }else{
                            echo translate('OUT OF STOCK');  
                        }
                    } 
                ?>
            </span>
        </div>
        <!-- <img src="<?php echo base_url('uploads/others/icon-cc(1).png') ?>" style="max-width: 47%; margin-left: 4px; margin-top: -2%;"> -->
    </div>

</form>
<div id="pnopoi"></div>
<script>
	$(document).ready(function() {
        $(document).on("keyup",".cart_quantity" , function(){
            user_qty = $(this).val();
            max = $(this).attr("max");
            min = 1;
            if(isNaN(user_qty)){
                $(".cart_quantity").val(1)
            }else if(user_qty>max){
                $(".cart_quantity").val(1);
            }
        });

        $(".cart_quantity").focusout(function(){
            user_qty = $(this).val();
            if(user_qty==""){
                $(".cart_quantity").val(1);
            }
        });
	});
</script>
<script>
$(document).ready(function() {
	check_checkbox();
});
function check_checkbox(){
	$('.checkbox input[type="checkbox"]').each(function(){
        if($(this).prop('checked') == true){
			$(this).closest('label').find('.cr-icon').addClass('add');
		}else{
			$(this).closest('label').find('.cr-icon').addClass('remove');
		}
    });
}
function check(now){
	if($(now).find('input[type="checkbox"]').prop('checked') == true){
		$(now).find('.cr-icon').removeClass('remove');
		$(now).find('.cr-icon').addClass('add');
	}else{
		$(now).find('.cr-icon').removeClass('add');
		$(now).find('.cr-icon').addClass('remove');
	}
}
function decrease_val(){
	var value=$('.quantity-field').val();
	if(value > 1){
		var value=--value;
	}
	$('.quantity-field').val(value);
}
function increase_val(){
	var value=$('.quantity-field').val();
	var max_val =parseInt($('.quantity-field').attr('max'));
	if(value < max_val){
		var value=++value;
	}
	$('.quantity-field').val(value);
}
</script>