<style type="text/css">
    .block-ellipsis {
        display: block;
        display: -webkit-box;
        max-width: 100%;
        margin: 0 auto;
        font-size: 14px;
        line-height: 1.5;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis;
    }
</style>
<section class="page-section">
    <div class="container">
        <div class="row">
        	<div class="recommendation col-md-12">
            	<div class="row">
                    <h3 class="title">
                        <?php echo translate('related_products');?>
                    </h3>
                	<?php
                        $title =  $single_variant['title'];
						$recommends = $this->crud_model->getRelatedProduct($title);
                        foreach($recommends as $rec){
                        $product_variants_img = json_decode($rec['images'] , true);
                    ?>
                	<div class="col-md-3 col-sm-3 col-xs-3" data-aos="flip-left" data-aos-duration="1500">
                        <div class="recommend_box_1">
                        	<a class="link" href="<?php echo $this->crud_model->product_link($rec['product_id']); ?>">
                                <div class="image-box" style="background-image:url('<?php echo $this->crud_model->get_image("product_variants" , $product_variants_img[0]); ?>');background-size:cover; background-position:center;">
                                </div>
                                <h4 class="block-ellipsis caption-title " style="height: 55px;">
                                    <b><?=$rec['title']?></b>
                                </h4>
                                <?php $rating = $this->crud_model->rating($rec['product_id']); ?>
                                <div  class="rateit" data-rateit-value="<?= $rating ?>" data-rateit-ispreset="true" data-rateit-readonly="true"></div>
                                <div class="price clearfix">
                                    <?php if($rec['discount'] > 0){ ?> 
                                        <ins>
                                            <?php echo currency($this->crud_model->get_product_price($rec['product_variants_id'])); ?>
                                        </ins>
                                        <del><?php echo currency($rec['selling_price']); ?></del>
                                    <?php 
                                    }
                                    else{
                                    ?>
                                    <ins>
                                        <?php echo currency($rec['selling_price']); ?>
                                    </ins>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php
						}
					?>
                </div>
            </div>
        </div>
    </div>
</section>