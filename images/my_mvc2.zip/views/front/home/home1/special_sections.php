<?php
$special_sections = 3;
$special_section_active = 1;
$special_sections_data = $this->crud_model->getSpecialSections($special_sections, $special_section_active);
?>
<?php if ($special_sections_data) {
  $dataLen = count($special_sections_data) ?>
<style type="text/css">
.special-sections .img-preview {
  border: none;
  padding: 0px;
  border-radius: 0px;
  max-height: 500px;
  transition: transform 0.5s ease-in-out;
}

.special-sections .row>div:hover .img-preview {
  transform: scale(1.02);
}
</style>

<section class="page-section special-sections" style="padding-top: 0px;">
  <div class="container">
    <div class="row" style="padding-bottom: 25px; padding-left: 0px; padding-right: 0px;">
      <?php if ($dataLen == 1) {
          $col = 12;
        } else if ($dataLen == 2) {
          $col = 6;
        } else {
          $col = 4;
        }
        foreach ($special_sections_data as $key => $value) {
          ?>
      <div class="text-center col-sm-<?php echo $col; ?>" id="section_<?php echo $key; ?>">
        <a href="<?php echo base_url('home/special_section/' . $value->uniq_id) ?>"><img
            class="img-thumbnail img-preview"
            src=<?php echo base_url(($dataLen == 1) ? 'uploads/special_sections/top_banner/' . $value->top_banner : 'uploads/special_sections/featured_banner/' . $value->featured_banner) ?>></a>
      </div>
      <?php } ?>
    </div>
  </div>
</section>

<!-- /PAGE -->
<?php } ?>