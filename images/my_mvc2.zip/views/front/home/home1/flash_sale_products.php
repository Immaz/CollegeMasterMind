<!-- timer banner -->
    <!-- <div class="banner container" style="background-image: url('https://aimg.kwcdn.com/material-put/1e65f7051c/6c12510d-e3d3-40a5-95d2-c144d4cd3fed.png?imageView2/2/w/2000/q/80/format/webp');">
        <div class="content">
            <div class="deal-info">
                <div class="deal-title">
                  <h2><i class="fa fa-bolt" aria-hidden="true" style="color: white;"></i> Flash Sale <span id="countdown"></span></h2>
                </div>
                
            </div>
        </div>
    </div> -->
    <div class="flash_deal_bg">
        <div class="container">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div><img src="./uploads/flash_deal_image/1st.png" alt="" class="flash_sale"></div>
            <div>
                <span id="countdown" class="_countdown"></span> <br>
                <span class="dhms">DAYS  <span style="margin-left: 9px;">HRS</span> &nbsp; <span style="margin-left: 8px;">MIN</span> &nbsp; <span style="margin-left: 10px;">SEC</span></span>
            </div>
                <div><img src="./uploads/flash_deal_image/3rd.png" alt="" class="spark"></div>
            </div>
            
        </div>
</div>

    <script>
        function pad(num, size) {
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
}
        <?php $time = $this->crud_model->get_type_name_by_id('general_settings','86','value'); ?>
        
      function updateTimer() {
    const dealEndDate = new Date("<?php echo $time; ?>"); // Set the end date and time of the deal
    const now = new Date();
    const timeLeft = dealEndDate - now;

    if (timeLeft <= 0) {
        // document.getElementById("countdown").innerHTML = "Deal Expired";
        $('.flash_deal_bg').hide();
    } else {
        const days = pad(Math.floor(timeLeft / (1000 * 60 * 60 * 24)),2);
        const hours = pad(Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),2);
        const minutes = pad(Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60)),2);
        const seconds = pad(Math.floor((timeLeft % (1000 * 60)) / 1000),2);
        

        const countdownText = `<span class="bg-black">${days}</span> : <span class="bg-black">${hours}</span> : <span class="bg-black">${minutes}</span> : <span class="bg-black">${seconds}</span>`;
        document.getElementById("countdown").innerHTML = countdownText;
    }
}

setInterval(updateTimer, 1000);
updateTimer();

    </script>

<style>
    ._countdown{
        color: white; 
        font-size: xx-large; 
        width: 33.33%;
    }
     .flash_deal_bg{
        width: 100%;
        background: url("<?php echo base_url(); ?>uploads/flash_deal_image/bg.jpg");
        padding-top: 10px;
        padding-top: 15px;
        margin-top: 40px;
    }
    .dhms{
        position: relative;
        color: white; 
        font-size: 18px; 
        font-weight: bold;
    }
    .bg-black {
        background-color: #232323;
        padding: 5px;
        border-radius: 8px;
    }
  .banner {
    background-color: #ff9900;
    color: #fff;
    padding: 20px;
    display: flex;
    justify-content: center;
}

.deal-title h2{
  position: relative;
    margin-left: 12px;
    font-size: 24px;
    color: #fff;
    font-weight: 800 !important;
    font-style: italic;
    font-family: 'roboto';
}

.deal-info {
    text-align: left;
}

.deal-timer {
    text-align: right;
}

._countdown {
    font-size: 24px;
    font-family: 'roboto';
    font-weight: 600;
}


@media only screen and (max-width: 768px) {
    ._countdown{
        font-size: medium;

    }
    .spark{
        height: 60px;
        width: 80px;
    }
    .flash_sale{
        height: 60px;
        width: 120px;
    }   
    .dhms{
        font-size: 12px;
    }
}
</style>

<!-- END -->
<?php
    $box_style =  $this->db->get_where('ui_settings',array('ui_settings_id' => 42))->row()->value;
    $limit =  $this->db->get_where('ui_settings',array('ui_settings_id' => 20))->row()->value;
    $featured_products = $this->crud_model->getSaleProducts();
?>
<?php if($featured_products){?>
<style type="text/css">
    .section-title{
        margin-bottom: 0px;
    }
    .owl-prev i,
    .owl-next i
    {
        display:block !important;
    }
    .featured-products .owl-prev{
        left: -0.1% !important;
    }
    .featured-products .owl-next{
        right: -0.1% !important;
    }
    .featured_product_top_slider .box-style-2 .btn_add_to_cart{
        font-size: 11px !important;
    }
    .featured_product_top_slider .box-style-2 .caption-title a{
        font-size: 12px;
    }
    .featured_product_top_slider .box-style-2 .btn_add_to_cart{
        height: 38px;
        margin: 0px -8px;
        padding: 10px 0px !important;
    }
    .thumbnail.box-style-2 .media-link{
        padding: 0px;
        display: flex; 
        align-items: center;
    }
    .featured_product_top_slider .featured-products-carousel .thumbnail.box-style-2 .media-link img{
        height: 100%;
    }
    .featured_product_top_slider .featured-products-carousel .thumbnail.box-style-2 .btn_add_to_cart{
        background-color: #727c84;
        border: 1px solid #727c84;
    }
    .featured_product_top_slider .featured-products-carousel .thumbnail.box-style-2 .btn_add_to_cart:hover
    {
        color: white !important;
        background-color: #25d3c9;
        border: 1px solid #25d3c9;
    }
</style>
<!-- PAGE -->
<!-- <section class="page-section featured-products sl-bundled featured_product_top_slider" style="padding-bottom: 0px; padding-top: 0px!important;">
    <div class="container">
        <div class="row">
            <div class="col-sm-12" style="margin-top: 0px; padding: 0px;">
                <div class="featured-products-carousel">
                    <div class="owl-carousel-2" id="most-viewed-carousel">
                        <?php
                           // $count = 2;
                            //foreach($featured_products as $row){
                        ?>
                        <div class="col-md-12" style="margin-top:10px; padding: 0px;  border: 0px solid #3C3B6E;">
                            <?php 
                                //echo $this->html_model->product_box($row, 'grid', $box_style);
                            ?>
                         </div>
                        <?php // $count++;  }?>
                    </div>
                </div>
            </div>
        </div>        
    </div>
</section> -->

<!-- /PAGE -->
<script>
$(document).ready(function(){
    if ($(window).width() < 900) {
           $(".owl-carousel-2").owlCarousel({
            items: 2,
            loop: true,
            margin: 3,
            autoplay: true,
            slideTransition: 'linear',
            autoplayTimeout: 100,
            autoplaySpeed: 4000,
            dots: false,
            nav: true,
            autoplayHoverPause:true,
            navText: [
                "<i class='fa fa-chevron-left'></i>",
                "<i class='fa fa-chevron-right' ></i>"
            ]
        });
    // console.log("Less than true");       
    }
    else {
        $(".owl-carousel-2").owlCarousel({
            items: 4,
            loop: true,
            margin: 3,
            autoplay: true,
            slideTransition: 'linear',
            autoplayTimeout: 100,
            autoplaySpeed: 4000,
            dots: false,
            nav: true,
            autoplayHoverPause:true,
            navText: [
                "<i class='fa fa-chevron-left'></i>",
                "<i class='fa fa-chevron-right' ></i>"
            ]
        });
     // console.log("Less than false");
    }

  //  set_bundled_product_box_height();
});

function set_bundled_product_box_height(){
    var max_title = 0;
    $('.sl-bundled .caption-title').each(function(){
        var current_height= parseInt($(this).css('height'));
        if(current_height >= max_title){
            max_title = current_height;
        }
    });
    if (max_title > 0) {
        $('.sl-bundled .caption-title').css('height',max_title);
    }
}
</script>
<?php } ?>

