<!-- PAGE -->
<style type="text/css">
:root {
  --main-color: #f3402d;
}

.no_data_available {
  display: none;
  font-size: 16px;
}

.row-m15 {
  margin-top: 15px !important;
}

.row-m15 div[class*="col-"] {
  margin-top: 15px !important;
}

#newsletter_subscription_modal .modal-dialog {
  top: 30%;
}

#newsletter_subscription_modal .modal-footer .row .col-md-9 {
  padding-right: 0px;
}

#newsletter_subscription_modal .modal-footer .row .col-md-3 {
  padding-left: 0px;
}

#newsletter_subscription_modal .media {
  display: flex;
  align-items: flex-end;
}

#newsletter_subscription_modal .modal-footer {}

.btn-subscription {
  padding: 9px 20px;
  background: #25d3c9;
  color: white;
}

.btn-subscription:hover {
  background: #B22234;
  color: white;
}

.btn-subscription:focus {
  background: #B22234 !important;
  color: white;
}

#subscription_msg {
  display: none;
}

.pd {
  padding: 0px 8px 0 0px !important;
}

.row_product_list .col-md-3:nth-child(4n+0) {
  padding-right: 1px !important;
}
</style>

<section class="featured-products sl-featured" style="padding: 20px;">

  <div class="container" style="padding: 20px; background-color: white; margin-top: 10px; border-radius: 8px; box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;">
    <p style="font-weight: 800; font-size: 18px; ">Products</p>
    <div class="row_product_list">
      <?php
            $box_style = $this->db->get_where('ui_settings', array('ui_settings_id' => 29))->row()->value;
            $see_first_products = $this->crud_model->getSeeFirstProducts();
            if ($see_first_products && count($see_first_products) > 0) {
                foreach ($see_first_products as $see_first_product) { ?>
      <div class="col-md-3 col-sm-6 col-xs-6 pd" data-aos="flip-left" data-aos-mirror="true" data-aos-once="true"
        data-aos-duration="1000" style="margin-top: 5px;">
        <?php
                        echo $this->html_model->product_box($see_first_product, 'grid', $box_style);
                        ?>
      </div>
      <?php }
            }
            ?>
      <?php
            $limit = $this->db->get_where('ui_settings', array('ui_settings_id' => 20))->row()->value;
            $allProducts = $this->crud_model->get_products("", $limit, "", "", "", "", "", "", "", "", "", "", $priority_product = true);
            
            ?>
      <?php
            foreach ($allProducts as $row) {
              $product_ids[] = $row['product_id'];
              $product_variants_ids[] = $row['product_variants_id'];
                ?>
      <div class="col-md-3 col-sm-6 col-xs-6 pd" data-aos="flip-left" data-aos-mirror="true" data-aos-once="true"
        data-aos-duration="1000" style="margin-top: 5px;">
        <?php
                    echo $this->html_model->product_box($row, 'grid', $box_style);
                    ?>
      </div>
      <?php } ?>
    </div>
    </div>
    <?php $lazy_loading = trim($this->db->get_where('ui_settings', array('ui_settings_id' => 62))->row()->value);
        if ($lazy_loading == 'no') { ?>
      
    <div class="text-center see_more_btn" style="position: relative; bottom: 0px;">
      <button onClick="getMoreProducts()" class="btn btn-bemartly mt-3"
        style="padding: 10px 35px; border-radius: 3px; background-color: #f3402d">See More <i
          class="fa fa-angle-down"></i></button>
    </div>
   
    <?php } else { ?>
    <script>
    var getHit = true;
    var threshold = 100;

    $(window).scroll(function() {
      // Calculate the distance from the top of the page to the bottom of the page
      var documentHeight = $(document).height();
      var windowHeight = $(window).height();
      var scrollTop = $(window).scrollTop();

      // Check if the user has scrolled to the bottom of the page
      if (documentHeight - (windowHeight + scrollTop) < threshold) {
        getMoreProducts();
      }
    });
    </script>
    <?php } ?>


</section>
<div class="text-center no_more_products mb-2">
      <br>
      <h3>No More Products</h3>
</div>

<!-- Modal -->

<?php if (get_cookie("subscription_popup") == NULL) { ?>
<div id="newsletter_subscription_modal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn_close_subscription_modal close">&times;</button>
      </div>
      <div class="modal-body">
        <div class="alert alert-danger" id="subscription_msg">
          <strong>Invalid Email ! </strong>
          <p>PLease Enter Valid Email</p>
        </div>
        <!-- Media middle -->
        <div class="media">
          <div class="media-left media-middle">
            <img src="<?php echo base_url('uploads/subscription_image/subscription_envelope.png'); ?>"
              class="media-object" style="width:100px">
          </div>
          <div class="media-body">
            <h4 class="media-heading" style="font-weight: bold !important;">
              Recieve Our Best Offer Directly To Your Inbox</h4>
            <p>Never Miss ! any more best deal by subscription into our list. We all ensure 100%
              delivery to
              your inbox right when deals enabled - Signup Now !</p>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <?php
                    echo form_open(base_url() . 'home/subscribe', array(
                        'class' => '',
                        'method' => 'post',
                        'id' => 'form_subscription'
                    ));
                    ?>
        <div class="row">
          <div class="col-md-9" style="margin-top: 0px;">
            <input id="email" type="text" class="form-control" name="email" placeholder="Enter Your Email Address">
            <input type="hidden" value="1" name="is_popup">
          </div>
          <div class="col-md-3" style="margin-top: 0px;">
            <button class="btn btn-default btn-md btn-subscription" type="submit">
              <i class="glyphicon glyphicon-envelope"></i>
              <?php echo translate("subscribe"); ?>
            </button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php } ?>
<script>
  $(".no_more_products").hide();
$(document).ready(function() {



  $('#newsletter_subscription_modal').modal({
    backdrop: 'static',
    keyboard: false
  });
  $(".btn_close_subscription_modal").click(function() {
    $('#newsletter_subscription_modal').modal("hide");
    var data = {
      '<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>'
    };
    $.ajax({
      type: "POST",
      url: '<?php echo base_url('home/unset_subscription_popup'); ?>',
      data: data,
      success: function(res) {}
    });
  });
  $(".btn-subscription").click(function(e) {
    $(".btn-subscription").children("i").attr("class", "fa fa-spinner fa-spin fa-fw");
    e.preventDefault();
    var form = $("#form_subscription").serialize();
    var url = $("#form_subscription").attr("action");
    $.ajax({
      type: "POST",
      url: url,
      data: form,
      success: function(res) {
        $(".btn-subscription i").attr("class", "glyphicon glyphicon-envelope");
        if (res == "validation_error") {
          $("#subscription_msg").show();
          setTimeout(function() {
            $("#subscription_msg").hide();
          }, 2000)
        } else {
          $('#newsletter_subscription_modal').modal("hide");
          Swal.fire({
            position: 'bottom-end',
            type: 'success',
            title: "We appreciate for subscription",
            allowOutsideClick: false,
            showConfirmButton: false,
            timer: 2000
          });
        }
      }
    });
  });
  // $('#newsletter_subscription_modal').modal("show");




});
var product_ids = `<?=json_encode($product_ids)?>`;
var product_ids = JSON.parse(product_ids);


function getMoreProducts() {
  var offset = <?= OFFSET_LIMIT ?>;
  var data = {
    offset: offset,
    speciality: 'allProducts',
    col: 3,
    category_id: '',
    sub_category_id: '',
    third_sub_category_id: '',
    sort_by: '',
    price: '',
    text: '',
    product_ids: `${JSON.stringify(product_ids)}`,
  };
  $("#product_loader").show();
  $.ajax({
    type: "POST",
    url: '<?= base_url("home/ajax_product_list") ?>',
    data: data,
    cache: false,
    success: function(data) {
      $ids = $(data);
      $ids = $ids[Number($ids.length) - 1];
      if(!$ids){
        $(".see_more_btn").hide();
        $(".no_more_products").show();
        return;
      }
      $ids = JSON.parse($($ids).val());
      product_ids = $ids.concat(product_ids);
      console.log(product_ids);
      getHit = true;
      $('.row_product_list').append(data);
      offset += <?= OFFSET_LIMIT ?>;
    }
  });

}
</script>

<!-- PAGE -->