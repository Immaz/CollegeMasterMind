<!-- PAGE -->
<?php
 $this->db->order_by("slides_id", "desc");
 $this->db->where("uploaded_by", "admin");
 $this->db->where("status", "ok");
 $slides=$this->db->get('slides')->result_array();
 $i=1;
?>

<style type="text/css">
    .top-section{
        animation-duration: 3s;
    }
    .main-slider .owl-theme .owl-controls .owl-nav .owl-prev{
        display: none!important;
    }
    .main-slider .owl-theme .owl-controls .owl-nav .owl-next{
        display: none!important;
    }
    .owl-carousel .owl-item img {
        width: 100%;
    }
    .backfill {
        background-color : <?php echo "purple"; ?>;
        width: 100%;
    }
</style>
<section class="top-section category_menu">
    <div class="">
        <div class="main-slider-row">
            <div class="col-md-12 col-sm-12 col-xs-12" style="margin-top: 0px!important;">
                <div class="row" style="margin-top: -5px;">
                    <div class="col-md-12 col-sm-12 col-xs-12 padding-lr-0-md" style="margin-top: 5px;">
                        <div class="main-slider">
                            <div class="owl-carousel" id="main-slider">
                                <?php
                                foreach($slides as $row){
                                ?>
                                <div class="item slide<?php echo $i; ?> alt" style="display: flex; justify-content: center; background-color: <?php echo $row['bg_color'] ? $row['bg_color'] : ""; ?>;">
                                    <a href="<?php echo $row['banner_link'] ? $row['banner_link'] : "#" ?>">
                                        <img class="slide-img image_delay" src="<?php echo $this->crud_model->file_view('slides',$row['slides_id'],'100','','no','src','','','.jpg') ?>" data-src="<?php echo $this->crud_model->file_view('slides',$row['slides_id'],'100','','no','src','','','.jpg') ?>" alt="" />
                                    </a>

                                    <div class="caption">
                                        <div class="div-table">
                                            <div class="div-cell">
                                                <div class="caption-content">
                                                    <p class="caption-text">
                                                        <?php if($row['button_text']!=NULL){ ?>
                                                        <a class="btn pull-right" style="background:<?php echo $row['button_color']; ?>; color:<?php echo $row['text_color']; ?>" href="<?php echo $row['button_link']; ?>">
                                                            <?php echo $row['button_text']; ?>
                                                        </a>
                                                        <?php } ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                    $i++;
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- /PAGE -->

<script>
    $(document).ready(function(){
        $('.category_side_set').each(function(){
            var obj = $(this);
            var childPos = obj.offset();
            var parentPos = obj.parent().offset();
            var reduce_top = childPos.top - parentPos.top;
            obj.find('.sub-menu').css('top','-'+reduce_top+'px');
        });
    });
</script>
