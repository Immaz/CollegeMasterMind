<style type="text/css">
.category_text {

  font-size: 14px;
  font-weight: 600;

  text-align: center;

  height: 32px;

  display: block;

  display: -webkit-box;

  width: 100%;

  margin: 0 auto;

  line-height: 1 !important;

  -webkit-line-clamp: 2;

  -webkit-box-orient: vertical;

  overflow: hidden;

  text-overflow: ellipsis;

  margin-top: 8px;
}

.category_img {

  max-width: 100%;

  border-radius: 10px;

}

.CircleImage:hover {

  background-color: rgba(34, 25, 36, .06);

  transform: translateY(-8px);

  border-color: transparent;

  position: relative;

  border-radius: 50%;

}

.fade {

  opacity: 1;

}


.shop_depart {

  font-weight: 400 !important;
  margin-bottom: 18px;

}

.close_box {

  background: #eee;

  border-radius: 20px;

  margin: 16px;

}

.close_out:hover {

  transform: translateY(-8px);

  border-color: transparent;

  position: relative;

}

.box-5 {

  background-color: #fff;

  margin-top: 40px;

  border-radius: 20px
}

.ct-text {

  padding-bottom: 18px;

  margin-top: -15px;

  margin-bottom: 30px !important;

}

.tooltip {

  word-break: break-all !important;

}

.featured-categories {
  background-color: #242424;
}

.category-box {
  background-color: white;
  border-radius: 5px;
  margin-bottom: 10px;
  width: 12%;
  padding-left: 5px;
  padding-right: 5px;
}
.fcategory{
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 16px; 
}
.fcategory div{
  box-sizing: border-box;
}
.fcategory div:nth-child(8n) {
  margin-left: 32px;
}
@media only screen and (max-width: 768px) {

  .category-box{
    width: 33%;
  }
  .fcategory div:nth-child(8n) {
  margin-left: 0px;
}
}

</style>



<?php

$category = "SELECT category_id AS id , category_name AS name , banner AS image , 'l1' AS category FROM category WHERE is_featured ='1' ORDER BY NAME ASC";
$sub_category = "SELECT sub_category_id AS id , sub_category_name AS name , banner AS image , 'l2' AS category FROM sub_category WHERE is_featured ='1' ORDER BY NAME ASC";
$thrid_sub_category = "SELECT third_sub_category_id AS id , third_sub_ctg_name AS NAME , banner AS image , 'l3' AS category FROM third_sub_category WHERE is_featured ='1' ORDER BY NAME ASC";

$category = $this->db->query($category);
$sub_category = $this->db->query($sub_category);
$third_sub_category = $this->db->query($thrid_sub_category);
// $sub_category = $this->db->query($home_widget_sql);
// $thrid_sub_category = $this->db->query($home_widget_sql);


$category_1_data = $category->result_array();
$category_2_data = $sub_category->result_array();
$category_3_data = $third_sub_category->result_array();
$home_widget = array_merge($category_1_data, $category_2_data, $category_3_data);
$home_widget_count = count($home_widget);
?>



<!-- PAGE -->

<section class="page-section featured-products sl-featured featured-categories" style="padding-top: 10px;

    padding-bottom: 25px;">

  <div class="container box-1">

    <div>

      <h2 class="col-md-12 shop_depart" style="color: white;">Explore your interests</h2>
      <section class="">


        <div class="row fcategory">

          <?php
          $count = 0;

          if ($home_widget_count > 0) {

            ?>

          <?php foreach ($category_1_data as $menu) { ?>

          <div class="category-box" style="margin-top:0px!important;">

            <a href="<?php echo base_url('home/category?category=' . $menu['id']); ?>">

              <div class="" style="border-bottom: 2px solid #ccc">

                <div class="">

                  <div class="" style="">

                    <img class="" style=" max-width: 100%;" alt=""
                      src="<?php echo base_url('') ?>uploads/category_image/<?php echo $menu['image']; ?>"
                      srcset="<?php echo base_url('') ?>uploads/category_image/<?php echo $menu['image']; ?>"
                      sizes="146px">

                  </div>

                </div>

              </div>

              <div class="category_text" data-toggle="tooltip" title="<?php echo $menu['name']; ?>">
                <?php echo $menu['name']; ?>
              </div>

            </a>

          </div>

          <?php $count++;
            } ?>

          <?php foreach ($category_2_data as $menu2) { ?>

          <div class="category-box" style="margin-top:0px!important;">

            <a href="<?php echo base_url('home/category?category=' . $menu2['id']); ?>">

              <div class="" style="border-bottom: 2px solid #ccc">

                <div class="">

                  <div class="" style="">

                    <img class="" style="max-width: 100%;" alt=""
                      src="<?php echo base_url('') ?>uploads/sub_category_image/<?php echo $menu2['image']; ?>"
                      srcset="<?php echo base_url('') ?>uploads/sub_category_image/<?php echo $menu2['image']; ?>"
                      sizes="146px">

                  </div>

                </div>

              </div>

              <div class="category_text" data-toggle="tooltip" title="<?php echo $menu2['name']; ?>">
                <?php echo $menu2['name']; ?>
              </div>

            </a>

          </div>

          <?php $count++;
            } ?>

          <?php foreach ($category_3_data as $menu3) { ?>

          <div class="category-box" style="margin-top:0px!important;">

            <a href="<?php echo base_url('home/category?category=' . $menu3['id']); ?>">

              <div class="" style="border-bottom: 2px solid #ccc">

                <div class="">

                  <div class="" style="">

                    <img class="" style="max-width: 100%;" alt=""
                      src="<?php echo base_url('') ?>uploads/third_sub_category_image/<?php echo $menu3['image']; ?>"
                      srcset="<?php echo base_url('') ?>uploads/third_sub_category_image/<?php echo $menu3['image']; ?>"
                      sizes="146px">

                  </div>

                </div>

              </div>

              <div class="category_text" data-toggle="tooltip" title="<?php echo $menu3['NAME']; ?>">
                <?php echo $menu3['NAME']; ?>
              </div>

            </a>

          </div>

          <?php $count++;
            }
          } ?>

        </div>

      </section>

    </div>

  </div>

</section>

<!-- /PAGE -->