<style>
.features {
  display: flex;
  justify-content: space-around;
  padding-top: 8px;
}

.iconbox {
  display: flex;
  align-items: center;
  padding: 10px 20px;
}

.iconbox-text {
  margin-left: 8px;
}
.iconbox img{
  height: 60px;
  width: 60px;
}

</style>
<div class="container features">
      <div class="iconbox box1"><img src="<?php echo base_url(); ?>uploads/others/customer.png" alt="customer">
        <div class="iconbox-text">
          <div style="font-weight:600; " class="heading">24/7 Support</div>
          <div style="margin-top: -8px; font-size: 10px; color: #9f9e9e;">Online Support 24/7</div>
        </div>
      </div>

      <div class="iconbox box2"><img src="<?php echo base_url(); ?>uploads/others/money.png" alt="customer">
        <div class="iconbox-text">
          <div style="font-weight: 600;" class="heading">Money Back Guarantee</div>
          <div style="margin-top: -8px; font-size: 10px; color: #9f9e9e">100% Secure Payment</div>
        </div>
      </div>

      <div class="iconbox box3"><img src="<?php echo base_url(); ?>uploads/others/gift.png" alt="customer">
        <div class="iconbox-text">
          <div style="font-weight: 600;" class="heading">Special Gift Cards</div>
          <div style="margin-top: -8px; font-size: 10px; color: #9f9e9e">Give The Perfect Gift</div>
        </div>
      </div>

      <div class="iconbox box4"><img src="<?php echo base_url(); ?>uploads/others/fast-delivery.png" alt="customer">
        <div class="iconbox-text">
          <div style="font-weight: 600;" class="heading">Worldwide Shipping</div>
          <div style="margin-top: -8px; font-size: 10px; color: #9f9e9e">On-orders over $99</div>
        </div>
      </div>

</div>

<style>
@media (max-width: 768px) {
  .heading{
  font-size: 12px;
  margin-bottom: 8px;
  }
  .features{
    display: block;
  }
  .box1, .box2, .box3, .box4{
    display: inline-block;
    width: 45%;
    text-align: center;
  }
}

</style>