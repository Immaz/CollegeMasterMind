<?php
$box_style = $this->db->get_where('ui_settings', array('ui_settings_id' => 42))->row()->value;
$limit = $this->db->get_where('ui_settings', array('ui_settings_id' => 20))->row()->value;
$featured_products = $this->crud_model->getFeaturedProducts();
?>
<?php if ($featured_products) { ?>
<style type="text/css">
.section-title {
  margin-bottom: 0px;
}

.owl-prev i,
.owl-next i {
  display: block !important;
}

.bg-grey {
  background-color: #f5f5f5;
}

.featured-products .owl-prev {
  left: -0.1% !important;
}

.featured-products .owl-next {
  right: -0.1% !important;
}

.featured_product_top_slider .box-style-2 .btn_add_to_cart {
  font-size: 11px !important;
}

.featured_product_top_slider .box-style-2 .caption-title a {
  font-size: 12px;
}

.featured_product_top_slider .box-style-2 .btn_add_to_cart {
  height: 38px;
  margin: 0px -8px;
  padding: 10px 0px !important;
}

.thumbnail.box-style-2 .media-link {
  padding: 0px;
  display: flex;
  align-items: center;
}

.featured_product_top_slider .featured-products-carousel .thumbnail.box-style-2 .media-link img {
  height: 100%;
}

.featured_product_top_slider .featured-products-carousel .thumbnail.box-style-2 .btn_add_to_cart {
  background-color: #727c84;
  border: 1px solid #727c84;
}

.featured_product_top_slider .featured-products-carousel .thumbnail.box-style-2 .btn_add_to_cart:hover {
  color: white !important;
  background-color: #25d3c9;
  border: 1px solid #25d3c9;
}
@media (max-width: 768px) {
  #add_to_cart{
    margin-left: 30px;
  }
}
</style>
<!-- PAGE -->
<section class="page-section featured-products sl-bundled featured_product_top_slider "
  style="padding-bottom: 0px; padding-top: 0px!important;">
  <div class="container">
    <div class="row">
      <div class="col-sm-12" style="margin-top: 0px; padding: 0px;">
        <div class="featured-products-carousel">
          <div class="owl-carousel-2" id="most-viewed-carousel">
            <?php
                            $count = 2;
                            foreach ($featured_products as $row) {
                                ?>
            <div class="col-md-12" style="margin-top:10px; padding: 0px;  border: 0px solid #3C3B6E;">
              <?php
                                    echo $this->html_model->product_box($row, 'grid', $box_style);
                                    ?>
            </div>
            <?php $count++;
                            } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- /PAGE -->
<script>
$(document).ready(function() {
  if ($(window).width() < 900) {
    $(".owl-carousel-2").owlCarousel({
      items: 2,
      loop: true,
      margin: 3,
      autoplay: true,
      slideTransition: 'linear',
      autoplayTimeout: 100,
      autoplaySpeed: 4000,
      dots: false,
      nav: true,
      autoplayHoverPause: true,
      navText: [
        "<i class='fa fa-chevron-left'></i>",
        "<i class='fa fa-chevron-right' ></i>"
      ]
    });
    // console.log("Less than true");       
  } else {
    $(".owl-carousel-2").owlCarousel({
      items: 4,
      loop: true,
      margin: 3,
      autoplay: true,
      slideTransition: 'linear',
      autoplayTimeout: 100,
      autoplaySpeed: 4000,
      dots: false,
      nav: true,
      autoplayHoverPause: true,
      navText: [
        "<i class='fa fa-chevron-left'></i>",
        "<i class='fa fa-chevron-right' ></i>"
      ]
    });
    // console.log("Less than false");
  }

  //  set_bundled_product_box_height();
});

function set_bundled_product_box_height() {
  var max_title = 0;
  $('.sl-bundled .caption-title').each(function() {
    var current_height = parseInt($(this).css('height'));
    if (current_height >= max_title) {
      max_title = current_height;
    }
  });
  if (max_title > 0) {
    $('.sl-bundled .caption-title').css('height', max_title);
  }
}
</script>
<?php } ?>