        <?php
            $meta_keyword = "BeMartly";
            $meta_description= "BeMartly.com.";
            if(isset($variants[0])){
                if($variants[0]['meta_keyword']!="" && $variants[0]['meta_keyword']!=NULL){
                    $meta_keyword = $variants[0]['meta_keyword'];
                } else{
                    if($variants[0]['title']!="" && $variants[0]['title']!=NULL){
                        $meta_keyword =  str_replace(" ",",", substr($variants[0]['title'], 0,120));
                    }
                }
                if($variants[0]['meta_description']!="" && $variants[0]['meta_description']!=NULL){
                    $meta_description =  substr($variants[0]['meta_description'], 0,120);
                }else{
                    if($variants[0]['description']!="" && $variants[0]['description']!=NULL){
                        $meta_description =  substr($variants[0]['description'], 0,120);
                    }
                }
            }

            if(isset($meta)){
                if($meta['meta_keyword']!="" && $meta['meta_keyword']!=NULL){
                    $meta_keyword = $meta['meta_keyword'];
                }else{
                    $meta_keyword =  $meta['category_name'];
                }
                if($meta['meta_description']!="" && $meta['meta_description']!=NULL){
                    $meta_description = substr($meta['meta_description'], 0,120);
                }else{
                    // if($meta['description']!="" && $meta['description']!=NULL){
                        $meta_description =  substr($meta_description, 0,120);
                    // }
                }
            }
        ?>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="revisit-after" content="<?php echo $revisit_after; ?> days">
        <meta name="keywords" content="<?php echo $meta_keyword; ?>">
        <meta name="description" content="<?php echo $meta_description; ?>">
        <meta property="og:title" content="BeMartly" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="<?php echo base_url(); ?>" />
        <?php
            $home_top_logo = $this->db->get_where('ui_settings',array('type' => 'home_top_logo'))->row()->value;
            ?>
        <meta property="og:image" content="<?php echo base_url(); ?>uploads/logo_image/logo_<?php echo $home_top_logo; ?>.png" />
        <meta property="og:image:type" content="image/png">
        <meta property="og:description" content="Bemartly.com" />
        <meta property="og:locale" content="en_US" />
        <?php
        	include 'meta/'.$asset_page.'.php';
		?>      
        <!-- Favicon -->
        <?php $ext =  $this->db->get_where('ui_settings',array('type' => 'fav_ext'))->row()->value;?>
       <!--  <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url(); ?>template/front/ico/apple-touch-icon-144-precomposed.png"> -->
        
        <link rel="shortcut icon" href="<?php echo base_url(); ?>uploads/others/favicon.<?php echo $ext; ?>">
        
        <title><?php echo $page_title; ?></title>
        <?php if($this->crud_model->get_type_name_by_id('general_settings','80','value') == 'ok'){?>
        <!-- Google Analytics -->
        <script>
        (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
        m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
        })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

        ga('create', "<?php echo $this->db->get_where('general_settings',array('type'=>'google_analytics_key'))->row()->value; ?>", 'auto');
        ga('send', 'pageview');
        </script>
        <!-- End Google Analytics -->
        <?php } ?>
        <!-- CSS Global -->
        <link href="<?php echo base_url(); ?>template/front/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>template/front/plugins/bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet">
        <!-- <link href="<?php // echo base_url(); ?>template/front/plugins/fontawesome/css/font-awesome.min.css" rel="stylesheet"> -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link href="<?php echo base_url(); ?>template/front/plugins/animate/animate.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>template/front/plugins/jquery-ui/jquery-ui.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>template/front/modal/css/sm.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>template/front/rateit/rateit.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>template/front/css/slick.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>template/front/css/slick-theme.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/assets/owl.carousel.min.css" rel="stylesheet">

        <!-- Theme CSS -->
        <?php $theme =  $this->db->get_where('ui_settings',array('type' => 'header_color'))->row()->value;?>
        <link href="<?php echo base_url(); ?>template/front/css/theme.css?<?php echo rand(); ?>" rel="stylesheet">
        <link href="<?php echo base_url(); ?>template/front/css/theme-<?php echo $theme; ?>.css" rel="stylesheet" id="theme-config-link">

        <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

        <link href="<?php echo base_url(); ?>template/front/plugins/smedia/custom-1.css" rel="stylesheet">
        
            <!-----------sweet alert 2 -------------->
        <link href="<?php echo base_url(); ?>template/back/css/sweetalert2.min.css" rel="stylesheet">

        <!-----mega menu css----------->
        <link href="<?php echo base_url(); ?>template/front/mega_menu/css/style.css?<?php echo rand(); ?>" rel="stylesheet">

        <!------------ Head Libs ------------>
        <script src="<?php echo base_url(); ?>template/front/plugins/jquery/jquery-1.11.1.min.js"></script>

        <!-----------sweet alert 2 -------------->
        <script src="<?php echo base_url(); ?>template/back/js/sweetalert2.min.js"></script>
        
        <!------jquery validation-------->
        <script src="<?php echo base_url(); ?>template/back/js/jquery.validate.js"></script>
        <script src="<?php echo base_url(); ?>template/back/js/additional-methods.js"></script>
       
       <?php 
            $font =  $this->db->get_where('ui_settings',array('type' => 'font'))->row()->value;
        ?>	
        <link href='https://fonts.googleapis.com/css?family=<?php echo $font; ?>:400,500,600,700,800&display=swap' rel='stylesheet' type='text/css'>
        <style>
			*{
				font-family: '<?php echo str_replace('+',' ',$font); ?>', sans-serif;
			}
			.remove_one{
				cursor:pointer;
				/*padding-left:5px;	*/
                border-radius: 10px;
                float: right;
                font-size: 10px;
			}
            .remove_one:hover{
                border-radius: 10px;
            }
		</style>
        <?php
        	include $asset_page.'.php';
        ?>

