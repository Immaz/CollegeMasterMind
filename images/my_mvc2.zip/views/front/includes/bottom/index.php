		<script>
            var base_url = "<?php echo base_url(); ?>";
        </script>
        <script src="<?php echo base_url(); ?>template/front/js/ajax_method.js"></script>
        <script src="<?php echo base_url(); ?>template/front/js/bootstrap-notify.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/jquery-ui/jquery-ui.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/bootstrap-select/js/bootstrap-select.min.js"></script>
        <!-- JS Global -->
        <script src="<?php echo base_url(); ?>template/front/plugins/superfish/js/superfish.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/jquery.sticky.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/jquery.easing.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/jquery.smoothscroll.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/smooth-scrollbar.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/jquery.cookie.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/owl-carousel2/owl.carousel.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/plugins/modernizr.custom.js"></script>
        <script src="<?php echo base_url(); ?>template/front/modal/js/jquery.active-modals.js"></script>
        <script src="<?php echo base_url(); ?>template/front/js/theme.js"></script>
        <script src="<?php echo base_url(); ?>template/front/rateit/jquery.rateit.min.js"></script>
        <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
        <script src="<?php echo base_url(); ?>template/front/js/slick.min.js"></script>
        <script src="<?php echo base_url(); ?>template/front/js/jquery.mask.js"></script>
        <!-----mega menu js----->
        <script src="<?php echo base_url(); ?>template/front/mega_menu/js/jquery.menu-aim.js"></script>
        <script src="<?php echo base_url(); ?>template/front/mega_menu/js/main.js?<?php echo rand(); ?>"></script>
        <?php
	       include $asset_page.'.php';
		?>
    <script>
        AOS.init();
        $(document).ready(function(){
            // $(".top-section").addClass("animated bounceInLeft slower");
            setInterval(function(){$(".top_slider_row").show(); $(".top_slider_row").addClass("animated bounceInRight slower");},200)
        });
    </script>
    <form id="cart_form_singl">
            <input type="hidden" name="single_color" value="">
            <input type="hidden" name="qty" value="1">
    </form>