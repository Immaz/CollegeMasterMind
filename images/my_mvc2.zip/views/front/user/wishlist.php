<style type="text/css">
    .ajax-to-cart{
        background-color: #B22234;
        border-color: #B22234;
        color: #ffffff;
    }
    .ajax-to-cart:hover,
    .added_to_cart:hover
    {
        color: white;
    }
    .added_to_cart:hover{
        cursor: no-drop;
    }
    .added_to_cart{
        border-color: #3C3B6E;
        color: white;
        background-color: #3C3B6E;
    }
    .table_wishlist th{
        font-size: 16px;
    }
    .table_wishlist td{
        font-size: 14px;
    }
    #table_wishlist td,
    #table_wishlist th{
        vertical-align: middle;
     }
</style>
    <table class="table table-bordered table-stripped table_wishlist" id="table_wishlist">
        <thead>
            <tr>
                <th>#</th>
                <th><?php echo translate('image');?></th>
                <th><?php echo translate('name');?></th>
                <th><?php echo translate('price');?></th>
                <th><?php echo translate('purchase');?></th>
                <th><?php echo translate('remove');?></th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $i = 0;
                foreach ($wishlist as $row1) {
                $i++;
                $variant_image = "default.jpg";
                if($row1['front_image']!="" && $row1['front_image']!=NULL){
                    $img =  json_decode($row1['front_image'], true);
                    $variant_image = $img[0];
                }else{
                    $img = json_decode($row1['images'], true);
                    if(count($img)>0){
                        $variant_image  =  $img[0];
                    }
                }
            ?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td class="image">
                        <a href="<?php echo  base_url("home/product_view/".$row1['product_id']."/".$this->crud_model->infiltrate_unwated_character($row1['title'])); ?>">
                            <img width="80" src="<?php echo $this->crud_model->get_image("product_variants", $variant_image); ?>" alt=""/>
                        </a>
                    </td>
                    <td class="description"><?php echo $row1['title']; ?></td>
                    <td class="price"><?php echo currency($this->crud_model->get_product_price($row1['product_variants_id'])); ?></td>
                    <td class="add">
                        <?php if(!$this->crud_model->is_added_to_cart($row1['product_variants_id'])){ ?>
                            <span class="btn btn-md btn-icon-left  ajax-to-cart"  onclick="to_cart(<?php echo $row1['product_variants_id']; ?>,event)">
                                <i class="fa fa-shopping-cart"></i> 
                                <?php echo translate('add_to_cart'); ?>
                            </span>
                        <?php } else { ?>
                            <span class="btn btn-md btn-icon-left added_to_cart">
                                <i class="fa fa-shopping-cart"></i>
                                <?php echo translate('added_to_cart'); ?>
                            </span>
                        <?php } ?>
                    </td>
                    <td class="total">
                        <span class="remove_from_wish" style="cursor:pointer; margin: 0 0 0 40%;" data-pid='<?php echo $row1['product_variants_id']; ?>' >
                            <i class="fa fa-trash" style="color: #f00;"></i>
                        </span>
                    </td>                        
                </tr>                                      
            <?php 
                }
            ?>
        </tbody>
    </table>
<!-- <div class="pagination_box">
</div> -->
<script>                         
 //product_listing_defaults();                                           
    function wish_listed(page){
        if(page == 'no'){
            page = $('#page_num4').val();   
        } else {
            $('#page_num4').val(page);
        }
        var alerta = $('#result4');
        alerta.load('<?php echo base_url();?>home/wish_listed/'+page,
            function(){
                //set_switchery();
            }
        );   
    }
    $(document).ready(function() {
        //wish_listed('0');
    });

</script>