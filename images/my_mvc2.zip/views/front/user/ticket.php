<div id="window">
    <div class="information-title">
        <?php echo translate('support_ticket');?>
    </div>
    <div class="details-wrap">
        <div class="row">
            <div class="col-md-12" style="margin-top: 0px!important;">
                <div class="tabs-wrapper content-tabs">
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a href="#tab1" data-toggle="tab">
                                <?php echo translate('all_messages');?>
                            </a>
                        </li>
                        <li>
                            <a href="#tab2" data-toggle="tab">
                                <?php echo translate('create_ticket');?>
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab1">
                            <table class="table table-bordered table-hovered table-stripped">
                                <thead>
                                    <tr>
                                        <th><?php echo translate('ticket_subject');?></th>
                                        <th><?php echo translate('options');?></th>
                                    </tr>
                                </thead>
                                <tbody >
                                <?php 
                                    $i = 0;
                                    foreach ($user_tickets as $row1) {
                                        $i++;
                                ?>         
                                    <tr>
                                        <td class="description">
                                            <?php echo $row1['subject'];?>
                                            <?php
                                                $num = $this->crud_model->ticket_unread_messages($row1['ticket_id'],'user');
                                                if($num > 0){
                                            ?>
                                                <span class="btn btn-info btn-xs" style="margin-left:10px">
                                                    <?php 
                                                        echo translate('new_message').' '.'('.' ';
                                                        echo $num .' '.')'; 
                                                    ?>
                                                </span>
                                            <?php }?>
                                        </td>
                                        <td class="add">
                                            <a class="btn btn-sm btn-default message_view" data-id="<?php echo $row1['ticket_id']?>" href="#">
                                                <i class="fa fa-envelope"></i>
                                                <?php echo translate('view_message');?>
                                            </a>
                                        </td>
                                    </tr>
                                <?php 
                                    }
                                ?>
                                </tbody>
                            </table>  
                        </div>
                        <div class="tab-pane fade" id="tab2">
                            <div class="row">
								<?php
                                    echo form_open(base_url() . 'home/ticket_message_add/', array(
                                        'class' => 'form-login',
                                        'method' => 'post',
                                        'id' => 'add_ticket',
                                        'enctype' => 'multipart/form-data'
                                    ));
                                ?>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                        	<input class="form-control" name="sub" type="text" placeholder="<?php echo translate('subject');?>">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <label class="sr-only">
											<?php echo translate('comment');?> *
                                        </label>
                                        <textarea maxlength="5000" rows="10" class="form-control" name="reply" id="comment" style="height: 138px;" placeholder="<?php echo translate('message');?> *"></textarea>
                                    </div>
                                    <div class="col-md-12">
                                        <span class="btn btn-theme-dark btn-icon-right pull-right submit_button enterer" onclick="form_submit('add_ticket');" data-ing="<?php echo translate('creating...'); ?>" data-success="<?php echo translate('ticket_created_successfully'); ?>!" data-unsuccessful="<?php echo translate('ticket_creation_unsuccessful'); ?>!" data-redirectclick="#ticket" >
                                        	<?php echo translate('create'); ?>
                                            <i class="fa fa-arrow-circle-right"></i>
                                        </span>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
	$('body').on('click','.message_view',function(){
        $(".overlay_holder1").show();
		var id = $(this).data('id');
		$("#window").load("<?php echo base_url()?>home/profile/message_view/"+id,function(){
            $(".overlay_holder1").hide();
        });
	});
								
</script>