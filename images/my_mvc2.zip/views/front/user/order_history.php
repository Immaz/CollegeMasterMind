<div class="row">
    <div class="col-lg-12" style="margin-top: 0px!important;">
        <div class="information-title">
            <?php echo translate('your_order_history');?>
        </div>
        <table class="table table-bordered table-hovered">
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo translate('date');?></th>
                    <th><?php echo translate('total_amount');?></th>
                    <th><?php echo translate('payment_status');?></th>
                    <th><?php echo translate('delivery_status');?></th>
                    <th><?php echo translate('invoice');?></th>
                </tr>
            </thead>
            <tbody>
                    <?php 
                        $i = 0;
                        foreach ($orders as $row1) {
                        $i++;
                    ?>
                        <tr>
                            <td class="image">
                                <?php echo $i; ?>
                            </td>
                            <td class="quantity">
                                <?php echo date('d M Y',$row1['sale_datetime']); ?>
                            </td>
                            <td class="description">
                                <?php echo currency($row1['grand_total']); ?>
                            </td>
                            <td class="payment-id">
                                <?php echo ucfirst(json_decode($row1['payment_status'])[0]->status);?>
                            </td>
                            <td class="order-id">
                                <?php echo ucfirst(json_decode($row1['delivery_status'])[0]->status);?>
                            </td>
                            <td class="add">
                                <a class="btn btn-default btn-sm" href="<?php echo base_url(); ?>home/invoice/<?php echo $row1['sale_id']; ?>">
                                    <?php echo translate('invoice');?> 
                                    <i class="fa fa-paper-plane"></i></a>
                            </td>
                        </tr>                                            
                    <?php 
                        }
                    ?>
            </tbody>
        </table>
    </div>

<!--     <div class="col-lg-3">
        <div class="information-title">
            <?php echo translate('order_tracing');?>
        </div>
        <div class="details-wrap">                                    
            <div class="details-box orders">                
                <?php
                    echo form_open(base_url() . 'home/profile/order_tracing/', array(
                        'class' => 'form-login',
                        'method' => 'post',
                        'enctype' => 'multipart/form-data'
                    ));
                ?>    
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <span style="width: 10%;float:left;padding-top: 3px;font-size: 25px;">#</span>
                                <input style="width: 90%;float:left;" class="form-control" name="sale_code" type="text" placeholder="<?php echo translate('sale_code');?>">
                            </div>
                        </div>
                        <div class="col-md-12" style="margin-top:0px;">
                            <span class="btn btn-theme btn-block signup_btn" data-callback="order_tracing" data-unsuccessful='<?php echo translate('order_tracing_unsuccessful!'); ?>' data-success='<?php echo translate('order_traced_successfully!'); ?>' data-ing='<?php echo translate('checking..') ?>' >
                                <?php echo translate('trace_my_order');?>
                            </span>
                            <div id="trace_details">

                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div> -->

    </div>
</div>
<script>
    $(document).ready(function() {
       
    });
</script>