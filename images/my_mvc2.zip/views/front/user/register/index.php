<style type="text/css">
    .user_registeration_failed{
        display: none;
    }
    .user_registeration_failed strong p{
        margin: 1px;
    }
</style>
<section class="page-section color get_into">
    <div class="container">
        <div class="row margin-top-0">
            <div class="col-sm-8 col-sm-offset-2">
<!--                 <div class="logo_top">
                    <a href="<?php echo base_url()?>">
                        <img class="img-responsive" src="<?php echo $this->crud_model->logo('home_bottom_logo'); ?>" alt="Shop" style="z-index:200">
                    </a>
                </div> -->
				<?php
                    echo form_open(base_url() . 'home/registration/add_info/', array(
                        'class' => 'form-login',
                        'method' => 'post',
                        'id' => 'sign_form'
                    ));
                    $fb_login_set = $this->crud_model->get_type_name_by_id('general_settings','51','value');
                    $g_login_set = $this->crud_model->get_type_name_by_id('general_settings','52','value');
                ?>
                	<div class="row box_shape">
                        <div class="title">
                            <?php echo translate('Create Account');?>
                            <div class="option">
                            	<?php echo translate('already_have_an_account_?_click_to_');?>
                                <?php
									if ($this->crud_model->get_type_name_by_id('general_settings','58','value') !== 'ok') {
								?>
                                <a href="<?php echo base_url(); ?>home/login_set/login"> 
                                    <?php echo translate('login');?>!
                                </a>
                                <?php
									}else{
								?>
                                <a href="<?php echo base_url(); ?>home/login_set/login"> 
                                    <?php echo translate('login');?>!
                                </a>
                                <?php
									}
								?>
                            </div>
                        </div>
                        <hr>
                        <div  class="col-md-12 user_registeration_failed">
                            <div class="alert alert-danger">
                                <strong></strong>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control required" name="username" type="text" placeholder="<?php echo translate('first_name');?>" data-toggle="tooltip" title="<?php echo translate('first_name');?>" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control required" name="surname" type="text" placeholder="<?php echo translate('last_name');?>" data-toggle="tooltip" title="<?php echo translate('last_name');?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control emails required" name="email" type="email" placeholder="<?php echo translate('email');?>" data-toggle="tooltip" title="<?php echo translate('email');?>" autocomplete="off">
                            </div>
                            <div id='email_note'></div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control" name="phone" type="text" id="phone" placeholder="<?php echo translate('phone');?>" data-toggle="tooltip" title="<?php echo translate('phone');?>" autocomplete="off">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control pass1 required" type="password" name="password1" placeholder="<?php echo translate('password');?>" data-toggle="tooltip" title="<?php echo translate('password');?>" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <input class="form-control pass2 required" type="password" name="password2" placeholder="<?php echo translate('confirm_password');?>" data-toggle="tooltip" title="<?php echo translate('confirm_password');?>" autocomplete="off">
                            </div>
                            <div id='pass_note'></div> 
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <input class="form-control required" name="address1" type="text" placeholder="<?php echo translate('address');?>" data-toggle="tooltip" title="<?php echo translate('address');?>" autocomplete="off">
                            </div>
                        </div>
<!--                         <div class="col-md-12">
                            <div class="form-group">
                                <input class="form-control required" name="address2" type="text" placeholder="<?php echo translate('address_line_2');?>" data-toggle="tooltip" title="<?php echo translate('address_line_2');?>">
                            </div>
                        </div> -->
                        <div class="col-md-6">
                            <select class="form-control required customer_info_form_inputs" id="country" name="country">
                                <option value=""><?php echo translate("-- Select Country --"); ?></option>
                                <?php 
                                    $countries = $this->db->get("country")->result_array();
                                    foreach($countries as $country){
                                ?>
                                <option value="<?php echo $country['country_id']; ?>" <?php echo $selected; ?>> 
                                    <?php echo $country['country_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <select class="form-control required customer_info_form_inputs" id="state" name="state">
                                    <option value=""><?php echo translate("-- Select State --"); ?></option>
                                    <?php
                                        $state_del = $this->crud_model->getStateById($state);
                                    ?>
                                    <?php if($state_del){?>
                                        <option selected="selected" value="<?php echo $state_del['state_id']; ?>"><?php echo $state_del['state_name']; ?></option>
                                    <?php }?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <select class="form-control required customer_info_form_inputs" id="city" name="city">
                                    <option value=""><?php echo translate("-- Select City --"); ?></option>
                                <?php
                                    $city_del = $this->crud_model->getCityById($city);
                                ?>
                                    <?php if($city_del){?>
                                        <option value="<?php echo $city_del['city_id']; ?>" selected="selected"><?php echo $city_del['city_name']; ?></option>
                                    <?php }?>
                                </select>
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="">
                                <input class="form-control required" name="zip" type="text" placeholder="<?php echo translate('Zip Code');?>" maxlength="15" data-toggle="tooltip" title="<?php echo translate('Zip Code');?>" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-12 terms">
                            <input  name="terms_check" type="checkbox" value="ok" > 
                            <?php echo translate('i_agree_with');?>
                            <a href="<?php echo base_url();?>home/legal/terms_conditions" target="_blank">
                                <?php echo translate('terms_&_conditions');?>
                            </a>
                        </div>
                        <?php
							if($this->crud_model->get_settings_value('general_settings','captcha_status','value') == 'ok'){
						?>
                        <div class="col-md-12">
                            <div class="outer required">
                                <div class="form-group">
                                    <?php echo $recaptcha_html; ?>
                                </div>
                            </div>
                        </div>
                        <?php
							}
						?>
                        <div class="col-md-12">
                            <span class="btn btn-theme-sm btn-block btn-theme-dark pull-right logup_btn register-btn" data-ing='<?php echo translate('registering..'); ?>' data-msg="">
                                <?php echo translate('register');?>
                            </span>
                        </div>
                        <!--- Facebook and google login -->
                        <?php if($fb_login_set == 'ok' || $g_login_set == 'ok'){ ?>
                            <div class="col-md-12 col-lg-12">
                                <h2 class="login_divider"><span>or</span></h2>
                            </div>
                        <?php if($fb_login_set == 'ok'){ ?>
                            <div class="col-md-12 col-lg-6 <?php if($g_login_set !== 'ok'){ ?>mr_log<?php } ?>">
                                <?php if (@$user): ?>
                                    <a class="btn btn-theme btn-block btn-icon-left facebook" href="<?= $url ?>">
                                        <i class="fa fa-facebook"></i>
                                        <?php echo translate('sign_in_with_facebook');?>
                                    </a>
                                <?php else: ?>
                                    <a class="btn btn-theme btn-block btn-icon-left facebook" href="<?= $url ?>">
                                        <i class="fa fa-facebook"></i>
                                        <?php echo translate('sign_in_with_facebook');?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php } if($g_login_set == 'ok'){ ?>  
                            <div class="col-md-12 col-lg-6 <?php if($fb_login_set !== 'ok'){ ?>mr_log<?php } ?>">
                                <?php if (@$g_user): ?>
                                    <a class="btn btn-theme btn-block btn-icon-left google" style="background:#ce3e26" href="<?= $g_url ?>">
                                        <i class="fa fa-google"></i>
                                        <?php echo translate('sign_in_with_google');?>
                                    </a>
                               <?php else: ?>
                                    <a class="btn btn-theme btn-block btn-icon-left google" style="background:#ce3e26" href="<?= $g_url ?>">
                                        <i class="fa fa-google"></i>
                                        <?php echo translate('sign_in_with_google');?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        <?php
                                }
                            }
                        ?>
                    </div>
            	</form>
            </div>
        </div>
    </div>
</section>

<script type="text/javascript">
    $(document ).ready(function() {
        //set_cart_map();
        $("#country").change(function(){
            var  country_id = $(this).val();
            if(country_id!=""){
                $(".overlay_holder1").show();
                var data = {
                    country_id: country_id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
                };
                $.ajax({
                    url : '<?php echo base_url('home/get_state_by_country_id'); ?>',
                    type : 'POST',
                    data : data,
                    success : function(response){
                        //console.log(response);
                        var converted = JSON.parse(response);
                        if(converted.status == "1"){
                            var state_opt = "<option value=''>-- Select --</option>";
                            $.each(converted.data,function(ind , val){
                                state_opt +="<option value='"+val.state_id+"'>"+val.state_name+"</option>";
                            });
                            $("#state").html(state_opt);
                        }
                        else{
                            $("#state").html("<option value=''>-- Select --</option>");
                            $("#city").html("<option value=''>-- Select --</option>");
                        }
                        $(".overlay_holder1").hide();
                    }   
                });
            }else{
                $("#state").html("<option value=''>-- Select --</option>");
                $("#city").html("<option value=''>-- Select --</option>");
            }
        });
        $("#state").change(function(){
            var  state_id = $(this).val();
            if(state_id!=""){
                $(".overlay_holder1").show();
                var data = {
                    state_id: state_id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
                };
                $.ajax({
                    url : '<?php echo base_url('home/get_city_by_state_id'); ?>',
                    type : 'POST',
                    data : data,
                    success : function(response){
                        var converted = JSON.parse(response);
                        if(converted.status == "1"){
                            var city_opt = "<option value=''>-- Select --</option>";
                            $.each(converted.data,function(ind , val){
                                city_opt +="<option value='"+val.city_id+"'>"+val.city_name+"</option>";
                            });
                            $("#city").html(city_opt);
                        }else{
                            $("#city").html("<option value=''>-- Select --</option>");
                        }                        
                        $(".overlay_holder1").hide();
                    }
                });
            }else{
                $("#city").html("<option value=''>-- Select --</option>");
            }
        });
        $('#state').trigger('change');
        // $("input[name='zip']").mask('999999999999999');

        $('#phone').keyup(function(e){
            var isValid = false;
            var regex = /^[0-9-+()]*$/;
            isValid = regex.test($("#phone").val());
            if(isValid == false){
                $('#phone').val('');   
            }
        });
    });
</script>

<style>
	.get_into .terms a{
		margin:5px auto;
		font-size: 14px;
		line-height: 24px;
		font-weight: 400;
		color: #00a075;
		cursor:pointer;
		text-decoration:underline;
	}
	
	.get_into .terms input[type=checkbox] {
		margin:0px;
		width:15px;
		height:15px;
		vertical-align:middle;
	}
</style>