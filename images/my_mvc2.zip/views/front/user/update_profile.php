
<?php
foreach($user_info as $row)
{
    ?>
    <div class="information-title">
        <?php echo translate('profile_information');?>
    </div>
    
    <div class="details-wrap">
        <div class="row">
            <div class="col-md-12" style="margin-top: 0px!important;">
                <div class="tabs-wrapper content-tabs">
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a href="#tab1" data-toggle="tab">
                                <?php echo translate('personal_info');?>
                            </a>
                        </li>
                        <li>
                            <a href="#tab2" data-toggle="tab">
                                <?php echo translate('change_password');?>
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade in active" id="tab1">
                           <div class="details-wrap">
                            <div class="block-title alt" style=""> 
                                <i class="fa fa-angle-down"></i> 
                                <?php echo translate('change_your_profile_information');?>
                            </div>
                            <div class="details-box">
                                <?php
                                echo form_open(base_url() . 'home/registration/update_info/', array(
                                    'class' => 'form-login',
                                    'method' => 'post',
                                    'enctype' => 'multipart/form-data'
                                ));
                                ?>    
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                           <label><?php echo translate("Name"); ?></label>
                                           <input class="form-control" name="username" value="<?php echo $row['username']; ?>" type="text">
                                       </div>
                                   </div>
                                   <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo translate("Last Name"); ?></label>
                                        <input class="form-control" name="lastname" value="<?php echo $row['surname']; ?>" type="text">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label><?php echo translate("Email"); ?></label>
                                        <input class="form-control" name="email" value="<?php echo $row['email']; ?>" type="email">
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label><?php echo translate("Address"); ?></label>
                                        <input class="form-control" name="address1" value="<?php echo $row['address1']; ?>" type="text">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label><?php echo translate("Phone"); ?></label>
                                        <input class="form-control" name="phone" id="phone" value="<?php echo $row['phone']; ?>" type="tel">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                       <label><?php echo translate("Zip Code"); ?></label>
                                       <input class="form-control" name="zip" value="<?php echo $row['zip']; ?>" type="text" placeholder="<?php echo translate('Zip Code');?>">
                                   </div>
                               </div>
                               <div class="col-md-4">
                                <label><?php echo translate("Country"); ?></label>
                                <select class="form-control required customer_info_form_inputs" id="country" name="country">
                                    <option value=""><?php echo translate("-- Select Country --"); ?></option>
                                    <?php 
                                    $country_det = $this->crud_model->getCountryById($row['country']);
                                    $countries = $this->db->get("country")->result_array();
                                    foreach($countries as $country){
                                        $selected = "";
                                        if($country_det['country_id'] == $country['country_id']){
                                            $selected = "selected='selected' ";
                                        }
                                        ?>
                                        <option id="country" value="<?php echo $country['country_id']; ?>" <?php echo $selected; ?>><?php echo $country['country_name']; ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                   <label><?php echo translate("state"); ?></label>
                                   <select class="form-control required customer_info_form_inputs" id="country_state" name="state">
                                    <option value=""><?php echo translate("-- Select State --"); ?></option>
                                </select>
                            </div>
                            <div class="col-md-4">
                              <label><?php echo translate("city"); ?></label>
                              <select class="form-control required customer_info_form_inputs" id="city" name="city">
                                <option value=""><?php echo translate("-- Select City --"); ?></option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <span class="btn btn-info btn-lg pull-right signup_btn" data-unsuccessful='<?php echo translate('info_update_unsuccessful!'); ?>' data-success='<?php echo translate('info_updated_successfully!'); ?>' data-ing='<?php echo translate('updating..') ?>' >
                                <?php echo translate('update');?>
                            </span>
                        </div>
                    </div>
                </form>
            </div>
        </div>   
    </div>
    <div class="tab-pane fade" id="tab2">
        <div class="details-wrap">
            <div class="block-title alt" style="margin-bottom: 10px;"> <i class="fa fa-angle-down"></i> <?php echo translate('change_your_password');?></div>
            <div class="details-box">
                <?php
                echo form_open(base_url() . 'home/registration/update_password/', array(
                    'class' => 'form-delivery',
                    'method' => 'post',
                    'enctype' => 'multipart/form-data'
                ));
                ?> 
                <div class="row">
                    <div class="col-md-12 col-sm-12">
                        <div class="form-group">
                            <label><?php echo translate("old_password"); ?></label>
                            <input required name="password" type="password" class="form-control"></div>
                        </div>
                        <div class="col-md-6 col-sm-6">
                            <div class="form-group">
                                <label><?php echo translate("new_password"); ?></label>
                                <input required name="password1" type="password"  class="form-control"></div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="form-group">
                                    <label><?php echo translate("confirm_new_password"); ?></label>
                                    <input required name="password2" type="password" class="form-control"></div>
                                </div>
                                <div class="col-md-12 col-sm-12">
                                    <span class="btn btn-info btn-lg pull-right signup_btn" data-unsuccessful='<?php echo translate('password_change_unsuccessful!'); ?>' data-success='<?php echo translate('password_changed_successfully!'); ?>' data-ing='<?php echo translate('updating..') ?>' >
                                        <?php echo translate('update');?> 
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>  
<?php $state_del = $this->crud_model->getStateById($row['state']);?>
<?php $city_del = $this->crud_model->getCityById($row['city']); ?>
<script type="text/javascript">
    $(document).ready(function(){
        $("#country").change(function(){
            var  country_id = $(this).val();
            // console.log(country_id);
            if(country_id!=""){
                var data = {
                    country_id: country_id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
                };
                $.ajax({
                    url : '<?php echo base_url('home/get_state_by_country_id'); ?>',
                    type : 'POST',
                    data : data,
                    success : function(response){
                        var converted = JSON.parse(response);
                        // console.log(converted);
                        if(converted.status == "1"){
                            var state_opt = "";
                            $.each(converted.data,function(ind , val){
                                if(val.state_id=='<?php echo $state_del['state_id']; ?>'){
                                    state_opt +="<option value='"+val.state_id+"' selected='selected'>"+val.state_name+"</option>";
                                }else{
                                    state_opt +="<option value='"+val.state_id+"'>"+val.state_name+"</option>";
                                } 
                            });
                            console.log(state_opt);
                            $("#country_state").html(state_opt);
                            $("#country_state").trigger('change');                            
                        }else{
                            $('#country_state').html(`<option value=""><?php echo translate("-- Select State --"); ?></option>`);
                            $("#city").html("<option value=''>-- Select City --</option>");
                        }
                    }   
                });
            }else{
                $("#country_state").html("<option value=''>-- Select --</option>");
                $("#city").html("<option value=''>-- Select --</option>");
                $(".overlay_holder1").hide();
            }
        });
        var country = $('#country').val();
        var state = $("#state").val();

        if(country!=""){
            $("#country").trigger('change');
        }

        $("#country_state").change(function(){
            var  state_id = $(this).val();
            if(state_id!=""){
                var data = {
                    state_id: state_id,
                    '<?php echo $this->security->get_csrf_token_name(); ?>':'<?php echo $this->security->get_csrf_hash(); ?>',
                };
                $.ajax({
                    url : '<?php echo base_url('home/get_city_by_state_id'); ?>',
                    type : 'POST',
                    data : data,
                    success : function(response){
                           //console.log(response);
                           var converted = JSON.parse(response);
                            if(converted.status == "1"){
                               var city_opt = "";
                                $.each(converted.data,function(ind , val){
                                    if(val.city_id == '<?php echo $city_del['city_id']; ?>'){
                                        city_opt +="<option value='"+val.city_id+"' selected='selected'>"+val.city_name+"</option>";   
                                    }else{
                                        city_opt +="<option value='"+val.city_id+"'>"+val.city_name+"</option>";   
                                    }
                                });
                               $("#city").html(city_opt);
                            }
                            else{
                                $("#city").html("<option value=''>-- Select --</option>");
                            }
                       }
                   });
            }else{
                $("#city").html("<option value=''>-- Select --</option>");
            }
        });

        $('#phone').keyup(function(e){
            var isValid = false;
            var regex = /^[0-9-+()]*$/;
            isValid = regex.test($("#phone").val());
            if(isValid == false){
                $('#phone').val('');   
            }
        });
    });
</script>
<?php
}
?>

