<?php if(!empty($section_data)){ foreach ($section_data as $key => $value) {?>
<style>
.special-section .img-preview {
 border: none;
 padding: 0px;
 border-radius: 0px;
 width: fit-content;
}

.margin-top-0 {
 margin-top: 0px !important;
}

.overflow-hidden {
 overflow: hidden !important;
}
</style>
<section class="page-section with-sidebar">
 <div class="container">
  <div class="row margin-top-0">
   <?php if(!empty($value->top_banner)) {?>
   <style>
   .page-section {
    padding-top: 0px !important;
   }
   </style>
   <div class="col-md-12 text-center margin-top-0 overflow-hidden special-section">
    <img class="img-thumbnail img-preview top_banner"
     src=<?php echo base_url('uploads/special_sections/top_banner/' . $value->top_banner);  ?>>
   </div>
   <?php }?>
   <div class="col-md-12 col-sm-12 col-xs-12 content" id="content">
    <div id="result" style="min-height:300px;">
     <?php 
 	$viewtype = "grid";
 ?>
     <style type="text/css">
     .no_data_available {
      display: none;
      font-size: 16px;
     }

     .row_product_list .pd {
      padding: 0px 8px 0 0px !important;
      margin-top: 15px !important;
     }
     </style>
     <?php $box_style =  $this->db->get_where('ui_settings',array('ui_settings_id' => 42))->row()->value; ?>
     <div class="row products <?php echo $viewtype; ?> row_product_list">
      <?php
    	if($viewtype == 'list'){
			$col_md = 'col-md-12';
			$col_sm = 'col-sm-12';
			$col_xs = 'col-xs-12';
		} elseif($viewtype == 'grid'){
			$col_md = 'col-md-4';
			$col_sm = 'col-sm-6';
			$col_xs = 'col-xs-6';
		}
    if(count($all_products)){
        foreach ($all_products as $row) {
    ?>
      <div class="pd <?= $col_xs.' '.$col_sm.' '.$col_md; ?>" data-aos="flip-left" data-aos-mirror="true"
       data-aos-duration="1000" data-aos-once="true" style="margin-top: 5px !important;">
       <?php echo $this->html_model->product_box($row, $viewtype, $box_style); ?>
      </div>
      <?php
        }
    }else{
    ?>
      <div class="col-md-12 text-center">
       <img src="<?php echo base_url("uploads/others/no_product_found.jpg"); ?>" class="img-responsive"
        style="display: inline-block; ">
      </div>
      <?php } ?>
     </div>
     <!-- /Pagination -->
     <script>
     $(document).ready(function() {
      <?php if(count($all_products)>0){ ?>
      var offset = <?= PRODUCT_LIMIT ?>;
      var getHit = true;
      $(window).scroll(function() {
       var sctop = ($(document).scrollTop());
       var initHeight = ($(document).height());
       if (initHeight > 300 && getHit == true) {
        getHit = false;
        $("#product_loader").show();
        var ajax_product_data = {
         col: 4,
         offset: offset,
         speciality: 'allProducts',
         third_sub_category_id: '<?php echo $value->third_sub_category ?>',
         discount: '<?php echo $value->discount ?>',
        };
        $.ajax({
         type: "POST",
         url: '<?= base_url("home/ajax_special_section")?>',
         data: ajax_product_data,
         cache: false,
         success: function(data) {
          getHit = true;
          $('.row_product_list').append(data);
          offset += <?= PRODUCT_LIMIT ?>;
         }
        });
       }
      });
      <?php } ?>
      $('[data-toggle="tooltip"]').tooltip();
     });
     </script>
    </div>
   </div>
  </div>
 </div>
</section>
<?php }?>
<?php }?>