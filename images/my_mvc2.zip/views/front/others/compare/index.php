<?php //echo "<pre>";print_r($compare_data);die();?>
<style type="text/css">
    .compare_table
    {
        animation-duration: 2s;
   /*     margin-top: 5%;*/
    }
    .compare_table tr th{
        padding: 10px;
        font-size: 15px;
        vertical-align: middle;
    }
     .compare_table tr td{
        padding: 8px;
        vertical-align: middle;
        font-size: 14px;
    }
    .compare_data_title{
        font-size: 20px;
    }   
    .compare_imgs{
        max-height: 100px;
        height: 100%;
    }
    .reset_compare,
    .compare_back_to_home
    {
        font-size: 18px;
    }
</style>
<section class="page-section color">
    <div class="container">
            <div class="row">
                <div class="col-md-12">
                	<div class="row">
                        <div class="col-md-6 pull-right">
                            <a class="btn-u btn-u-dark btn-labeled fa fa-repeat pull-right reset_compare" href="<?php echo base_url(); ?>home/compare/clear">
                                <?php echo translate('reset_compare_list'); ?>
                            </a>
                        </div>
                        <div class="col-md-6 pull-left">
                            <a class="btn-u btn-u-blue btn-labeled fa fa-chevron-circle-left pull-left compare_back_to_home" href="<?php echo base_url();?>">
                                <?php echo translate('back_to_home'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div><br>
            <table class="table table-striped table-bordered table-hover compare_table">
                <tbody>
                    <tr >
                        <th><?php echo translate('name');?></th>  
                        <?php 
                            foreach($compare_data as $data){
                        ?>
                        <td><?php echo $data['title'];  ?></td>
                        <?php
                            }
                        ?>
                    </tr>                                           
                    <tr>
                        <th><?php echo translate('image');?></th>  
                        <?php 
                            foreach($compare_data as $data){
                        ?>
                        <td>
                            <?php   
                                $images = json_decode($data['images'] , true);
                                $image = $images[0];
                            ?>
                            <img src="<?php echo $this->crud_model->get_image("product_variants",$image); ?>" class="img-responsive img-thumbnail compare_imgs">
                           <?php
                                }
                            ?>
                         </td>
                    </tr>
                    <tr>
                        <th><?php echo translate('price');?></th>  
                        <?php 
                            foreach($compare_data as $data){
                        ?>
                        <td><?php echo currency($data['selling_price']);  ?></td>
                        <?php
                            }
                        ?>
                    </tr>
                    <tr>
                        <th><?php echo translate('Weight');?></th>  
                       <?php 
                            foreach($compare_data as $data){
                        ?>
                        <td><?php echo $data['weight'];  ?></td>
                        <?php
                            }
                        ?>
                    </tr>
                    <tr>
                        <th><?php echo translate('actual_size');?></th>  
                       <?php 
                            foreach($compare_data as $data){
                        ?>
                        <td><?php echo $data['actual_size'];  ?></td>
                        <?php
                            }
                        ?>
                    </tr>
                    <tr>
                        <th><?php echo translate('shape');?></th>  
                       <?php 
                            foreach($compare_data as $data){
                        ?>
                        <td><?php echo $data['shape'];  ?></td>
                        <?php
                            }
                        ?>
                    </tr>
                </tbody>
            </table>
        </div>
   
</section>
<!-- /PAGE -->

<script>
$(document).ready(function(){
    $(".compare_table").addClass("animated bounceInLeft");
});

$('.searcher').on('change',function(){
	var cat = $(this).closest('table').data('cat');
	var col = $(this).data('col');
	var pro = $(this).val();
	$.getJSON("<?php echo base_url(); ?>home/compare/get_detail/"+pro,
		function(result){
			$.each(result, function(i, field){
				$('.colm_'+cat+'_'+col+'_'+i).html(field);
			});
		}
	);
});
</script>
<?php
echo form_open(base_url() . 'home/compare/add', array(
'method' => 'post',
'id' => 'plistform',
'enctype' => 'multipart/form-data'
));
?>
<input type="hidden" name="category" id="categoryaa">
<input type="hidden" name="sub_category" id="sub_categoryaa">
<input type="hidden" name="featured" id="featuredaa">
<input type="hidden" name="range" id="rangeaa">
<input type="hidden" name="vendor" id="vendora">
</form>
<style>
.sub_cat{
	padding-left:30px !important;
}
.compared_category{
    position: relative;
    display: inline-block;
    width: 100%;
    text-align-last: center;
    background: #3c3b6e;
    color: #fff;
    font-size: 20px;
    font-weight: 600;
    margin-top: 15px;
    padding: 5px 0;
}
</style>
