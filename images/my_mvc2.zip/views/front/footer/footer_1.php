<?php
$contact_address = $this->db->get_where('general_settings', array('type' => 'contact_address'))->row()->value;
$contact_phone = $this->db->get_where('general_settings', array('type' => 'contact_phone'))->row()->value;
$contact_email = $this->db->get_where('general_settings', array('type' => 'contact_email'))->row()->value;
$contact_website = $this->db->get_where('general_settings', array('type' => 'contact_website'))->row()->value;
$contact_about = $this->db->get_where('general_settings', array('type' => 'contact_about'))->row()->value;

$facebook = $this->db->get_where('social_links', array('type' => 'facebook'))->row()->value;
$googleplus = isset($this->db->get_where('social_links', array('type' => 'google-plus'))->row()->value) ? $this->db->get_where('social_links', array('type' => 'google-plus'))->row()->value : "";
$twitter = $this->db->get_where('social_links', array('type' => 'twitter'))->row()->value;
$skype = $this->db->get_where('social_links', array('type' => 'skype'))->row()->value;
$youtube = $this->db->get_where('social_links', array('type' => 'youtube'))->row()->value;
$pinterest = isset($this->db->get_where('social_links', array('type' => 'pinterest'))->row()->value) ? $this->db->get_where('social_links', array('type' => 'pinterest'))->row()->value : "";
$instagram = $this->db->get_where('social_links', array('type' => 'instagram'))->row()->value;
$tiktok = $this->db->get_where('social_links', array('type' => 'tiktok'))->row()->value;
$footer_text = $this->db->get_where('general_settings', array('type' => 'footer_text'))->row()->value;
$footer_category = json_decode($this->db->get_where('general_settings', array('type' => 'footer_category'))->row()->value);
?>
<style>
.under_log_txt {
  font-size: 16px;
  color: white;
  margin-top: 15px;
}

.link:hover {
  text-decoration: underline;
}

.model-2 a {
  margin: 0px 1px;
  height: 32px;
  width: 32px;
  line-height: 32px;
}

.footer1 {
  background-color: #242424 !important;
}

.footer-bottom {
  background-color: #1f1d1e;
}

@media only screen and (max-width: 768px) {
  .footer-bottom {
  width: 100%;
}
}
</style>
<footer class="footer1">
  <div class="" style="padding-bottom: 0px;">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-sm col-xs-12" style="margin-top: 0px;">
          <div class="widget">
            <a href="<?php echo base_url(); ?>">
              <img class="img-responsive" src="<?php echo base_url() ?>uploads/logo_image/logo_83_white.png" alt="">

            </a>
            <p>
              <?php echo $footer_text; ?>
            </p>

          </div>
        </div>
        <div class="col-md-2 hidden-xs hidden-sm" style="margin-top: 0px;">
          <div class="widget widget-categories">
            <h4 class="widget-title">
              <?php echo translate('categories'); ?>
            </h4>
            <ul>
              <li>
                <?php
                $this->db->limit(4);
                $this->db->order_by('category_id asc', 'rand()', NULL);
                $categories = $this->db->get("category");
                foreach ($categories->result_array() as $key => $row2) {
                  echo "<a href='" . base_url('home/category?category=' . $row2['category_id']) . "'>";
                  echo $row2['category_name'];
                  echo "</a>";
                }
                ?>
              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-2  col-sm-12 hidden-xs" style="margin-top: 0px;">
          <div class="widget widget-categories">
            <h4 class="widget-title">
              <?php echo translate('customer_services'); ?>
            </h4>
            <ul>
              <li>

                <a href="<?php echo base_url(); ?>home/legal/terms_conditions" class="link">
                  <?php echo translate('terms_&_condition'); ?>
                </a>
                <a href="<?php echo base_url(); ?>home/legal/privacy_policy" class="link">
                  <?php echo translate('privacy_policy'); ?>
                </a>
                <a href="<?php echo base_url(); ?>home/legal/return_shipping_policy" class="link">
                  <?php echo translate('return_shipping_policy'); ?>
                </a>

              </li>
            </ul>
          </div>
        </div>
        <div class="col-md-2 hidden-xs hidden-sm" style="margin-top: 0px;">
          <div class="widget widget-categories">
            <h4 class="widget-title">
              <?php echo 'contact Bemartly'; ?>
            </h4>
            <ul>
              <li>
                <a href="#" class="link"> info@bemartly.com </a>
              </li>
              <li class="hover_link" style="border: 0px solid;">
                <a href="<?php echo base_url(); ?>home/contact" class="link">
                  <?php echo translate('contact us'); ?>
                </a>
              </li>
            </ul>


            <!-- 								<div class="social-nav model-2" style="font-size: 30px; float: none; margin-top:10px; ">
                  <ul>
                    <li style="border-top: none;"><a href="https://www.facebook.com/" class="facebook social_a"><i class="fa fa-facebook"></i></a></li>
                                  <li style="border-top: none;"><a href="https://twitter.com/" class="twitter social_a"><i class="fa fa-twitter"></i></a></li>
                                   <li style="border-top: none;"><a href="https://www.linkedin.com/" class="linkedin social_a"><i class="fa fa-linkedin"></i></a></li>
                                   <li style="border-top: none;"><a href="https://www.youtube.com/" class="youtube social_a"><i class="fa fa-youtube"></i></a></li>
                                   <li style="border-top: none;"><a href="https://www.instagram.com/" class="instagram social_a"><i class="fa fa-instagram"></i></a></li>
                    
                  </ul>
                </div> -->

          </div>
        </div>
        <div class="col-md-3 hidden-xs hidden-sm" style="margin-top: 0px;">
          <div class="widget subscribe">
            <h4 class="widget-title">
              <?php echo translate('SIGN UP FOR NEWSLETTER'); ?>
            </h4>
            <div class="media-list">
              <div class="media">
                <p>Subscribe Our newsletter to recieve the latest news and exclusive offers.</p>
                <?php
                echo form_open(base_url() . 'home/subscribe', array(
                  'class' => '',
                  'method' => 'post'
                ));
                ?>
                <div class="form-group row">
                  <div class="col-md-12 d-flex align-items-center">
                    <div>
                      <input type="text" class="form-control col-md-8" name="email" id="subscr"
                        placeholder="<?php echo translate('email_address'); ?>">
                    </div>
                    <div>
                      <span class="btn btn-subcribe subscriber enterer "
                        style="background-color: #f3402d; padding: 9px 15px;">
                        <?php echo translate('subscribe'); ?>
                      </span>
                    </div>
                  </div>
                </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer1-meta">
    <div class="container-fluid">
      <div class="row" style="display: flex; align-items: center;">
        <div class="col-md-12 footer-bottom" style="margin-top: 0px; padding: 15px 50px;">
          <div class="col-md-6 col-xs-12" style="margin-top: 0px;">
            <div class="copyright">
              <?php echo date('Y'); ?>
              <?php echo "Bemartly"; ?> &copy;
              <?php echo translate('all_rights_reserved'); ?>
              <!-- 	| 
              <a href="<?php echo base_url(); ?>home/legal/terms_conditions" class="link">
                <?php echo translate('terms_&_condition'); ?>
              </a> 
                | 
              <a href="<?php echo base_url(); ?>home/legal/privacy_policy" class="link">
                <?php echo translate('privacy_policy'); ?>
              </a>
                | 
              <a href="<?php echo base_url(); ?>home/legal/return_shipping_policy" class="link">
                <?php echo translate('return_shipping_policy'); ?>
              </a> -->
            </div>
          </div>
          <div class="col-md-3" style="margin-top: 0px;">
            <div class="social-nav model-2 payments" style="font-size: 30px;">
              <ul>
                <li style="border-top: none;"><a href="<?php echo $facebook; ?>" class="facebook social_a"
                    target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                <li style="border-top: none;"><a href="<?php echo $twitter; ?>" class="twitter social_a"
                    target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                <li style="border-top: none;"><a href="<?php echo $youtube; ?>" class="youtube social_a"
                    target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                <li style="border-top: none;"><a href="<?php echo $instagram; ?>" class="instagram social_a"
                    target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                <li style="border-top: none;"><a href="<?php echo $tiktok; ?>" class="tiktok social_a"
                    target="_blank"><i class="fa-brands fa-tiktok"></i></a></li>
              </ul>
            </div>
          </div>
          <!-- <div class="col-md-3 hidden-xs hidden-sm" style="margin-top: 0px;"> 
            <div class="social-nav model-2 payments" style="font-size: 30px;">
              <ul>
                <li><img src="<?php echo base_url(); ?>uploads/payment_img/payment_card_img.png"></li>
              </ul>
            </div>
          </div> -->
        </div>
      </div>
    </div>
  </div>
</footer>

<style type="text/css">
.hover_link:hover {
  text-decoration-line: underline;
}
</style>