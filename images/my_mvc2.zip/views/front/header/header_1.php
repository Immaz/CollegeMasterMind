<?php
$is_user_logged = isset($_SESSION['user_login']) && ($_SESSION['user_login'] == 'yes') ? true : false;
$logged_user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : "";
$this->db->select("c.category_id, c.category_name , sc.sub_category_id, sc.sub_category_name , tsc.third_sub_ctg_name, tsc.third_sub_category_id , sc.brand as sc_brand, tsc.brand as tsc_brand");
$this->db->from("category c");
$this->db->join("sub_category sc", "sc.category = c.category_id", "left");
$this->db->join("third_sub_category tsc", "tsc.category = c.category_id and tsc.sub_category = sc.sub_category_id", "left");
$this->db->order_by("c.category_name", "asc");
$q = $this->db->get();


$this->db->select("*");
$this->db->from("user");
$this->db->where("user_id", $logged_user_id);
$this->db->limit(1);
$logged_user_data = $this->db->get()->row();

$this->db->select("*");
$this->db->from("vendor");
$this->db->where("user_id", $logged_user_id);
$this->db->limit(1);
$logged_vendor_data = $this->db->get()->row();

$final = array();
foreach ($q->result() as $row) {
  $final[$row->category_id . "@@" . $row->category_name]['category_name'] = $row->category_name;
  $final[$row->category_id . "@@" . $row->category_name]['category_id'] = $row->category_id;

  if ($row->sub_category_id != "" && $row->sub_category_id != NULL) {

    $final[$row->category_id . "@@" . $row->category_name]['sub_categories'][$row->sub_category_id . "@@" . $row->sub_category_name]['sub_category_name'] = $row->sub_category_name;
    $final[$row->category_id . "@@" . $row->category_name]['sub_categories'][$row->sub_category_id . "@@" . $row->sub_category_name]['sub_category_id'] = $row->sub_category_id;
    $sc_brand_arr = json_decode($row->sc_brand, true);

    if (count($sc_brand_arr) > 0) {
      $this->db->where_in("brand_id", $sc_brand_arr);
      $this->db->limit(10);
      $q = $this->db->get("brand");
      $brands = $q->result_array();
      $final[$row->category_id . "@@" . $row->category_name]['sub_categories'][$row->sub_category_id . "@@" . $row->sub_category_name]['brand'] = $brands;
    }

  }

  if (count($sc_brand_arr) == 0) {

    $tsc_brand_arr = ($row->tsc_brand) ? json_decode($row->tsc_brand, true) : null;
    if ($row->third_sub_category_id != "" && $row->third_sub_category_id != NULL) {

      $final[$row->category_id . "@@" . $row->category_name]['sub_categories'][$row->sub_category_id . "@@" . $row->sub_category_name]['third_sub_categories'][$row->third_sub_category_id . "@@" . $row->third_sub_ctg_name]["third_sub_ctg_name"] = $row->third_sub_ctg_name;

      $final[$row->category_id . "@@" . $row->category_name]['sub_categories'][$row->sub_category_id . "@@" . $row->sub_category_name]['third_sub_categories'][$row->third_sub_category_id . "@@" . $row->third_sub_ctg_name]["third_sub_category_id"] = $row->third_sub_category_id;

      if (count($tsc_brand_arr) > 0) {
        $this->db->where_in("brand_id", $tsc_brand_arr);
        $this->db->limit(10);
        $q = $this->db->get("brand");
        $brands = $q->result_array();

        $final[$row->category_id . "@@" . $row->category_name]['sub_categories'][$row->sub_category_id . "@@" . $row->sub_category_name]['third_sub_categories'][$row->third_sub_category_id . "@@" . $row->third_sub_ctg_name]['brand'] = $brands;
      }
    }
  }
}
// echo "<pre>";print_r($final);
?>
<style type="text/css">
:root {
  --main-color: #f3402d;
}

.suggestion-box {
  background-color: white;
  width: 69.5%;
  z-index: 99999999;
  height: 193px;
  position: absolute;
  border: 1px solid var(--main-color);
  border-top: none;
  overflow: auto;
  display: none;
}

.suggestion-box-child {
  padding: 2% 2%;
  border-bottom: 1px solid var(--main-color);
  font-size: small;
  font-family: inherit;
  cursor: pointer;
}

.suggestion-box-child:hover {
  background: #cccccc;
}

#ui-id-1 {
  z-index: 9999999;
}

.toggle-side-bar {
  /*width: 250px;*/
  left: 0% !important;
}

#mySidenav {
  width: 250px;
  padding: 0px;
  left: -76%;
  z-index: 99999;
}

.sidebar_heading_cont {
  display: flex;
  align-items: center;
}

#mySidenav ul li {
  padding: 0px;
  background-color: transparent;
  transition-delay: 0.5s;
}

#mySidenav ul {
  margin-bottom: 0px;
}

.home_sidebar_nav li {
  border: 0px solid;
}

#mySidenav ul li a {
  font-size: 12px;
  color: #fff;
  font-weight: 500;
}

.sidebar_heading {
  color: #ffffff;
  padding: 0px 16px;
  font-size: 16px;
  text-transform: uppercase;
  font-weight: 700;
}

#mySidenav ul li a:hover {
  background-color: #25d3c9;
  transition-delay: 0.2s;
  cursor: pointer;
}

#mySidenav ul li a {
  border-bottom: 1px solid #717171;
}

.divider {
  border-bottom: 1px solid #ccc;
}

.multilevel_nav ul,
.multilevel_nav {
  border: 1px solid red;
}

.multilevel_nav li:hover {
  color: red;
  font-size: 15px;
  transition-delay: 0.5s;
}

.sf-menu li {
  padding: 4px;
}

.side-menu {
  font-size: 23px;
  cursor: pointer;
  position: absolute;
  display: inline-block;
  margin: -5% 0 0 20.7%;
  /*border: 1px solid var(--main-color);*/
  border-radius: 5px;
  padding: 0px 7px 0px 7px;
  color: #3c3b6e;
}

.subheader {
  background-color: #242424;
  height: fit-content;
  font-size: 16px;
  color: white;
}

.subheader-container {
  display: flex;
  justify-content: start;
  align-items: center;
}

.sh-boxes {
  padding: 8px 15px;
  margin: 0 10px;
}

.subheader .all_category {
  width: 20%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.sub_category_menu li a span {
  margin-left: 20px;
}

.third_category_menu li a span {
  margin-left: 40px;
}

.sub_category_menu ul,
.third_category_menu ul {
  list-style: circle;
}

.fa_sidebar {
  font-size: 12px;
  color: var(--main-color);
  font-weight: 900;
  margin-right: 5px;
}

.shrc_btn {
  font-family: 'roboto', 'droid' !important;
  background-color: #f3402d !important;

}

.nested_menu a {
  padding-left: 20px;
}

.row_term_cond_policy {
  display: flex;
  align-items: center;
}

.sidebar_privacy_policy {
  /*position: absolute;
        bottom: 0%;
        left: 0;
        right: 0;*/
}

.sidebar_privacy_policy li a {
  font-size: 12px !important;
}

.sidebar_privacy_policy li {
  font-size: 12px !important;
  border-bottom: 1px solid #656565;
}

.sidebar_privacy_policy li:last-child {
  border-bottom: 0px solid;
}

.sidebar_show_chevron {
  font-size: 12px;
  float: right;
  line-height: 2.5;
}

.home_sidebar_nav ul {
  display: none;
}

.home_sidebar_nav {
  min-height: 75%;
}

.home_sidebar_nav li:hover>a>i {
  display: block;
}

.cart_num {
  position: absolute;
  top: -15px;
  /*color: white !important;*/
  /*top: -7px;*/
  left: 16.25px;
  /*left: 10px;*/
  font-size: 10px;
  font-size: 14px;
  font-weight: 900;
}

.btn_show_cart {
  position: relative;
}

.btn_header_compare {
  margin-right: 20px;
}

.sidebar_li_holder {
  display: flex;
  align-items: center;
}

.sidebar_li_holder .sidbar_li_href {
  width: 90%;
}

.sidebar_fa_fa_plane_link {
  float: right;
}



.mega_nav_category_label,
.mega_nav_sub_category_label,
.mega_nav_third_sub_category_label,
.mega_nav_third_sub_category_brand_label {
  padding: 6px 18px;
  font-size: 18px;
  font-weight: bold;
  text-decoration: underline;
}

.mega_nav_third_sub_category_brand_label {
  color: #3c3b6e;
}

.mega_nav_sub_category_label,
.mega_nav_third_sub_category_label {
  font-size: 16px;
}

.mega_nav_category_label:hover,
.mega_nav_sub_category_label:hover,
.mega_nav_third_sub_category_label:hover {
  border: 0px solid !important;
}

.font_color {
  color: white !important;
}

.bg_color {
  background-color: #ccc;
}

.show {
  display: block;
}

.fa_fa_left_mega_menu {
  font-size: 8px;
  /* color: var(--main-color); */
  float: left;
  line-height: 3.5;
}

.brand_hover_bg {
  color: white !important;
  background-color: #3c3b6e;
}

.top-contact {
  float: right;
}

.top-contact a:nth-child(2) {
  margin-left: 10px;
}

.header-cart .top-bar-right ul {
  margin-bottom: 0px;
}
</style>
<!-- Header top bar -->
<div class="top-bar">
  <div class="container">
    <div class="top-bar-left">
      <ul class="list-inline">
        <!-- <li class="dropdown flags">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <?php
                        if ($set_lang = $this->session->userdata('language')) {
                        } else {
                          $set_lang = $this->db->get_where('general_settings', array('type' => 'language'))->row()->value;
                        }
                        $lid = $this->db->get_where('language_list', array('db_field' => $set_lang))->row()->language_list_id;
                        $lnm = $this->db->get_where('language_list', array('db_field' => $set_lang))->row()->name;
                        ?>
                        <img src="<?php echo $this->crud_model->file_view('language_list', $lid, '', '', 'no', 'src', '', '', '.jpg') ?>" width="20px;" alt=""/> <span class="hidden-xs"><?php echo $lnm; ?></span><i class="fa fa-angle-down"></i></a>
                        <ul role="menu" class="dropdown-menu">
                            <?php
                            $langs = $this->db->get_where('language_list', array('status' => 'ok'))->result_array();
                            foreach ($langs as $row) {
                              ?>
                                <li <?php if ($set_lang == $row['db_field']) { ?>class="active"<?php } ?> >
                                    <a class="set_langs" data-href="<?php echo base_url(); ?>home/set_language/<?php echo $row['db_field']; ?>">
                                        <img src="<?php echo $this->crud_model->file_view('language_list', $row['language_list_id'], '', '', 'no', 'src', '', '', '.jpg') ?>" width="20px;" alt=""/>
                                        <?php echo $row['name']; ?>
                                        <?php if ($set_lang == $row['db_field']) { ?>
                                            <i class="fa fa-check"></i>
                                        <?php } ?>
                                    </a>
                                </li>
                            <?php
                            break;
                            }
                            ?>
                    </ul>
                </li> -->
        <li class="dropdown flags">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <?php
            if ($this->session->userdata('currency')) {
              $currency_id = $this->session->userdata('currency');
            } else {
              $currency_id = $this->db->get_where('business_settings', array('type' => 'currency'))->row()->value;
            }
            $symbol = $this->db->get_where('currency_settings', array('currency_settings_id' => $currency_id))->row()->symbol;
            $c_name = $this->db->get_where('currency_settings', array('currency_settings_id' => $currency_id))->row()->name;
            ?>
            <span class="hidden-xs">
              <?php echo $c_name; ?>
            </span>
            <?php $symbol; ?>
            <i class="fa fa-angle-down"></i>
          </a>
          <ul role="menu" class="dropdown-menu">
            <?php
            $currencies = $this->db->get_where('currency_settings', array('status' => 'ok'))->result_array();
            foreach ($currencies as $row) {
              ?>
            <li <?= ($currency_id == $row['currency_settings_id']) ? 'class="active"' : ''; ?>> <a class="set_langs"
                data-href="<?php echo base_url(); ?>home/set_currency/<?php echo $row['currency_settings_id']; ?>">
                <?php echo $row['name']; ?> (
                <?php echo $row['symbol']; ?>)
                <?php if ($currency_id == $row['currency_settings_id']) { ?>
                <i class=" fa fa-check"></i>
                <?php } ?>
              </a>
            </li>
            <?php
              break;
            }
            ?>
          </ul>
        </li>
      </ul>
    </div>
    <div class="top-contact">
      <?php if ($is_user_logged) { ?>

      <!-- Vendor id status
      
            0 -> not a vendor
            1 -> pending
            2 -> approved
    -->

      <?php if ($logged_user_data->vendor_id == "") { ?>
      <a href="<?php echo base_url(); ?>vendor/register">
        <span>
          <?php echo translate('Become a seller |'); ?>
        </span>
      </a>
      <?php } elseif ($logged_vendor_data->status == 'pending') { ?>
      <a href="#" style="">
        <span>
          <?php echo translate('Pending Approval |'); ?>
        </span>
      </a>
      <?php } elseif ($logged_vendor_data->status == 'approved') { ?>
      <a href="<?php echo base_url(); ?>vendor/index/1">
        <span>
          <?php echo translate('Login as Vendor |'); ?>
        </span>
      </a>
      <?php }
      } ?>
      <span class="login-res">
        <?php if ($this->session->userdata('user_login') != 'yes') { ?>
        <a href="<?php echo base_url(); ?>home/login_set/login">
          <span>
            <?php echo translate('Log In '); ?>
          </span>
        </a>
        /
        <a href="<?php echo base_url(); ?>home/login_set/registration">
          <span>
            <?php echo translate('Register'); ?>
          </span>
        </a>

        <?php } else { ?>
        <a href="<?php echo base_url(); ?>home/profile/">
          <span style="font-size: 17px;">Welcome</span>
          <span class="block-ellipsis">
            <?php echo ucfirst($this->session->userdata()['user_name']); ?>
          </span>
        </a>
        <?php } ?>
      </span>
      <a href="<?php echo base_url(); ?>home/contact">
        <span>
          <?php echo translate('contact_us'); ?>
        </span>
      </a>

      <?php if ($this->session->userdata('user_login') == 'yes') { ?>
      <a href="<?php echo base_url(); ?>home/logout/">
        <span>
          <?php echo translate('| logout'); ?>
        </span>
      </a>
      <?php } ?>
    </div>
  </div>
</div>
<!-- /Header top bar -->

<!-- HEADER -->
<header class="header header-logo-left fixed-header" id="header">
  <div class="header-wrapper" id="header">
    <div class="container">
      <!-- Logo -->
      <div class="logo">
        <?php
        $home_top_logo = $this->db->get_where('ui_settings', array('type' => 'home_top_logo'))->row()->value;
        ?>
        <a href="<?php echo base_url(); ?>">
          <img src="<?php echo base_url(); ?>uploads/logo_image/logo_<?php echo $home_top_logo; ?>.png"
            alt="Bemartly" />
        </a>
      </div>
      <!-- /Logo -->
      <div class="side-menu">
        <div class="cd-dropdown-wrapper">
          <a class="cd-dropdown-trigger">&#9776;</a>
        </div>
      </div>
      <nav class="cd-dropdown">
        <ul class="cd-dropdown-content">
          <li class="mega_nav_category_label">
            <?php echo translate("Shop By Category"); ?>
          </li>
          <?php
          foreach ($final as $key => $row2) {
            echo "<li>";
            echo "<a href='" . base_url('home/category?category=' . $row2['category_id']) . '&categories=' . $this->crud_model->infiltrate_unwated_character($row2['category_name']) . "'>";
            echo "<span class='fa_fa_left_mega_menu'></span>&nbsp;&nbsp;";
            echo ucwords($row2['category_name']);
            echo "</a>";
            if (isset($row2['sub_categories'])) {
              echo "<div class='sub_category_holder_div'>";
              echo "<ul class='cd-sub-dropdown'>";
              echo "<li class='mega_nav_sub_category_label'>" . ucwords($row2['category_name']) . "</li>";
              foreach ($row2['sub_categories'] as $key2 => $sub_category) {
                echo "<li>";
                echo "<a href='" . base_url('home/category?category=' . $row2['category_id'] . "&sub_category=" . $sub_category['sub_category_id']) . '&categories=' . $this->crud_model->infiltrate_unwated_character($row2['category_name']) . "/" . $this->crud_model->infiltrate_unwated_character($sub_category['sub_category_name']) . "'>";
                echo "<span class='fa_fa_left_mega_menu'></span>&nbsp;&nbsp;";
                echo ucwords($sub_category['sub_category_name']);
                echo "</a>";
                if (isset($sub_category['third_sub_categories'])) {
                  echo "<div class='third_category_holder_div'>";
                  echo "<ul class='cd-third-dropdown'>";
                  echo "<li class='mega_nav_third_sub_category_label'>" . ucwords($sub_category['sub_category_name']) . "</li>";
                  foreach ($sub_category['third_sub_categories'] as $key2 => $third_sub_category) {
                    echo "<li>";
                    echo "<a href='" . base_url('home/category?category=' . $row2['category_id'] . "&sub_category=" . $sub_category['sub_category_id'] . "&third_sub_category=" . $third_sub_category['third_sub_category_id']) . '&categories=' . $this->crud_model->infiltrate_unwated_character($row2['category_name']) . "/" . $this->crud_model->infiltrate_unwated_character($sub_category['sub_category_name']) . "/" . $this->crud_model->infiltrate_unwated_character($third_sub_category['third_sub_ctg_name']) . "'>";
                    echo "<span class='fa_fa_left_mega_menu'></span>&nbsp;&nbsp;";
                    echo ucwords($third_sub_category['third_sub_ctg_name']);

                    echo "</a>";
                    /* third sub category brands */
                    if (isset($third_sub_category['brand'])) {
                      echo "<div class='third_category_brand_holder_div'>";
                      echo "<ul class='cd-third-b-dropdown'>";
                      echo "<li class='mega_nav_third_sub_category_brand_label'>Top Brands</li>";
                      foreach ($third_sub_category['brand'] as $third_sub_category_brands) {
                        echo "<li>";
                        echo "<a href='" . base_url('home/category?category=' . $row2['category_id'] . "&sub_category=" . $sub_category['sub_category_id'] . "&third_sub_category=" . $third_sub_category['third_sub_category_id']) . "&brand=" . $third_sub_category_brands['brand_id'] . '&categories=' . $this->crud_model->infiltrate_unwated_character($row2['category_name']) . "/" . $this->crud_model->infiltrate_unwated_character($sub_category['sub_category_name']) . "/" . $this->crud_model->infiltrate_unwated_character($third_sub_category['third_sub_ctg_name']) . "'>";
                        echo ucwords($third_sub_category_brands['name']);
                        echo "</a>";
                        echo "</li>";
                      }
                      echo "</ul>";
                      echo "</div>";
                    }
                    /* third sub category brands */
                    echo "</li>";
                  }
                  echo "</ul>";
                  echo "</div>";
                }
                echo "</li>";
              }
              echo "</ul>";
              echo "</div>";
            }
            echo "</li>";
          }
          ?>
        </ul>
      </nav>
      <!-- Header search -->
      <div class="header-search">
        <?php
        echo form_open(base_url() . 'home/category', array(
          'method' => 'get',
          'accept-charset' => "UTF-8",
          'id' => 'top_product_search'
        ));
        ?>
        <input id="search-home" name="text" type="text" class="form-control" accept-charset="utf-8"
          placeholder="<?php echo translate('Search here for what you are looking for...'); ?>"
          style="border-radius: 2px; border: 1px solid #E5E5E5;"
          value="<?php echo (isset($_GET['text']) ? trim($_GET['text']) : ''); ?>" />

        <!--                     <select class="selectpicker header-search-select cat_select hidden-xs"data-live-search="true" name="category" data-toggle="tooltip" title="<?php echo translate('select'); ?>" id="category">
                        <option value=""><?php echo translate('all_categories'); ?></option>
                        <?php
                        $categories = $this->db->get('category')->result_array();
                        foreach ($categories as $row1) {
                          $selected = "";
                          if ($this->crud_model->if_publishable_category($row1['category_id'])) {
                            if (isset($_GET['category'])) {
                              if ($row1['category_id'] == $_GET['category']) {
                                $selected = "selected='selected'";
                              }
                            }
                            ?>
                        <option value="<?php echo $row1['category_id']; ?>" <?php echo $selected; ?>><?php echo $row1['category_name']; ?></option>
                        <?php
                          }
                        }
                        ?>
                    </select> -->
        <?php
        if ($this->crud_model->get_type_name_by_id('general_settings', '58', 'value') == 'ok') {
          ?>
        <!-- <select
                        class="selectpicker header-search-select" data-live-search="true" name="type" onchange="header_search_set(this.value);"
                        data-toggle="tooltip" title="<?php echo translate('select'); ?>">
                        <option value="product"><?php echo translate('product'); ?></option>               
                    </select> -->
        <?php
        }
        ?>
        <button class="shrc_btn" style="border: none;"><i class="fa-solid fa-magnifying-glass"></i>
        </button>
        </form>
      </div>
      <!-- /Header search -->

      <!-- Header shopping cart -->
      <div class="header-cart">
        <div class="top-bar-right">

          <!-- <?php //echo base_url().'home/top_bar_right';?> -->
        </div>
        <div class="cart-wrapper">
          <!-- <a href="<?php echo base_url(); ?>home/compare" class="btn btn-theme-transparent btn_header_compare" id="compare_tooltip" data-toggle="tooltip" data-original-title="<?php //echo $this->crud_model->compared_num(); ?>" data-placement="right" >
                        <i class="fa fa-exchange"></i>
                        <span class="hidden-sm hidden-xs"><?php echo translate('compare'); ?></span>
                        (
                        <span id="compare_num">
                            <?php //echo $this->crud_model->compared_num(); ?>
                        </span>
                        )
                    </a> -->
          <a href="#" class="btn_show_cart" data-toggle="modal" data-target="#popup-cart">
            <span class="cart_num badge" style="background: none!important; color: white !important"></span>
            <img src="<?php echo base_url("uploads/others/icon2.png"); ?>" width="45" class="header_img_cart">
          </a>
          <!-- Mobile menu toggle button -->
          <a href="#" class="menu-toggle btn btn-theme-transparent"><i class="fa fa-bars"></i></a>
          <!-- /Mobile menu toggle button -->
        </div>
      </div>
      <!-- Header shopping cart -->

    </div>
  </div>

</header>

<div class="subheader ">
  <div class="container subheader-container">
    <div style="background-color: #f3402d" class="all_category sh-boxes">

      <div style="margin: 0 10px;">All
        Categories</div>
        
      <div><i class="fa fa-angle-down"></i></div>
    </div>
    <div><i class="fa fa-bars subheader-bars"></i></div>
    <a class="sh-boxes sh-box-toggle" style="color: white;" href="<?= base_url(); ?>">Home</a>
    <a class="sh-boxes sh-box-toggle" style="color: white;" href="<?= base_url(); ?>home/category">Shop </a>
    <a class="sh-boxes sh-box-toggle" style="color: white;" href="<?= base_url(); ?>home/special_section/1">Discounted Items</a>
    <a class="sh-boxes sh-box-toggle" style="color: white;" href="<?= base_url(); ?>">Pages</a>
    <a class="sh-boxes sh-box-toggle" style="color: white;" href="<?= base_url(); ?>">Blogs</a>
  </div>
  
</div>



<!-- /HEADER -->
<!-- <div class="navigation-wrapper">
        <div class="container-floaid">
          
            <?php
            $others_list = $this->uri->segment(3);
            ?>
            <nav class="navigation closed clearfix">
                <a href="#" class="menu-toggle-close btn"><i class="fa fa-times"></i></a>
                <ul class="nav sf-menu">
                    <?php if ($this->db->get_where('ui_settings', array('type' => 'header_homepage_status'))->row()->value == 'yes') { ?>
                    <li <?php if ($asset_page == 'home') { ?>class="active"<?php } ?>>
                        <a href="<?php echo base_url(); ?>home">
                            <?php echo translate('home'); ?>
                        </a>
                    </li>
                    <?php }
                    if ($this->db->get_where('ui_settings', array('type' => 'header_all_categories_status'))->row()->value == 'yes') { ?>
                    <?php } ?>
                    <li class="hidden-lg hidden-md <?php if ($asset_page == 'all_category') {
                      echo 'active';
                    } ?>">
                        <a href="#">
                            <?php echo translate('all_categories'); ?>
                        </a>
                        <ul>
                            <?php
                            $all_category = $this->db->get('category')->result_array();
                            foreach ($all_category as $row) {
                              if ($this->crud_model->if_publishable_category($row['category_id'])) {
                                ?>
                            <li>
                                <a href="<?php echo base_url(); ?>home/category/<?php echo $row['category_id']; ?>">
                                    <?php echo $row['category_name']; ?>
                                </a>
                            </li>
                            <?php
                              }
                            }
                            ?>
                        </ul>
                    </li>
                    <li class="hidden-lg hidden-md <?php if ($asset_page == 'all_category') {
                      echo 'active';
                    } ?>">
                        <a href="<?php echo base_url(); ?>home/all_category">
                            <?php echo translate('all_sub_categories'); ?>
                        </a>
                    </li>
                    <?php if ($this->db->get_where('ui_settings', array('type' => 'header_featured_products_status'))->row()->value == 'yes') { ?>
                    <li class="<?php if ($others_list == 'featured') {
                      echo 'active';
                    } ?>">
                        <a href="<?php echo base_url(); ?>home/others_product/featured">
                            <?php echo translate('featured_products'); ?>
                        </a>
                    </li>
                    <?php }
                    if ($this->db->get_where('ui_settings', array('type' => 'header_todays_deal_status'))->row()->value == 'yes') { ?>
                    <li class="<?php if ($others_list == 'todays_deal') {
                      echo 'active';
                    } ?>">
                        <a href="<?php echo base_url(); ?>home/others_product/todays_deal">
                            <?php echo translate('todays_deal'); ?>
                        </a>
                    </li>
                    <?php } ?>
                    <?php if ($this->crud_model->get_type_name_by_id('general_settings', '82', 'value') == 'ok') {
                      if ($this->db->get_where('ui_settings', array('type' => 'header_bundled_product_status'))->row()->value == 'yes') { ?>
                    <li <?php if ($page_name == 'bundled_product') { ?>class="active"<?php } ?>>
                        <a href="<?php echo base_url(); ?>home/bundled_product">
                            <?php echo translate('bundled_product'); ?>
                        </a>
                    </li>
                     <?php }
                    } ?>
                    <?php if (0) {
                      if (1) { ?>
                    <li <?php if ($page_name == 'customer_product_bulk_upload') { ?>class="active"<?php } ?>>
                        <a href="<?php echo base_url(); ?>home/customer_product_bulk_upload">
                            <?php echo translate('Bulk upload'); ?>
                        </a>
                    </li>
                    <?php }
                    }
                    if ($this->crud_model->get_type_name_by_id('general_settings', '83', 'value') == 'ok') {
                      if ($this->db->get_where('ui_settings', array('type' => 'header_classifieds_status'))->row()->value == 'yes') { ?>
                    <li <?php if ($page_name == 'customer_products') { ?>class="active"<?php } ?>>
                        <a href="<?php echo base_url(); ?>home/customer_products">
                            <?php echo translate('classifieds'); ?>
                        </a>
                    </li>
                    <?php }
                    }
                    if ($this->crud_model->get_type_name_by_id('general_settings', '58', 'value') !== 'ok') {
                      if ($this->db->get_where('ui_settings', array('type' => 'header_latest_products_status'))->row()->value == 'yes') {
                        ?>
                    <li class="<?php if ($others_list == 'latest') {
                      echo 'active';
                    } ?>">
                        <a href="<?php echo base_url(); ?>home/others_product/latest">
                            <?php echo translate('latest_products'); ?>
                        </a>
                    </li>
                    <?php
                      }
                    }
                    ?>
                    <?php
                    if ($this->crud_model->get_type_name_by_id('general_settings', '68', 'value') == 'ok') {
                      if ($this->db->get_where('ui_settings', array('type' => 'header_all_brands_status'))->row()->value == 'yes') {
                        ?>
                    <li <?php if ($asset_page == 'all_brands') { ?>class="active"<?php } ?>>
                        <a href="<?php echo base_url(); ?>home/all_brands">
                            <?php echo translate('all_brands'); ?>
                        </a>
                    </li>
                    <?php
                      }
                    }
                    ?>
                    <?php
                    if ($this->crud_model->get_type_name_by_id('general_settings', '58', 'value') == 'ok') {
                      if ($this->crud_model->get_type_name_by_id('general_settings', '81', 'value') == 'ok') {
                        if ($this->db->get_where('ui_settings', array('type' => 'header_all_vendors_status'))->row()->value == 'yes') {
                          ?>
                    <li <?php if ($asset_page == 'all_vendor') { ?>class="active"<?php } ?>>
                        <a href="<?php echo base_url(); ?>home/all_vendor/">
                            <?php echo translate('all_vendors'); ?>
                        </a>
                    </li>
                    <?php
                        }
                      }
                    }
                    ?>
                    <?php if ($this->db->get_where('ui_settings', array('type' => 'header_blogs_status'))->row()->value == 'yes') { ?>
                    <li class="hidden-sm hidden-xs <?php if ($asset_page == 'blog') {
                      echo 'active';
                    } ?>">
                        <a href="<?php echo base_url(); ?>home/blog">
                            <?php echo translate('blogs'); ?>
                        </a>
                        <ul>
                            <?php
                            $blogs = $this->db->get('blog_category')->result_array();
                            foreach ($blogs as $row) {
                              ?>
                            <li>
                                <a href="<?php echo base_url(); ?>home/blog/<?php echo $row['blog_category_id']; ?>">
                                    <?php echo $row['name']; ?>
                                </a>
                            </li>
                            <?php
                            }
                            ?>
                        </ul>
                    </li>
                    <?php } ?>
                    <li class="hidden-lg hidden-md <?php if ($asset_page == 'blog') {
                      echo 'active';
                    } ?>">
                        <a href="#">
                            <?php echo translate('blogs'); ?>
                        </a>
                        <ul>
                            <?php
                            $blogs = $this->db->get('blog_category')->result_array();
                            foreach ($blogs as $row) {
                              ?>
                            <li>
                                <a href="<?php echo base_url(); ?>home/blog/<?php echo $row['blog_category_id']; ?>">
                                    <?php echo $row['name']; ?>
                                </a>
                            </li>
                            <?php
                            }
                            ?>
                        </ul>
                    </li>
                    <?php
                    if ($this->crud_model->get_type_name_by_id('general_settings', '58', 'value') == 'ok' && $this->crud_model->get_type_name_by_id('general_settings', '81', 'value') == 'ok') {
                      if ($this->db->get_where('ui_settings', array('type' => 'header_store_locator_status'))->row()->value == 'yes') {
                        ?>
                    <li <?php if ($asset_page == 'store_locator') { ?>class="active"<?php } ?>>
                        <a href="<?php echo base_url(); ?>home/store_locator">
                            <?php echo translate('store_locator'); ?>
                        </a>
                    </li>
                    <?php
                      }
                    }
                    ?>
                    <?php if ($this->db->get_where('ui_settings', array('type' => 'header_contact_status'))->row()->value == 'yes') { ?>
                    <li <?php if ($asset_page == 'contact') { ?>class="active"<?php } ?>>
                        <a href="<?php echo base_url(); ?>home/contact">
                            <?php echo translate('contact'); ?>
                        </a>
                    </li>
                    <?php }
                    if ($this->db->get_where('ui_settings', array('type' => 'header_more_status'))->row()->value == 'yes') { ?>
                    <li>
                        <a href="#">
                            <?php echo translate('more'); ?>
                        </a>
                        <ul>
                            <?php
                            if ($this->crud_model->get_type_name_by_id('general_settings', '58', 'value') == 'ok') {
                              ?>
                            <li class="<?php if ($others_list == 'latest') {
                              echo 'active';
                            } ?>">
                                <a href="<?php echo base_url(); ?>home/others_product/latest">
                                    <?php echo translate('latest_products'); ?>
                                </a>
                            </li>
                            <?php
                            }
                            ?>
                            <?php
                            $this->db->where('status', 'ok');
                            $all_page = $this->db->get('page')->result_array();
                            foreach ($all_page as $row2) {
                              ?>
                            <li>
                                <a href="<?php echo base_url(); ?>home/page/<?php echo $row2['parmalink']; ?>">
                                    <?php echo $row2['page_name']; ?>
                                </a>
                            </li>
                            <?php
                            }
                            ?>
                        </ul>
                    </li>
                    <?php } ?>
                </ul>
            </nav>
          
        </div>
    </div>  -->

<script type="text/javascript">

$(".subheader-bars").click(function(){
  $(".sh-box-toggle").toggle("d-none");
})

</script>

<script type="text/javascript">
$(document).ready(function() {

  var li_length = $(".cd-dropdown-content > li").length;
  for (var i = 0; i < li_length; i++) {
    var sub_category_nav_holder = $(".cd-dropdown-content > li").eq(i).children(".sub_category_holder_div").length;
    if (sub_category_nav_holder > 0) {
      var arrow = "<span class='fa fa-chevron-right sidebar_show_chevron'></span>";
      $(".cd-dropdown-content > li").eq(i).children("a").append(arrow);
    }

  }

  var li_length = $(".cd-sub-dropdown > li").length;
  for (var i = 0; i < li_length; i++) {
    var third_sub_category_nav_holder = $(".cd-sub-dropdown > li").eq(i).children(".third_category_holder_div")
      .length;
    if (third_sub_category_nav_holder > 0) {
      var arrow = "<span class='fa fa-chevron-right sidebar_show_chevron'></span>";
      $(".cd-sub-dropdown > li").eq(i).children("a").append(arrow);
    }
  }

  $("#top_product_search").submit(function(e) {
    e.preventDefault();
    var query_string = "";
    var text = $("#search-home").val();
    if (text != "") {
      query_string += "text=" + text + "&";
    }
    if (query_string != "") {
      query_string = query_string.substr(0, query_string.length - 1);
      window.location = '<?php echo base_url('home/category?'); ?>' + query_string;
    }

  });
  $('.set_langs').on('click', function() {
    var lang_url = $(this).data('href');
    $.ajax({
      url: lang_url,
      success: function(result) {
        location.reload();
      }
    });
  });
  $('.top-bar-right').load('<?php echo base_url(); ?>home/top_bar_right');
});


$(document).ready(function() {

  $(".all_category").hover(function() {
    $('.cd-dropdown').addClass("dropdown-is-active");
  });


  $("#search-home").autocomplete({
    source: function(request, response) {
      $.ajax({
        url: "<?= base_url('home/searchBarHome') ?>",
        data: {
          term: request.term
        },
        dataType: "json",
        success: function(data) {
          var resp = $.map(data, function(obj) {
            // console.log(obj.title);
            return obj.title;
          });
          response(resp);
        }
      });
    },
    minLength: 1
  });
});

// $('#search-home').on('keyup',function(e)
//     {

//         var user_input = $(this).val();
//         console.log(user_input);
//         if (user_input == '' || user_input.length < 3) {
//         $('.suggestion-box').hide();
//         }else{
//             if (e.keyCode == 37 || e.keyCode == 38 || e.keyCode == 39 || e.keyCode == 40 ) {

//             }else{
//                 if (user_input.length == 3) {
//                 $('#search-home').attr("readonly","readonly");
//                 }
//                 $('.suggestion-box').html('');
//                 $('.suggestion-box').show();
//                 $.getJSON('<?= base_url('home/searchBarHome') ?>/'+user_input,function(data){
//                     if (data == 'empty') {
//                         $('#search-home').removeAttr("readonly","readonly");
//                         $('.suggestion-box').html('');
//                         $('.suggestion-box').hide();
//                     }else{
//                         if (data == null || data == '') {
//                         $('#search-home').removeAttr("readonly","readonly");
//                         $('.suggestion-box').html('');
//                         $('.suggestion-box').hide();
//                         }else{
//                             $('#search-home').removeAttr("readonly","readonly");
//                             $('.suggestion-box').show();
//                             for(i in data){
//                                 $('.suggestion-box').append('<div data-title="'+data[i].title+'" class="suggestion-box-child">'+data[i].title+'</div>');
//                              }
//                         }
//                     }
//                 });
//             }
//         }

//     });

// $(document).delegate('.suggestion-box-child','click',function(){
//     var getTitle = $(this).data('title');
//     $('#search-home').val(getTitle);
//     $('.suggestion-box').html('');
//     $('.suggestion-box').hide();
// });
</script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<style>
.dropdown-menu .active a {
  color: #fff !important;
}

.dropdown-menu li a {
  cursor: pointer;
}

.header-search select {
  display: block !important;
}

.cat_select button {
  right: 170px !important;
}
.subheader-bars{
  display: none;

}
@media (min-width: 769px) and (max-width: 1025px) {
  .subheader{
    
  }
}
@media (max-width: 768px) {
  .cat_select button {
    right: 80px !important;
  }
  .subheader-bars{
    display: block;
    position: relative; 
    float: right;
    margin-top: -25px;

  }
  .subheader-container{
    display: block;
  }
  .sh-boxes{
    display: none;
  }
  .all_category {
    width: 40% !important;
  }
  
}
</style>
<?php
if ($this->crud_model->get_type_name_by_id('general_settings', '58', 'value') !== 'ok') {
  ?>
<style>
.header.header-logo-left .header-search .header-search-select .dropdown-toggle {
  right: 40px !important;
}
</style>
<?php
}
?>