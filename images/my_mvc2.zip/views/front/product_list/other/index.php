 <!-- PAGE WITH SIDEBAR -->
<?php
	//echo "<pre>";print_r($all_products);die();
	//echo "<pre>";print_r($sidebar_filter_data);die();
	$actual_sizes_arr = array();
	$color_arr = array();
	$shape_arr = array();
	foreach($sidebar_filter_data as $key => $val){
		if($val["shape"]!=""){
			$shape_arr[ucwords($val["shape"])] = ucwords($val["shape"]);
		}
		if($val["actual_size"]!=""){
			$actual_sizes_arr[$val["actual_size"]] = $val["actual_size"];
		}	
		$color_arr_decoding = ($val["color"])? json_decode($val["color"]) : [];
		if(count($color_arr_decoding)>0){
			foreach($color_arr_decoding as $color){
				if($color!=""){
					if(!strstr($color,",")){
						$color_arr[ucwords($color)] = ucwords($color);
					}	
				}
			}
		}
	}
	$actual_sizes_arr = array_values($actual_sizes_arr);
	$color_arr = array_values($color_arr);
	$shape_arr = array_values($shape_arr);
	// echo "<pre>";print_r($color_arr);die();
?>
 <style>
    .widget.shop-categories ul ul.children label {
        margin-right: 0;
    }
    .widget.shop-categories ul label {
        display: block;
        margin-right: 20px;
        color: #232323;
        cursor: pointer;
    }
	.pagination-wrapper.bottom{
		text-align-last:center;
	}
	.sort-item{
		display:table;
	}
	.sort-item .form-inline{
		display:table-row;
	}
	.sort-item .form-group{
		display:table-cell;
	}
	.sort-item .widget-search .form-control{
		height:35px;
		line-height: 35px;
	}
	.sort-item .widget-search button{
		line-height: 26px;
	}
	.sort-item .widget-search button:before{
		height:30px;
	}
	.shop-sorting .btn-theme-sm {
		padding: 5px 7px;
	}
	.sidebar.close_now{
		position: relative;
		left:0px;
		opacity:1;
	}
	@media(max-width: 991px) {
		.sidebar.open{
			opacity:1;
			position: fixed;
			z-index: 9999;
			top: -30px;
			background: #f5f5f5;
			height: 100vh;
			overflow-y: auto;
			padding-top: 50px;
			left:0px;
		}
		.sidebar.close_now{
			position: fixed;
			left:-500px;
			opacity:0;
		}
		.view_select_btn{
			margin-top: 10px !important;
		}
	}
	.bc{
		font-size: 14px;
		height: auto;
		min-height: 40px;
	}
	.bc a{
		color: #f3402d;
	}
	.bc a .fa-chevron-right{
		margin-left: 5px;
		margin-right: 5px;
	}
	.bc a:hover{
		cursor: pointer;
		color: #242424;
		transition: all 0.2s;
	}
	.bc_search_label{
		font-weight: bold;
		font-size: 15px;
	}
	.page-section{
		padding-top: 10px;
	}
	.bc_search_category{
		display: inline-block;
		width: 90%;
		margin-left: 1%;
 	}
	.bc_filter_page{
		padding: 7px 18px !important;
		display: flex;
	}
</style>
<section class="page-section with-sidebar">
	<div class="container">
		
        <div class="row">
            <!-- SIDEBAR -->
            <?php 
                include 'sidebar.php';
            ?>
            <!-- /SIDEBAR -->
            <!-- CONTENT -->
            <div class="col-md-9 col-sm-12 col-xs-12" style="margin-top: 0px!important;padding-left:0px!important;">
               	<div class="bc_filter_page bc sidebar_jumbotron jumbtron">
            		<span class="bc_search_label">Search :</span>
            		<div class="bc_search_category">
	            		<?php 
				         	if(isset($_GET['text'])){
					        	echo "<a>";
					        		echo $_GET['text'];
					        	echo "</a>";
					        }
					        if(isset($_GET['category'])){
					        	echo "<a href='".base_url('home/category?category='.$this->input->get("category"))."&categories=".$this->crud_model->getCategoriesName($this->input->get("category"))." '>";
					        		echo ucwords($this->crud_model->get_type_name_by_id("category",$this->input->get("category"),"category_name"));
					        	echo "</a>";
					        }
					        if(isset($_GET['sub_category'])){
					        	echo "<a href='".base_url('home/category?category='.$this->input->get("category").'&sub_category='.$this->input->get("sub_category"))."&categories=".$this->crud_model->getCategoriesName($this->input->get("category"),$this->input->get("sub_category"))."  '>";
					        		echo  "<i class='fa fa-chevron-right'></i> ".ucwords($this->crud_model->get_type_name_by_id("sub_category",$this->input->get("sub_category"),"sub_category_name"));
					        	echo "</a>";
					        }
					        if(isset($_GET['third_sub_category'])){
					        	echo "<a href='".base_url('home/category?category='.$this->input->get("category").'&sub_category='.$this->input->get("sub_category").'&third_sub_category='.$this->input->get("third_sub_category"))."&categories=".$this->crud_model->getCategoriesName($this->input->get("category"),$this->input->get("sub_category"),$this->input->get("third_sub_category"))." '>";
					        		echo  "<i class='fa fa-chevron-right'></i> ".ucwords($this->crud_model->get_type_name_by_id("third_sub_category",$this->input->get("third_sub_category"),"third_sub_ctg_name"));
					        	echo "</a>";
					        }
					        if(isset($_GET['brand'])){
					        	echo "<a href='".base_url('home/category?category='.$this->input->get("category").'&sub_category='.$this->input->get("sub_category").'&third_sub_category='.$this->input->get("third_sub_category").'&brand='.$this->input->get("brand"))."&categories=".$this->crud_model->getCategoriesName($this->input->get("category"),$this->input->get("sub_category"),$this->input->get("third_sub_category"),$this->input->get("brand"))." '>";
					        		echo  "<i class='fa fa-chevron-right'></i> ".ucwords($this->crud_model->get_type_name_by_id("brand",$this->input->get("brand"),"name"));
					        	echo "</a>";
					        }
					    ?>	
            		</div>
			    </div>
			</div>    
            <div class="col-md-9 col-sm-12 col-xs-12 content" id="content" style="margin-top: -5px;">
                <div id="result" style="min-height:300px;">
                    <?php include 'listed.php'; ?>
                </div>
            </div>
            <!-- /CONTENT -->
        </div>
    </div>
</section>
<!-- /PAGE WITH SIDEBAR -->
<script>
	$(document).ready(function(e) {
        close_sidebar();
    });
	function open_sidebar(){
		$('.sidebar').removeClass('close_now');
		$('.sidebar').addClass('open');
	}
	function close_sidebar(){
		$('.sidebar').removeClass('open');
		$('.sidebar').addClass('close_now');
	}
</script>