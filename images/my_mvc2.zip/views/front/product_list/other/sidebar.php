<?php
    $get_size_from_url = [];
    $get_color_from_url = [];
    $get_shape_from_url = [];
    $get_brand_from_url = [];
    if(isset($_GET['size']) && $_GET['size']){
        $get_size_from_url = $this->input->get("size");
        $get_size_from_url = explode("-",$get_size_from_url);
    }
    if(isset($_GET['color']) && $_GET['color']){
        $get_color_from_url = $this->input->get("color");
        $get_color_from_url = explode("-",$get_color_from_url);
    }
    if(isset($_GET['shape']) && $_GET['shape']){
        $get_shape_from_url = $this->input->get("shape");
        $get_shape_from_url = explode("-",$get_shape_from_url);
    }
     if(isset($_GET['brand']) && $_GET['brand']){
        $get_brand_from_url = $this->input->get("brand");
        $get_brand_from_url = explode("-" , $get_brand_from_url);
    }
?>
<style type="text/css">
    .sidebar_jumbotron{
        background-color: white;    
        box-shadow: 1px 1px 8px 0px #ccc;
        border:1px solid #ccc;
       padding: 5px 18px !important;
    }
    .sidebar_jumbotron{
        margin-bottom: 10px;
    }
    .widget-tabs{
        box-shadow: 1px 1px 8px 0px #ccc;
    }
    .sidebar_jumbotron .heading{
        color: #242424;
        font-size: 16px;
    }
    .category_list li a{
        color:  #3a3a3a;
    }
  
    .category_list li {
        background-color: transparent !important;
        border:0px solid !important;
        font-size: 14px;
        padding: 4px 7px;
        transition: all 0.2s;
    }
    .category_list li:hover a{
        color: black;
        cursor: pointer;
    }
    .slider {
        -webkit-appearance: none;
        width: 100%;
        height: 8px;
         border-radius: 3px;  
        background: #d3d3d3;
        outline: none;
        -webkit-transition: .2s;
        transition: opacity .2s;
        margin-bottom: 15px;
        margin-top: 10px;
    }

    .slider::-webkit-slider-thumb {
        -webkit-appearance: none;
        appearance: none;
        width: 10px;
        height: 25px;
        background: #3C3B6E;
        cursor: pointer;
    }

    .slider::-moz-range-thumb {
        width: 25px;
        height: 25px;
        border-radius: 50%;
        background: #4CAF50;
        cursor: pointer;
    }
    .ui-slider-handle{
        margin-top: -5px;
        width: 10px !important;
        height: 25px !important;
        background: #242424 !important;
        cursor: pointer  !important;
    }
    .jb_latest_popular_deal_prod{
        min-height: 470px !important;
    }
    .change_price_filter{
        font-weight: bold;
        font-size: 12px;
    }
    .jb_cateogory .nested_menu a{
        padding-left: 0px;
    }
    .jb_cateogory .sub_category_menu li a span{
        margin-left: 0px;
    }
    .jb_cateogory .list-group{
        margin-bottom: 0px;
    }
    .jb_product_size,
    .jb_product_shape,
    .jb_product_color
    {
        max-height: 300px;
        height: auto;
        overflow-x: hidden;
       overflow: auto;
    }
    .chk_filter_holder{
        display: flex;
        padding: 4px 8px;
    }
    .chk_filter_holder label span{
        font-size: 12px;
        font-weight: bold;
    }
    #min_price{
        margin-right: 5%;
    }
    #min_price, #max_price{
        height: 36px;
        display: inline-block;
        width: 80px;
        margin-top: 8%;
    }
    .jb_product_size label{
        margin-right: 2px;
        font-size: 18px;
    }
    #slider-range{
        margin-top: 5%;
    }
    .jb_product_price_filter{
        overflow: hidden;
        padding-bottom: 20px !important;
        margin-top: 10px;
    }
</style>
<aside class="col-md-3 sidebar" id="sidebar" style="margin-top: 0px;">
    <select class="selectpicker input-price sorter_search" data-width="100%" data-toggle="tooltip" title="Select">                               
        <option value=""><?php echo translate('sort_by'); ?></option>
        <option value="low" <?php echo (isset($_GET['sort_by']) && $_GET['sort_by']=="low") ? "selected='selected'" : "" ;?>><?php echo translate('price_low_to_high'); ?></option>
        <option value="high" <?php echo (isset($_GET['sort_by']) && $_GET['sort_by']=="high") ? "selected='selected'" : "" ;?>><?php echo translate('price_high_to_low'); ?></option>
        <option value="new_to_old" <?php echo (isset($_GET['sort_by']) && $_GET['sort_by']=="new_to_old") ? "selected='selected'" : "" ;?>>
            <?php echo translate('newest_to_oldest'); ?></option>
        <option value="old_to_new" <?php echo (isset($_GET['sort_by']) && $_GET['sort_by']=="old_to_new") ? "selected='selected'" : "" ;?>><?php echo translate('oldest_to_newest'); ?></option>
    </select>
    <!-- widget shop categories -->
    <div class="sidebar_jumbotron jumbtron jb_price jb_product_size jb_product_price_filter">
        <strong class="heading">
            <i class="fa fa-usd"></i>
                <?php echo translate('PRICE');?>
        </strong>
        <div id="slider-range"></div>
        <input type="hidden" value="<?php echo  (isset($_GET['min']) && isset($_GET['max'])) ? 1 :  0; ?>" id="is_slider_change">
        <label><?php echo currency(); ?></label><input type="text" name="min_price" id="min_price" class="form-control" readonly="readonly">
        <label><?php echo currency(); ?></label><input type="text" name="max_price" id="max_price" class="form-control" readonly="readonly">
    </div>
    <button class="btn btn-block btn_filter_price btn-theme"><i class="fa fa-search"></i>
        <?php echo translate("go"); ?></button>
    <br />
    <?php if (isset($meta['catelog']) && $meta['catelog']) {?>
    <div class="sidebar_jumbotron jumbtron jb_price jb_product_size">
        <strong class="heading">
            <i class="fa fa-tag"></i>
            <?php echo translate('Download Catalogue');?>  
            <hr style="margin: 8px 0px;" />
        </strong>
        <div class="chk_filter_holder">
            <a href="<?php echo base_url('uploads/category_catelog/'.$meta['catelog']);?>" target="_blank" ><img src="<?= base_url('template/front/img/pdf.png');?>" alt="pdf"><strong><?php echo translate('download'); ?></strong></a>
        </div>
    </div>
    <?php } ?>
    <!-- <div class="sidebar_jumbotron jumbtron jb_price jb_product_size">
        <strong class="heading">
           <i class="fa fa-tag"></i>
             <?php //echo translate('Brand');?>  
             <hr style="margin: 8px 0px;" />
         </strong>
             <?php 
                    // foreach ($all_brands as  $all_brand) {
                    //     $checked = "";
                    //     if(in_array($all_brand->brand_id , $get_brand_from_url)){
                    //         $checked  = "checked='checked'";
                    //     }
            ?>
            <div class="chk_filter_holder">
                <div class="my_checkbox_container">
                        <input type="checkbox" value="<?php //echo $all_brand->brand_id; ?>" class="chk_brand_filter" <?php //echo $checked; ?>>
                        <span class="my_checkmark"></span>
                 </div>
                 <span><?php //echo ucwords($all_brand->name); ?></span>
            </div>
            <?php //} ?>
    </div> -->
     <!-- widget size filter -->
    <?php if(count($actual_sizes_arr)>0){ ?>
    <div class="sidebar_jumbotron jumbtron jb_price jb_product_size hidden">
        <strong class="heading">
           <i class="fa fa-tag"></i>
             <?php echo translate('size');?>  
             <hr style="margin: 8px 0px;" />
         </strong>
             <?php 
                    foreach ($actual_sizes_arr as  $actual_size) {
                        $actual_size_q =  $actual_size;
                        $actual_size = str_replace("'", "", $actual_size);
                        $actual_size = str_replace('"', "", $actual_size);
                        $checked = "";
                        if(in_array($actual_size , $get_size_from_url)){
                            $checked  = "checked='checked'";
                        }
            ?>
            <div class="chk_filter_holder">
                <div class="my_checkbox_container">
                        <input type="checkbox" value="<?php echo $actual_size; ?>" class="chk_size_filter" <?php echo $checked; ?>>
                        <span class="my_checkmark"></span>
                 </div>
                 <span><?php echo $actual_size_q; ?></span>
            </div>
            <?php } ?>
    </div>
    <?php } ?>

     <?php if(count($color_arr)>0){ ?>
    <div class="sidebar_jumbotron jumbtron jb_price jb_product_color">
        <strong class="heading">
           <i class="fa fa-tag"></i>
             <?php echo translate('Variant');?>  
             <hr style="margin: 8px 0px;" />
         </strong>
             <?php 
                foreach ($color_arr as  $color) {
                    $checked = "";
                    if(in_array($color , $get_color_from_url)){
                        $checked  = "checked='checked'";
                    }
            ?>
            <div class="chk_filter_holder">
                <div class="my_checkbox_container">
                  <input type="checkbox" value="<?php echo $color; ?>" class="chk_color_filter" <?php echo $checked; ?>>
                  <span class="my_checkmark"></span>
                </div>
                <span><?php echo $color; ?></span>
            </div>
            <?php } ?>
    </div>
    <?php } ?>

     <?php if(count($shape_arr)>0){ ?>
    <div class="sidebar_jumbotron jumbtron jb_price jb_product_shape">
        <strong class="heading">
           <i class="fa fa-tag"></i>
             <?php echo translate('Shape');?>  
             <hr style="margin: 8px 0px;" />
         </strong>
             <?php 
                foreach ($shape_arr as  $shape) {
                    $checked = "";
                    if(in_array($shape , $get_shape_from_url)){
                        $checked  = "checked='checked'";
                    }
            ?>
            <div class="chk_filter_holder">
                <div class="my_checkbox_container">
                  <input type="checkbox" value="<?php echo $shape; ?>" class="chk_shape_filter" <?php echo $checked; ?>>
                  <span class="my_checkmark"></span>
                </div>
                <span><?php echo $shape; ?></span>
            </div>
            <?php } ?>
    </div>
    <?php } ?>
    <!-- /widget size filter -->

    <div class="sidebar_jumbotron jumbtron jb_latest_popular_deal_prod">
       <?php
            echo $this->html_model->widget('special_products');
        ?>
        <div class="clear"></div>
    </div>
</aside>

<input type="hidden" id="univ_max" value="<?php echo $this->crud_model->get_range_lvl('product_id !=', '', "max"); ?>">
<input type="hidden" id="cur_cat" value="0">
<script>
    $(document).ready(function(){
        $( function() {
            $( "#slider-range" ).slider({
                range: true,
                min: 0,
                max: '<?php echo $min_max['max_selling_price']; ?>',
                values: [ '<?php echo  (isset($_GET['min']) ? $_GET['min'] : 0)?>', '<?php echo  (isset($_GET['max']) ? $_GET['max'] : $min_max['max_selling_price'])?>' ],
                slide: function( event, ui ) {
                    $("#min_price").val(ui.values[ 0 ]);
                    $("#max_price").val( ui.values[ 1 ] );
                },
                change : function(event, ui){
                    $("#is_slider_change").val(1);
                }
            });
            $("#min_price").val($( "#slider-range" ).slider( "values", 0 ));
            $("#max_price").val($( "#slider-range" ).slider( "values", 1 ) );
        });
    });
</script>
<?php include 'search_script.php'; ?>
