 <?php 
 	//echo "<pre>";print_r($all_products);die();
 	$viewtype = "grid";
 ?>
<style type="text/css">
    .no_data_available{
        display: none;
        font-size: 16px;
    }
    .row_product_list .pd{
       padding: 0px 8px 0 0px!important;
       margin-top: 15px!important;
    }
</style>
<?php $box_style =  $this->db->get_where('ui_settings',array('ui_settings_id' => 29))->row()->value; ?>
<div class="row products <?php echo $viewtype; ?> row_product_list">
    <?php
    	if($viewtype == 'list'){
			$col_md = 'col-md-12';
			$col_sm = 'col-sm-12';
			$col_xs = 'col-xs-12';
		} elseif($viewtype == 'grid'){
			$col_md = 'col-md-4';
			$col_sm = 'col-sm-6';
			$col_xs = 'col-xs-6';
		}
    if(count($all_products)){
        foreach ($all_products as $row) {
    ?>
    <div class="pd <?= $col_xs.' '.$col_sm.' '.$col_md; ?>" data-aos="flip-left" data-aos-mirror="true" data-aos-duration="1000" data-aos-once="true" style="margin-top: 5px !important;">
        <?php echo $this->html_model->product_box($row, $viewtype, $box_style); ?>
    </div>
    <?php
        }
    }else{
    ?>
    <img src="<?php echo base_url("uploads/others/no_product_found.jpg"); ?>" class="img-responsive" style="margin-top: 30px;">
   <?php } ?>
</div>
<!-- /Pagination -->
<script>
$(document).ready(function(){
    <?php if(count($all_products)>0){ ?>
        var offset = <?= PRODUCT_LIMIT ?> ;
        var getHit = true;
        $(window).scroll(function () {
            var sctop   = ($(document).scrollTop());
            var initHeight  = ($(document).height());
            if (initHeight > 300 && getHit == true) 
            {
                getHit = false;
    			$("#product_loader").show();
                var ajax_product_data = {
                	col : 4,
    				offset : offset, 
    				speciality :'allProducts',
    				category_id :  $("#category").val(),
    				sub_category_id :  $("#sub_category").val(),
    				third_sub_category_id :  $("#third_sub_category").val(),
    				sort_by : $("#sort_by").val(),
    				price : $("#price").val(),
    				text : $("#text").val(),
                    size : $("#size").val(),
                    color : $("#color").val(),
                    shape : $("#shape").val(),
                    brand : $("#brand").val()
    			};
                //console.log(ajax_product_data); return false;
    			$.ajax({
                        type: "POST",
                        url: '<?= base_url("home/ajax_product_list")?>',
                        data: ajax_product_data ,
                        cache: false,
                        success: function (data) {
                            getHit = true;
                            // $('.row_product_list').append(data);
                            offset += <?= PRODUCT_LIMIT ?>;
                    }
                });
            }
    });
    <?php } ?>
	// set_product_box_height();
	$('[data-toggle="tooltip"]').tooltip();
});

// function set_product_box_height(){
// 	var max_img = 0;
// 	$('.products .media img').each(function(){
//         var current_height= parseInt($(this).css('height'));
// 		if(current_height >= max_img){
// 			max_img = current_height;
// 		}
//     });
// 	$('.products .media img').css('height',max_img);
	
// 	var max_title=0;
// 	$('.products .caption-title').each(function(){
//         var current_height= parseInt($(this).css('height'));
// 		if(current_height >= max_title){
// 			max_title = current_height;
// 		}
//     });
// 	$('.products .caption-title').css('height',max_title);
// }
</script>