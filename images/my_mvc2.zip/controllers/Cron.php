<?php
ini_set('memory_limit', '-1');
set_time_limit(0);
if (!defined('BASEPATH')) exit('No direct script access allowed');

/* class start */
class Cron extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		$this->load->model("crud_model");
		$this->load->model("remove_duplicate_images_model");
	}
	public function download_product_variant_img_video()
	{
    	exit;
		$this->crud_model->getVariantForDownload();
	}
	public function remove_duplicate_images_model()
	{
    	exit;
		$this->remove_duplicate_images_model->removeDuplicateImages();
	}
	public function update_stock()
	{
		exit;
		$data = $this->crud_model->getUploadedFilesForUpdate("stock");
		if($data){

			$file_name = $data['file_name'];
			$file_id = $data['file_id'];

            $this->db->where("file_id" , $file_id);
            $this->db->set("completed", 2);
            $this->db->set("updated", date("Y-m-d h:i:s"));
            $this->db->update("uploaded_files");

			$fp = fopen("uploads/file/stock_update/".$file_name, "r+");
			$count  = 0;
			while($row = fgetcsv($fp))
			{
				$count++;
				if($count==1){
					continue;
				}
				if($data['completed']==2 && $count<$data['processed']){
					continue;
				}
				$upc = (float) $row[0]; // upc 
				$seller_sku = $row[1]; // seller sku
				$stock = $row[2]; // stock
				$status = $row[3]; // active

                if(empty($upc) && empty($seller_sku) && empty($stock) && empty($status)){
                  	$this->db->where("file_id" , $file_id);
		            $this->db->set("completed", 1);
		            $this->db->set("updated", date("Y-m-d h:i:s"));
		            $this->db->update("uploaded_files");
		            break;
                }
				if(!is_numeric($stock) || $stock=="" || !is_numeric($status) || $status==""){
					continue;
				}
				echo "count ".$count."upc : ".$upc." seller sku ".$seller_sku."<br />";
				//$this->db->where("upc",$upc);
				$this->db->where("seller_sku",$seller_sku);
				$this->db->set("stock_status", $stock);
				$this->db->set("status", $status);
				$this->db->update("product_variants");

		        $effected_rows = $this->db->affected_rows();

				$this->db->where("file_id" , $file_id);
				$this->db->set("processed","processed+1",FALSE);
				$this->db->set("pending_row","pending_row-1",FALSE);

		        if($effected_rows>0){
					$this->db->set("submitted","submitted+1",FALSE);
				}else{
					$this->db->set("errors","errors+1",FALSE);
				}
				$this->db->set("updated", date("Y-m-d h:i:s"));
				$this->db->update("uploaded_files");
			}

			$this->db->where("file_id" , $file_id);
			$this->db->set("completed", 1);
			$this->db->set("updated", date("Y-m-d h:i:s"));
			$this->db->update("uploaded_files");
		}
	}
	function getLastProductDate(){
		$this->db->select("*");
		$this->db->from("product_variants");
		$this->db->order_by('product_variants_id', 'DESC');
		$this->db->limit(1);
		$q = $this->db->get();

		if($q->num_rows() > 0){
			return $q->row()->created;	
		}
		
	}
	function insertFirstCategory($name, $vendor_cat_id){
		$data = array(
			'category_name' => $name,
			'vendor_category_id' => $vendor_cat_id,
		);
		$this->db->insert('category', $data);

		return $this->db->insert_id();
	}
	function insertSecondCategory($name, $vendor_cat_id, $first_cat_id){
		$data = array(
			'sub_category_name' => $name,
			'category' => $first_cat_id,
			'vendor_category_id' => $vendor_cat_id,
		);
		$this->db->insert('sub_category', $data);

		return $this->db->insert_id();
	}

	function insertThirdCategory($name, $vendor_cat_id, $first_cat_id, $second_cat_id){
		$data = array(
			'third_sub_ctg_name' => $name,
			'vendor_category_id' => $vendor_cat_id,
			'category' => $first_cat_id,
			'sub_category' => $second_cat_id,
		);
		$this->db->insert('third_sub_category', $data);
	}

	function getProductDetails($pid){

		$url = "https://developers.cjdropshipping.com/api2.0/v1/product/query?pid=$pid";

		$accessToken = CJ_ACCESS_TOKEN;
		
		$ch = curl_init($url);
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // Return the response as a string
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('CJ-Access-Token: ' . $accessToken)); // Set the access token in the header
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  // Follow redirects
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification (not recommended for production)
		
		$response = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'cURL error: ' . curl_error($ch);
		}
		
		curl_close($ch);
		
		$res = json_decode($response); 
		return $res;
		
	}

	function getCategoryFromVendor($vendor_category){
		$this->db->select("third_sub_category_id, sub_category, category");
		$this->db->from("third_sub_category");
		$this->db->where("vendor_category_id", $vendor_category);
		$this->db->limit(1);
		$q = $this->db->get();
		if($q->num_rows() > 0){
			return $q->row();
		}
		return false;
	}

	function getLastProductDateDESC() {

		$date = $this->db->select("*")
		->from("product")
		->where("created !=", "")
		->order_by("created", 'DESC')
		->limit(1)->get();
		if($date->num_rows() > 0){
			return $date->row()->created;
		}
		return false;
	}

	function importCategories(){
// 		print_r("import band h pakistan mn");
		die();
	
		$url = "https://developers.cjdropshipping.com/api2.0/v1/product/getCategory";

		$accessToken = CJ_ACCESS_TOKEN;
		
		$ch = curl_init($url);
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // Return the response as a string
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('CJ-Access-Token: ' . $accessToken)); // Set the access token in the header
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  // Follow redirects
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification (not recommended for production)
		
		$response = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'cURL error: ' . curl_error($ch);
		}
		
		curl_close($ch);
		
		
		$res = json_decode($response);

		$data = $res->data;


		foreach($data as $first){
			$first_id = $this->insertFirstCategory($first->categoryFirstName, $first->categoryFirstId);
			foreach($first->categoryFirstList as $second){
				$second_id = $this->insertSecondCategory($second->categorySecondName, $second->categorySecondId, $first_id);
				foreach($second->categorySecondList as $third){
					$this->insertThirdCategory($third->categoryName, $third->categoryId, $first_id, $second_id);
				}

			}
		}
	}
	function getLastIncompleteFile(){
			$this->db->select("*");
			$this->db->from("uploaded_files");
			$this->db->where("completed", 0);
			$this->db->limit(1);
			$this->db->order_by('file_id', "DESC");
			$q = $this->db->get();
			if($q->num_rows() > 0){
				return $q->row();
			}else{
				return false;
			}
	}
	function setLastFileStatus($status, $file_id, $processed, $pending, $submitted){
			$this->db->set('completed', $status);
			$this->db->set("processed", $processed);
			$this->db->set("submitted", $submitted);
			$this->db->set("pending_row", $pending);
			$this->db->where("file_id", $file_id);
			return $this->db->update('uploaded_files');
	}

	function getCSVProducts(){

		$file_details = $this->getLastIncompleteFile();
	
		if(count($file_details) > 0){
			$csvFilePath = "uploads/file/stock_update/$file_details->file_name";
			$fileHandle = fopen($csvFilePath, 'r');
			$products = array();
				while (($rowData = fgetcsv($fileHandle)) !== false) {
					sleep(1);
					$product_id = $rowData[0];
					$r = $this->getProductDetails($product_id)->data;
					if($r){
						$products[] = $r; 
					}
				}
				return $products;
		}else{
			return 0;
		}
	}

	function calculateFreight($variant_id) {
    // API endpoint
    $url = 'https://developers.cjdropshipping.com/api2.0/v1/logistic/freightCalculate';

    // Request headers
    $headers = array(
        'Content-Type: application/json',
        'CJ-Access-Token: ' . CJ_ACCESS_TOKEN
    );

    // Request data
    $data = array(
        'startCountryCode' => 'US',
        'endCountryCode' => 'US',
        'products' => array(
            array(
                'quantity' => 2,
                'vid' => "$variant_id"
            )
        )
    );

    // Initialize cURL session
    $ch = curl_init($url);

    // Set cURL options
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Execute cURL session
    $response = curl_exec($ch);

    // Close cURL session
    curl_close($ch);

    // Return response
    return $response;
}

	public function add_stock_from_file()
	{

		$products = $this->getCSVProducts();
		
		if(!$products){
			echo '<pre>'; print_r("API didnt respond OR Wrong Product ID's Added"); die(); 
		}

		$no=0;
		$up=0;
		$date = date('Y-m');

		$forbidden_category = [
			"9694B484-7EA0-4D71-993B-9CF02D24B271",
			"A6158EC0-C66D-456D-923C-E784EE432A02",
			"A7DE167B-ECFF-481E-A52A-2E7937BFAA95",
			"7D830BF3-03DB-4EBB-8A50-ED5F1231E17A",
			"8A22518D-0C6F-430D-8CD9-7E043062A279",
			"56F1151E-2544-4044-BB41-03081A532B2F"
		];


			foreach($products as $product){
			  
			    if($product->productNameEn == ""){
					continue;
				}
				
				$is_forbidden = in_array($product->categoryId, $forbidden_category);
				if(!$is_forbidden){
					//create time to upload
					$created = explode("T", $product->createTime);
					$created_date = $created[0];
					$created_time = explode(".", $created[1])[0];
					$created = $created_date . " " . $created_time;

					// $product_details = $this->getProductDetails($product->pid)->data;
					
					$categories = $this->getCategoryFromVendor($product->categoryId);

					$product_data = array(
						'added_by' => '{"type":"vendor","id":"35"}',
						'category' => $categories->category,
						'sub_category' => $categories->sub_category,
						'third_sub_category' => $categories->third_sub_category_id,
						'featured' => 'ok',
						'title' => $product->productNameEn,
						'status' => 'ok',
						'brand' => "",
						'vendor_id' => 35,
						'admin_product' => 1,
						'make_first' => 0,
						'created' => $created,
						'productkey' => $product->productKeyEn,
						'is_approved' => 0,
						'admin_product' => 1,
						'description' => $product->description,
						'current_stock' => $product->listedNum,
						'cj_productid ' => $product->pid,
					);

					
					$this->db->insert('product', $product_data);
					$product_id = $this->db->insert_id();
				
					
					//image upload
					if (!file_exists("uploads/product_variants_image/$date")) {
                        mkdir("uploads/product_variants_image/$date", 0777, true);
            }
                    
						$url= "";
						$pImage = json_decode($product->productImage);
						$url = $pImage[0];
						$ext = end(explode(".", $url)); 
						
						$file_name = $product_id . "-1.$ext";
						$this->db->set('front_image', "[\"$date\/$file_name\"]");
						$this->db->where('product_id', $product_id);
						$this->db->update('product');
						
					 
					 $main_image_count = 0;
					 $main_image_array = array();
					 $main_image_array[] = "$date/$file_name";
					 foreach($pImage as $pi){
						$other_ext = end(explode(".", $pi)); 

						if($main_image_count == 0){
							$data = file_get_contents($url);
							$new = "uploads/product_variants_image/$date/$file_name";
							$q = file_put_contents($new, $data);
						}else{
							$data = file_get_contents($pi);
							$new = "uploads/product_variants_image/$date/$product_id-1" . '_' . $main_image_count . '.' .$other_ext;
							$q = file_put_contents($new, $data);
							$main_image_array[] = "$date/$product_id-1_$main_image_count.$other_ext";
						}
						$main_image_count++;
					 }

					
					$i=1;
					
					foreach($product->variants as $variant){

						$variant_image_name = $variant->pid ."-$i.jpg";
						//upload variant image
						$data = file_get_contents($variant->variantImage);
						$new = "uploads/product_variants_image/$date/$variant_image_name";
						$q = file_put_contents($new, $data);

                        if($variant->variantNameEn == ""){
                            $variant->variantNameEn = $product->productNameEn;
                        }

						$product_varient_data = array(
							'title' => $variant->variantNameEn,
							'product_id' => $product_id,
							'description' => $product->description,
							'selling_price' => $variant->variantSellPrice,
							'cost' => $product->sellPrice,
							'total_cost' => $product->sellPrice,
							'stock_status' => ($product->listingCount) ? $product->listingCount : (($product->listedNum) ? $product->listedNum : 50),
							'supplier_sku' => $product->productSku,
							'seller_sku' => $product->pid,
							'upc' => $product->pid,
							'weight' => $product->productWeight,
							'actual_size' => "-",
							'color' => '["' . $variant->variantKey . '"]',
							'images' => ($i==1) ? json_encode($main_image_array):"[\"$date\/$variant_image_name\"]",
							'is_download' => 1,
							'created' => $created,
							'cj_variantid ' => $variant->vid,
						);
						$this->db->insert('product_variants', $product_varient_data);
						$i++;
					
					}

				}
				$no++;
			}
	  if($no > 0){
			$last_file = $this->getLastIncompleteFile();
			$processed = $no;
			$pending = count($products) - $no;
			$this->setLastFileStatus(1, $last_file->file_id, $processed, $pending, $submitted);
			print_R("$no Products Added");
		}else{
			print_r("Product Upload Failed");
		}
	}
	function getInventoryByVariant($vid){
	

		$curl = curl_init();
		
		curl_setopt_array($curl, array(
			CURLOPT_URL => "https://developers.cjdropshipping.com/api2.0/v1/product/stock/queryByVid?vid=$vid",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'GET',
			CURLOPT_HTTPHEADER => array(
				'CJ-Access-Token: eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIxMTQ0NCIsInR5cGUiOiJBQ0NFU1NfVE9LRU4iLCJzdWIiOiJicUxvYnFRMGxtTm55UXB4UFdMWnlpWE82YzZWM2xoTVhUTUNaLyt5Znk3OGdubDFIUFI0a0M1Y1Z5T2c5RlhNZmJpODlGM1hWNHBLdmdQQUQycHhmQ2xNeUpiNVE4R2J0cTZxMkJjL3pzdVVHWTRpYnJwR25EbWtXYmlpRWZYRmV3SlRBTmxITlcwT3JsU0l3S0VFbWVCaEYvMXIydjlwZVB6NStHOUxTRFdKdUl5dU1sLy9vOGgvd1pUUlh0RTYrWkhtYnBiOWpWMmF1ckU1VjFPWnlqMW5KcDlnaVlCd3JYWFpqTXdlVmVEelhyaDdUUFJ1dVgvb3JOa1dtMEs1WERpbGJIRW14S0h1UnZxTHVSRTNSSSt1L2w5OHdhbnZvYkJoRGpodUJmZz0ifQ.JmNKvf13ffYqfiK-0Sr-1OPGwN3qzEkQwhiIFA8MogQ'
			),
		));

		
		$response = curl_exec($curl);
		curl_close($curl);
		$result = json_decode($response);
		return $result->data[0]->storageNum;
		
	}

	function updateActiveProductStock(){

		$approved_products = $this->crud_model->getApprovedVendorProducts();
		$total_updated = 0;

		foreach($approved_products as $variant){
			sleep(1);
			$newqty = $this->getInventoryByVariant($variant['cj_variantid']);	
			if($newqty > 0){
				$this->crud_model->updateVariantStock($variant['cj_variantid'], $newqty);
			}	
			$total_updated++;
		}
		
		echo "Stock Status of " . $total_updated . " Products has been updated.";
	}

	function getApiProducts()
	{
		$data = array();
		$page_size = $this->config->item('page_size');

		$last_product_date = $this->getLastProductDateDESC() ? $this->getLastProductDateDESC() : date("Y-m-d H:i:s");

        
		//-1 second
		$dateString = "$last_product_date";
		$timestamp = strtotime($dateString);
		$newTimestamp = $timestamp - 1;
		
		$createTo = urlencode(date("Y-m-d H:i:s", $newTimestamp));

		$url = "https://developers.cjdropshipping.com/api2.0/v1/product/list?pageSize=$page_size&createTimeTo=$createTo";
	
		$accessToken = CJ_ACCESS_TOKEN;
		
		$ch = curl_init($url);
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // Return the response as a string
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('CJ-Access-Token: ' . $accessToken)); // Set the access token in the header
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  // Follow redirects
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification (not recommended for production)
		
		$response = curl_exec($ch);
		if (curl_errno($ch)) {
			echo 'cURL error: ' . curl_error($ch);
		}
		
		curl_close($ch);
		
		$res = json_decode($response);

		$data = $res->data->list;
		return $data;
	}

	public function add_stock_cjAPI()
	{
		$products = $this->getApiProducts();
		// echo "<pre>";
		// print_r($products);
		// die();
		$no=0;
		$up=0;
		$date = date('Y-m');

		$forbidden_category = [
			"9694B484-7EA0-4D71-993B-9CF02D24B271",
			"A6158EC0-C66D-456D-923C-E784EE432A02",
			"A7DE167B-ECFF-481E-A52A-2E7937BFAA95",
			"7D830BF3-03DB-4EBB-8A50-ED5F1231E17A",
			"8A22518D-0C6F-430D-8CD9-7E043062A279",
			"56F1151E-2544-4044-BB41-03081A532B2F"
		];


			foreach($products as $product){
			    
			    if($product->productNameEn == ""){
					continue;
				}
				
				$is_forbidden = in_array($product->categoryId, $forbidden_category);
				if(!$is_forbidden){
					//create time to upload
					$created = explode("T", $product->createTime);
					
					//means T wala timestamp exists
					if(count($created > 1)){
					$created_date = $created[0];
					$created_time = explode(".", $created[1])[0];
					$created = $created_date . " " . $created_time;
					}else{
					    $created = date("Y-m-d H:i:s");
					}
            

					$product_details = $this->getProductDetails($product->pid)->data;
					
					if(!$product_details){
					    continue;
					}
					
					$categories = $this->getCategoryFromVendor($product_details->categoryId);
							
					$product_data = array(
						'added_by' => '{"type":"vendor","id":"35"}',
						'category' => $categories->category,
						'sub_category' => $categories->sub_category,
						'third_sub_category' => $categories->third_sub_category_id,
						'featured' => 'ok',
						'title' => $product->productNameEn,
						'status' => 'ok',
						'brand' => 1,
						'vendor_id' => 20,
						'make_first' => 0,
						'created' => $created,
						'productkey' => $product_details->productKeyEn,
						'is_approved' => "1"
					);

					$this->db->insert('product', $product_data);
					$product_id = $this->db->insert_id();
					$file_name = $product_id . '-1.jpg';

					$this->db->set('front_image', "[\"$date\/$file_name\"]");
					$this->db->where('product_id', $product_id);
					$this->db->update('product');
					
					//image upload
					if (!file_exists("uploads/product_variants_image/$date")) {
                        mkdir("uploads/product_variants_image/$date", 0777, true);
                    }
                    
					$url= $product->productImage;
					$data = file_get_contents($url);
					$new = "uploads/product_variants_image/$date/$file_name";
					$q = file_put_contents($new, $data);

					$i=1;
					foreach($product_details->variants as $variant){
	
						$variant_image_name = $variant->pid ."-$i.jpg";
						//upload variant image
						$data = file_get_contents($variant->variantImage);
						$new = "uploads/product_variants_image/$date/$variant_image_name";
						$q = file_put_contents($new, $data);

                        if($variant->variantNameEn == ""){
                            $variant->variantNameEn = $product->productNameEn;
                        }
						$product_varient_data = array(
							'title' => $variant->variantNameEn,
							'product_id' => $product_id,
							'description' => $product_details->description,
							'selling_price' => $variant->variantSellPrice,
							'cost' => $product->sellPrice,
							'total_cost' => $product->sellPrice,
							'stock_status' => $product->listingCount,
							'supplier_sku' => $product->productSku,
							'seller_sku' => $product->pid,
							'upc' => $product->pid,
							'weight' => $product->productWeight,
							'actual_size' => "-",
							'color' => '["' . $variant->variantKey . '"]',
							'images' => "[\"$date\/$variant_image_name\"]",
							'is_download' => 1,
							'created' => $created
						);
						$this->db->insert('product_variants', $product_varient_data);
						$i++;
					
					}

				}
				$no++;
				echo ".";
			}
	  
		print_R("$no Products Added");
	}

	public function addCategoryIfNotExist($name, $id){
		$this->db->select("*");
		$this->db->from("category");
		$this->db->where("supplier_category_id", $id);
		$this->db->limit(1);
		$q = $this->db->get();
		if($q->num_rows() > 0){
			$data = $q->row();
			return $data->category_id;
		}
		$data['category_name'] = $name;
		$data['supplier_category_id'] = $id;
		$this->db->insert('category', $data);
		return $this->db->insert_id();
	}

	public function update_price()
	{
		exit;
		$data = $this->crud_model->getUploadedFilesForUpdate("price");
		if($data){

			$file_name = $data['file_name'];
			$file_id = $data['file_id'];

			$this->db->where("file_id" , $file_id);
            $this->db->set("completed", 2);
            $this->db->set("updated", date("Y-m-d h:i:s"));
            $this->db->update("uploaded_files");

			$fp = fopen("uploads/file/price_update/".$file_name, "r+");
			
			$count = 0;
			while($row = fgetcsv($fp))
			{
				$count++;
				if($count==1){
					continue;
				}
				if($data['completed']==2 && $count<$data['processed']){
					continue;
				}
				$upc = (float) $row[0]; // upc
				$seller_sku = $row[1]; // seller sku
				$selling_price = $row[2]; // selling_price 
				$discounted_price = $row[3]; // discount
				$status = $row[4]; // status
				
				if(empty($upc) && empty($seller_sku) && empty($selling_price) && empty($discounted_price) && empty($status)){
                  	$this->db->where("file_id" , $file_id);
		            $this->db->set("completed", 1);
		            $this->db->set("updated", date("Y-m-d h:i:s"));
		            $this->db->update("uploaded_files");
		            break;
                }

				echo "count ".$count."upc : ".$upc." seller sku ".$seller_sku."<br />";
				
				if(!is_numeric($selling_price) || $selling_price=="" || !is_numeric($selling_price) || $selling_price=="" || !is_numeric($status) || $status==""){
					continue;
				}

				$this->db->where("seller_sku",$seller_sku);
				$this->db->set("selling_price", $selling_price);
				$this->db->set("discount", ($selling_price - $discounted_price));
				$this->db->set("discounted_price", $discounted_price);
				$this->db->set("status", $status);
				$this->db->update("product_variants");

				$effected_rows = $this->db->affected_rows();
				
				$this->db->where("file_id" , $file_id);
				$this->db->set("processed","processed+1",FALSE);
				$this->db->set("pending_row","pending_row-1",FALSE);

	            if($effected_rows>0){
					$this->db->set("submitted","submitted+1",FALSE);
				}else{
					$this->db->set("errors","errors+1",FALSE);
				}
				$this->db->set("updated", date("Y-m-d h:i:s"));
				$this->db->update("uploaded_files");
			}
			$this->db->where("file_id" , $file_id);
			$this->db->set("completed", 1);
			$this->db->set("updated", date("Y-m-d h:i:s"));
			$this->db->update("uploaded_files");
		}
	}

	function download_dropshiptown_file()
	{
		exit;
		$url = "https://www.dropshiptown.com/dtset/dwnl_splr_csv.php?cust_id=4652&prod_id=3&sup_id=ctg&add_profit=ctg_profit&supplier=Warehouse%2090058";
		$name = "dropshiptown_".time().".csv";
		$content  = file_get_contents($url);
		$fp = fopen("uploads/file/dropshiptown/".$name , "w+");
		if(fwrite($fp, $content)){

            $read_file = "uploads/file/dropshiptown/".$name;
            $file = file($read_file);
            $total_rows = count($file)-1;
            
            $data = array(
				"file_name"=>$name,
				"total_row"=>$total_rows,
				"pending_row"=>$total_rows,
				"file_type"=>"api_dropshiptown",	
				"created"=>date("Y-m-d h:i:s")
			);
			$this->db->insert("uploaded_files",$data);
			echo "File downloaded";
			fclose($fp);
		}else{
			echo "Error while downloading file from >>> ".$url;
		}
	}

	function vendor_api_file()
	{
		exit;
		$data = $this->crud_model->getUploadedFilesForUpdate("api_dropshiptown");
		if($data){

			$file_name = $data['file_name'];
			$file_id = $data['file_id'];

			$this->db->where("file_id" , $file_id);
            $this->db->set("completed", 2);
            $this->db->set("updated", date("Y-m-d h:i:s"));
            $this->db->update("uploaded_files");

			$fp = fopen("uploads/file/dropshiptown/".$file_name, "r+");
			
			$count = 0;
			$supplier_sku_ind = 0;
			$qty_ind = 0;
			$first_row_col_counter = 0;

			while($row = fgetcsv($fp))
			{
				/* finding sku and qty column */
				foreach($row as $finding_column){
					if(trim($finding_column)=="sku"){
						$supplier_sku_ind = $first_row_col_counter;
					}
					if(trim($finding_column)=="qty"){
						$qty_ind = $first_row_col_counter;
					}
					$first_row_col_counter++;
				}

				$count++;
				if($count==1){
					continue;
				}
				if($data['completed']==2 && $count<$data['processed']){
					continue;
				}

				$supplier_sku = $row[$supplier_sku_ind]; // supplier_sku
				$qty = $row[$qty_ind]; // qty
				
				if(empty($supplier_sku) && empty($qty))
				{
                  	$this->db->where("file_id" , $file_id);
		            $this->db->set("completed", 1);
		            $this->db->set("updated", date("Y-m-d h:i:s"));
		            $this->db->update("uploaded_files");
		            break;
                }

				echo "count >> ".$count."supplier sku  >>  ".$supplier_sku." qty  >>  ".$qty."<br />";
				
				if(!is_numeric($qty) || $qty=="" || $supplier_sku==""){
					continue;
				}
				
				$this->db->where("supplier_sku" , $supplier_sku);
				$this->db->set("stock_status", $qty);
				$this->db->update("product_variants");
				$effected_rows = $this->db->affected_rows();
				
				$this->db->where("file_id" , $file_id);
				$this->db->set("processed","processed+1",FALSE);
				$this->db->set("pending_row","pending_row-1",FALSE);

	            if($effected_rows>0){
					$this->db->set("submitted","submitted+1",FALSE);
				}else{
					$this->db->set("errors","errors+1",FALSE);
				}
				$this->db->set("updated", date("Y-m-d h:i:s"));
				$this->db->update("uploaded_files");
			}
			$this->db->where("file_id" , $file_id);
			$this->db->set("completed", 1);
			$this->db->set("updated", date("Y-m-d h:i:s"));
			$this->db->update("uploaded_files");
		}
	}

} /* end of class */