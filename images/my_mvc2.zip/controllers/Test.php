<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Test extends CI_Controller{

	function __construct()
    {
        parent::__construct();
		
    }
	
	public function index()
	{
		/*
			[firstname] => zeshan
            [lastname] => rehman
            [address1] => asdfasdfdasf
            [address2] => 
            [zip] => 75622
            [email] => zeshan@test.com
            [phone] => 1231111	
		*/
			$lineItemsArr['lineItem'] = array 
										(
											array 
											(
											  'itemId' => '9',
											  'name' => 'vase',
											  'description' => 'Cannes logo',
											  'quantity' => '18',
											  'unitPrice' => '45.00',
											),
											array
											(
											  'itemId' => '20',
											  'name' => 'Chart',
											  'description' => 'My Chart',
											  'quantity' => '1',
											  'unitPrice' => '4.00',
											),
										);
										
			$tax['tax'] = 	array
								(
									"amount" 		=> "4.26",
									"name" 			=> "level2 tax name",
									"description" 	=> "level2 tax"
								);	
			//$lineItemsArr =
									  
			//echo '<pre>'. print_r( (object) $lineItemsArr, 1).'</pre>'; die();
		
		$data 	= 	array(
						'amount' 		=> "2.25",
						'card_number' 	=> '4111111111111111',
						'cv_code' 		=> '123',
						'expiryyear' 	=> '2020',
						'expirymonth' 	=> '08',						
						'firstname' 	=> 'zeshan',
						'lastname' 		=> 'rehman',
						'address' 		=> 'Office # 204, Community Hall & Office Complex, PECHS',
						'zip' 			=> '75622',
						'email' 		=> 'zeshan@test.com',
						'phone' 		=> '1231111',
						'user_id' 		=> '11',
						'city' 			=> 'fsdfsd',
						'state' 		=> 'stats_dens_f(x, dfr1, dfr2)',
						'country' 		=> 'sdfsd',
						'loyalty_num' 	=> '',
						'ref' 			=> 'ref' . time(),
						'invoice_numb'	=> '45'.time(),
						'orderInfo'		=> '1 Metrer USB 2.0 A Male to 2.0mm Power Charger Cord Cable for Nokia E71 E90 N70 N71 N72 - Black Rs. 45 Quantity: 2 Seller: Mega Store (Lahore)',
						'lineItem'		=> (object) $lineItemsArr,
					);
		echo "<pre>";print_r($data);die();
		$this->load->library('Authrize', 'authrize');
		$res = $this->authrize->chargeCreditCardDetail($data);
		echo "<pre>";print_r($res);
	}
}