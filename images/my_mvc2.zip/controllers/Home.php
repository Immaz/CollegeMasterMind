<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
require_once APPPATH . "libraries/PhpSpreadsheet/vendor/autoload.php";
class Home extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        //$this->output->enable_profiler(TRUE);
        $this->load->database();
        $this->load->library('paypal');
        // $this->load->library('twoCheckout_Lib');
        // $this->load->library('vouguepay');
        // $this->load->library('pum');
        $this->load->model('crud_model');
        $this->load->model('email_model');
        $this->load->model('html_model');
        $this->load->model('wallet_model');
        $this->load->helper('cookie');


        /*cache control*/
        //ini_set("user_agent","My-Great-Marketplace-App");
        $cache_time = $this->db->get_where('general_settings', array('type' => 'cache_time'))->row()->value;
        if (!$this->input->is_ajax_request()) {
            $this->output->set_header('HTTP/1.0 200 OK');
            $this->output->set_header('HTTP/1.1 200 OK');
            $this->output->set_header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT');
            $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate');
            $this->output->set_header('Cache-Control: post-check=0, pre-check=0');
            $this->output->set_header('Pragma: no-cache');
            if (
                $this->router->fetch_method() == 'index' ||
                $this->router->fetch_method() == 'featured_item' ||
                $this->router->fetch_method() == 'others_product' ||
                $this->router->fetch_method() == 'bundled_product' ||
                $this->router->fetch_method() == 'all_brands' ||
                $this->router->fetch_method() == 'all_category' ||
                $this->router->fetch_method() == 'all_vendor' ||
                $this->router->fetch_method() == 'blog' ||
                $this->router->fetch_method() == 'blog_view' ||
                $this->router->fetch_method() == 'vendor' ||
                $this->router->fetch_method() == 'category'
            ) {
                $this->output->cache($cache_time);
            }
        }
        $currency = $this->session->userdata('currency');
        $language = $this->session->userdata('language');
        if (!isset($currency)) {
            $this->session->set_userdata('currency', $this->db->get_where('business_settings', array('type' => 'home_def_currency'))->row()->value);
        }
        if (!isset($language)) {
            $this->session->set_userdata('language', $this->db->get_where('general_settings', array('type' => 'language'))->row()->value);
        }
        setcookie('lang', $this->session->userdata('language'), time() + (86400), "/");
        setcookie('curr', $this->session->userdata('currency'), time() + (86400), "/");
    }

    /* FUNCTION: Loads Homepage*/





    public function index()
    {
        $this->get_ranger_val();
        $home_style = $this->db->get_where('ui_settings', array('type' => 'home_page_style'))->row()->value;

        if ($this->config->item('demo_mode')) {
            $home_style = isset($_REQUEST['requested_homepage']) ? $_REQUEST['requested_homepage'] : $this->db->get_where('ui_settings', array('type' => 'home_page_style'))->row()->value;
        }
        $navigation = $this->crud_model->getMultiLevelNavigation();
        $page_data['page_name'] = "home/home" . $home_style;
        $page_data['asset_page'] = "home";
        $page_data['page_title'] = translate('home');
        $page_data['navigation'] = $navigation;
        // $this->benchmark->mark('code_start');
        $this->load->view('front/index', $page_data);
        // $this->benchmark->mark('code_end');
    }

    // function product_list_set()
    // {
    //   $speciality = $this->input->post('speciality');
    //   $limitfrom = $this->input->post('limitfrom');
    //   $limitto = $this->input->post('limitto');
    //   $id = $this->input->post('id');
    //   $limit = '20';
    //   $data = $this->crud_model->product_list_set($speciality,$limit,$id);
    //   echo json_encode($data);
    // }
    function ajax_product_list()
    {
        $id = $this->input->post('id');
        $limit = $this->input->post('limit');
        $col = $this->input->post("col");
        $offset = $this->input->post('offset');
        $category_id = $this->input->post('category_id');
        $sub_category_id = $this->input->post('sub_category_id');
        $third_sub_category_id = $this->input->post('third_sub_category_id');
        $sort_by = $this->input->post('sort_by');
        $price = $this->input->post('price');
        $text = $this->input->post('text');
        $size = $this->input->post('size');
        $color = $this->input->post('color');
        $shape = $this->input->post('shape');
        $brand = $this->input->post('brand');
        $already_appeared_products = json_decode($this->input->post('product_ids'));

        $data = $this->crud_model->get_products($offset, $limit, $category_id, $sub_category_id, $third_sub_category_id, $brand, $sort_by, $price, $text, $size, $color, $shape, false, $already_appeared_products);

        $boxgrid = '';
        $box_style = $this->db->get_where('ui_settings', array('ui_settings_id' => 29))->row()->value;
        foreach ($data as $row) {
            $newProductIDS[] = $row['product_id'];

            $boxgrid .= '<div class="pd  col-sm-6 col-xs-6 col-md-' . $col . '" data-aos="flip-left" data-aos-mirror="true" data-aos-duration="1000" data-aos-once="true" style="margin-top: 5px;">';
            $boxgrid .= $this->html_model->ajax_product_box($row, 'grid', $box_style);
            $boxgrid .= '</div>';
        }
        echo $boxgrid . (($newProductIDS) ? "<data value=".json_encode($newProductIDS)."></data>" : '');
    }

    function top_bar_right()
    {
        $this->load->view('front/components/top_bar_right.php');
    }

    function abnl($abnl)
    {
        //echo $this->wallet_model->add_user_balance($abnl);
    }

    function load_portion($page = '')
    {
        $page = str_replace('-', '/', $page);
        $this->load->view('front/' . $page);
    }

    function vendor_profile($para1 = '', $para2 = '')
    {
        if ($this->crud_model->get_settings_value('general_settings', 'vendor_system') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        if ($this->crud_model->get_settings_value('general_settings', 'show_vendor_website') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        if ($para1 == 'get_slider') {
            $page_data['vendor_id'] = $para2;
            $this->db->where("status", "ok");
            $this->db->where('added_by', json_encode(array('type' => 'vendor', 'id' => $para2)));
            $page_data['sliders'] = $this->db->get('slides')->result_array();
            $this->load->view('front/vendor/public_profile/home/slider', $page_data);
        } else {
            $status = $this->db->get_where('vendor', array('vendor_id' => $para1))->row()->status;
            if ($status !== 'approved') {
                redirect(base_url(), 'refresh');
            }
            $page_data['page_title'] = $this->crud_model->get_type_name_by_id('vendor', $para1, 'display_name');
            $page_data['asset_page'] = "vendor_public_home";
            $page_data['page_name'] = "vendor/public_profile";
            $page_data['content'] = "home";
            $this->db->where("status", "ok");
            $this->db->where('added_by', json_encode(array('type' => 'vendor', 'id' => $para1)));
            $page_data['sliders'] = $this->db->get('slides')->result_array();
            $page_data['vendor_info'] = $this->db->get_where('vendor', array('vendor_id' => $para1))->result_array();
            $page_data['vendor_tags'] = $this->db->get_where('vendor', array('vendor_id' => $para1))->row()->keywords;
            $page_data['vendor_id'] = $para1;
            $this->load->view('front/index', $page_data);
        }
    }

    /* FUNCTION: Loads Category filter page */
    function vendor_category($vendor, $para1 = "", $para2 = "", $min = "", $max = "", $text = '')
    {
        if ($this->crud_model->get_settings_value('general_settings', 'vendor_system') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        if ($this->crud_model->get_settings_value('general_settings', 'show_vendor_website') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        if ($para2 == "") {
            $page_data['all_products'] = $this->db->get_where('product', array(
                'category' => $para1
            ))->result_array();
        } else if ($para2 != "") {
            $page_data['all_products'] = $this->db->get_where('product', array(
                'sub_category' => $para2
            ))->result_array();
        }

        $brand_sub = explode('-', $para2);

        $sub = 0;
        $brand = 0;

        if (isset($brand_sub[0])) {
            $sub = $brand_sub[0];
        }
        if (isset($brand_sub[1])) {
            $brand = $brand_sub[1];
        }

        $page_data['range'] = $min . ';' . $max;
        $page_data['page_name'] = "vendor/public_profile";
        $page_data['content'] = "product_list";
        $page_data['asset_page'] = "product_list_other";
        $page_data['page_title'] = translate('products');
        $page_data['all_category'] = $this->db->get('category')->result_array();
        $page_data['all_sub_category'] = $this->db->get('sub_category')->result_array();
        $page_data['cur_sub_category'] = $sub;
        $page_data['cur_brand'] = $brand;
        $page_data['cur_category'] = $para1;
        $page_data['vendor_id'] = $vendor;
        $page_data['text'] = $text;
        $page_data['category_data'] = $this->db->get_where('category', array(
            'category_id' => $para1
        ))->result_array();
        $this->load->view('front/index', $page_data);
    }

    function vendor_featured($para1 = '', $para2 = '')
    {
        if ($this->crud_model->get_settings_value('general_settings', 'vendor_system') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        if ($this->crud_model->get_settings_value('general_settings', 'show_vendor_website') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        if ($para1 == 'get_list') {
            $page_data['vendor_id'] = $para2;
            $this->load->view('front/vendor/public_profile/featured/list_page', $page_data);
        } elseif ($para1 == 'get_ajax_list') {
            $this->load->library('Ajax_pagination');

            $vendor_id = $this->input->post('vendor');

            $this->db->where('status', 'ok');
            $this->db->where('vendor_featured', 'ok');
            $this->db->where('added_by', json_encode(array('type' => 'vendor', 'id' => $vendor_id)));
            // pagination
            $config['total_rows'] = $this->db->count_all_results('product');
            $config['base_url'] = base_url() . 'index.php?home/listed/';
            $config['per_page'] = 8;
            $config['uri_segment'] = 5;
            $config['cur_page_giv'] = $para2;

            $function = "filter_blog('0')";
            $config['first_link'] = '&laquo;';
            $config['first_tag_open'] = '<li><a onClick="' . $function . '">';
            $config['first_tag_close'] = '</a></li>';

            $rr = ($config['total_rows'] - 1) / $config['per_page'];
            $last_start = floor($rr) * $config['per_page'];
            $function = "filter_vendor_featured('" . $last_start . "')";
            $config['last_link'] = '&raquo;';
            $config['last_tag_open'] = '<li><a onClick="' . $function . '">';
            $config['last_tag_close'] = '</a></li>';

            $function = "filter_vendor_featured('" . ($para2 - $config['per_page']) . "')";
            $config['prev_tag_open'] = '<li><a onClick="' . $function . '">';
            $config['prev_tag_close'] = '</a></li>';

            $function = "filter_vendor_featured('" . ($para2 + $config['per_page']) . "')";
            $config['next_link'] = '&rsaquo;';
            $config['next_tag_open'] = '<li><a onClick="' . $function . '">';
            $config['next_tag_close'] = '</a></li>';

            $config['full_tag_open'] = '<ul class="pagination">';
            $config['full_tag_close'] = '</ul>';

            $config['cur_tag_open'] = '<li class="active"><a>';
            $config['cur_tag_close'] = '<span class="sr-only">(current)</span></a></li>';

            $function = "filter_vendor_featured(((this.innerHTML-1)*" . $config['per_page'] . "))";
            $config['num_tag_open'] = '<li><a onClick="' . $function . '">';
            $config['num_tag_close'] = '</a></li>';
            $this->ajax_pagination->initialize($config);

            $this->db->where('status', 'ok');
            $this->db->where('vendor_featured', 'ok');
            $this->db->where('added_by', json_encode(array('type' => 'vendor', 'id' => $vendor_id)));

            $page_data['products'] = $this->db->get('product', $config['per_page'], $para2)->result_array();
            $page_data['count'] = $config['total_rows'];

            $this->load->view('front/vendor/public_profile/featured/ajax_list', $page_data);
        } else {
            $page_data['page_title'] = translate('vendor_featured_product');
            $page_data['asset_page'] = "product_list_other";
            $page_data['page_name'] = "vendor/public_profile";
            $page_data['content'] = "featured";
            $page_data['vendor_id'] = $para1;
            $this->load->view('front/index', $page_data);
        }
    }

    function all_vendor()
    {
        if ($this->crud_model->get_settings_value('general_settings', 'vendor_system') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        if ($this->crud_model->get_settings_value('general_settings', 'show_vendor_website') !== 'ok') {
            redirect(base_url(), 'refresh');
        }

        $page_data['page_name'] = "vendor/all";
        $page_data['asset_page'] = "all_vendor";
        $page_data['page_title'] = translate('all_vendors');
        $this->load->view('front/index', $page_data);
    }

    function vendor($vendor_id)
    {
        if ($this->crud_model->get_settings_value('general_settings', 'vendor_system') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        if ($this->crud_model->get_settings_value('general_settings', 'show_vendor_website') !== 'ok') {
            redirect(base_url(), 'refresh');
        }
        $vendor_system = $this->db->get_where('general_settings', array('type' => 'vendor_system'))->row()->value;
        if (
            $vendor_system == 'ok' &&
            $this->db->get_where('vendor', array('vendor_id' => $vendor_id))->row()->status == 'approved'
        ) {
            $min = $this->get_range_lvl('added_by', '{"type":"vendor","id":"' . $vendor_id . '"}', "min");
            $max = $this->get_range_lvl('added_by', '{"type":"vendor","id":"' . $vendor_id . '"}', "max");
            $this->db->order_by('product_id', 'desc');
            $page_data['featured_data'] = $this->db->get_where('product', array(
                'featured' => "ok",
                'status' => 'ok',
                'added_by' => '{"type":"vendor","id":"' . $vendor_id . '"}'
            ))->result_array();
            $page_data['range'] = $min . ';' . $max;
            $page_data['all_category'] = $this->db->get('category')->result_array();
            $page_data['all_sub_category'] = $this->db->get('sub_category')->result_array();
            $page_data['page_name'] = 'vendor_home';
            $page_data['vendor'] = $vendor_id;
            $page_data['page_title'] = $this->db->get_where('vendor', array('vendor_id' => $vendor_id))->row()->display_name;
            $this->load->view('front/index', $page_data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }

    function surfer_info()
    {
        $this->crud_model->ip_data();
    }

    function pogg()
    {
        $id = 17;
        $user = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->user;
        $amount = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->amount;
        $this->wallet_model->add_user_balance($amount, $user);
    }

    /* FUNCTION: Verify paypal payment by IPN*/
    function wallet_paypal_ipn()
    {
        if ($this->paypal->validate_ipn() == true) {
            $data['status'] = 'paid';
            $data['payment_details'] = json_encode($_POST);
            $id = $_POST['custom'];
            $this->db->where('wallet_load_id', $id);
            $this->db->update('wallet_load', $data);

            $user = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->user;
            $amount = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->amount;
            $balance = base64_decode($this->db->get_where('user', array('user_id' => $user))->row()->wallet);
            $new_balance = base64_encode($balance + $amount);
            $this->db->where('user_id', $user);
            $this->db->update('user', array('wallet' => $new_balance));
        }
    }


    /* FUNCTION: Loads after cancelling paypal*/
    function wallet_paypal_cancel()
    {
        $invoice_id = $this->session->userdata('wallet_id');
        $this->db->where('wallet_load_id', $invoice_id);
        $this->db->delete('wallet_load');
        $this->session->set_userdata('wallet_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
    }

    /* FUNCTION: Loads after successful paypal payment*/
    function wallet_paypal_success()
    {
        $this->session->set_userdata('wallet_id', '');
        redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
    }

    function wallet_twocheckout_success()
    {
        /*$this->twocheckout_lib->set_acct_info('532001', 'tango', 'Y');*/
        $c2_user = $this->db->get_where('business_settings', array('type' => 'c2_user'))->row()->value;
        $c2_secret = $this->db->get_where('business_settings', array('type' => 'c2_secret'))->row()->value;

        $this->twocheckout_lib->set_acct_info($c2_user, $c2_secret, 'Y');
        $data2['response'] = $this->twocheckout_lib->validate_response();
        //var_dump($this->twocheckout_lib->validate_response());
        $status = $data2['response']['status'];
        if ($status == 'pass') {
            $data1['status'] = 'paid';
            $data1['payment_details'] = json_encode($this->twocheckout_lib->validate_response());
            $wallet_id = $this->session->userdata('wallet_id');
            $this->db->where('wallet_load_id', $wallet_id);
            $this->db->update('wallet_load', $data1);
            $user = $this->db->get_where('wallet_load', array('wallet_load_id' => $wallet_id))->row()->user;
            $amount = $this->db->get_where('wallet_load', array('wallet_load_id' => $wallet_id))->row()->amount;

            $user = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->user;
            $amount = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->amount;
            $balance = base64_decode($this->db->get_where('user', array('user_id' => $user))->row()->wallet);
            $new_balance = base64_encode($balance + $amount);
            $this->db->where('user_id', $user);
            $this->db->update('user', array('wallet' => $new_balance));
            redirect(base_url() . 'home/profile/part/wallet/', 'refresh');

        } else {
            $wallet_id = $this->session->userdata('wallet_id');
            $this->db->where('wallet_load_id', $wallet_id);
            $this->db->delete('wallet_load');
            $this->session->set_userdata('wallet_id', '');
            $this->session->set_flashdata('alert', 'payment_cancel');
            redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
        }
    }

    function getApiProducts()
    {

        $url = 'https://developers.cjdropshipping.com/api2.0/v1/product/list';
        $accessToken = 'eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIxMTQ0NCIsInR5cGUiOiJBQ0NFU1NfVE9LRU4iLCJzdWIiOiJicUxvYnFRMGxtTm55UXB4UFdMWnlpWE82YzZWM2xoTVhUTUNaLyt5Znk3OGdubDFIUFI0a0M1Y1Z5T2c5RlhNZmJpODlGM1hWNHBLdmdQQUQycHhmQ2xNeUpiNVE4R2J0cTZxMkJjL3pzdVVHWTRpYnJwR25EbWtXYmlpRWZYRmV3SlRBTmxITlcwT3JsU0l3S0VFbWVCaEYvMXIydjlwZVB6NStHOUxTRFdKdUl5dU1sLy9vOGgvd1pUUlh0RTYrWkhtYnBiOWpWMmF1ckU1VjFPWnlqMW5KcDlnaVlCd3JYWFpqTXdlVmVEelhyaDdUUFJ1dVgvb3JOa1dtMEs1WERpbGJIRW14S0h1UnZxTHVSRTNSSSt1L2w5OHdhbnZvYkJoRGpodUJmZz0ifQ.JmNKvf13ffYqfiK-0Sr-1OPGwN3qzEkQwhiIFA8MogQ';

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  // Return the response as a string
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('CJ-Access-Token: ' . $accessToken)); // Set the access token in the header
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);  // Follow redirects
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL verification (not recommended for production)

        $response = curl_exec($ch);

        if (curl_errno($ch)) {
            echo 'cURL error: ' . curl_error($ch);
        }

        curl_close($ch);

        $res = json_decode($response);

        echo "<pre>";
        print_r($res->data->list);
    }

    /* FUNCTION: Verify vouguepay payment by IPN*/
    function wallet_vouguepay_ipn()
    {
        $res = $this->vouguepay->validate_ipn();
        $wallet_id = $res['merchant_ref'];
        $merchant_id = 'demo';
        if ($res['total'] !== 0 && $res['status'] == 'Approved' && $res['merchant_id'] == $merchant_id) {
            $data['status'] = 'paid';
            $data['details'] = json_encode($res);
            $this->db->where('wallet_load_id', $wallet_id);
            $this->db->update('wallet_load', $data);

            $user = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->user;
            $amount = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->amount;
            $balance = base64_decode($this->db->get_where('user', array('user_id' => $user))->row()->wallet);
            $new_balance = base64_encode($balance + $amount);
            $this->db->where('user_id', $user);
            $this->db->update('user', array('wallet' => $new_balance));
        }
    }

    /* FUNCTION: Loads after cancelling vouguepay*/
    function wallet_vouguepay_cancel()
    {
        $wallet_id = $this->session->userdata('wallet_id');
        $this->db->where('wallet_load_id', $wallet_id);
        $this->db->delete('wallet_load');
        $this->session->set_userdata('wallet_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
    }

    /* FUNCTION: Loads after successful vouguepay payment*/
    function wallet_vouguepay_success()
    {
        $this->session->set_userdata('wallet_id', '');
        redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
    }

    function wallet_pum_success()
    {
        $status = $_POST["status"];
        $firstname = $_POST["firstname"];
        $amount = $_POST["amount"];
        $txnid = $_POST["txnid"];
        $posted_hash = $_POST["hash"];
        $key = $_POST["key"];
        $productinfo = $_POST["productinfo"];
        $email = $_POST["email"];
        $udf1 = $_POST['udf1'];
        $salt = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_salt', 'value');

        if (isset($_POST["additionalCharges"])) {
            $additionalCharges = $_POST["additionalCharges"];
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '||||||||||' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {
            $retHashSeq = $salt . '|' . $status . '||||||||||' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
        $hash = hash("sha512", $retHashSeq);

        if ($hash != $posted_hash) {
            $invoice_id = $this->session->userdata('wallet_id');
            $this->db->where('wallet_load_id', $invoice_id);
            $this->db->delete('wallet_load');
            $this->session->set_userdata('wallet_id', '');
            $this->session->set_flashdata('alert', 'payment_cancel');
            redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
        } else {

            $data['status'] = 'paid';
            $data['payment_details'] = json_encode($_POST);
            $id = $_POST['custom'];
            $this->db->where('wallet_load_id', $id);
            $this->db->update('wallet_load', $data);

            $user = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->user;
            $amount = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->amount;
            $balance = base64_decode($this->db->get_where('user', array('user_id' => $user))->row()->wallet);
            $new_balance = base64_encode($balance + $amount);
            $this->db->where('user_id', $user);
            $this->db->update('user', array('wallet' => $new_balance));

            $this->session->set_userdata('wallet_id', '');
            redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
        }
    }

    function wallet_pum_failure()
    {
        $invoice_id = $this->session->userdata('wallet_id');
        $this->db->where('wallet_load_id', $invoice_id);
        $this->db->delete('wallet_load');
        $this->session->set_userdata('wallet_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
    }

    function wallet_sslcommerz_success()
    {
        $id = $this->session->userdata('wallet_id');

        if ($id != '' || !empty($id)) {
            $data['status'] = 'paid';

            $this->db->where('wallet_load_id', $id);
            $this->db->update('wallet_load', $data);

            $user = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->user;
            $amount = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->amount;
            $balance = base64_decode($this->db->get_where('user', array('user_id' => $user))->row()->wallet);
            $new_balance = base64_encode($balance + $amount);
            $this->db->where('user_id', $user);
            $this->db->update('user', array('wallet' => $new_balance));

            $this->session->set_userdata('wallet_id', '');
            redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
        } else {
            redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
        }
    }

    function wallet_sslcommerz_fail()
    {
        $invoice_id = $this->session->userdata('wallet_id');
        $this->db->where('wallet_load_id', $invoice_id);
        $this->db->delete('wallet_load');
        $this->session->set_userdata('wallet_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
    }

    function wallet_sslcommerz_cancel()
    {
        $invoice_id = $this->session->userdata('wallet_id');
        $this->db->where('wallet_load_id', $invoice_id);
        $this->db->delete('wallet_load');
        $this->session->set_userdata('wallet_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
    }

    /* FUNCTION: Loads Customer Profile Page */
    function profile($para1 = "", $para2 = "", $para3 = "")
    {

        if ($this->session->userdata('user_login') != "yes") {
            redirect(base_url(), 'refresh');
        }
        if ($para1 == "info") {
            $page_data['user_info'] = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->result_array();
            $this->load->view('front/user/profile', $page_data);
        } elseif ($para1 == "wishlist") {
            $id = $this->session->userdata('user_id');

            $ids = json_decode($this->db->get_where('user', array('user_id' => $id))->row()->wishlist, true);
            if (!is_array($ids) || count($ids) == 0) {
                $whishlist_data = array();
            } else {
                $this->db->where_in('product_variants_id', $ids);
                $whishlist_data = $this->db->select('p.front_image, pv.*')->join('product p', 'p.product_id = pv.product_id', 'left')->get('product_variants pv')->result_array();
            }
            $page_data['wishlist'] = $whishlist_data;
            $this->load->view('front/user/wishlist', $page_data);
        } elseif ($para1 == "uploaded_products") {
            $this->load->view('front/user/uploaded_products');
        } elseif ($para1 == "uploaded_product_status") {
            $page_data['customer_product_id'] = $para2;
            $this->load->view('front/user/uploaded_product_status', $page_data);
        } elseif ($para1 == "update_prod_status") {
            $data['is_sold'] = $this->input->post('is_sold');
            $this->db->where('customer_product_id', $para2);
            $this->db->update('customer_product', $data);
            redirect(base_url() . 'home/profile/part/uploaded_products', 'refresh');
        } elseif ($para1 == "package_payment_info") {
            $this->load->view('front/user/package_payment_info');
        } elseif ($para1 == "view_package_details") {
            $info = $this->db->get_where('package_payment', array('package_payment_id' => $para2))->row();
            $page_info['det']['status'] = $info->payment_status;
            $page_info['id'] = $para2;
            $page_info['payment_details'] = $info->payment_details;
            $this->load->view('front/user/view_package_details', $page_info);
        } elseif ($para1 == "package_set_info") {
            $data['payment_status'] = 'pending';
            $data['payment_details'] = $this->input->post('payment_details');
            $data['payment_timestamp'] = time();
            if (!empty($this->input->post('payment_details'))) {
                $this->db->where('package_payment_id', $para2);
                $this->db->update('package_payment', $data);
            }
            echo 'done';
        } elseif ($para1 == "wallet") {
            if ($this->crud_model->get_type_name_by_id('general_settings', '84', 'value') !== 'ok') {
                redirect(base_url() . 'home');
            }
            if ($para2 == "add_view") {
                $this->load->view('front/user/add_wallet');
            } else if ($para2 == "info_view") {
                $info = $this->db->get_where('wallet_load', array('wallet_load_id' => $para3))->row();
                $page_info['det']['status'] = $info->status;
                //$page_info['det']['status'] = $info->status;
                $page_info['id'] = $para3;
                $page_info['payment_info'] = $info->payment_details;
                $this->load->view('front/user/wallet_info', $page_info);
            } else if ($para2 == "add") {
                $grand_total = $this->input->post('amount');
                $amount_in_usd = $grand_total;
                $method = $this->input->post('method_0');
                if ($method == 'paypal') {
                    $data['user'] = $this->session->userdata('user_id');
                    $data['method'] = $this->input->post('method_0');
                    $data['amount'] = $grand_total;
                    $data['status'] = 'due';
                    $data['payment_details'] = '[]';
                    $data['timestamp'] = time();
                    $this->db->insert('wallet_load', $data);
                    $id = $this->db->insert_id();
                    $this->session->set_userdata('wallet_id', $id);

                    $paypal_email = $this->crud_model->get_type_name_by_id('business_settings', '1', 'value');

                    /****TRANSFERRING USER TO PAYPAL TERMINAL****/
                    $this->paypal->add_field('rm', 2);
                    $this->paypal->add_field('no_note', 0);
                    $this->paypal->add_field('cmd', '_xclick');

                    //$this->paypal->add_field('amount', $this->cart->format_number($amount_in_usd));
                    $this->paypal->add_field('amount', $amount_in_usd);

                    //$this->paypal->add_field('amount', $grand_total);
                    $this->paypal->add_field('custom', $id);
                    $this->paypal->add_field('business', $paypal_email);
                    $this->paypal->add_field('notify_url', base_url() . 'home/wallet_paypal_ipn');
                    $this->paypal->add_field('cancel_return', base_url() . 'home/wallet_paypal_cancel');
                    $this->paypal->add_field('return', base_url() . 'home/wallet_paypal_success');

                    $this->paypal->submit_paypal_post();
                    // submit the fields to paypal
                } else if ($method == 'c2') {
                    $data['user'] = $this->session->userdata('user_id');
                    $data['method'] = $this->input->post('method_0');
                    $data['amount'] = $grand_total;
                    $data['status'] = 'due';
                    $data['payment_details'] = '[]';
                    $data['timestamp'] = time();
                    $this->db->insert('wallet_load', $data);
                    $id = $this->db->insert_id();
                    $this->session->set_userdata('wallet_id', $id);

                    $c2_user = $this->db->get_where('business_settings', array('type' => 'c2_user'))->row()->value;
                    $c2_secret = $this->db->get_where('business_settings', array('type' => 'c2_secret'))->row()->value;


                    $this->twocheckout_lib->set_acct_info($c2_user, $c2_secret, 'Y');
                    $this->twocheckout_lib->add_field('sid', $this->twocheckout_lib->sid);   //Required - 2Checkout account number
                    $this->twocheckout_lib->add_field('cart_order_id', $id);
                    //Required - Cart ID
                    $this->twocheckout_lib->add_field('total', $this->cart->format_number($amount_in_usd));

                    $this->twocheckout_lib->add_field('x_receipt_link_url', base_url() . 'home/wallet_twocheckout_success');
                    $this->twocheckout_lib->add_field('demo', $this->twocheckout_lib->demo);                    //Either Y or N

                    $this->twocheckout_lib->submit_form();
                } else if ($method == 'vp') {
                    $vp_id = $this->db->get_where('business_settings', array('type' => 'vp_merchant_id'))->row()->value;

                    $data['user'] = $this->session->userdata('user_id');
                    $data['method'] = $this->input->post('method_0');
                    $data['amount'] = $grand_total;
                    $data['status'] = 'due';
                    $data['payment_details'] = '[]';
                    $data['timestamp'] = time();
                    $this->db->insert('wallet_load', $data);
                    $id = $this->db->insert_id();
                    $this->session->set_userdata('wallet_id', $id);

                    /****TRANSFERRING USER TO vouguepay TERMINAL****/
                    $this->vouguepay->add_field('v_merchant_id', $vp_id);
                    $this->vouguepay->add_field('merchant_ref', $id);
                    $this->vouguepay->add_field('memo', 'Wallet Money Load');

                    $this->vouguepay->add_field('total', $amount_in_usd);

                    $this->vouguepay->add_field('notify_url', base_url() . 'home/wallet_vouguepay_ipn');
                    $this->vouguepay->add_field('fail_url', base_url() . 'home/wallet_vouguepay_cancel');
                    $this->vouguepay->add_field('success_url', base_url() . 'home/wallet_vouguepay_success');

                    $this->vouguepay->submit_vouguepay_post();
                    // submit the fields to vouguepay
                } else if ($method == 'stripe') {
                    if ($this->input->post('stripeToken')) {

                        $stripe_api_key = $this->db->get_where('business_settings', array('type' => 'stripe_secret'))->row()->value;
                        require_once(APPPATH . 'libraries/stripe-php/init.php');
                        \Stripe\Stripe::setApiKey($stripe_api_key); //system payment settings
                        $user_email = $this->db->get_where('user', array('user_id' => $user))->row()->email;

                        $usera = \Stripe\Customer::create(array(
                            'email' => $user_email, // customer email id
                            'card' => $_POST['stripeToken']
                        ));

                        $charge = \Stripe\Charge::create(array(
                            'customer' => $usera->id,
                            'amount' => ceil($amount_in_usd * 100),
                            'currency' => 'USD'
                        ));

                        if ($charge->paid == true) {
                            $usera = (array) $usera;
                            $charge = (array) $charge;

                            $data['user'] = $this->session->userdata('user_id');
                            $data['method'] = $this->input->post('method_0');
                            $data['amount'] = $grand_total;
                            $data['status'] = 'paid';
                            $data['payment_details'] = "Customer Info: \n" . json_encode($usera, true) . "\n \n Charge Info: \n" . json_encode($charge, true);
                            ;
                            $data['timestamp'] = time();
                            $this->db->insert('wallet_load', $data);

                            $id = $this->db->insert_id();
                            $user = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->user;
                            $amount = $this->db->get_where('wallet_load', array('wallet_load_id' => $id))->row()->amount;
                            $balance = base64_decode($this->db->get_where('user', array('user_id' => $user))->row()->wallet);
                            $new_balance = base64_encode($balance + $amount);
                            $this->db->where('user_id', $user);
                            $this->db->update('user', array('wallet' => $new_balance));

                            redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
                        } else {
                            $this->session->set_flashdata('alert', 'unsuccessful_stripe');
                            redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
                        }
                    } else {
                        $this->session->set_flashdata('alert', 'unsuccessful_stripe');
                        redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
                    }
                } else if ($method == 'pum') {

                    $data['user'] = $this->session->userdata('user_id');
                    $data['method'] = $this->input->post('method_0');
                    $data['amount'] = $grand_total;
                    $data['status'] = 'due';
                    $data['payment_details'] = '[]';
                    $data['timestamp'] = time();
                    $this->db->insert('wallet_load', $data);
                    $id = $this->db->insert_id();
                    $this->session->set_userdata('wallet_id', $id);

                    $pum_merchant_key = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_key', 'value');
                    $pum_merchant_salt = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_salt', 'value');

                    $user_id = $this->session->userdata('user_id');
                    /****TRANSFERRING USER TO PUM TERMINAL****/
                    $this->pum->add_field('key', $pum_merchant_key);
                    $this->pum->add_field('txnid', substr(hash('sha256', mt_rand() . microtime()), 0, 20));
                    $this->pum->add_field('amount', $grand_total);
                    $this->pum->add_field('firstname', $this->db->get_where('user', array('user_id' => $user_id))->row()->username);
                    $this->pum->add_field('email', $this->db->get_where('user', array('user_id' => $user_id))->row()->email);
                    $this->pum->add_field('phone', $this->db->get_where('user', array('user_id' => $user_id))->row()->phone);
                    $this->pum->add_field('productinfo', 'Payment with PayUmoney');
                    $this->pum->add_field('service_provider', 'payu_paisa');
                    $this->pum->add_field('udf1', $id);

                    $this->pum->add_field('surl', base_url() . 'home/wallet_pum_success');
                    $this->pum->add_field('furl', base_url() . 'home/wallet_pum_failure');

                    // submit the fields to pum
                    $this->pum->submit_pum_post();

                } else if ($method == 'ssl') {
                    $data['user'] = $this->session->userdata('user_id');
                    $data['method'] = $this->input->post('method_0');
                    $data['amount'] = $grand_total;
                    $data['status'] = 'due';
                    $data['payment_details'] = '[]';
                    $data['timestamp'] = time();
                    $this->db->insert('wallet_load', $data);
                    $id = $this->db->insert_id();
                    $this->session->set_userdata('wallet_id', $id);

                    $ssl_store_id = $this->db->get_where('business_settings', array('type' => 'ssl_store_id'))->row()->value;
                    $ssl_store_passwd = $this->db->get_where('business_settings', array('type' => 'ssl_store_passwd'))->row()->value;
                    $ssl_type = $this->db->get_where('business_settings', array('type' => 'ssl_type'))->row()->value;

                    // $total_amount = $grand_total / $exchange;
                    $total_amount = $grand_total;

                    /* PHP */
                    $post_data = array();
                    $post_data['store_id'] = $ssl_store_id;
                    $post_data['store_passwd'] = $ssl_store_passwd;
                    $post_data['total_amount'] = $total_amount;
                    $post_data['currency'] = "BDT";
                    $post_data['tran_id'] = date('Ym', $data['timestamp']) . $id;
                    $post_data['success_url'] = base_url() . "home/wallet_sslcommerz_success";
                    $post_data['fail_url'] = base_url() . "home/wallet_sslcommerz_fail";
                    $post_data['cancel_url'] = base_url() . "home/wallet_sslcommerz_cancel";
                    # $post_data['multi_card_name'] = "mastercard,visacard,amexcard";  # DISABLE TO DISPLAY ALL AVAILABLE

                    # EMI INFO
                    $post_data['emi_option'] = "1";
                    $post_data['emi_max_inst_option'] = "9";
                    $post_data['emi_selected_inst'] = "9";

                    $user_id = $this->session->userdata('user_id');
                    $user_info = $this->db->get_where('user', array('user_id' => $user_id))->row();

                    $cus_name = $user_info->username . ' ' . $user_info->surname;

                    # CUSTOMER INFORMATION
                    $post_data['cus_name'] = $cus_name;
                    $post_data['cus_email'] = $user_info->email;
                    $post_data['cus_add1'] = $user_info->address1;
                    $post_data['cus_add2'] = $user_info->address2;
                    $post_data['cus_city'] = $user_info->city;
                    $post_data['cus_state'] = $user_info->state;
                    $post_data['cus_postcode'] = $user_info->zip;
                    $post_data['cus_country'] = $user_info->country;
                    $post_data['cus_phone'] = $user_info->phone;

                    # REQUEST SEND TO SSLCOMMERZ
                    if ($ssl_type == "sandbox") {
                        $direct_api_url = "https://sandbox.sslcommerz.com/gwprocess/v3/api.php"; // Sandbox
                    } elseif ($ssl_type == "live") {
                        $direct_api_url = "https://securepay.sslcommerz.com/gwprocess/v3/api.php"; // Live
                    }

                    $handle = curl_init();
                    curl_setopt($handle, CURLOPT_URL, $direct_api_url);
                    curl_setopt($handle, CURLOPT_TIMEOUT, 30);
                    curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 30);
                    curl_setopt($handle, CURLOPT_POST, 1);
                    curl_setopt($handle, CURLOPT_POSTFIELDS, $post_data);
                    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
                    if ($ssl_type == "sandbox") {
                        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, FALSE); # KEEP IT FALSE IF YOU RUN FROM LOCAL PC
                    } elseif ($ssl_type == "live") {
                        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, TRUE);
                    }


                    $content = curl_exec($handle);

                    $code = curl_getinfo($handle, CURLINFO_HTTP_CODE);

                    if ($code == 200 && !(curl_errno($handle))) {
                        curl_close($handle);
                        $sslcommerzResponse = $content;
                    } else {
                        curl_close($handle);
                        echo "FAILED TO CONNECT WITH SSLCOMMERZ API";
                        exit;
                    }

                    # PARSE THE JSON RESPONSE
                    $sslcz = json_decode($sslcommerzResponse, true);

                    if (isset($sslcz['GatewayPageURL']) && $sslcz['GatewayPageURL'] != "") {
                        # THERE ARE MANY WAYS TO REDIRECT - Javascript, Meta Tag or Php Header Redirect or Other
                        # echo "<script>window.location.href = '". $sslcz['GatewayPageURL'] ."';</script>";
                        echo "<meta http-equiv='refresh' content='0;url=" . $sslcz['GatewayPageURL'] . "'>";
                        # header("Location: ". $sslcz['GatewayPageURL']);
                        exit;
                    } else {
                        echo "JSON Data parsing error!";
                    }
                }
                //$this->email_model->wallet_email('payment_info_require_mail_to_customer', $id);
                //$this->email_model->wallet_email('customer_added_wallet_to_admin', $id);
            } else if ($para2 == "set_info") {
                $data['status'] = 'pending';
                $data['payment_details'] = $this->input->post('payment_info');
                $data['timestamp'] = time();
                $this->db->where('wallet_load_id', $para3);
                $this->db->update('wallet_load', $data);
                // $this->email_model->wallet_email('customer_set_payment_info_to_admin', $para3);
                echo 'done';
            } else {
                $this->load->view('front/user/wallet');
            }
        } elseif ($para1 == "order_history") {
            $id = $this->session->userdata('user_id');
            $this->db->where('buyer', $id);
            $page_data['orders'] = $this->db->order_by("sale_id", "desc")->get('sale')->result_array();
            $this->load->view('front/user/order_history', $page_data);
        } elseif ($para1 == "downloads") {
            $this->load->view('front/user/downloads');
        } elseif ($para1 == "update_profile") {
            $page_data['user_info'] = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->result_array();
            $this->load->view('front/user/update_profile', $page_data);
        } elseif ($para1 == "ticket") {
            $id = $this->session->userdata('user_id');
            $this->db->where('from_where', '{"type":"user","id":"' . $id . '"}');
            $this->db->or_where('to_where', '{"type":"user","id":"' . $id . '"}');
            $page_data['user_tickets'] = $this->db->get('ticket', $config['per_page'], $para2)->result_array();
            $this->load->view('front/user/ticket', $page_data);
        } elseif ($para1 == "message_box") {
            $page_data['ticket'] = $para2;
            $this->crud_model->ticket_message_viewed($para2, 'user');
            $this->load->view('front/user/message_box', $page_data);
        } elseif ($para1 == "message_view") {
            $page_data['ticket'] = $para2;
            $page_data['message_data'] = $this->db->get_where('ticket', array(
                'ticket_id' => $para2
            ))->result_array();
            $this->crud_model->ticket_message_viewed($para2, 'user');
            $this->load->view('front/user/message_view', $page_data);
        } elseif ($para1 == "order_tracing") {
            $sale_data = $this->db->get_where('sale', array(
                'sale_code' => $this->input->post('sale_code')
            ));
            if ($sale_data->num_rows() >= 1) {
                $page_data['status'] = 'done';
                $page_data['sale_datetime'] = $sale_data->row()->sale_datetime;
                $page_data['delivery_status'] = json_decode($sale_data->row()->delivery_status, true);
            } else {
                $page_data['status'] = '';
            }
            $this->load->view('front/user/order_tracing', $page_data);
        } elseif ($para1 == "post_product") {
            $this->load->view('front/user/post_product');
        } elseif ($para1 == "post_product_bulk") {

            /*if ($this->session->userdata('user_login') != "yes") {
                redirect(base_url() . 'home/login_set/login', 'refresh');
            }*/

            $physical_categories = $this->db->where('digital', null)->or_where('digital', '')->get('category')->result_array();
            $physical_sub_categories = $this->db->where('digital', null)->or_where('digital', '')->get('sub_category')->result_array();
            $digital_categories = $this->db->where('digital', 'ok')->get('category')->result_array();
            $digital_sub_categories = $this->db->where('digital', 'ok')->get('sub_category')->result_array();
            $brands = $this->db->get('brand')->result_array();

            $page_data['page_name'] = "customer_product_bulk_upload";
            $page_data['page_title'] = translate('Bulk upload');

            $page_data['upload_amount'] = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->row()->product_upload;


            $page_data['physical_categories'] = $physical_categories;
            $page_data['physical_sub_categories'] = $physical_sub_categories;
            $page_data['digital_categories'] = $digital_categories;
            $page_data['digital_sub_categories'] = $digital_sub_categories;
            $page_data['brands'] = $brands;

            $this->load->view('front/user/post_product_bulk', $page_data);

        } elseif ($para1 == "do_post_product") {
            $upload_amount = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->row()->product_upload;
            if ($upload_amount > 0) {
                $this->load->library('form_validation');

                $this->form_validation->set_rules('title', 'Title', 'required');
                $this->form_validation->set_rules('category', 'Category', 'required');
                $this->form_validation->set_rules('sub_category', 'Sub Category', 'required');
                $this->form_validation->set_rules('prod_condition', 'Condition', 'required');
                $this->form_validation->set_rules('sale_price', 'Price', 'required');
                $this->form_validation->set_rules('location', 'Location', 'required');
                $this->form_validation->set_rules('description', 'Description', 'required');

                if ($this->form_validation->run() == FALSE) {
                    echo '<br>' . validation_errors();
                } else {
                    $options = array();
                    if ($_FILES["images"]['name'][0] == '') {
                        $num_of_imgs = 0;
                    } else {
                        $num_of_imgs = count($_FILES["images"]['name']);
                    }
                    $data['title'] = $this->input->post('title');
                    $data['category'] = $this->input->post('category');
                    $data['sub_category'] = $this->input->post('sub_category');
                    $data['brand'] = $this->input->post('brand');
                    $data['prod_condition'] = $this->input->post('prod_condition');
                    $data['sale_price'] = $this->input->post('sale_price');
                    $data['location'] = $this->input->post('location');
                    $data['description'] = $this->input->post('description');
                    $data['add_timestamp'] = time();
                    $data['status'] = 'ok';
                    $data['admin_status'] = 'ok';
                    $data['is_sold'] = 'no';
                    $data['rating_user'] = '[]';
                    $data['num_of_imgs'] = $num_of_imgs;
                    $data['front_image'] = 0;
                    $additional_fields['name'] = json_encode($this->input->post('ad_field_names'));
                    $additional_fields['value'] = json_encode($this->input->post('ad_field_values'));
                    $data['additional_fields'] = json_encode($additional_fields);
                    $data['added_by'] = $this->session->userdata('user_id');

                    $this->db->insert('customer_product', $data);
                    // echo $this->db->last_query();
                    $id = $this->db->insert_id();
                    // $this->benchmark->mark_time();
                    $this->crud_model->file_up("images", "customer_product", $id, 'multi');
                    $this->crud_model->set_category_data(0);
                    recache();

                    // Package Info subtract code
                    $data1['product_upload'] = $upload_amount - 1;
                    $this->db->where('user_id', $this->session->userdata('user_id'));
                    $this->db->update('user', $data1);

                    echo "done";
                }
            } else {
                echo "failed";
            }
        } else {
            $page_data['part'] = 'info';
            if ($para2 == "info") {
                $page_data['part'] = 'info';
            } elseif ($para2 == "wallet") {
                if ($this->crud_model->get_type_name_by_id('general_settings', '84', 'value') !== 'ok') {
                    redirect(base_url() . 'home');
                } else {
                    $page_data['part'] = 'wallet';
                }

            } elseif ($para2 == "wishlist") {
                $page_data['part'] = 'wishlist';
            } elseif ($para2 == "uploaded_products") {
                $page_data['part'] = 'uploaded_products';
            } elseif ($para2 == "order_history") {
                $page_data['part'] = 'order_history';
            } elseif ($para2 == "downloads") {
                $page_data['part'] = 'downloads';
            } elseif ($para2 == "update_profile") {
                $page_data['part'] = 'update_profile';
            } elseif ($para2 == "ticket") {
                $page_data['part'] = 'ticket';
            } elseif ($para2 == "post_product") {
                $page_data['part'] = 'post_product';

            } elseif ($para2 == "post_product_bulk") {
                $page_data['part'] = 'post_product_bulk';

                $physical_categories = $this->db->where('digital', null)->or_where('digital', '')->get('category')->result_array();
                $physical_sub_categories = $this->db->where('digital', null)->or_where('digital', '')->get('sub_category')->result_array();
                $digital_categories = $this->db->where('digital', 'ok')->get('category')->result_array();
                $digital_sub_categories = $this->db->where('digital', 'ok')->get('sub_category')->result_array();
                $brands = $this->db->get('brand')->result_array();

                $page_data['page_name'] = "customer_product_bulk_upload";
                $page_data['page_title'] = translate('Bulk upload');

                $page_data['upload_amount'] = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->row()->product_upload;


                $page_data['physical_categories'] = $physical_categories;
                $page_data['physical_sub_categories'] = $physical_sub_categories;
                $page_data['digital_categories'] = $digital_categories;
                $page_data['digital_sub_categories'] = $digital_sub_categories;
                $page_data['brands'] = $brands;
            } elseif ($para2 == "uploaded_products") {
                $page_data['part'] = 'uploaded_products';
            } elseif ($para2 == "payment_info") {
                $page_data['part'] = 'package_payment_info';
            }

            $page_data['user_info'] = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->result_array();
            $page_data['page_name'] = "user";
            $page_data['asset_page'] = "user_profile";
            $page_data['page_title'] = translate('my_profile');
            $this->load->view('front/index', $page_data);
        }
        /*$page_data['all_products'] = $this->db->get_where('user', array(
            'user_id' => $this->session->userdata('user_id')
        ))->result_array();
        $page_data['user_info']    = $this->db->get_where('user', array(
            'user_id' => $this->session->userdata('user_id')
        ))->result_array();*/
    }

    public function customer_product_bulk_upload()
    {
        if ($this->session->userdata('user_login') != "yes") {
            redirect(base_url() . 'home/login_set/login', 'refresh');
        }

        $physical_categories = $this->db->where('digital', null)->or_where('digital', '')->get('category')->result_array();
        $physical_sub_categories = $this->db->where('digital', null)->or_where('digital', '')->get('sub_category')->result_array();
        $digital_categories = $this->db->where('digital', 'ok')->get('category')->result_array();
        $digital_sub_categories = $this->db->where('digital', 'ok')->get('sub_category')->result_array();
        $brands = $this->db->get('brand')->result_array();

        $page_data['page_name'] = "customer_product_bulk_upload";
        $page_data['page_title'] = translate('Bulk upload');

        $page_data['upload_amount'] = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->row()->product_upload;


        $page_data['physical_categories'] = $physical_categories;
        $page_data['physical_sub_categories'] = $physical_sub_categories;
        $page_data['digital_categories'] = $digital_categories;
        $page_data['digital_sub_categories'] = $digital_sub_categories;
        $page_data['brands'] = $brands;
        $this->load->view('front/index', $page_data);

    }




    public function customer_product_bulk_upload_save()
    {
        if (!file_exists($_FILES['bulk_file']['tmp_name']) || !is_uploaded_file($_FILES['bulk_file']['tmp_name'])) {
            $_SESSION['error'] = translate('File is not selected');
            //redirect('home/customer_product_bulk_upload');
            redirect(base_url() . 'home/profile/part/post_product_bulk');
        }

        $inputFileName = $_FILES['bulk_file']['tmp_name'];

        $inputFileType = \PhpOffice\PhpSpreadsheet\IOFactory::identify($inputFileName);
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($inputFileType);
        $spreadsheet = $reader->load($inputFileName);
        $sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);

        $products = array();
        if (!empty($sheetData)) {

            if (!isset($sheetData[1])) {
                $_SESSION['error'] = translate('Column names are missing');
                //redirect('home/customer_product_bulk_upload');
                redirect(base_url() . 'home/profile/part/post_product_bulk');
            }

            foreach ($sheetData[1] as $colk => $colv) {
                $col_map[$colk] = $colv;
            }


            if (!isset($sheetData[2])) {
                $_SESSION['error'] = translate('Data missing');
                //redirect('home/customer_product_bulk_upload');
                redirect(base_url() . 'home/profile/part/post_product_bulk');
            }

            for ($i = 2; $i <= count($sheetData); $i++) {
                $product = array();
                foreach ($sheetData[$i] as $colk => $colv) {
                    $product[$col_map[$colk]] = $colv;
                }
                $products[] = $product;
            }
        }


        if (!empty($products)) {
            foreach ($products as $product) {
                $upload_amount = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->row()->product_upload;
                if ($upload_amount > 0) {
                    $this->customer_product_bulk_upload_save_single($product);
                }

            }
        }

        //exit;
        $_SESSION['success'] = translate('Products uploaded');
        //redirect('home/customer_product_bulk_upload');
        redirect(base_url() . 'home/profile/part/post_product_bulk');

    }

    public function customer_product_bulk_upload_save_single($product)
    {
        $image_urls = array();

        $product_data['num_of_imgs'] = 0;
        if (!empty($product['images'])) {
            $image_urls = explode(',', $product['images']);
            $product_data['num_of_imgs'] = count($image_urls);
        }

        $product_data['title'] = $product['title'];
        $product_data['description'] = $product['description'];
        $product_data['category'] = is_numeric($product['category']) ? $product['category'] : 0;
        $product_data['sub_category'] = is_numeric($product['sub_category']) ? $product['sub_category'] : 0;
        $product_data['brand'] = $product['brand'];
        $product_data['prod_condition'] = $product['condition'] != "used" ? "new" : "used";

        $product_data['sale_price'] = is_numeric($product['sale_price']) ? $product['sale_price'] : 0;

        $product_data['add_timestamp'] = time();
        $product_data['status'] = $product['published'] == 'yes' ? 'ok' : '';
        $product_data['admin_status'] = 'ok';
        $product_data['is_sold'] = 'no';
        $product_data['rating_user'] = '[]';

        $product_data['tag'] = $product['tag'];
        $product_data['color'] = null;

        $product_data['front_image'] = 0;

        $product_data['additional_fields'] = null;
        $product_data['added_by'] = $this->session->userdata('user_id');
        $product_data['options'] = json_encode($options = array());

        $this->db->insert('customer_product', $product_data);

        //echo $this->db->last->query().'\n';

        $product_id = $this->db->insert_id();
        $this->crud_model->set_category_data(0);
        recache();

        // Package Info subtract code
        $upload_amount = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->row()->product_upload;
        $du['product_upload'] = $upload_amount - 1;
        $this->db->where('user_id', $this->session->userdata('user_id'));
        $this->db->update('user', $du);

        if (!empty($image_urls)) {
            $this->crud_model->file_up_from_urls($image_urls, "image", "customer_product", $product_id);
        }

    }

    function ticket_message($para1 = '')
    {
        $page_data['page_name'] = "ticket_message";
        $page_data['ticket'] = $para1;
        $page_data['message_data'] = $this->db->get_where('ticket', array(
            'ticket_id' => $para1
        ))->result_array();
        $this->crud_model->ticket_message_viewed($para1, 'user');
        $page_data['msgs'] = $this->db->get_where('ticket_message', array('ticket_id' => $para1))->result_array();
        $page_data['ticket_id'] = $para1;
        $page_data['page_name'] = "ticket_message";
        $page_data['page_title'] = translate('ticket_message');
        $this->load->view('front/index', $page_data);
    }

    function ticket_message_add()
    {
        $this->load->library('form_validation');
        $safe = 'yes';
        $char = '';
        foreach ($_POST as $row) {
            if (preg_match('/[\^}{#~|+¬]/', $row, $match)) {
                $safe = 'no';
                $char = $match[0];
            }
        }

        $this->form_validation->set_rules('sub', 'Subject', 'required');
        $this->form_validation->set_rules('reply', 'Message', 'required');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
        } else {
            if ($safe == 'yes') {
                $data['time'] = time();
                $data['subject'] = $this->input->post('sub');
                $id = $this->session->userdata('user_id');
                $data['from_where'] = json_encode(array('type' => 'user', 'id' => $id));
                $data['to_where'] = json_encode(array('type' => 'admin', 'id' => ''));
                $data['view_status'] = 'ok';
                $this->db->insert('ticket', $data);
                $ticket_id = $this->db->insert_id();
                $data1['message'] = $this->input->post('reply');
                $data1['time'] = time();
                if (!empty($this->db->get_where('ticket_message', array('ticket_id' => $ticket_id))->row()->ticket_id)) {
                    $data1['from_where'] = $this->db->get_where('ticket_message', array('ticket_id' => $ticket_id))->row()->from_where;
                    $data1['to_where'] = $this->db->get_where('ticket_message', array('ticket_id' => $ticket_id))->row()->to_where;
                } else {
                    $data1['from_where'] = $this->db->get_where('ticket', array('ticket_id' => $ticket_id))->row()->from_where;
                    $data1['to_where'] = $this->db->get_where('ticket', array('ticket_id' => $ticket_id))->row()->to_where;
                }
                $data1['ticket_id'] = $ticket_id;
                $data1['view_status'] = json_encode(array('user_show' => 'ok', 'admin_show' => 'no'));
                $data1['subject'] = $this->db->get_where('ticket', array('ticket_id' => $ticket_id))->row()->subject;
                $this->db->insert('ticket_message', $data1);
                echo 'success#-#-#';
            } else {
                echo 'fail#-#-#Disallowed charecter : " ' . $char . ' " in the POST';
            }
        }
    }

    function ticket_reply($para1 = '')
    {
        $this->load->library('form_validation');
        $safe = 'yes';
        $char = '';
        foreach ($_POST as $row) {
            if (preg_match('/[\^}{#~|+¬]/', $row, $match)) {
                $safe = 'no';
                $char = $match[0];
            }
        }

        $this->form_validation->set_rules('reply', 'Message', 'required');

        if ($this->form_validation->run() == FALSE) {
            echo validation_errors();
        } else {
            if ($safe == 'yes') {
                $data['message'] = $this->input->post('reply');
                $data['time'] = time();
                if (!empty($this->db->get_where('ticket_message', array('ticket_id' => $para1))->row()->ticket_id)) {
                    $data['from_where'] = $this->db->get_where('ticket_message', array('ticket_id' => $para1))->row()->from_where;
                    $data['to_where'] = $this->db->get_where('ticket_message', array('ticket_id' => $para1))->row()->to_where;
                } else {
                    $data['from_where'] = $this->db->get_where('ticket', array('ticket_id' => $para1))->row()->from_where;
                    $data['to_where'] = $this->db->get_where('ticket', array('ticket_id' => $para1))->row()->to_where;
                }
                $data['ticket_id'] = $para1;
                $data['view_status'] = json_encode(array('user_show' => 'ok', 'admin_show' => 'no'));
                $data['subject'] = $this->db->get_where('ticket', array('ticket_id' => $para1))->row()->subject;
                $this->db->insert('ticket_message', $data);
                echo 'success#-#-#';
            } else {
                echo 'fail#-#-#Disallowed charecter : " ' . $char . ' " in the POST';
            }
        }
    }

    function uploaded_products_list($para2 = '')
    {
        $this->load->library('Ajax_pagination');

        $id = $this->session->userdata('user_id');

        $this->db->where('added_by', $id);

        $config['total_rows'] = $this->db->count_all_results('customer_product');
        ;
        $config['base_url'] = base_url() . 'home/uploaded_products_list/';
        $config['per_page'] = 5;
        $config['uri_segment'] = 5;
        $config['cur_page_giv'] = $para2;

        $function = "uploaded_products_list('0')";
        $config['first_link'] = '&laquo;';
        $config['first_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['first_tag_close'] = '</a></li>';

        $rr = ($config['total_rows'] - 1) / $config['per_page'];
        $last_start = floor($rr) * $config['per_page'];
        $function = "uploaded_products_list('" . $last_start . "')";
        $config['last_link'] = '&raquo;';
        $config['last_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['last_tag_close'] = '</a></li>';

        $function = "uploaded_products_list('" . ($para2 - $config['per_page']) . "')";
        $config['prev_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['prev_tag_close'] = '</a></li>';

        $function = "uploaded_products_list('" . ($para2 + $config['per_page']) . "')";
        $config['next_link'] = '&rsaquo;';
        $config['next_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['next_tag_close'] = '</a></li>';

        $config['full_tag_open'] = '<ul class="pagination pagination-style-2 ">';
        $config['full_tag_close'] = '</ul>';

        $config['cur_tag_open'] = '<li class="active"><a rel="grow" class="btn-u btn-u-red grow" class="active">';
        $config['cur_tag_close'] = '</a></li>';

        $function = "uploaded_products_list(((this.innerHTML-1)*" . $config['per_page'] . "))";
        $config['num_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['num_tag_close'] = '</a></li>';
        $this->ajax_pagination->initialize($config);
        $this->db->where('added_by', $id);
        $page_data['query'] = $this->db->get('customer_product', $config['per_page'], $para2)->result_array();
        $this->load->view('front/user/uploaded_products_list', $page_data);
    }

    function package_payment_list($para2 = '')
    {
        $this->load->library('Ajax_pagination');

        $id = $this->session->userdata('user_id');

        $this->db->where('user_id', $id);

        $config['total_rows'] = $this->db->count_all_results('package_payment');
        ;
        $config['base_url'] = base_url() . 'home/package_payment_list/';
        $config['per_page'] = 5;
        $config['uri_segment'] = 5;
        $config['cur_page_giv'] = $para2;

        $function = "package_payment_list('0')";
        $config['first_link'] = '&laquo;';
        $config['first_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['first_tag_close'] = '</a></li>';

        $rr = ($config['total_rows'] - 1) / $config['per_page'];
        $last_start = floor($rr) * $config['per_page'];
        $function = "package_payment_list('" . $last_start . "')";
        $config['last_link'] = '&raquo;';
        $config['last_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['last_tag_close'] = '</a></li>';

        $function = "package_payment_list('" . ($para2 - $config['per_page']) . "')";
        $config['prev_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['prev_tag_close'] = '</a></li>';

        $function = "package_payment_list('" . ($para2 + $config['per_page']) . "')";
        $config['next_link'] = '&rsaquo;';
        $config['next_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['next_tag_close'] = '</a></li>';

        $config['full_tag_open'] = '<ul class="pagination pagination-style-2 ">';
        $config['full_tag_close'] = '</ul>';

        $config['cur_tag_open'] = '<li class="active"><a rel="grow" class="btn-u btn-u-red grow" class="active">';
        $config['cur_tag_close'] = '</a></li>';

        $function = "package_payment_list(((this.innerHTML-1)*" . $config['per_page'] . "))";
        $config['num_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['num_tag_close'] = '</a></li>';
        $this->ajax_pagination->initialize($config);
        $this->db->where('user_id', $id);
        $page_data['query'] = $this->db->order_by("package_payment_id", "desc")->get('package_payment', $config['per_page'], $para2)->result_array();
        $this->load->view('front/user/package_payment_list', $page_data);
    }

    function wallet_listed($para2 = '')
    {
        $this->load->library('Ajax_pagination');

        $id = $this->session->userdata('user_id');
        $this->db->where('user', $id);

        $config['total_rows'] = $this->db->count_all_results('wallet_load');
        ;
        $config['base_url'] = base_url() . 'home/wallet_listed/';
        $config['per_page'] = 5;
        $config['uri_segment'] = 5;
        $config['cur_page_giv'] = $para2;

        $function = "wallet_listed('0')";
        $config['first_link'] = '&laquo;';
        $config['first_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['first_tag_close'] = '</a></li>';

        $rr = ($config['total_rows'] - 1) / $config['per_page'];
        $last_start = floor($rr) * $config['per_page'];
        $function = "wallet_listed('" . $last_start . "')";
        $config['last_link'] = '&raquo;';
        $config['last_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['last_tag_close'] = '</a></li>';

        $function = "wallet_listed('" . ($para2 - $config['per_page']) . "')";
        $config['prev_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['prev_tag_close'] = '</a></li>';

        $function = "wallet_listed('" . ($para2 + $config['per_page']) . "')";
        $config['next_link'] = '&rsaquo;';
        $config['next_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['next_tag_close'] = '</a></li>';

        $config['full_tag_open'] = '<ul class="pagination pagination-style-2 ">';
        $config['full_tag_close'] = '</ul>';

        $config['cur_tag_open'] = '<li class="active"><a rel="grow" class="btn-u btn-u-red grow" class="active">';
        $config['cur_tag_close'] = '</a></li>';

        $function = "wallet_listed(((this.innerHTML-1)*" . $config['per_page'] . "))";
        $config['num_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['num_tag_close'] = '</a></li>';
        $this->ajax_pagination->initialize($config);
        $this->db->order_by('wallet_load_id', 'DESC');
        $this->db->where('user', $id);
        $page_data['query'] = $this->db->get('wallet_load', $config['per_page'], $para2)->result_array();
        $this->load->view('front/user/wallet_listed', $page_data);
    }

    function downloads_listed($para2 = '')
    {
        $this->load->library('Ajax_pagination');

        $id = $this->session->userdata('user_id');
        $downloads = json_decode($this->db->get_where('user', array('user_id' => $id))->row()->downloads, true);
        $ids = array();
        foreach ($downloads as $row) {
            $ids[] = $row['product'];
        }
        if (count($ids) !== 0) {
            $this->db->where_in('product_id', $ids);
        } else {
            $this->db->where('product_id', 0);
        }

        $config['total_rows'] = $this->db->count_all_results('product');
        ;
        $config['base_url'] = base_url() . 'home/downloads_listed/';
        $config['per_page'] = 5;
        $config['uri_segment'] = 5;
        $config['cur_page_giv'] = $para2;

        $function = "downloads_listed('0')";
        $config['first_link'] = '&laquo;';
        $config['first_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['first_tag_close'] = '</a></li>';

        $rr = ($config['total_rows'] - 1) / $config['per_page'];
        $last_start = floor($rr) * $config['per_page'];
        $function = "downloads_listed('" . $last_start . "')";
        $config['last_link'] = '&raquo;';
        $config['last_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['last_tag_close'] = '</a></li>';

        $function = "downloads_listed('" . ($para2 - $config['per_page']) . "')";
        $config['prev_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['prev_tag_close'] = '</a></li>';

        $function = "downloads_listed('" . ($para2 + $config['per_page']) . "')";
        $config['next_link'] = '&rsaquo;';
        $config['next_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['next_tag_close'] = '</a></li>';

        $config['full_tag_open'] = '<ul class="pagination pagination-style-2 ">';
        $config['full_tag_close'] = '</ul>';

        $config['cur_tag_open'] = '<li class="active"><a rel="grow" class="btn-u btn-u-red grow" class="active">';
        $config['cur_tag_close'] = '</a></li>';

        $function = "downloads_listed(((this.innerHTML-1)*" . $config['per_page'] . "))";
        $config['num_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
        $config['num_tag_close'] = '</a></li>';
        $this->ajax_pagination->initialize($config);
        if (count($ids) !== 0) {
            $this->db->where_in('product_id', $ids);
        } else {
            $this->db->where('product_id', 0);
        }
        $page_data['query'] = $this->db->get('product', $config['per_page'], $para2)->result_array();
        $this->load->view('front/user/downloads_listed', $page_data);
    }

    /* FUNCTION: Loads Customer Download */
    function download($id)
    {
        if ($this->session->userdata('user_login') != "yes") {
            redirect(base_url(), 'refresh');
        }
        $this->crud_model->download_product($id);
    }

    /* FUNCTION: Loads Customer Download Permission */
    function can_download($id)
    {
        if ($this->session->userdata('user_login') != "yes") {
            redirect(base_url(), 'refresh');
        }
        if ($this->crud_model->can_download($id)) {
            echo 'ok';
        } else {
            echo 'not';
        }
    }

    /* FUNCTION: Loads Category filter page */
    function category()
    {

        $filter_where_clause_arr = array();
        $filter_by_size = array();
        $filter_by_color = array();
        $filter_by_shape = array();

        if (isset($_GET['size'])) {
            $filter_by_size = explode("-", $this->input->get("size"));
        }
        if (isset($_GET['color'])) {
            $filter_by_color = explode("-", $this->input->get("color"));
        }
        if (isset($_GET['shape'])) {
            $filter_by_shape = explode("-", $this->input->get("shape"));
        }

        if (isset($_GET['category'])) {
            $filter_where_clause_arr["p.category"] = $_GET['category'];
            $meta = $this->crud_model->getMetaByCategoryId($_GET['category']);
            $page_data['meta'] = $meta;
        }
        if (isset($_GET['sub_category'])) {
            $filter_where_clause_arr["p.sub_category"] = $_GET['sub_category'];
        }
        if (isset($_GET['third_sub_category'])) {
            $filter_where_clause_arr["p.third_sub_category"] = $_GET['third_sub_category'];
        }

        $on_clause = "pv.stock_status>0 and pv.is_download='1' and pv.images!='[]' and pv.images!='' ";
        $on_clause_brand = "";
        if (isset($_GET['text'])) {
            $on_clause .= " and (p.tag like '%" . $_GET['text'] . "%' ";
            $on_clause .= " or pv.title like '%" . $_GET['text'] . "%' ";
            $on_clause .= " or pv.upc like '%" . $_GET['text'] . "%' ";
            $on_clause .= " or pv.seller_sku like '%" . $_GET['text'] . "%') ";
        }
        if (isset($_GET['text'])) {
            $on_clause_brand .= " and b.name like '%" . $_GET['text'] . "%' ";
        }
        if (isset($_GET['min']) && isset($_GET['max'])) {
            $on_clause .= " and ((pv.discounted_price >= " . (int) $_GET['min'] . "  and pv.discounted_price<=" . (int) $_GET['max'] . " ) OR (pv.selling_price >= " . (int) $_GET['min'] . "  and pv.selling_price<=" . (int) $_GET['max'] . " ))";
        }
        $this->db->select("pv.stock_status ,pv.product_id , pv.product_variants_id , pv.title , pv.selling_price , pv.images ,  p.front_image");
        $this->db->from("product p");
        $this->db->where("is_approved", 1);
        $this->db->where("p.status", "ok");
        $this->db->where("$on_clause");
        // $this->db->join("product_variants pv", "p.product_id = pv.product_id " . $on_clause);
        $this->db->join("product_variants pv", "p.product_id = pv.product_id ");
        $this->db->join("brand b", "b.brand_id = p.brand " . $on_clause_brand, "left");

        foreach ($filter_where_clause_arr as $key => $val) {
            $this->db->where($key, $val);
        }
        if (isset($_GET['brand'])) {
            $brand_arr = explode("-", $_GET['brand']);
            $this->db->where_in("p.brand", $brand_arr);
        }
        if (count($filter_by_size) > 0) {
            $this->db->group_start();
            foreach ($filter_by_size as $f_size) {
                $this->db->or_like('replace(replace(pv.actual_size,"' . "'" . '",""),' . "'" . '"' . "'" . ',"")', $f_size);
            }
            $this->db->group_end();
        }

        if (count($filter_by_color) > 0) {
            $this->db->group_start();
            foreach ($filter_by_color as $f_color) {
                $this->db->or_like("pv.color", $f_color);
            }
            $this->db->group_end();
        }
        if (count($filter_by_shape) > 0) {
            $this->db->where_in("pv.shape", $filter_by_shape);
        }
       

        if (count($filter_by_color) > 0) {
            $this->db->group_by("pv.color");
        }

        $this->db->group_by("p.product_id");
        if (isset($_GET['sort_by'])) {
            if ($_GET['sort_by'] == "high") {
                $this->db->order_by("cast(pv.selling_price as UNSIGNED)", "desc");
            } elseif ($_GET['sort_by'] == "low") {
                $this->db->order_by("cast(pv.selling_price as UNSIGNED)", "asc");
            } elseif ($_GET['sort_by'] == "new_to_old") {
                $this->db->order_by("date(p.created)", "DESC");
            } elseif ($_GET['sort_by'] == "old_to_new") {
                $this->db->order_by("date(p.created)", "ASC");
            } else {
                $this->db->order_by('rand()');
            }
        } else {
            $this->db->order_by('rand()');
        }

        $this->db->limit(15);
        $q = $this->db->get();
        // echo '<pre>'; print_r($this->db->last_query()); die(); 
        log_message('debug', $this->db->last_query());
        if ($q->num_rows() > 0) {
            $products = $q->result_array();
            $prev_product_id = -1;
            foreach($products as $product){
                if($product['product_id'] == $prev_product_id){
                    continue;
                }else{
                    $page_data['all_products'][] = $product; 
                    $prev_product_id = $product['product_id'];
                }
            }
            
        } else {
            $page_data['all_products'] = array();
        }
        $this->db->select("AVG(CAST(pv.selling_price AS UNSIGNED ))  AS avg_selling_price , MAX(CAST(pv.selling_price AS UNSIGNED )) AS max_selling_price  , MIN(CAST(pv.selling_price AS UNSIGNED )) AS min_selling_price");
        $this->db->from("product p");
        foreach ($filter_where_clause_arr as $key => $val) {
            $this->db->where($key, $val);
        }
        if (isset($_GET['brand'])) {
            $brand_arr = explode("-", $_GET['brand']);
            $this->db->where_in("p.brand", $brand_arr);
        }
        $this->db->join("product_variants pv", "p.product_id = pv.product_id and pv.stock_status>0 and pv.is_download='1' and pv.images!='[]' and pv.images!=''");
        $min_max = $this->db->get();
        //echo $this->db->last_query();die();
        $page_data['min_max'] = $min_max->row_array();

        /* collecting filters */
        $this->db->select("pv.actual_size , pv.color , pv.shape");
        $this->db->from("product p");
        foreach ($filter_where_clause_arr as $key => $val) {
            $this->db->where($key, $val);
        }
        if (isset($_GET['brand'])) {
            $brand_arr = explode("-", $_GET['brand']);
            $this->db->where_in("p.brand", $brand_arr);
        }
        $this->db->join("product_variants pv", "p.product_id = pv.product_id ");
        $this->db->where("$on_clause");
        $this->db->where("p.is_approved", 1);
        $this->db->group_by("actual_size , color , shape");
        $filter_data = $this->db->get()->result_array();
        // echo '<pre>'; print_r($filter_data); die(); 
        /* end of collecting filter */
        $page_data['sidebar_filter_data'] = $filter_data;
        $_GET['text'] = str_replace("\'", "'", $_GET['text']);
        $page_data['all_brands'] = $this->crud_model->getBrandByFilters($filter_where_clause_arr);
        $page_data['page_name'] = "product_list/other";
        $page_data['asset_page'] = "product_list_other";
        $page_data['page_title'] = translate('category');
        $this->load->view('front/index', $page_data);
    }
    function all_category()
    {
        $page_data['page_name'] = "others/all_category";
        $page_data['asset_page'] = "all_category";
        $page_data['page_title'] = translate('all_category');
        $this->load->view('front/index', $page_data);
    }

    function all_brands()
    {
        $page_data['page_name'] = "others/all_brands";
        $page_data['asset_page'] = "all_brands";
        $page_data['page_title'] = translate('all_brands');
        $this->load->view('front/index', $page_data);
    }
    function faq()
    {
        $page_data['page_name'] = "others/faq";
        $page_data['asset_page'] = "all_category";
        $page_data['page_title'] = translate('frequently_asked_questions');
        $page_data['faqs'] = json_decode($this->crud_model->get_type_name_by_id('business_settings', '11', 'value'), true);
        $this->load->view('front/index', $page_data);
    }

    /* FUNCTION: Search Products */
    function home_search($param = '')
    {
        $category = $this->input->post('category');
        $this->session->set_userdata('searched_cat', $category);
        if ($param !== 'top') {
            $sub_category = $this->input->post('sub_category');
            $range = $this->input->post('price');
            $brand = $this->input->post('brand');
            $query = $this->input->post('query');
            $p = explode(';', $range);
            $this->session->set_flashdata('query', $query);
            redirect(base_url() . 'home/category/' . $category . '/' . $sub_category . '-' . $brand . '/' . $p[0] . '/' . $p[1] . '/' . $query, 'refresh');
        } else if ($param == 'top') {
            redirect(base_url() . 'home/category/' . $category, 'refresh');
        }
    }

    function modify_for_multi_search($search)
    {

        $find = array("+");
        $replace = array(" ");

        $search = str_replace($find, $replace, $search);

        return $search;

    }

    function text_search()
    {
        echo "<pre>";
        print_r($_POST);
        exit();
        $type = $this->input->post('type');
        $search = $this->modify_for_multi_search(urlencode($this->input->post('query')));
        $category = $this->input->post('category');
        $this->session->set_flashdata('query', $search);

        if ($this->crud_model->get_settings_value('general_settings', 'vendor_system') !== 'ok') {
            // echo $search = $this->input->post('query');

            redirect(base_url() . 'home/category/' . $category . '/0-0/0/0/' . $search, 'refresh');
        } else {
            if ($type == 'vendor') {
                redirect(base_url() . 'home/store_locator/' . $search, 'refresh');
            } else if ($type == 'product') {
                redirect(base_url() . 'home/category/' . $category . '/0-0/0/0/' . $search, 'refresh');
            }
        }
    }

    /* FUNCTION: Check if user logged in */
    function is_logged()
    {
        if ($this->session->userdata('user_login') == 'yes') {
            echo 'yah!good';
        } else {
            echo 'nope!bad';
        }
    }

    function ajax_others_product($para1 = "")
    {
        $physical_product_activation = $this->db->get_where('general_settings', array('type' => 'physical_product_activation'))->row()->value;
        $digital_product_activation = $this->db->get_where('general_settings', array('type' => 'digital_product_activation'))->row()->value;
        $vendor_system = $this->db->get_where('general_settings', array('type' => 'vendor_system'))->row()->value;

        $this->load->library('Ajax_pagination');
        $type = $this->input->post('type');
        if ($type == 'featured') {
            $this->db->where('featured', 'ok');
        } elseif ($type == 'todays_deal') {
            $this->db->where('deal', 'ok');
        }
        $this->db->where('status', 'ok');

        if ($physical_product_activation == 'ok' && $digital_product_activation !== 'ok') {
            $this->db->where('download', NULL);
        } else if ($physical_product_activation !== 'ok' && $digital_product_activation == 'ok') {
            $this->db->where('download', 'ok');
        } else if ($physical_product_activation !== 'ok' && $digital_product_activation !== 'ok') {
            $this->db->where('product_id', '');
        }

        if ($vendor_system !== 'ok') {
            $this->db->like('added_by', '{"type":"admin"', 'both');
        }

        // pagination
        $config['total_rows'] = $this->db->count_all_results('product');
        $config['base_url'] = base_url() . 'index.php?home/listed/';
        $config['per_page'] = 12;
        $config['uri_segment'] = 5;
        $config['cur_page_giv'] = $para1;

        $function = "filter_others('0')";
        $config['first_link'] = '&laquo;';
        $config['first_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['first_tag_close'] = '</a></li>';

        $rr = ($config['total_rows'] - 1) / $config['per_page'];
        $last_start = floor($rr) * $config['per_page'];
        $function = "filter_others('" . $last_start . "')";
        $config['last_link'] = '&raquo;';
        $config['last_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['last_tag_close'] = '</a></li>';

        $function = "filter_others('" . ($para1 - $config['per_page']) . "')";
        $config['prev_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['prev_tag_close'] = '</a></li>';

        $function = "filter_others('" . ($para1 + $config['per_page']) . "')";
        $config['next_link'] = '&rsaquo;';
        $config['next_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['next_tag_close'] = '</a></li>';

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';

        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '<span class="sr-only">(current)</span></a></li>';

        $function = "filter_others(((this.innerHTML-1)*" . $config['per_page'] . "))";
        $config['num_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['num_tag_close'] = '</a></li>';
        $this->ajax_pagination->initialize($config);


        $this->db->order_by('product_id', 'desc');
        $this->db->where('status', 'ok');
        if ($type == 'featured') {
            $this->db->where('featured', 'ok');
        } elseif ($type == 'todays_deal') {
            $this->db->where('deal', 'ok');
        }

        if ($physical_product_activation == 'ok' && $digital_product_activation !== 'ok') {
            $this->db->where('download', NULL);
        } else if ($physical_product_activation !== 'ok' && $digital_product_activation == 'ok') {
            $this->db->where('download', 'ok');
        } else if ($physical_product_activation !== 'ok' && $digital_product_activation !== 'ok') {
            $this->db->where('product_id', '');
        }

        if ($vendor_system !== 'ok') {
            $this->db->like('added_by', '{"type":"admin"', 'both');
        }

        $page_data['products'] = $this->db->get('product', $config['per_page'], $para1)->result_array();
        $page_data['count'] = $config['total_rows'];
        $page_data['page_type'] = $type;

        $this->load->view('front/others_list/listed', $page_data);
    }

    /* FUNCTION: Loads Product List */
    function listed($para1 = "", $para2 = "", $para3 = "")
    {
        $this->load->library('Ajax_pagination');
        if ($para1 == "click") {
            $physical_product_activation = $this->db->get_where('general_settings', array('type' => 'physical_product_activation'))->row()->value;
            $digital_product_activation = $this->db->get_where('general_settings', array('type' => 'digital_product_activation'))->row()->value;
            $vendor_system = $this->db->get_where('general_settings', array('type' => 'vendor_system'))->row()->value;
            if ($this->input->post('range')) {
                $range = $this->input->post('range');
            }
            if ($this->input->post('text')) {
                $text = $this->input->post('text');
            }
            $category = $this->input->post('category');
            $category = explode(',', $category);
            $sub_category = $this->input->post('sub_category');
            $sub_category = explode(',', $sub_category);
            $featured = $this->input->post('featured');
            $brand = $this->input->post('brand');
            $name = '';
            $cat = '';
            $setter = '';
            $vendors = array();
            $approved_users = $this->db->get_where('vendor', array('status' => 'approved'))->result_array();
            foreach ($approved_users as $row) {
                $vendors[] = $row['vendor_id'];
            }

            if ($vendor_system !== 'ok') {
                $this->db->like('added_by', '{"type":"admin"', 'both');
            }

            if ($physical_product_activation == 'ok' && $digital_product_activation !== 'ok') {
                $this->db->where('download', NULL);
            } else if ($physical_product_activation !== 'ok' && $digital_product_activation == 'ok') {
                $this->db->where('download', 'ok');
            } else if ($physical_product_activation !== 'ok' && $digital_product_activation !== 'ok') {
                $this->db->where('product_id', '');
            }

            if (isset($text)) {
                if ($text !== '') {
                    $this->db->like('title', $text, 'both');
                }
            }

            if ($vendor = $this->input->post('vendor')) {
                if (in_array($vendor, $vendors)) {
                    $this->db->where('added_by', '{"type":"vendor","id":"' . $vendor . '"}');
                } else {
                    $this->db->where('product_id', '');
                }
            }


            $this->db->where('status', 'ok');
            if ($featured == 'ok') {
                $this->db->where('featured', 'ok');
            }

            if ($brand !== '0' && $brand !== '') {
                $this->db->where('brand', $brand);
            }

            if (isset($range)) {
                $p = explode(';', $range);
                $this->db->where('sale_price >=', $p[0]);
                $this->db->where('sale_price <=', $p[1]);
            }

            $query = array();
            if (count($sub_category) > 0) {
                $i = 0;
                foreach ($sub_category as $row) {
                    $i++;
                    if ($row !== "") {
                        if ($row !== "0") {
                            $query[] = $row;
                            $setter = 'get';
                        } else {
                            $this->db->where('sub_category !=', '0');
                        }
                    }
                }
                if ($setter == 'get') {
                    $this->db->where_in('sub_category', $query);
                }
            }

            if (count($category) > 0 && $setter !== 'get') {
                $i = 0;
                foreach ($category as $row) {
                    $i++;
                    if ($row !== "") {
                        if ($row !== "0") {
                            if ($i == 1) {
                                $this->db->where('category', $row);
                            } else {
                                $this->db->or_where('category', $row);
                            }
                        } else {
                            $this->db->where('category !=', '0');
                        }
                    }
                }
            }
            $this->db->order_by('product_id', 'desc');

            // pagination
            $config['total_rows'] = $this->db->count_all_results('product');
            $config['base_url'] = base_url() . 'index.php?home/listed/';
            if ($featured !== 'ok') {
                $config['per_page'] = 12;
            } else if ($featured == 'ok') {
                $config['per_page'] = 12;
            }
            $config['uri_segment'] = 5;
            $config['cur_page_giv'] = $para2;

            $function = "do_product_search('0')";
            $config['first_link'] = '&laquo;';
            $config['first_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
            $config['first_tag_close'] = '</a></li>';

            $rr = ($config['total_rows'] - 1) / $config['per_page'];
            $last_start = floor($rr) * $config['per_page'];
            $function = "do_product_search('" . $last_start . "')";
            $config['last_link'] = '&raquo;';
            $config['last_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
            $config['last_tag_close'] = '</a></li>';

            $function = "do_product_search('" . ($para2 - $config['per_page']) . "')";
            $config['prev_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
            $config['prev_tag_close'] = '</a></li>';

            $function = "do_product_search('" . ($para2 + $config['per_page']) . "')";
            $config['next_link'] = '&rsaquo;';
            $config['next_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
            $config['next_tag_close'] = '</a></li>';

            $config['full_tag_open'] = '<ul class="pagination pagination-v2">';
            $config['full_tag_close'] = '</ul>';

            $config['cur_tag_open'] = '<li class="active"><a rel="grow" class="btn-u btn-u-red grow" class="active">';
            $config['cur_tag_close'] = '</a></li>';

            $function = "do_product_search(((this.innerHTML-1)*" . $config['per_page'] . "))";
            $config['num_tag_open'] = '<li><a rel="grow" class="btn-u btn-u-sea grow" onClick="' . $function . '">';
            $config['num_tag_close'] = '</a></li>';
            $this->ajax_pagination->initialize($config);


            $this->db->where('status', 'ok');
            if ($featured == 'ok') {
                $this->db->where('featured', 'ok');
                $grid_items_per_row = 3;
                $name = 'Featured';
            } else {
                $grid_items_per_row = 3;
            }

            if (isset($text)) {
                if ($text !== '') {
                    $this->db->like('title', $text, 'both');
                }
            }

            if ($physical_product_activation == 'ok' && $digital_product_activation !== 'ok') {
                $this->db->where('download', NULL);
            } else if ($physical_product_activation !== 'ok' && $digital_product_activation == 'ok') {
                $this->db->where('download', 'ok');
            } else if ($physical_product_activation !== 'ok' && $digital_product_activation !== 'ok') {
                $this->db->where('product_id', '');
            }

            if ($vendor_system !== 'ok') {
                $this->db->like('added_by', '{"type":"admin"', 'both');
            }

            if ($vendor = $this->input->post('vendor')) {
                if (in_array($vendor, $vendors)) {
                    $this->db->where('added_by', '{"type":"vendor","id":"' . $vendor . '"}');
                } else {
                    $this->db->where('product_id', '');
                }
            }


            if ($brand !== '0' && $brand !== '') {
                $this->db->where('brand', $brand);
            }

            if (isset($range)) {
                $p = explode(';', $range);
                $this->db->where('sale_price >=', $p[0]);
                $this->db->where('sale_price <=', $p[1]);
            }

            $query = array();
            if (count($sub_category) > 0) {
                $i = 0;
                foreach ($sub_category as $row) {
                    $i++;
                    if ($row !== "") {
                        if ($row !== "0") {
                            $query[] = $row;
                            $setter = 'get';
                        } else {
                            $this->db->where('sub_category !=', '0');
                        }
                    }
                }
                if ($setter == 'get') {
                    $this->db->where_in('sub_category', $query);
                }
            }

            if (count($category) > 0 && $setter !== 'get') {
                $i = 0;
                foreach ($category as $rowc) {
                    $i++;
                    if ($rowc !== "") {
                        if ($rowc !== "0") {
                            if ($i == 1) {
                                $this->db->where('category', $rowc);
                            } else {
                                $this->db->or_where('category', $rowc);
                            }
                        } else {
                            $this->db->where('category !=', '0');
                        }
                    }
                }
            }

            $sort = $this->input->post('sort');

            if ($sort == 'most_viewed') {
                $this->db->order_by('number_of_view', 'desc');
            }
            if ($sort == 'condition_old') {
                $this->db->order_by('product_id', 'asc');
            }
            if ($sort == 'condition_new') {
                $this->db->order_by('product_id', 'desc');
            }
            if ($sort == 'price_low') {
                $this->db->order_by('sale_price', 'asc');
            }
            if ($sort == 'price_high') {
                $this->db->order_by('sale_price', 'desc');
            } else {
                $this->db->order_by('product_id', 'desc');
            }
            $page_data['all_products'] = $this->db->get('product', $config['per_page'], $para2)->result_array();
            if ($name != '') {
                $name .= ' : ';
            }
            if (isset($rowc)) {
                $cat = $rowc;
            } else {
                if ($setter == 'get') {
                    $cat = $this->crud_model->get_type_name_by_id('sub_category', $sub_category[0], 'category');
                }
            }
            if ($cat !== '') {
                if ($cat !== '0') {
                    $name .= $this->crud_model->get_type_name_by_id('category', $cat, 'category_name');
                } else {
                    $name = 'All Products';
                }
            } else {
                $name = 'All Products';
            }

        } elseif ($para1 == "load") {
            $page_data['all_products'] = $this->db->get('product')->result_array();
        }
        $page_data['vendor_system'] = $this->db->get_where('general_settings', array('type' => 'vendor_system'))->row()->value;
        $page_data['category_data'] = $category;
        $page_data['viewtype'] = $this->input->post('view_type');
        $page_data['name'] = $name;
        $page_data['count'] = $config['total_rows'];
        $page_data['grid_items_per_row'] = $grid_items_per_row;
        $this->load->view('front/product_list/other/listed', $page_data);
    }

    /* FUNCTION: Loads Custom Pages */
    function store_locator($parmalink = '')
    {
        if ($this->crud_model->get_settings_value('general_settings', 'vendor_system') !== 'ok') {
            redirect(base_url() . 'home');
        }
        $page_data['page_name'] = "others/store_locator";
        $page_data['asset_page'] = "store_locator";
        $page_data['page_title'] = translate('store_locator');
        $page_data['vendors'] = $this->db->get_where('vendor', array('status' => 'approved'))->result_array();
        $page_data['text'] = $this->modify_for_multi_search($parmalink);
        $this->load->view('front/index', $page_data);
    }


    /* FUNCTION: Loads Custom Pages */
    function page($parmalink = '')
    {
        $pagef = $this->db->get_where('page', array(
            'parmalink' => $parmalink
        ));
        if ($pagef->num_rows() > 0) {
            $page_data['page_name'] = "others/custom_page";
            $page_data['asset_page'] = "page";
            $page_data['tags'] = $pagef->row()->tag;
            $page_data['page_title'] = $parmalink;
            $page_data['page_items'] = $pagef->result_array();
            if ($this->session->userdata('admin_login') !== 'yes' && $pagef->row()->status !== 'ok') {
                redirect(base_url() . 'home/', 'refresh');
            }
        } else {
            redirect(base_url() . 'home/', 'refresh');
        }
        $this->load->view('front/index', $page_data);
    }
    function getCjVariantId($variant_id){
        $data = $this->db->get_where('product_variants', array('product_variants_id' => "$variant_id"))->row()->cj_variantid;
        echo $data;
    }
    /* FUNCTION: Loads Product View Page */
    function product_view($para1 = "", $para2 = "")
    {
        $user_id = $this->session->userdata('user_id') ? $this->session->userdata('user_id') : 0;

        $product_data = $this->db->get_where('product', array('product_id' => $para1, 'status' => 'ok'));

        $this->db->select('p.brand as brand_name, pv.product_variants_id, pv.product_id , pv.weight , pv.color , pv.actual_size , pv.shape , pv.description , pv.features , pv.material , pv.cost , pv.total_cost , pv.selling_price , pv.images , pv.stock_status , pv.title , pv.upc , pv.seller_sku, pv.gender , pv.collection , pv.style , pv.primary_style,  pv.construction  ,pv.use , pv.origin , pv.asin , pv.discount_type , pv.discount  , p.front_image , p.shipping_type , p.flat_rate , p.rating_num , p.rating_user, p.rating_total , p.shipping_days , p.meta_description , p.meta_keyword');
        $this->db->from('product p');
        $this->db->join('product_variants pv', 'p.product_id = pv.product_id', 'left');
        $this->db->join('brand b', 'b.brand_id = p.brand', 'left');
        $this->db->where('p.product_id', $para1);
        $this->db->order_by("pv.product_variants_id", "asc");
        $product_variant = $this->db->get();
        foreach ($product_variant->result_array() as $row) {
            $data[] = $row;
        }
        $this->db->where('product_id', $para1);
        $this->db->update('product', array(
            'number_of_view' => $product_data->row()->number_of_view + 1,
            'last_viewed' => time()
        ));
        $page_data['variants'] = $data;
        $page_data['para_product_id'] = $para1;
        $page_data['product_details'] = $this->db->get_where('product', array('product_id' => $para1, 'status' => 'ok'))->result_array();
        $page_data['page_name'] = "product_view/other/page_view";
        $page_data['asset_page'] = "product_view_other";
        $page_data['product_data'] = $product_data->result_array();
        $page_data['page_title'] = '';
        $page_data['product_tags'] = $product_data->row()->tag;
        $page_data['product_view_bc'] = $this->crud_model->getProductViewBcByProductId($para1);
        $page_data['percentage_rating'] = $this->crud_model->getRatingByProductId($para1);
        $page_data['is_user_add_rating'] = $this->crud_model->is_user_add_rating_by_product_id($para1);
        $page_data['review_allowed'] = $this->crud_model->checkAllowedReviews();

        $this->load->view('front/index', $page_data);

    }

    /* FUNCTION: Loads Product View Page */
    function quick_view($para1 = "")
    {
        $product_data = $this->db->get_where('product', array('product_id' => $para1, 'status' => 'ok'));
        $this->db->select("pv.product_variants_id, pv.product_id , pv.weight , p.category, p.sub_category, p.third_sub_category, p.brand, pv.color , pv.actual_size , pv.shape , pv.description , pv.features , pv.material , pv.cost , pv.total_cost , pv.selling_price , pv.images , pv.stock_status , pv.title , pv.upc , pv.seller_sku, pv.gender , pv.collection , pv.style , pv.primary_style,  pv.construction  ,pv.use , pv.origin , pv.asin , pv.discount_type , pv.discount , p.front_image , p.shipping_type , p.flat_rate");
        $this->db->from("product p");
        $this->db->join("product_variants pv", "p.product_id = pv.product_id", "left");
        $this->db->where("p.product_id", $para1);
        $this->db->order_by("pv.product_variants_id", "asc");
        $q = $this->db->get();
        //echo $this->db->last_query();die();
        foreach ($q->result_array() as $row) {
            $data[] = $row;
        }
        $type = 'other';
        $page_data['variants'] = $data;
        $page_data['page_title'] = $product_data->row()->title;
        $page_data['product_tags'] = $product_data->row()->tag;
        $page_data['product_id'] = $product_data->row()->product_id;

        $this->load->view('front/product_view/' . $type . '/quick_view/index', $page_data);
    }

    function customer_product_view($para1 = "", $para2 = "")
    {
        if ($this->crud_model->get_type_name_by_id('general_settings', '83', 'value') == 'ok') {
            $product_data = $this->db->get_where('customer_product', array('customer_product_id' => $para1, 'status' => 'ok', 'is_sold' => 'no'));

            $this->db->where('customer_product_id', $para1);
            $this->db->update('customer_product', array(
                'number_of_view' => $product_data->row()->number_of_view + 1,
                'last_viewed' => time()
            ));

            $type = 'other';

            $page_data['product_details'] = $this->db->get_where('customer_product', array('customer_product_id' => $para1, 'status' => 'ok', 'is_sold' => 'no'))->result_array();
            $page_data['page_name'] = "customer_product_view/" . $type . "/page_view";
            $page_data['asset_page'] = "customer_product_view_" . $type;
            $page_data['product_data'] = $product_data->result_array();
            $page_data['page_title'] = $product_data->row()->title;
            $page_data['product_tags'] = $product_data->row()->tag;

            $this->load->view('front/index', $page_data);
        } else {
            redirect(base_url(), 'refresh');
        }
    }

    function quick_view_cp($para1 = "")
    {
        $product_data = $this->db->get_where('customer_product', array(
            'customer_product_id' => $para1,
            'status' => 'ok'
        ));

        $type = 'other';

        $page_data['product_details'] = $product_data->result_array();
        $page_data['page_title'] = $product_data->row()->title;
        $page_data['product_tags'] = $product_data->row()->tag;

        $this->load->view('front/customer_product_view/' . $type . '/quick_view/index', $page_data);
    }

    /* FUNCTION: Setting Frontend Language */
    function set_language($lang)
    {
        $this->session->set_userdata('language', $lang);
        $page_data['page_name'] = "home";
        recache();
    }

    /* FUNCTION: Setting Frontend Language */
    function set_currency($currency)
    {
        $this->session->set_userdata('currency', $currency);
        recache();
    }

    /* FUNCTION: Loads Contact Page */
    function contact($para1 = "")
    {
        if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
            $this->load->library('recaptcha');
        }
        $this->load->library('form_validation');
        if ($para1 == 'send') {
            $safe = 'yes';
            $char = '';
            foreach ($_POST as $row) {
                if (preg_match('/[\'^":()}{#~><>|=+¬]/', $row, $match)) {
                    $safe = 'no';
                    $char = $match[0];
                }
            }

            $this->form_validation->set_rules('name', 'Name', 'required');
            $this->form_validation->set_rules('subject', 'Subject', 'required');
            $this->form_validation->set_rules('message', 'Message', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required');

            if ($this->form_validation->run() == FALSE) {
                echo validation_errors();
            } else {
                if ($safe == 'yes') {

                    if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
                        $captcha_answer = $this->input->post('g-recaptcha-response');
                        $response = $this->recaptcha->verifyResponse($captcha_answer);
                        if ($response['success']) {
                            $data['name'] = $this->input->post('name', true);
                            $data['subject'] = $this->input->post('subject');
                            $data['email'] = $this->input->post('email');
                            $data['message'] = $this->security->xss_clean(($this->input->post('message')));
                            $data['view'] = 'no';
                            $data['timestamp'] = time();
                            $this->db->insert('contact_message', $data);
                            echo 'sent';
                        } else {
                            echo translate('captcha_incorrect');
                        }
                    } else {
                        $data['name'] = $this->input->post('name', true);
                        $data['subject'] = $this->input->post('subject');
                        $data['email'] = $this->input->post('email');
                        $data['message'] = $this->security->xss_clean(($this->input->post('message')));
                        $data['view'] = 'no';
                        $data['timestamp'] = time();
                        $this->db->insert('contact_message', $data);
                        echo 'sent';
                    }
                } else {
                    echo 'Disallowed charecter : " ' . $char . ' " in the POST';
                }
            }
        } else {
            if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
                $page_data['recaptcha_html'] = $this->recaptcha->render();
            }
            $page_data['page_name'] = "others/contact";
            $page_data['asset_page'] = "contact";
            $page_data['page_title'] = translate('contact');
            $this->load->view('front/index', $page_data);
        }
    }

    function putu($um)
    {
        $this->db->where('type', 'version');
        $this->db->update('general_settings', array('value' => $um));
    }

    /* FUNCTION: Concerning Login */
    function vendor_logup($para1 = "", $para2 = "")
    {
        if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
            $this->load->library('recaptcha');
        }
        $this->load->library('form_validation');
        if ($para1 == "add_info") {
            $msg = '';
            $this->load->library('form_validation');
            $safe = 'yes';
            $char = '';
            foreach ($_POST as $k => $row) {
                if (preg_match('/[\'^":()}{#~><>|=¬]/', $row, $match)) {
                    if ($k !== 'password1' && $k !== 'password2') {
                        $safe = 'no';
                        $char = $match[0];
                    }
                }
            }

            $this->form_validation->set_rules('name', 'First Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'valid_email|required|is_unique[vendor.email]', array('required' => 'You have not provided %s.', 'is_unique' => 'This %s already exists.'));
            $this->form_validation->set_rules('password1', 'Password', 'required|matches[password2]');
            $this->form_validation->set_rules('password2', 'Confirm Password', 'required');
            $this->form_validation->set_rules('address1', 'Address Line 1', 'required');
            $this->form_validation->set_rules('display_name', 'Display Name', 'required');
            $this->form_validation->set_rules('state', 'State', 'required');
            $this->form_validation->set_rules('country', 'Country', 'required');
            $this->form_validation->set_rules('city', 'City', 'required');
            $this->form_validation->set_rules('zip', 'Zip', 'required');
            $this->form_validation->set_rules('terms_check', 'Terms & Conditions', 'required', array('required' => translate('you_must_agree_with_terms_&_conditions')));
            if ($this->form_validation->run() == FALSE) {
                echo validation_errors();
            } else {
                if ($safe == 'yes') {
                    if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
                        $captcha_answer = $this->input->post('g-recaptcha-response');
                        $response = $this->recaptcha->verifyResponse($captcha_answer);
                        if ($response['success']) {
                            $data['name'] = $this->input->post('name');
                            $data['email'] = $this->input->post('email');
                            $data['address1'] = $this->input->post('address1');
                            $data['address2'] = $this->input->post('address2');
                            $data['company'] = $this->input->post('company');
                            $data['display_name'] = $this->input->post('display_name');
                            $data['state'] = $this->input->post('state');
                            $data['country'] = $this->input->post('country');
                            $data['city'] = $this->input->post('city');
                            $data['zip'] = $this->input->post('zip');
                            $data['create_timestamp'] = time();
                            $data['approve_timestamp'] = 0;
                            $data['approve_timestamp'] = 0;
                            $data['membership'] = 0;
                            $data['status'] = 'pending';
                            $data['user_id'] = $_SESSION['user_id'] ? $_SESSION['user_id'] : "";

                            if ($this->input->post('password1') == $this->input->post('password2')) {
                                $password = $this->input->post('password1');
                                $data['password'] = sha1($password);
                                $this->db->insert('vendor', $data);
                                $vendor_id = $this->db->insert_id();
                                $user_id = $_SESSION['user_id'];

                                $this->db->set('is_vendor', 1);
                                $this->db->set('vendor_id', $vendor_id);
                                $this->db->where('user_id', $user_id);
                                $this->db->update('user');

                                $msg = 'done';
                                if ($this->email_model->account_opening('vendor', $data['email'], $password) == false) {
                                    $msg = 'done_but_not_sent';
                                } else {
                                    $msg = 'done_and_sent';
                                }
                            }
                            echo $msg;
                        } else {
                            echo translate('please_fill_the_captcha');
                        }
                    } else {
                        $data['name'] = $this->input->post('name');
                        $data['email'] = $this->input->post('email');
                        $data['address1'] = $this->input->post('address1');
                        $data['address2'] = $this->input->post('address2');
                        $data['company'] = $this->input->post('company');
                        $data['display_name'] = $this->input->post('display_name');
                        $data['state'] = $this->input->post('state');
                        $data['country'] = $this->input->post('country');
                        $data['city'] = $this->input->post('city');
                        $data['zip'] = $this->input->post('zip');
                        $data['create_timestamp'] = time();
                        $data['approve_timestamp'] = 0;
                        $data['approve_timestamp'] = 0;
                        $data['membership'] = 0;
                        $data['status'] = 'pending';
                        $data['user_id'] = $_SESSION['user_id'] ? $_SESSION['user_id'] : "";

                        if ($this->input->post('password1') == $this->input->post('password2')) {
                            $password = $this->input->post('password1');
                            $data['password'] = sha1($password);
                            $this->db->insert('vendor', $data);
                            $vendor_id = $this->db->insert_id();
                            $user_id = $_SESSION['user_id'];

                            $this->db->set('is_vendor', 1);
                            $this->db->set('vendor_id', $vendor_id);
                            $this->db->where('user_id', $user_id);
                            $this->db->update('user');
                            $msg = 'done';
                            if ($this->email_model->account_opening('vendor', $data['email'], $password) == true) {
                                if ($this->email_model->vendor_reg_email_to_admin($data['email'], $password) == false) {
                                    $msg = 'done_but_not_sent';
                                } else {
                                    $msg = 'done_and_sent';
                                }
                            } else {
                                $msg = 'done_and_sent';
                            }
                        }
                        echo $msg;
                    }
                } else {
                    echo 'Disallowed charecter : " ' . $char . ' " in the POST';
                }
            }
        } else if ($para1 == 'registration') {
            if ($this->crud_model->get_settings_value('general_settings', 'vendor_system') !== 'ok') {
                redirect(base_url());
            }
            if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
                $page_data['recaptcha_html'] = $this->recaptcha->render();
            }
            $page_data['page_name'] = "vendor/register";
            $page_data['asset_page'] = "register";
            $page_data['page_title'] = translate('registration');
            $this->load->view('front/index', $page_data);
        }

    }
    function vendor_login_msg()
    {
        $page_data['page_name'] = "vendor/register/login_msg";
        $page_data['asset_page'] = "register";
        $page_data['page_title'] = translate('registration');
        $this->load->view('front/index', $page_data);
    }
    /* FUNCTION: Concerning Login */
    function login($para1 = "", $para2 = "")
    {


        $page_data['page_name'] = "login";

        $this->load->library('form_validation');
        if ($para1 == "do_login") {
            $this->form_validation->set_rules('email', 'Email', 'required');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if ($this->form_validation->run() == FALSE) {
                echo validation_errors();
            } else {
                $signin_data = $this->db->get_where('user', array(
                    'email' => $this->input->post('email'),
                    'password' => sha1($this->input->post('password'))
                ));
                if ($signin_data->num_rows() > 0) {
                    foreach ($signin_data->result_array() as $row) {
                        $this->session->set_userdata('user_login', 'yes');
                        $this->session->set_userdata('user_id', $row['user_id']);
                        $this->session->set_userdata('user_name', $row['username']);
                        $this->session->set_flashdata('alert', 'successful_signin');
                        $this->db->where('user_id', $row['user_id']);
                        $this->db->update('user', array(
                            'last_login' => time()
                        ));
                        echo 'done';
                    }
                } else {
                    echo 'failed';
                }
            }
        } else if ($para1 == 'forget') {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('email', 'Email', 'required');

            if ($this->form_validation->run() == FALSE) {
                echo validation_errors();
            } else {
                $query = $this->db->get_where('user', array(
                    'email' => $this->input->post('email')
                ));
                if ($query->num_rows() > 0) {
                    $user_id = $query->row()->user_id;
                    $password = substr(hash('sha512', rand()), 0, 12);
                    $data['password'] = sha1($password);
                    $this->db->where('user_id', $user_id);
                    $this->db->update('user', $data);
                    if ($this->email_model->password_reset_email('user', $user_id, $password)) {
                        echo 'email_sent';
                    } else {
                        echo 'email_not_sent';
                    }
                } else {
                    echo 'email_nay';
                }
            }
        }
        //$this->load->view('front/index', $page_data);
    }
    /* FUNCTION: Setting login page with facebook and google */
    function login_set($para1 = '', $para2 = '', $para3 = '')
    {
        if ($this->session->userdata('user_login') == "yes") {
            redirect(base_url() . 'home/profile', 'refresh');
        }
        if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
            $this->load->library('recaptcha');
        }
        $this->load->library('form_validation');

        $fb_login_set = $this->crud_model->get_settings_value('general_settings', 'fb_login_set');
        $g_login_set = $this->crud_model->get_settings_value('general_settings', 'g_login_set');
        $page_data = array();

        if ($fb_login_set == 'ok') {
            $appid = $this->db->get_where('general_settings', array(
                'type' => 'fb_appid'
            ))->row()->value;
            $secret = $this->db->get_where('general_settings', array(
                'type' => 'fb_secret'
            ))->row()->value;
            $config = array(
                'appId' => $appid,
                'secret' => $secret
            );
            $this->load->library('Facebook', $config);

            // Try to get the user's id on Facebook
            //$data['user'] = array();
            if ($this->facebook->is_authenticated()) {
                $page_data['url'] = $this->facebook->login_url();

            } else {
                // Generate a login url
                //$page_data['url'] = $this->facebook->getLoginUrl(array('scope'=>'email'));

                $page_data['url'] = $this->facebook->login_url();
                /*
                $this->facebook->getLoginUrl(array(
                    'redirect_uri' => site_url('home/login_set/back/' . $para2),
                    'scope' => array(
                        "email"
                    ) // permissions here
                ));
                */
                /*
                $permissions        = ['email']; // optional
                $page_data['url']   = $this->facebook->getLoginUrl(site_url('home/login_set/back/' . $para2), $permissions);
                */
                //redirect($data['url']);
            }

            /*
            else {
                // Get user's data and print it
                $atok = $this->facebook->getAccessToken();
                $page_data['user'] = $this->facebook->api('/me?fields=email,first_name,last_name&access_token={'.$atok.'}');
                $page_data['url']  = site_url('home/login_set/back/' . $para2); // Logs off application
                //print_r($user);
            }
            */

            if ($para1 == 'back') {
                //$userid = $this->facebook->getUser();
                //if($userid == 0){
                //echo 'pp----<br>';
                if (1 == 0) {

                } else {
                    //$atok = $this->facebook->getAccessToken();

                    //$user = $this->facebook->api('/me?fields=email,first_name,last_name&access_token={'.$this->facebook->getAccessTokenFromCode($this->input->get('code')));
                    $user = $this->facebook->request('get', '/me?fields=id,first_name,last_name,name,email');
                    //var_dump($user);
                    if (!isset($user['error'])) {
                        if ($user_id = $this->crud_model->exists_in_table('user', 'fb_id', $user['id'])) {

                        } else {

                            $data['username'] = $user['first_name'];
                            $data['surname'] = $user['last_name'];
                            $data['email'] = $user['email'];
                            $data['fb_id'] = $user['id'];
                            $data['wishlist'] = '[]';
                            $data['package_info'] = '[]';
                            $data['product_upload'] = $this->db->get_where('package', array('package_id' => 1))->row()->upload_amount;
                            $data['creation_date'] = time();
                            $data['password'] = substr(hash('sha512', rand()), 0, 12);

                            $this->db->insert('user', $data);
                            $user_id = $this->db->insert_id();
                        }
                        $this->session->set_userdata('user_login', 'yes');
                        $this->session->set_userdata('user_id', $user_id);
                        $this->session->set_userdata('user_name', $this->db->get_where('user', array(
                            'user_id' => $user_id
                        ))->row()->username);
                        $this->session->set_flashdata('alert', 'successful_signin');

                        $this->db->where('user_id', $user_id);
                        $this->db->update('user', array(
                            'last_login' => time()
                        ));

                        $para2a = $this->session->userdata('back');

                        if ($para2a == 'cart' || $para2a == 'back_to_cart') {
                            redirect(base_url() . 'home/cart_checkout', 'refresh');
                        } else {
                            redirect(base_url() . 'home/profile', 'refresh');
                        }
                    }

                }
            }
        }



        if ($g_login_set == 'ok') {
            $this->load->library('googleplus');
            if (isset($_GET['code'])) { //just_logged in
                $this->googleplus->client->authenticate();
                $_SESSION['token'] = $this->googleplus->client->getAccessToken();
                $g_user = $this->googleplus->people->get('me');
                if ($user_id = $this->crud_model->exists_in_table('user', 'g_id', $g_user['id'])) {

                } else {
                    $data['username'] = $g_user['displayName'];
                    $data['email'] = 'required';
                    $data['wishlist'] = '[]';
                    $data['package_info'] = '[]';
                    $data['product_upload'] = $this->db->get_where('package', array('package_id' => 1))->row()->upload_amount;
                    $data['g_id'] = $g_user['id'];

                    $data['g_photo'] = $g_user['image']['url'];
                    $data['creation_date'] = time();
                    $data['password'] = substr(hash('sha512', rand()), 0, 12);
                    $this->db->insert('user', $data);
                    $user_id = $this->db->insert_id();
                }
                $this->session->set_userdata('user_login', 'yes');
                $this->session->set_userdata('user_id', $user_id);
                $this->session->set_userdata('user_name', $this->db->get_where('user', array(
                    'user_id' => $user_id
                ))->row()->username);
                $this->session->set_flashdata('alert', 'successful_signin');

                $this->db->where('user_id', $user_id);
                $this->db->update('user', array(
                    'last_login' => time()
                ));

                if ($para2 == 'cart') {
                    redirect(base_url() . 'home/cart_checkout', 'refresh');
                } else {
                    redirect(base_url() . 'home', 'refresh');
                }
            }
            if (@$_SESSION['token']) {
                $this->googleplus->client->setAccessToken($_SESSION['token']);
            }
            if ($this->googleplus->client->getAccessToken()) //already_logged_in
            {
                $page_data['g_user'] = $this->googleplus->people->get('me');
                $page_data['g_url'] = $this->googleplus->client->createAuthUrl();
                $_SESSION['token'] = $this->googleplus->client->getAccessToken();
            } else {
                $page_data['g_url'] = $this->googleplus->client->createAuthUrl();
            }
        }

        if ($para1 == 'login') {
            $page_data['page_name'] = "user/login";
            $page_data['asset_page'] = "login";
            $page_data['page_title'] = translate('login');
            if ($para2 == 'modal') {
                $page_data['page'] = $para3;
                $this->load->view('front/user/login/quick_modal', $page_data);
            } else {
                $this->load->view('front/index', $page_data);
            }
        } elseif ($para1 == 'registration') {
            if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
                $page_data['recaptcha_html'] = $this->recaptcha->render();
            }
            $page_data['page_name'] = "user/register";
            $page_data['asset_page'] = "register";
            $page_data['page_title'] = translate('registration');
            if ($para2 == 'modal') {
                $this->load->view('front/user/register/index', $page_data);
            } else {
                $this->load->view('front/index', $page_data);
            }
        }
    }

    /* FUNCTION: Logout set */
    function logout()
    {
        if ($this->crud_model->get_settings_value('general_settings', 'fb_login_set') !== 'no') {
            $appid = $this->db->get_where('general_settings', array('type' => 'fb_appid'))->row()->value;
            $secret = $this->db->get_where('general_settings', array('type' => 'fb_secret'))->row()->value;
            $config = array('appId' => $appid, 'secret' => $secret);
            $this->load->library('Facebook', $config);
            $this->facebook->destroy_session();
        }
        $this->session->sess_destroy();
        redirect(base_url() . 'home/logged_out', 'refresh');
    }

    /* FUNCTION: Logout */
    function logged_out()
    {
        $this->session->set_flashdata('alert', 'successful_signout');
        redirect(base_url() . 'home/', 'refresh');
    }

    /* FUNCTION: Check if Email user exists */
    function exists()
    {
        $email = $this->input->post('email');
        $user = $this->db->get('user')->result_array();
        $exists = 'no';
        foreach ($user as $row) {
            if ($row['email'] == $email) {
                $exists = 'yes';
            }
        }
        echo $exists;
    }

    function unset_subscription_popup()
    {
        $cookie_data = array(
            "name" => "subscription_popup",
            "value" => "unset",
            "expire" => "86400",
            "domain " => base_url(),
        );
        set_cookie($cookie_data);
    }

    /* FUNCTION: Newsletter Subscription */
    function subscribe()
    {
        $safe = 'yes';
        $char = '';
        foreach ($_POST as $row) {
            if (preg_match('/[\'^":()}{#~><>|=+¬]/', $row, $match)) {
                $safe = 'no';
                $char = $match[0];
            }
        }

        $this->load->library('form_validation');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email');
        if ($this->form_validation->run() == FALSE) {
            echo "validation_error";
        } else {
            if (isset($_POST['is_popup'])) {
                $cookie_data = array(
                    "name" => "subscription_popup",
                    "value" => "unset",
                    "expire" => "31540000",
                    "domain " => base_url(),
                );
                set_cookie($cookie_data);
            }
            if ($safe == 'yes') {
                $subscribe_num = $this->session->userdata('subscriber');
                $email = $this->input->post('email');
                $subscriber = $this->db->get('subscribe')->result_array();
                $exists = 'no';
                foreach ($subscriber as $row) {
                    if ($row['email'] == $email) {
                        $exists = 'yes';
                    }
                }
                if ($exists == 'yes') {
                    echo 'already';
                } else if ($subscribe_num >= 3) {
                    echo 'already_session';
                } else if ($exists == 'no') {
                    $subscribe_num = $subscribe_num + 1;
                    $this->session->set_userdata('subscriber', $subscribe_num);
                    $data['email'] = $email;
                    $this->db->insert('subscribe', $data);
                    echo 'done';
                }
            } else {
                echo 'Disallowed charecter : " ' . $char . ' " in the POST';
            }
        }
    }

    /* FUNCTION: Customer Registration*/
    function registration($para1 = "", $para2 = "")
    {
        $safe = 'yes';
        $char = '';
        foreach ($_POST as $k => $row) {
            if (preg_match('/[\'^":()}{#~><>|=¬]/', $row, $match)) {
                if ($k !== 'password1' && $k !== 'password2' && $k !== 'address1') {
                    $safe = 'no';
                    $char = $match[0];
                }
            }
        }
        if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
            $this->load->library('recaptcha');
        }
        $this->load->library('form_validation');
        $page_data['page_name'] = "registration";
        if ($para1 == "add_info") {
            $msg = '';
            $this->form_validation->set_rules('username', 'First Name', 'required|trim');
            $this->form_validation->set_rules('surname', 'Last Name', 'required|trim');
            $this->form_validation->set_rules('email', 'Email', 'required|is_unique[user.email]|valid_email', array('required' => 'You have not provided %s.', 'is_unique' => 'This %s already exists.'));
            $this->form_validation->set_rules('password1', 'Password', 'required|matches[password2]');
            $this->form_validation->set_rules('password2', 'Confirm Password', 'required');
            $this->form_validation->set_rules('address1', 'Address Line 1', 'required');
            $this->form_validation->set_rules('phone', 'Phone', 'required');
            $this->form_validation->set_rules('zip', 'ZIP', 'required');
            $this->form_validation->set_rules('city', 'City', 'required');
            $this->form_validation->set_rules('state', 'State', 'required');
            $this->form_validation->set_rules('country', 'Country', 'required');
            $this->form_validation->set_rules('terms_check', 'Terms & Conditions', 'required', array('required' => translate('you_must_agree_with_terms_&_conditions')));

            if ($this->form_validation->run() == FALSE) {
                echo validation_errors();
            } else {
                if ($safe == 'yes') {
                    if ($this->crud_model->get_settings_value('general_settings', 'captcha_status', 'value') == 'ok') {
                        $captcha_answer = $this->input->post('g-recaptcha-response');
                        $response = $this->recaptcha->verifyResponse($captcha_answer);
                        if ($response['success']) {
                            $data['username'] = $this->input->post('username');
                            $data['email'] = $this->input->post('email');
                            $data['address1'] = $this->input->post('address1');
                            $data['address2'] = $this->input->post('address2');
                            $data['phone'] = $this->input->post('phone');
                            $data['surname'] = $this->input->post('surname');
                            $data['zip'] = $this->input->post('zip');
                            $data['city'] = $this->input->post('city');
                            $data['state'] = $this->input->post('state');
                            $data['country'] = $this->input->post('country');
                            $data['langlat'] = '';
                            $data['wishlist'] = '[]';
                            $data['package_info'] = '[]';
                            $data['product_upload'] = $this->db->get_where('package', array('package_id' => 1))->row()->upload_amount;
                            $data['creation_date'] = time();

                            if ($this->input->post('password1') == $this->input->post('password2')) {
                                $password = $this->input->post('password1');
                                $data['password'] = sha1($password);
                                $this->db->insert('user', $data);
                                $msg = 'done';
                                if ($this->email_model->account_opening('user', $data['email'], $password) == false) {
                                    $msg = 'done_but_not_sent';
                                } else {
                                    $msg = 'done_and_sent';
                                }
                            }
                            echo $msg;
                        } else {
                            echo translate('please_fill_the_captcha');
                        }
                    } else {
                        $data['username'] = $this->input->post('username');
                        $data['email'] = $this->input->post('email');
                        $data['address1'] = $this->input->post('address1');
                        $data['address2'] = $this->input->post('address2');
                        $data['phone'] = $this->input->post('phone');
                        $data['surname'] = $this->input->post('surname');
                        $data['zip'] = $this->input->post('zip');
                        $data['city'] = $this->input->post('city');
                        $data['state'] = $this->input->post('state');
                        $data['country'] = $this->input->post('country');
                        $data['langlat'] = '';
                        $data['wishlist'] = '[]';
                        $data['package_info'] = '[]';
                        $data['product_upload'] = $this->db->get_where('package', array('package_id' => 1))->row()->upload_amount;
                        $data['creation_date'] = time();

                        if ($this->input->post('password1') == $this->input->post('password2')) {
                            $password = $this->input->post('password1');
                            $data['password'] = sha1($password);
                            $this->db->insert('user', $data);
                            $msg = 'done';
                            if ($this->email_model->account_opening('user', $data['email'], $password) == false) {
                                $msg = 'done_but_not_sent';
                            } else {
                                $msg = 'done_and_sent';
                            }
                        }
                        echo $msg;
                    }
                } else {
                    echo 'Disallowed charecter : " ' . $char . ' " in the POST';
                }
            }
        } else if ($para1 == "update_info") {
            $id = $this->session->userdata('user_id');
            $this->form_validation->set_rules('username', 'First Name', 'required');
            $this->form_validation->set_rules('lastname', 'Last Name', 'required');
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('address1', 'Address Line 1', 'required');
            $this->form_validation->set_rules('phone', 'Phone', 'required');
            $this->form_validation->set_rules('zip', 'ZIP', 'required');
            $this->form_validation->set_rules('city', 'City', 'required');
            $this->form_validation->set_rules('state', 'State', 'required');
            $this->form_validation->set_rules('country', 'Country', 'required');
            if ($this->form_validation->run() == FALSE) {
                echo array_values($this->form_validation->error_array())[0];

            } else {
                $data['username'] = $this->input->post('username');
                $data['surname'] = $this->input->post('lastname');
                $data['address1'] = $this->input->post('address1');
                $data['address2'] = $this->input->post('address2');
                $data['phone'] = $this->input->post('phone');
                $data['city'] = $this->input->post('city');
                $data['state'] = $this->input->post('state');
                $data['country'] = $this->input->post('country');
                $data['skype'] = $this->input->post('skype');
                $data['google_plus'] = $this->input->post('google_plus');
                $data['facebook'] = $this->input->post('facebook');
                $data['zip'] = $this->input->post('zip');

                $this->db->where('user_id', $id);
                $this->db->update('user', $data);
                echo "done";
            }
        } else if ($para1 == "update_password") {
            $user_data['password'] = $this->input->post('password');
            $account_data = $this->db->get_where('user', array(
                'user_id' => $this->session->userdata('user_id')
            ))->result_array();
            foreach ($account_data as $row) {
                if (sha1($user_data['password']) == $row['password']) {
                    if ($this->input->post('password1') == $this->input->post('password2')) {
                        $data['password'] = sha1($this->input->post('password1'));
                        $this->db->where('user_id', $this->session->userdata('user_id'));
                        $this->db->update('user', $data);
                        echo "done";
                    } else {
                        echo translate('passwords_did_not_match!');
                    }
                } else {
                    echo translate('wrong_old_password!');
                }
            }

        } else if ($para1 == "change_picture") {
            $id = $this->session->userdata('user_id');
            $this->crud_model->file_up('img', 'user', $id, '', '', '.jpg');
            echo 'done';
        } else {
            $this->load->view('front/registration', $page_data);
        }
    }

    function error()
    {
        $this->load->view('front/others/404_error');
    }


    /* FUNCTION: Product rating*/
    function rating($product_id, $rating)
    {
        if ($this->session->userdata('user_login') != "yes") {
            redirect(base_url() . 'home/login/', 'refresh');
        }
        if ($rating <= 5) {
            if ($this->crud_model->set_rating($product_id, $rating) == 'yes') {
                echo 'success';
            } else if ($this->crud_model->set_rating($product_id, $rating) == 'no') {
                echo 'already';
            }
        } else {
            echo 'failure';
        }
    }

    /* FUNCTION: Concerning Compare*/
    function compare($para1 = "", $para2 = "")
    {
        if ($para1 == 'add') {
            $this->crud_model->add_compare($para2);
        } else if ($para1 == 'remove') {
            $this->crud_model->remove_compare($para2);
        } else if ($para1 == 'num') {
            echo $this->crud_model->compared_num();
        } else if ($para1 == 'clear') {
            $this->session->set_userdata('compare', '');
            redirect(base_url() . 'home', 'refresh');
        } else if ($para1 == 'get_detail') {
            $product = $this->db->get_where('product', array('product_id' => $para2));
            $return = array();
            $return += array('image' => '<img src="' . $this->crud_model->file_view('product', $para2, '', '', 'thumb', 'src', 'multi', 'one') . '" width="100" />');
            $return += array('price' => currency() . $product->row()->sale_price);
            $return += array('description' => $product->row()->description);
            if ($product->row()->brand) {
                $return += array('brand' => $this->db->get_where('brand', array('brand_id' => $product->row()->brand))->row()->name);
            }
            if ($product->row()->sub_category) {
                $return += array('sub' => $this->db->get_where('sub_category', array('sub_category_id' => $product->row()->sub_category))->row()->sub_category_name);
            }
            echo json_encode($return);
        } else {
            if ($this->session->userdata('compare') == '[]') {
                redirect(base_url() . 'home/', 'refresh');
            }
            $compare_datas = $this->crud_model->compared_shower();
            foreach ($compare_datas as $compare_data) {
                $compare_variant_id = $compare_data['products'];
            }
            $page_data['page_name'] = "others/compare";
            $page_data['asset_page'] = "compare";
            $page_data['compare_data'] = $this->crud_model->getMultipleVariantById($compare_variant_id);
            $page_data['page_title'] = 'compare';
            $this->load->view('front/index', $page_data);
        }

    }

    function add_m()
    {
        //$this->wallet_model->add_user_balance(20);
    }

    function cancel_order()
    {
        $this->session->set_userdata('sale_id', '');
        $this->session->set_userdata('couponer', '');
        $this->cart->destroy();
        redirect(base_url(), 'refresh');
    }

    /* FUNCTION: Concering Add, Remove and Updating Cart Items*/
    function cart($para1 = '', $para2 = '', $para3 = '', $para4 = '')
    {
        $this->cart->product_name_rules = '[:print:]';
        //echo "<pre>";print_r($_POST);die();
        if ($para1 == "add") {
            $qty = $this->input->post('qty');
            $color = $this->input->post('single_color');
            $ship_cost = $this->input->post('shipping_cost');

            // if($para3 == 'pp') {
            //     $carted = $this->cart->contents();
            //     foreach ($carted as $items) {
            //         if ($items['id'] == $para2 && $items['options']['color']==$color) {
            //             $data = array(
            //                 'rowid' => $items['rowid'],
            //                 'qty' => 0
            //             );
            //         } 
            //         $this->cart->update($data);
            //     }
            // }
            $options = array(
                'weight' => $this->crud_model->get_type_name_by_id('product_variants', $para2, 'weight'),
                'actual_size' => $this->crud_model->get_type_name_by_id('product_variants', $para2, 'actual_size'),
                'image' => $this->crud_model->get_type_name_by_id('product_variants', $para2, 'images'),
                'product_id' => $this->crud_model->get_type_name_by_id('product_variants', $para2, 'product_id'),
                'discount_type' => $this->crud_model->get_type_name_by_id('product_variants', $para2, 'discount_type'),
                'discount' => $this->crud_model->get_type_name_by_id('product_variants', $para2, 'discount'),
                'selling_price' => $this->crud_model->get_type_name_by_id('product_variants', $para2, 'selling_price'),
                'shipping_charges' => $ship_cost,
            );

            if ($color == "") {
                $variant_colors = json_decode($this->crud_model->get_type_name_by_id('product_variants', $para2, 'color'), true);
                $options['color'] = $variant_colors[0];
            } else {
                $options['color'] = $color;
            }

            $data = array(
                'id' => $para2,
                'qty' => $qty,
                'price' => $this->crud_model->get_product_price($para2),
                'name' => ($this->crud_model->get_type_name_by_id('product_variants', $para2, 'title') == "") ? "not available" : $this->crud_model->get_type_name_by_id('product_variants', $para2, 'title'),
                'options' => $options,
                'coupon' => '',
            );
            //echo "<pre>";print_r($data);die();
            $stock = $this->crud_model->get_type_name_by_id('product_variants', $para2, 'stock_status');
            if (!$this->crud_model->is_added_to_cart($para2) || $para3 == 'pp') {
                if ($stock >= $qty) {
                    $this->cart->insert($data);
                    echo 'added';
                } else {
                    echo 'shortage';
                }
            } else {
                echo 'already';
            }
            //var_dump($this->cart->contents());
        }

        if ($para1 == "added_list") {
            $page_data['carted'] = $this->cart->contents();
            $this->load->view('front/added_list', $page_data);
        }

        if ($para1 == "empty") {
            $this->cart->destroy();
            $this->session->set_userdata('couponer', '');
        }

        if ($para1 == "quantity_update") {

            $carted = $this->cart->contents();
            foreach ($carted as $items) {
                if ($items['rowid'] == $para2) {
                    $product = $items['id'];
                }
            }
            $current_quantity = $this->crud_model->get_type_name_by_id('product_variants', $product, 'stock_status');
            $msg = 'not_limit';

            foreach ($carted as $items) {
                if ($items['rowid'] == $para2) {
                    if ($current_quantity >= $para3) {
                        $data = array(
                            'rowid' => $items['rowid'],
                            'qty' => $para3
                        );
                    } else {
                        $msg = $current_quantity;
                        $data = array(
                            'rowid' => $items['rowid'],
                            'qty' => $current_quantity
                        );
                    }
                } else {
                    $data = array(
                        'rowid' => $items['rowid'],
                        'qty' => $items['qty']
                    );
                }
                $this->cart->update($data);
            }
            $return = '';
            $carted = $this->cart->contents();
            foreach ($carted as $items) {
                if ($items['rowid'] == $para2) {
                    $return = currency($items['subtotal']);
                }
            }
            $return .= '---' . $msg;
            echo $return;
        }

        if ($para1 == "remove_one") {
            $carted = $this->cart->contents();
            foreach ($carted as $items) {
                if ($items['rowid'] == $para2) {
                    $data = array(
                        'rowid' => $items['rowid'],
                        'qty' => 0
                    );
                } else {
                    $data = array(
                        'rowid' => $items['rowid'],
                        'qty' => $items['qty']
                    );
                }
                $this->cart->update($data);
            }

            $carted = $this->cart->contents();
            echo count($carted);
            if (count($carted) == 0) {
                $this->cart('empty');
            }
        }


        if ($para1 == "whole_list") {
            echo json_encode($this->cart->contents());
        }

        if ($para1 == 'calcs') {
            if ($para2 == 'prices') {
                $carted = $this->cart->contents();
                $return = array();
                foreach ($carted as $row) {
                    $return[] = array('id' => $row['rowid'], 'price' => currency($row['price']), 'subtotal' => currency($row['subtotal']));
                }
                echo json_encode($return);
            }
        }
    }

    function whole_cart_cal()
    {
        $country_id = $this->input->post("country_id");
        $state_id = $this->input->post("state_id");
        $city_id = $this->input->post("city_id");
        $country_name = $this->input->post("country_name");
        $city_name = $this->input->post("city_name");
        $pan_from_wallet = $this->input->post("pan_from_wallet");
        // echo $city_name;die();
        $total = $this->cart->total();
        // $threshold_rate = $this->db->get("threshold_rate")->row_array();
        $no_of_item_in_cart = count($this->cart->contents());
        // if($this->crud_model->CheckAllowedTax()){
        //     $tax = $this->crud_model->getTaxByCountryAndState($country_id , $state_id );
        // }
        // else{
        //  $tax = 0;   
        // }
        if ($country_id != "") {
            // $shipping_charges = "0";
            $weight = 0;
            $is_weight_wise = false;
            $delivery_charges = $this->crud_model->getDeliveryChargesByCountryState($country_id, $state_id, $city_id);
            
            // $quoted_del_ch = $this->crud_model->getQuotedDeliveryCharges($country_name);
            foreach ($this->cart->contents() as $cart_content) {
                $product_id = $cart_content["options"]["product_id"];
                $this->db->where("product_id", $product_id);
                $shipping_details = $this->db->get("product")->row_array();

                // if($quoted_del_ch == null){
                //     if($country_name != 'pakistan'){
                //         $shipping_charges = QUOTED_FLAT_AMOUNT;
                //     }
                // }else{
                if ($delivery_charges && $delivery_charges['type'] == "w_b_s") {
                    for ($i = 1; $i <= $cart_content["qty"]; $i++) {
                        $weight = $weight + $cart_content["options"]["weight"];
                    }
                    $is_weight_wise = true;
                }
                // }
            }
            // if($threshold_rate=="" || $total <= $threshold_rate['threshold_rate']){
            if ($is_weight_wise == true) {
                if ($weight <= $delivery_charges['weight_over']) {
                    $shipping_charges = $delivery_charges['charges'];
                } else {
                    $shipping_charges = $delivery_charges['charges'];
                    $cart_addtional_weight = $weight - $delivery_charges['additional_weight'];
                    $cart_addtional_weight = ceil($cart_addtional_weight);
                    $shipping_charges = $shipping_charges + $cart_addtional_weight * $delivery_charges['additional_price'];
                }
            }
            //     if($country_name == "pakistan"){
            //         if($city_name == "karachi"){
            //             $shipping_charges = $shipping_charges + KHI_FLAT_AMOUNT;
            //         }
            //         else{
            //             $shipping_charges = $shipping_charges + CITY_OTHER_FLAT_AMOUNT;
            //         }
            //     }

            //     $grand = $total + $shipping_charges;
            //     $data = array(
            //         "grand"=>$grand,
            //         "ship"=>$shipping_charges,
            //         "tax"=>$tax
            //     ); 
            // }else{
            //     $data = array(
            //         "grand"=>$total,
            //         "ship"=>0,
            //         "tax"=>$tax
            //     ); 
            // }
            $data["no_of_item_in_cart"] = $no_of_item_in_cart;
            if ($is_weight_wise) {
                $data["ship"] = (int) $shipping_charges;
            } else {
                if ($delivery_charges) {
                    $data["ship"] = (int) $delivery_charges['charges'];
                } else {
                    $data["ship"] = 0;
                }
            }
            $data["total"] = $total;
            if ($delivery_charges && $delivery_charges['type'] == "f_r_s") {
                $data["title"] = 'For ' . $country_name;
            } else {
                if ($delivery_charges) {
                    $data["title"] = $delivery_charges['title'];
                } else {
                    $data["title"] = 'Free Shipping';
                }
            }
            $data["tax_amount"] = 0;
            $data["tax_percent"] = 0;
            $data["grand"] = $total + $data["ship"];

            // if($tax!=0){
            //     $data['tax_amount'] = round(($data['grand'] * $tax) / 100,2);
            //     $data['tax_percent'] = $tax;
            //     $data['grand'] = $data['grand'] + ($data['grand'] * $tax) / 100; 
            // } 

            if ($this->session->has_userdata("coupon_data")) {
                $coupon_data = $this->session->userdata("coupon_data");
                if (($data['grand'] - $coupon_data['total_discount']) <= 0) {
                    $data['grand'] = "0";
                } else {
                    $data['grand'] = ($data['grand'] - $coupon_data['total_discount']);
                }
            }

            if ($this->session->userdata('user_login') == "yes") {
                $user_balance = $this->wallet_model->user_balance();
                if ($pan_from_wallet && $user_balance > 0) {
                    if (($data['grand'] - $user_balance) <= 0) {
                        $user_balance = (int) ($user_balance - $data['grand']);
                        $data['panned_from_wallet'] = $data['grand'];
                        $data['grand'] = "0";
                    } else {
                        $data['panned_from_wallet'] = (int) $user_balance;
                        $data['grand'] = (int) ($data['grand'] - $user_balance);
                        $user_balance = 0;
                    }
                    $data['user_balance'] = (int) $user_balance;
                } else {
                    $data['user_balance'] = (int) $user_balance;
                }
            }

            $data['grand'] = round($data['grand'], 2);
            // if($is_weight_wise == true){
            //     $data['shipping_available'] =  ($quoted_del_ch) ? 1 : 0;
            // }
            echo json_encode($data);
        } else {
            $grand = $total;
            $data = array(
                "title" => 'Shipping rates vary by country.',
                "total" => $total,
                "grand" => $grand,
                "no_of_item_in_cart" => $no_of_item_in_cart,
                "ship" => 0,
            );
            $ship = 0;
            // if($total <= $threshold_rate['threshold_rate']){
            //    $is_flat = false;
            //     foreach( $this->cart->contents() as $cart_content){
            //         $product_id =  $cart_content["options"]["product_id"];

            //         $this->db->where("product_id",$product_id);
            //         $shipping_details = $this->db->get("product")->row_array();

            //         if($quoted_del_ch == null){
            //                         // for($i=1; $i<=$cart_content["qty"]; $i++){
            //             $ship = QUOTED_FLAT_AMOUNT;
            //                         // }
            //             $is_flat = true;
            //         }
            //     }  
            //     if($is_flat){
            //         $data["ship"] = $ship;
            //     }else{
            //         $data["ship"] = 0;
            //     } 
            //     $data["grand"] = ($data["grand"] + $ship);
            // }else{
            //     $data["grand"] = ($grand);
            //     $data["ship"] = 0;
            // }
            // $data["total"] = $total;
            // $data["grand_total_val"] = ($grand + $ship);
            /* if coupon set then below things will happens */
            if ($this->session->has_userdata("coupon_data")) {
                $coupon_data = $this->session->userdata("coupon_data");
                if (($data['grand'] - $coupon_data['total_discount']) <= 0) {
                    $data['grand'] = 0;
                } else {
                    $data['grand'] = ($data['grand'] - $coupon_data['total_discount']);
                }
            }
            // /* end of coupon amount setting */
            // if($tax!=0){
            //     $data['tax_amount'] = round(($data['grand'] * $tax) / 100,2);
            //     $data['grand'] = $data['grand'] + ($data['grand'] * $tax) / 100;
            // }
            $data['grand'] = round($data['grand'], 2);
            // $data['tax_percent'] = $tax;
            echo json_encode($data);
        }
    }

    /* FUNCTION: Loads Cart Checkout Page*/
    function cart_checkout($para1 = "")
    {
        $carted = $this->cart->contents();
        if (count($carted) <= 0) {
            redirect(base_url() . 'home/', 'refresh');
        }
        if ($para1 == "orders") {
            $data["countries"] = $this->db->select('*')->from("country")->order_by('country_name', 'ASC')->get()->result_array();
            $this->load->view('front/shopping_cart/order_set', $data);
        } elseif ($para1 == "delivery_address") {
            $this->load->view('front/shopping_cart/delivery_address');
        } elseif ($para1 == "payments_options") {
            $this->load->view('front/shopping_cart/payments_options');
        } else {
            $page_data['logger'] = $para1;
            $page_data['page_name'] = "shopping_cart";
            $page_data['asset_page'] = "shopping_cart";
            $page_data['page_title'] = translate('my_cart');
            $page_data['carted'] = $this->cart->contents();
            $this->load->view('front/index', $page_data);
        }
    }

    function apply_coupon()
    {
        $coupon_code = $this->input->post("code");
        $grand_total = $this->input->post("hdd_grand_amount");
        $data = array();
        $this->db->where("code", $coupon_code);
        $this->db->where("status", "ok");
        $this->db->where("till >=", date("Y-m-d"));
        $c = $this->db->get("coupon");
        $coupon = $c->row_array();
        if ($c->num_rows() > 0) {
            if ($coupon['unlimited'] != 1) {
                if ($coupon['no_of_apply'] <= 0) {
                    $data['status'] = 0;
                    $data['msg'] = "Invalid Coupon.";
                    echo json_encode($data);
                    exit;
                }
            }
            if ($coupon['discount_type'] == "amount") {
                $discounted_amount = $coupon['discount_value'];
                $data['discount_amount_for_user'] = currency($discounted_amount);
            } else if ($coupon['discount_type'] == "percent") {
                $discounted_amount = ($grand_total * $coupon['discount_value']) / 100;
                $data['discount_amount_for_user'] = $coupon['discount_value'] . "% off";
            }

            $data['msg'] = "Coupon Discount Succesfully";
            $data['status'] = 1;
            if ($grand_total == 0) {
                $data['grand_total'] = 0;
                $data['discounted_amount'] = $discounted_amount;
            } else {
                $after_apply = $grand_total - $discounted_amount;
                if ($after_apply <= 0) {
                    $data['grand_total'] = 0;
                    $data['discounted_amount'] = $discounted_amount;
                } else {
                    $data['grand_total'] = $after_apply;
                    $data['discounted_amount'] = $discounted_amount;
                }
            }
            $this->session->set_userdata("coupon_data", array("set_coupon" => 1,
                "coupon_id" => $coupon['coupon_id'],
                "discount_type" => $coupon['discount_type'],
                "discount_amount_for_user" => $data['discount_amount_for_user'],
                "no_of_apply" => ($coupon['unlimited'] == 1 ? "unlimited" : "limited"),
                "total_discount" => $discounted_amount));
        } else {
            $data['status'] = 0;
            $data['msg'] = "Invalid Coupon.";
        }
        echo json_encode($data);
    }

    /* FUNCTION: Loads Cart Checkout Page*/
    function coupon_check()
    {
        $para1 = $this->input->post('code');
        $carted = $this->cart->contents();
        if (count($carted) > 0) {
            $p = $this->session->userdata('coupon_apply') + 1;
            $this->session->set_userdata('coupon_apply', $p);
            $p = $this->session->userdata('coupon_apply');
            if ($p < 10) {
                $c = $this->db->get_where('coupon', array('code' => $para1));
                $coupon = $c->result_array();
                //echo $c->num_rows();
                //,'till <= '=>date('Y-m-d')
                if ($c->num_rows() > 0) {
                    foreach ($coupon as $row) {
                        // $spec = json_decode($row['spec'],true);
                        $coupon_id = $row['coupon_id'];
                        $till = strtotime($row['till']);
                    }
                    if ($till > time()) {
                        $ro = $spec;
                        $type = $row['discount_type'];
                        $value = $row['discount_value'];
                        $set_type = $row['set_type'];
                        $set = json_decode($row['set']);
                        if ($set_type !== 'total_amount') {
                            $dis_pro = array();
                            $set_ra = array();
                            if ($set_type == 'all_products') {
                                $set_ra[] = $this->db->get('product')->result_array();
                            } else {
                                foreach ($set as $p) {
                                    if ($set_type == 'product') {
                                        $set_ra[] = $this->db->get_where('product', array('product_id' => $p))->result_array();
                                    } else {
                                        $set_ra[] = $this->db->get_where('product', array($set_type => $p))->result_array();
                                    }
                                }
                            }
                            foreach ($set_ra as $set) {
                                foreach ($set as $n) {
                                    $dis_pro[] = $n['product_id'];
                                }
                            }
                            foreach ($carted as $items) {
                                if (in_array($items['id'], $dis_pro)) {
                                    $base_price = $this->crud_model->get_product_price($items['id']);
                                    if ($type == 'percent') {
                                        $discount = $base_price * $value / 100;
                                    } else if ($type == 'amount') {
                                        $discount = $value;
                                    }
                                    $data = array(
                                        'rowid' => $items['rowid'],
                                        'price' => $base_price - $discount,
                                        'coupon' => $coupon_id
                                    );
                                } else {
                                    $data = array(
                                        'rowid' => $items['rowid'],
                                        'price' => $items['price'],
                                        'coupon' => $items['coupon']
                                    );
                                }
                                $this->cart->update($data);
                            }
                            echo 'wise:-:-:' . translate('coupon_discount_activated');
                        } else {
                            $this->cart->set_discount($value);
                            echo 'total:-:-:' . translate('coupon_discount_activated') . ':-:-:' . currency() . $value;
                        }
                        $this->cart->set_coupon($coupon_id);
                        $this->session->set_userdata('couponer', 'done');
                        $this->session->set_userdata('coupon_apply', 0);
                    } else {
                        echo 'nope';
                    }
                } else {
                    echo 'nope';
                }
            } else {
                echo 'Too many coupon request!';
            }
        }
    }


    /* FUNCTION: Finalising Purchase*/
    function cart_finish($para1 = "", $para2 = "")
    {
        $today = date("Y-m-d h:i:s");
        $this->guess_account_delivery_set();

        $carted = $this->cart->contents();
        if (count($carted) <= 0) {
            redirect(base_url() . 'home/', 'refresh');
        }

        $carted = $this->cart->contents();
        $total = $this->cart->total();
        $exchange = exchange('usd');
        // $vat_per  = '';
// $vat      = $this->crud_model->cart_total_it('tax');
        if ($this->crud_model->get_type_name_by_id('business_settings', '3', 'value') == 'product_wise') {
            $shipping = $this->crud_model->cart_total_it('shipping');
        } else {
            $shipping = $this->crud_model->get_type_name_by_id('business_settings', '2', 'value');
        }
        $grand_total = $total;
        $product_details = json_encode($carted);

        $this->db->where('user_id', $this->session->userdata('user_id'));
        $this->db->update('user', array(
            'langlat' => $this->input->post('langlat')
        ));

        if ($this->input->post('payment_type') == 'authorize_net') {
            // echo "<pre>";print_r($product_details);die();
            $this->load->library("form_validation");
            $this->form_validation->set_rules("firstname", "First Name", "required|trim");
            $this->form_validation->set_rules("lastname", "Last Name", "required|trim");
            $this->form_validation->set_rules("address1", "Address", "required|trim");
            $this->form_validation->set_rules("zip", "Zip", "required|trim|min_length[5]|max_length[10]");
            $this->form_validation->set_rules("email", "Email", "required|trim|valid_email");
            $this->form_validation->set_rules("phone", "Phone", "required|trim");
            $this->form_validation->set_rules("country", "Country", "required|trim");
            $this->form_validation->set_rules("state", "State", "required|trim");
            $this->form_validation->set_rules("city", "City", "required|trim");
            $this->form_validation->set_rules("card_number", "Cart Number", "required|trim|numeric|min_length[16]");
            $this->form_validation->set_rules("expirymonth", "Expiry Month", "required|trim|numeric|exact_length[2]");
            $this->form_validation->set_rules("expiryyear", "Expiry Year", "required|trim|numeric|exact_length[4]");
            $this->form_validation->set_rules("cv_code", "CV Code", "required|trim|min_length[3]");
            $this->form_validation->set_rules("hdd_grand_amount", "HDD Grand Price", "required|trim");
            $this->form_validation->set_rules("hdd_shipping_charges", "HDD Shipping Price", "required|trim");

            if ($this->form_validation->run()) {
                $my_grand = $this->input->post("hdd_grand_amount");
                $first_name = $this->input->post("firstname");
                $last_name = $this->input->post("lastname");
                $address = $this->input->post("address1");
                $zip = $this->input->post("zip");
                $email = $this->input->post("email");
                $phone = $this->input->post("phone");
                $country = $this->crud_model->get_type_name_by_id("country", $this->input->post("country"), "country_name");
                $state = $this->crud_model->get_type_name_by_id("state", $this->input->post("state"), "state_name");
                $city = $this->crud_model->get_type_name_by_id("city", $this->input->post("city"), "city_name");
                $card_number = $this->input->post("card_number");
                $card_expire_month = $this->input->post("expirymonth");
                $card_expire_year = $this->input->post("expiryyear");
                $card_cvv_code = $this->input->post("cv_code");

                $hdd_shipping_charges = $this->input->post("hdd_shipping_charges");
                $hdd_tax_percent = $this->input->post("hdd_tax_percent");
                $hdd_tax_amount = $this->input->post("hdd_tax_amount");
                $product_details = json_decode($product_details, true);
                $hdd_discount_coupon_amount = $this->input->post("hdd_discount_coupon");

                $sales_prod_details = array();
                foreach ($product_details as $product_detail) {
                    unset($product_detail['rowid']);
                    $sales_prod_details[] = $product_detail;
                }

                $lineItemsArr = array();
                $desc = "";
                foreach ($product_details as $pro) {
                    $this->db->where("product_variants_id", $pro['id']);
                    $results = $this->db->get("product_variants")->result_array();
                    foreach ($results as $key => $result) {
                        $desc .= $result["title"] . " , ";
                    }

                    $item_arr = array
                    (
                        'itemId' => $pro['id'],
                        'name' => substr($pro['name'], 0, 22),
                        'quantity' => $pro['qty'],
                        'unitPrice' => $pro['price'],
                    );
                    $lineItemsArr["lineItem"][] = $item_arr;
                }
                

                $data = array
                (
                    'amount' => str_replace(",", "", $my_grand),
                    'tax' => str_replace(",", "", $hdd_tax_amount),
                    'card_number' => $card_number,
                    'cv_code' => $card_cvv_code,
                    'expiryyear' => $card_expire_year,
                    'expirymonth' => $card_expire_month,
                    'firstname' => $first_name,
                    'lastname' => $last_name,
                    'address' => $address,
                    'zip' => $zip,
                    'email' => $email,
                    'phone' => $phone,
                    'user_id' => '',
                    'city' => $city,
                    'state' => $state,
                    'country' => $country,
                    'ref' => 'ref-' . time(),
                    'invoice_numb' => time(),
                    'orderInfo' => $desc,
                    'lineItem' => (object) $lineItemsArr,
                );

                $shipping_address = $_POST;

                $card_number = $shipping_address['card_number'];
                $hide_card_number = "";
                $card_number_length = strlen($card_number) - 4;
                for ($i = 1; $i <= strlen($card_number); $i++) {
                    if ($card_number_length > $i) {
                        $hide_card_number .= "*";
                    } else {
                        $hide_card_number .= $card_number[$i];
                    }
                }

                $shipping_address['card_number'] = $hide_card_number;

                $dataSale['created'] = $today;
                $dataSale['product_details'] = json_encode($sales_prod_details);
                $dataSale['shipping_address'] = json_encode($shipping_address);
                $dataSale['vat'] = isset($vat) ? $vat : "";
                $dataSale['vat_percent'] = isset($vat_per) ? $vat_per : "";
                $dataSale['shipping'] = $hdd_shipping_charges;
                // $dataSale['delivery_status']    = '[]';
                $dataSale['payment_type'] = "authorize_net";
                $dataSale['payment_status'] = '[]';
                $dataSale['payment_details'] = 'none';
                $dataSale['grand_total'] = $my_grand;
                $dataSale['sale_datetime'] = time();
                // $dataSale['delivary_datetime']  = '';
                $dataSale['status'] = 'half';
                if ($this->session->has_userdata(coupon_data)) {
                    $coupon_data = $this->session->userdata("coupon_data");
                    $dataSale['coupon_id'] = $coupon_data["coupon_id"];
                    $dataSale['coupon_amount'] = $coupon_data["total_discount"];
                }
                $dataSale['ref_id'] = 11;
                $dataSale['vat_percent'] = $hdd_tax_percent;
                $dataSale['vat'] = $hdd_tax_amount;
                if ($this->session->userdata('user_login') == 'yes') {
                    $dataSale['buyer'] = $this->session->userdata('user_id');
                    $data['user_id'] = $this->session->userdata('user_id');
                } else {
                    $dataSale['buyer'] = "guest";
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < 10; $i++) {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                    $dataSale['guest_id'] = $randomString;
                    $data['user_id'] = $randomString;
                }

                // echo "<pre>";print_r( $dataSale) ;die();
                if ($this->db->insert('sale', $dataSale)) {
                    $sale_id = $this->db->insert_id();

                    //setting invoice no.
                    $sales_code = date('Ym', $dataSale['sale_datetime']) . $sale_id;
                    $this->db->set('sale_code', $sales_code);
                    $this->db->where('sale_id', $sale_id);
                    $this->db->update('sale');

                    foreach ($product_details as $pro) {
                        $order_product_details[] = array(
                            "sale_id" => $sale_id,
                            "product_id" => $pro['options']['product_id'],
                            "product_variants_id" => $pro['id'],
                            "qty" => $pro['qty'],
                            "price" => $pro['price'],
                            "product_name" => $pro['name'],
                            "selling_price" => $pro['options']['selling_price'],
                            "discount" => $pro['options']['discount'],
                            "discount_type" => $pro['options']['discount_type'],
                            "weight" => $pro['options']['weight'],
                            "actual_size" => $pro['options']['actual_size'],
                            "images" => $pro['options']['image'],
                            "color" => $pro['options']['color'],
                        );
                    }

                    $this->db->insert_batch('order_products', $order_product_details);

                    $data['ref'] = $sale_id;

                    $this->load->library('Authrize', 'authrize');
                    $resp = $this->authrize->chargeCreditCardDetail($data);

                    if ($resp['status'] == 1) {
                        $history_arr = array(
                            'created' => $today,
                            'updated' => $today,
                            'payment_type' => "authorize_net",
                            'payment_detail' => json_encode($resp['raw']),
                            'sale_id' => $sale_id
                        );
                        foreach ($product_details as $product_detail) {
                            $product_variants_id = $product_detail['id'];
                            $qty = $product_detail['qty'];
                            $this->db->where("product_variants_id", $product_variants_id);
                            $this->db->set("stock_status", "stock_status-$qty", FALSE);
                            $this->db->update('product_variants');
                        }
                        if ($this->session->has_userdata(coupon_data)) {
                            $coupon_data = $this->session->userdata("coupon_data");
                            if ($coupon_data['no_of_apply'] == "limited") {
                                $this->db->set('no_of_apply', 'no_of_apply-1', FALSE);
                                $this->db->where("coupon_id", $coupon_data['coupon_id']);
                                $this->db->update("coupon");
                            }
                            $this->session->unset_userdata("coupon_data");
                        }
                    } else {
                        $this->session->set_flashdata("errors", "Some Errors Found In  Your Payment Detail.");
                        redirect("home/cart_checkout");
                    }

                    if ($this->db->insert('payment_history', $history_arr)) {
                        $vendors = $this->crud_model->vendors_in_sale($sale_id);
                        $payment_status = array();
                        $delivery_status = array();
                        foreach ($product_details as $product_detail) {
                            $vendor_id = $this->crud_model->get_type_name_by_id("product", $product_detail['options']['product_id'], "vendor_id");
                            $payment_status[] = array('vendor' => $vendor_id);
                            $delivery_status[] = array('vendor' => $vendor_id);
                        }
                        $data_ins_final = array
                        (
                            'updated' => $today,
                            'trans_id' => $resp['trans_id'],
                            'sale_code' => date('Ym', time()) . $sale_id,
                            'delivery_status' => json_encode($delivery_status),
                            'payment_status' => json_encode($payment_status),
                            'status' => 'full'
                        );

                        $this->db->where('sale_id', $sale_id);
                        $this->db->update('sale', $data_ins_final);

                    } else {
                        $this->session->set_flashdata("errors", "Error Occured While Saving Payment History");
                        redirect("home/cart_checkout");
                    }

                    $this->email_model->email_invoice($sale_id);
                    $this->cart->destroy();
                    $this->session->set_userdata('couponer', '');
                    if ($this->session->userdata('user_login') == 'yes') {
                        echo '<script>' . 'window.location="' . base_url() . 'home/invoice/' . $sale_id . '";' . '</script>';
                        redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
                    } else {
                        echo '<script>' . 'window.location="' . base_url() . 'home/guest_invoice/' . $dataSale['guest_id'] . '";' . '</script>';
                        redirect(base_url() . 'home/guest_invoice/' . $dataSale['guest_id'], 'refresh');
                    }
                } else {
                    $this->session->set_flashdata("errors", "Error Occured While Saving Sales Record");
                    redirect("home/cart_checkout");
                }
            } else {
                $this->session->set_flashdata("errors", validation_errors("<p style='margin:0px;'>", "</p>"));
                redirect("home/cart_checkout");
            }
            //echo '<pre>'. print_r($data, 1).'</pre>';
        } else if ($this->input->post('payment_type') == 'paypal') {
            if ($para1 == 'go') {
                $this->load->library("form_validation");
                $this->form_validation->set_rules("firstname", "First Name", "required|trim");
                $this->form_validation->set_rules("lastname", "Last Name", "required|trim");
                $this->form_validation->set_rules("address1", "Address", "required|trim");
                $this->form_validation->set_rules("zip", "Zip", "required|trim|min_length[5]|max_length[10]");
                $this->form_validation->set_rules("email", "Email", "required|trim|valid_email");
                $this->form_validation->set_rules("phone", "Phone", "required|trim");
                $this->form_validation->set_rules("country", "Country", "required|trim");
                $this->form_validation->set_rules("state", "State", "required|trim");
                $this->form_validation->set_rules("city", "City", "required|trim");
                $this->form_validation->set_rules("hdd_grand_amount", "HDD Grand Price", "required|trim");
                $this->form_validation->set_rules("hdd_shipping_charges", "HDD Shipping Price", "required|trim");
                if ($this->form_validation->run()) {
                    $my_grand = $this->input->post("hdd_grand_amount");
                    $first_name = $this->input->post("firstname");
                    $last_name = $this->input->post("lastname");
                    $address = $this->input->post("address1");
                    $zip = $this->input->post("zip");
                    $email = $this->input->post("email");
                    $phone = $this->input->post("phone");
                    $country = $this->crud_model->get_type_name_by_id("country", $this->input->post("country"), "country_name");
                    $state = $this->crud_model->get_type_name_by_id("state", $this->input->post("state"), "state_name");
                    $city = $this->crud_model->get_type_name_by_id("city", $this->input->post("city"), "city_name");
                    $hdd_shipping_charges = $this->input->post("hdd_shipping_charges");
                    $hdd_tax_percent = $this->input->post("hdd_tax_percent");
                    $hdd_tax_amount = $this->input->post("hdd_tax_amount");
                    $product_details = json_decode($product_details, true);
                    $hdd_discount_coupon_amount = $this->input->post("hdd_discount_coupon");
                    $shipping_address = $_POST;

                    $card_number = $shipping_address['card_number'];
                    $hide_card_number = "";
                    $card_number_length = strlen($card_number) - 4;
                    for ($i = 1; $i <= strlen($card_number); $i++) {
                        if ($card_number_length > $i) {
                            $hide_card_number .= "*";
                        } else {
                            $hide_card_number .= $card_number[$i];
                        }
                    }
                    $shipping_address['card_number'] = $hide_card_number;

                    $sales_prod_details = array();
                    foreach ($product_details as $product_detail) {
                        unset($product_detail['rowid']);
                        $sales_prod_details[] = $product_detail;
                    }

                    $data['product_details'] = json_encode($sales_prod_details);
                    $data['shipping_address'] = json_encode($shipping_address);
                    $data['vat'] = $hdd_tax_amount;
                    $data['vat_percent'] = $hdd_tax_percent;
                    $data['shipping'] = $hdd_shipping_charges;
                    $data['buyer'] =  $_SESSION['user_id'];
                    // $data['delivery_status'] = '[]';
                    // $data['delivary_datetime'] = '';
                    $data['payment_type'] = "paypal";
                    $data['payment_status'] = '[]';
                    $data['payment_details'] = 'none';
                    $data['grand_total'] = $my_grand;
                    $data['sale_datetime'] = time();
                    $data['status'] = 'half';
                    $data['created'] = $today;
                    if ( isset($_SESSION['coupon_data']) ){
                        $coupon_data = $this->session->userdata("coupon_data");
                        $data['coupon_id'] = $coupon_data["coupon_id"];
                        $data['coupon_amount'] = $coupon_data["total_discount"];
                    }
                    $paypal_email = $this->crud_model->get_type_name_by_id('business_settings', '1', 'value');
                    $this->db->insert('sale', $data);
                    $sale_id = $this->db->insert_id();


                    foreach ($product_details as $product_detail) {

                        $order_product_details[] = array(
                            "sale_id" => $sale_id,
                            "product_id" => $product_detail['options']['product_id'],
                            "product_variants_id" => $product_detail['id'],
                            "qty" => $product_detail['qty'],
                            "price" => $product_detail['price'],
                            "product_name" => $product_detail['name'],
                            "selling_price" => $product_detail['options']['selling_price'],
                            "discount" => $product_detail['options']['discount'],
                            "discount_type" => $product_detail['options']['discount_type'],
                            "weight" => $product_detail['options']['weight'],
                            "actual_size" => $product_detail['options']['actual_size'],
                            "images" => $product_detail['options']['image'],
                            "color" => $product_detail['options']['color'],
                        );
                    }

                    $this->db->insert_batch('order_products', $order_product_details);

                    if ($this->session->userdata('user_login') == 'yes') {
                        $data['buyer'] = $this->session->userdata('user_id');
                    } else {
                        $data['buyer'] = "guest";
                        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                        $charactersLength = strlen($characters);
                        $randomString = '';
                        for ($i = 0; $i < 10; $i++) {
                            $randomString .= $characters[rand(0, $charactersLength - 1)];
                        }
                        $data['guest_id'] = $sale_id . '-' . $randomString;
                    }

                    $vendors = $this->crud_model->vendors_in_sale($sale_id);
                    $delivery_status = array();
                    $payment_status = array();
                    foreach ($product_details as $product_detail) {
                        $vendor_id = $this->crud_model->get_type_name_by_id("product", $product_detail['options']['product_id'], "vendor_id");
                        $payment_status[] = array('vendor' => $vendor_id);
                        $delivery_status[] = array('vendor' => $vendor_id);
                    }
                    $data['sale_code'] = date('Ym', $data['sale_datetime']) . $sale_id;
                    $data['delivery_status'] = json_encode($delivery_status);
                    $data['payment_status'] = json_encode($payment_status);
                    
                    $this->db->where('sale_id', $sale_id);
                    $this->db->update('sale', $data);
                    $this->session->set_userdata('sale_id', $sale_id);
                    //echo $my_grand; die();
                    //die('herere');
                    /****TRANSFERRING USER TO PAYPAL TERMINAL****/
                    $this->paypal->add_field('rm', 2);
                    $this->paypal->add_field('no_note', 0);
                    $this->paypal->add_field('cmd', '_cart');
                    $this->paypal->add_field('upload', '1');
                    $i = 1;

                    /*echo "<pre>";
                    print_r($carted);
                    echo "</pre>";
                    exit;*/

                    foreach ($carted as $val) {
                        $this->paypal->add_field('item_number_' . $i, $i);
                        $this->paypal->add_field('item_name_' . $i, $val['name']);
                        //$this->paypal->add_field('amount_' . $i, $this->cart->format_number(($val['price'] / $exchange)));
                        $this->paypal->add_field('amount_' . $i, $val['price']);
                        if ($this->crud_model->get_type_name_by_id('business_settings', '3', 'value') == 'product_wise') {
                            //$this->paypal->add_field('shipping_' . $i, $this->cart->format_number((($val['shipping'] / $exchange) * $val['qty'])));
                            //$this->paypal->add_field('shipping_' . $i, ($val['shipping'] / $exchange) * $val['qty']);
                        }
                        //$this->paypal->add_field('tax_' . $i, $this->cart->format_number(($val['tax'] / $exchange)));
                        // $this->paypal->add_field('tax_' . $i, $val['tax']);
                        $this->paypal->add_field('quantity_' . $i, $val['qty']);
                        $i++;
                    }

                    //$this->paypal->add_field('amount_1', $my_grand);

                    $this->paypal->add_field('shipping_1', $hdd_shipping_charges);
                    $this->paypal->add_field('tax_cart', $hdd_tax_amount);
                    $this->paypal->add_field('discount_amount_1', $hdd_discount_coupon_amount);

                    //$this->paypal->add_field('currency_code', 'currency_code()');
                    //$this->paypal->add_field('custom', $sale_id);
                    $this->paypal->add_field('business', $paypal_email);
                    $this->paypal->add_field('notify_url', base_url() . 'home/paypal_ipn');
                    $this->paypal->add_field('cancel_return', base_url() . 'home');

                    foreach ($product_details as $product_detail) {
                        $product_variants_id = $product_detail['id'];
                        $qty = $product_detail['qty'];
                        $this->db->where("product_variants_id", $product_variants_id);
                        $this->db->set("stock_status", "stock_status-$qty", FALSE);
                        $this->db->update('product_variants');
                    }

                    $sess_data = array(
                        'timestamp' => time(),
                        'data' => json_encode($_SESSION),
                        'is_used' => 0,
                    );
                    $this->db->insert('paypal_return_sessions', $sess_data);
                    $this->paypal->add_field('return', base_url() . 'home/paypal_success?sale_id=' . $sale_id . '&code=' . $sess_data['timestamp']);
                    $this->paypal->submit_paypal_post();
                    exit();

                    // submit the fields to paypal
                } else {
                    $this->session->set_flashdata("errors", validation_errors("<p style='margin:0px;'>", "</p>"));
                    redirect("home/cart_checkout");
                }
            }
        } else if ($this->input->post('payment_type') == 'cod') {

            //echo "<pre>";print_r($product_details);die();
            $this->load->library("form_validation");
            $this->form_validation->set_rules("firstname", "First Name", "required|trim");
            $this->form_validation->set_rules("lastname", "Last Name", "required|trim");
            $this->form_validation->set_rules("address1", "Address", "required|trim");
            $this->form_validation->set_rules("zip", "Zip", "required|trim|min_length[5]|max_length[10]");
            $this->form_validation->set_rules("email", "Email", "required|trim|valid_email");
            $this->form_validation->set_rules("phone", "Phone", "required|trim");
            $this->form_validation->set_rules("country", "Country", "required|trim");
            $this->form_validation->set_rules("state", "State", "required|trim");
            $this->form_validation->set_rules("city", "City", "required|trim");
            $this->form_validation->set_rules("hdd_grand_amount", "HDD Grand Price", "required|trim");
            $this->form_validation->set_rules("hdd_shipping_charges", "HDD Shipping Price", "required|trim");

            
            if ($this->form_validation->run()) {
                $my_grand = $this->input->post("hdd_grand_amount");
                $first_name = $this->input->post("firstname");
                $last_name = $this->input->post("lastname");
                $address = $this->input->post("address1");
                $zip = $this->input->post("zip");
                $email = $this->input->post("email");
                $phone = $this->input->post("phone");
                $country = $this->crud_model->get_type_name_by_id("country", $this->input->post("country"), "country_name");
                $state = $this->crud_model->get_type_name_by_id("state", $this->input->post("state"), "state_name");
                $city = $this->crud_model->get_type_name_by_id("city", $this->input->post("city"), "city_name");
                $card_number = $this->input->post("card_number");
                $card_expire_month = $this->input->post("expirymonth");
                $card_expire_year = $this->input->post("expiryyear");
                $card_cvv_code = $this->input->post("cv_code");

                $hdd_shipping_charges = $this->input->post("hdd_shipping_charges");
                $hdd_tax_percent = $this->input->post("hdd_tax_percent");
                $hdd_tax_amount = $this->input->post("hdd_tax_amount");
                $product_details = json_decode($product_details, true);
                $hdd_discount_coupon_amount = $this->input->post("hdd_discount_coupon");

                $sales_prod_details = array();
                foreach ($product_details as $product_detail) {
                    unset($product_detail['rowid']);
                    $sales_prod_details[] = $product_detail;
                }

                $lineItemsArr = array();
                $desc = "";
                foreach ($product_details as $pro) {
                    $this->db->where("product_variants_id", $pro['id']);
                    $results = $this->db->get("product_variants")->result_array();
                    foreach ($results as $key => $result) {
                        $desc .= $result["title"] . " , ";
                    }

                    $item_arr = array
                    (
                        'itemId' => $pro['id'],
                        'name' => substr($pro['name'], 0, 22),
                        'quantity' => $pro['qty'],
                        'unitPrice' => $pro['price'],
                    );
                    $lineItemsArr["lineItem"][] = $item_arr;
                }

                $shipping_address = $_POST;

                $dataSale['created'] = $today;
                $dataSale['product_details'] = json_encode($sales_prod_details);
                $dataSale['shipping_address'] = json_encode($shipping_address);
                $dataSale['vat'] = $vat;
                $dataSale['vat_percent'] = $vat_per;
                $dataSale['shipping'] = $hdd_shipping_charges;
                $dataSale['delivery_status'] = '[]';
                $dataSale['payment_type'] = "authorize_net";
                $dataSale['payment_status'] = '[]';
                $dataSale['payment_details'] = 'none';
                $dataSale['grand_total'] = $my_grand;
                $dataSale['sale_datetime'] = time();
                $dataSale['delivary_datetime'] = '';
                $dataSale['status'] = 'full';
                if ($this->session->has_userdata(coupon_data)) {
                    $coupon_data = $this->session->userdata("coupon_data");
                    $dataSale['coupon_id'] = $coupon_data["coupon_id"];
                    $dataSale['coupon_amount'] = $coupon_data["total_discount"];
                }
                $dataSale['ref_id'] = 11;
                $dataSale['vat_percent'] = $hdd_tax_percent;
                $dataSale['vat'] = $hdd_tax_amount;
                if ($this->session->userdata('user_login') == 'yes') {
                    $dataSale['buyer'] = $this->session->userdata('user_id');
                } else {
                    $dataSale['buyer'] = "guest";
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < 10; $i++) {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                    $dataSale['guest_id'] = $randomString;
                    $data['user_id'] = $randomString;
                }

                $this->db->insert('sale', $dataSale);
                $sale_id = $this->db->insert_id();

                foreach ($product_details as $pro) {
                    $order_product_details[] = array(
                        "sale_id" => $sale_id,
                        "product_id" => $pro['options']['product_id'],
                        "product_variants_id" => $pro['id'],
                        "qty" => $pro['qty'],
                        "price" => $pro['price'],
                        "product_name" => $pro['name'],
                        "selling_price" => $pro['options']['selling_price'],
                        "discount" => $pro['options']['discount'],
                        "discount_type" => $pro['options']['discount_type'],
                        "weight" => $pro['options']['weight'],
                        "actual_size" => $pro['options']['actual_size'],
                        "images" => $pro['options']['image'],
                        "color" => $pro['options']['color'],
                    );
                }

                $this->db->insert_batch('order_products', $order_product_details);
                $history_arr = array(
                    'created' => $today,
                    'updated' => $today,
                    'payment_type' => "cod",
                    'sale_id' => $sale_id
                );
                foreach ($product_details as $product_detail) {
                    $product_variants_id = $product_detail['id'];
                    $qty = $product_detail['qty'];
                    $this->db->where("product_variants_id", $product_variants_id);
                    $this->db->set("stock_status", "stock_status-$qty", FALSE);
                    $this->db->update('product_variants');
                }
                if ($this->session->has_userdata(coupon_data)) {
                    $coupon_data = $this->session->userdata("coupon_data");
                    if ($coupon_data['no_of_apply'] == "limited") {
                        $this->db->set('no_of_apply', 'no_of_apply-1', FALSE);
                        $this->db->where("coupon_id", $coupon_data['coupon_id']);
                        $this->db->update("coupon");
                    }
                    $this->session->unset_userdata("coupon_data");
                }

                $this->db->insert('payment_history', $history_arr);

                $vendors = $this->crud_model->vendors_in_sale($sale_id);
                $payment_status = array();
                $delivery_status = array();
                foreach ($product_details as $product_detail) {
                    $vendor_id = $this->crud_model->get_type_name_by_id("product", $product_detail['options']['product_id'], "vendor_id");
                    $payment_status[] = array('vendor' => $vendor_id);
                    $delivery_status[] = array('vendor' => $vendor_id);
                }
                $data_ins_final = array
                (
                    'updated' => $today,
                    'sale_code' => date('Ym', time()) . $sale_id,
                    'delivery_status' => json_encode($delivery_status),
                    'payment_status' => json_encode($payment_status)
                );
                $this->db->where('sale_id', $sale_id);
                $this->db->update('sale', $data_ins_final);

                $this->email_model->email_invoice($sale_id);
                $this->email_model->order_confirmation_email_admin($sale_id);

                $this->cart->destroy();
                if ($this->session->userdata('user_login') == 'yes') {
                    redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
                } else {
                    redirect(base_url() . 'home/guest_invoice/' . $dataSale['guest_id'], 'refresh');
                }
            } else {
                $this->session->set_flashdata("errors", validation_errors("<p style='margin:0px;'>", "</p>"));
                redirect("home/cart_checkout");
            }
            //echo '<pre>'. print_r($data, 1).'</pre>';
        } else if ($this->input->post('payment_type') == 'c2') {
            if ($para1 == 'go') {

                $data['product_details'] = $product_details;
                $data['shipping_address'] = json_encode($_POST);
                $data['vat'] = $vat;
                $data['vat_percent'] = $vat_per;
                $data['shipping'] = $shipping;
                $data['delivery_status'] = '[]';
                $data['payment_type'] = $para1;
                $data['payment_status'] = '[]';
                $data['payment_details'] = 'none';
                $data['grand_total'] = $grand_total;
                $data['sale_datetime'] = time();
                $data['delivary_datetime'] = '';
                $c2_user = $this->db->get_where('business_settings', array('type' => 'c2_user'))->row()->value;
                $c2_secret = $this->db->get_where('business_settings', array('type' => 'c2_secret'))->row()->value;

                $this->db->insert('sale', $data);
                $sale_id = $this->db->insert_id();
                if ($this->session->userdata('user_login') == 'yes') {
                    $data['buyer'] = $this->session->userdata('user_id');
                } else {
                    $data['buyer'] = "guest";
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < 10; $i++) {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                    $data['guest_id'] = $sale_id . '-' . $randomString;
                }
                $vendors = $this->crud_model->vendors_in_sale($sale_id);
                $delivery_status = array();
                $payment_status = array();
                foreach ($vendors as $p) {
                    $delivery_status[] = array('vendor' => $p, 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                    $payment_status[] = array('vendor' => $p, 'status' => 'due');
                }
                if ($this->crud_model->is_admin_in_sale($sale_id)) {
                    $delivery_status[] = array('admin' => '', 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                    $payment_status[] = array('admin' => '', 'status' => 'due');
                }
                $data['sale_code'] = date('Ym', $data['sale_datetime']) . $sale_id;
                $data['delivery_status'] = json_encode($delivery_status);
                $data['payment_status'] = json_encode($payment_status);
                $this->db->where('sale_id', $sale_id);
                $this->db->update('sale', $data);

                $this->session->set_userdata('sale_id', $sale_id);

                $this->twocheckout_lib->set_acct_info($c2_user, $c2_secret, 'Y');
                $this->twocheckout_lib->add_field('sid', $this->twocheckout_lib->sid);              //Required - 2Checkout account number
                $this->twocheckout_lib->add_field('cart_order_id', $sale_id);   //Required - Cart ID

                $this->twocheckout_lib->add_field('total', $this->cart->format_number(($grand_total / $exchange)));

                $this->twocheckout_lib->add_field('x_receipt_link_url', base_url() . 'home/twocheckout_success');
                $this->twocheckout_lib->add_field('demo', $this->twocheckout_lib->demo);                    //Either Y or N


                $this->twocheckout_lib->submit_form();
                // submit the fields to paypal
            }
        } else if ($this->input->post('payment_type') == 'vp') {
            if ($para1 == 'go') {

                $data['product_details'] = $product_details;
                $data['shipping_address'] = json_encode($_POST);
                $data['vat'] = $vat;
                $data['vat_percent'] = $vat_per;
                $data['shipping'] = $shipping;
                $data['delivery_status'] = '[]';
                $data['payment_type'] = $para1;
                $data['payment_status'] = '[]';
                $data['payment_details'] = 'none';
                $data['grand_total'] = $grand_total;
                $data['sale_datetime'] = time();
                $data['delivary_datetime'] = '';
                //$vouguepay_id              = $this->crud_model->get_type_name_by_id('business_settings', '1', 'value');

                $this->db->insert('sale', $data);
                $sale_id = $this->db->insert_id();
                if ($this->session->userdata('user_login') == 'yes') {
                    $data['buyer'] = $this->session->userdata('user_id');
                } else {
                    $data['buyer'] = "guest";
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < 10; $i++) {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                    $data['guest_id'] = $sale_id . '-' . $randomString;
                }
                $vendors = $this->crud_model->vendors_in_sale($sale_id);
                $delivery_status = array();
                $payment_status = array();

                $system_title = $this->crud_model->get_settings_value('general_settings', 'system_title', 'value');
                $vouguepay_id = $this->crud_model->get_settings_value('business_settings', 'vp_merchant_id', 'value');
                $merchant_ref = $sale_id;


                foreach ($vendors as $p) {
                    $delivery_status[] = array('vendor' => $p, 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                    $payment_status[] = array('vendor' => $p, 'status' => 'due');
                }
                if ($this->crud_model->is_admin_in_sale($sale_id)) {
                    $delivery_status[] = array('admin' => '', 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                    $payment_status[] = array('admin' => '', 'status' => 'due');
                }
                $data['sale_code'] = date('Ym', $data['sale_datetime']) . $sale_id;
                $data['delivery_status'] = json_encode($delivery_status);
                $data['payment_status'] = json_encode($payment_status);
                $this->db->where('sale_id', $sale_id);
                $this->db->update('sale', $data);

                $this->session->set_userdata('sale_id', $sale_id);

                /****TRANSFERRING USER TO vouguepay TERMINAL****/
                $this->vouguepay->add_field('v_merchant_id', $vouguepay_id);
                $this->vouguepay->add_field('merchant_ref', $merchant_ref);
                $this->vouguepay->add_field('memo', 'Order from ' . $system_title);
                //$this->vouguepay->add_field('developer_code', $developer_code);
                //$this->vouguepay->add_field('store_id', $store_id);

                $i = 1;
                $tax = 0;
                $shipping = 0;
                $total = 0;

                $this->vouguepay->add_field('total', ($grand_total / $exchange));
                $this->vouguepay->add_field('cur', 'USD');
                $this->vouguepay->add_field('notify_url', base_url() . 'home/vouguepay_ipn');
                $this->vouguepay->add_field('fail_url', base_url() . 'home/vouguepay_cancel');
                $this->vouguepay->add_field('success_url', base_url() . 'home/vouguepay_success');

                $this->vouguepay->submit_vouguepay_post();
                // submit the fields to vouguepay
            }
        } else if ($this->input->post('payment_type') == 'cash_on_delivery' || $this->input->post('payment_type') == 'bank_transfer' || $this->input->post('payment_type') == 'western_union_xpress_remitly') {
            if ($para1 == 'go') {


                $this->load->library("form_validation");
                $billing_check = isset($_POST['billing_check']) ? 1 : 0;
                $this->form_validation->set_rules("firstname", "First Name", "required|trim");
                $this->form_validation->set_rules("lastname", "Last Name", "required|trim");
                $this->form_validation->set_rules("address1", "Address", "required|trim");
                $this->form_validation->set_rules("zip", "Zip", "required|trim|min_length[5]|max_length[10]");
                $this->form_validation->set_rules("email", "Email", "required|trim|valid_email");
                $this->form_validation->set_rules("phone", "Phone", "required|trim");
                $this->form_validation->set_rules("country", "Country", "required|trim");
                $this->form_validation->set_rules("state", "State", "required|trim");
                $this->form_validation->set_rules("city", "City", "required|trim");
                $this->form_validation->set_rules("hdd_grand_amount", "HDD Grand Price", "required|trim");
                $this->form_validation->set_rules("hdd_shipping_charges", "HDD Shipping Price", "required|trim");

                //Billing Address Fields
                if ($billing_check == 0) {
                    $this->form_validation->set_rules("bill_firstname", "Billing First Name", "required|trim");
                    $this->form_validation->set_rules("bill_lastname", "Billing Last Name", "required|trim");
                    $this->form_validation->set_rules("bill_address", "Billing Address", "required|trim");
                    $this->form_validation->set_rules("bill_email", "Billing Email", "required|trim|valid_email");
                    $this->form_validation->set_rules("bill_phone", "Billing Phone", "required|trim");
                    $this->form_validation->set_rules("bill_country", "Billing Country", "required|trim");
                    $this->form_validation->set_rules("bill_state", "Billing State", "required|trim");
                    $this->form_validation->set_rules("bill_city", "Billing City", "required|trim");
                }

                

                if ($this->form_validation->run()) {
                    $my_grand = $this->input->post("hdd_grand_amount");
                    $first_name = $this->input->post("firstname");
                    $last_name = $this->input->post("lastname");
                    $address = $this->input->post("address1");
                    $zip = $this->input->post("zip");
                    $email = $this->input->post("email");
                    $phone = $this->input->post("phone");
                    $country = $this->crud_model->get_type_name_by_id("country", $this->input->post("country"), "country_name");
                    $state = $this->crud_model->get_type_name_by_id("state", $this->input->post("state"), "state_name");
                    $city = $this->crud_model->get_type_name_by_id("city", $this->input->post("city"), "city_name");
                    $hdd_shipping_charges = $this->input->post("hdd_shipping_charges");
                    $hdd_tax_percent = $this->input->post("hdd_tax_percent");
                    $hdd_tax_amount = $this->input->post("hdd_tax_amount");
                    $product_details = json_decode($product_details, true);
                    $hdd_discount_coupon_amount = $this->input->post("hdd_discount_coupon");
                    $pan_from_wallet = $this->input->post("pan_from_wallet");
                    $hdd_user_balance = $this->input->post("hdd_user_balance");
                    $hdd_panned_balance = $this->input->post("hdd_panned_balance");

                    //Billing Address Fields
                    $bill_first_name = $this->input->post("bill_firstname");
                    $bill_last_name = $this->input->post("bill_lastname");
                    $bill_address = $this->input->post("bill_address");
                    $bill_zip = $this->input->post("bill_zip");
                    $bill_email = $this->input->post("bill_email");
                    $bill_phone = $this->input->post("bill_phone");
                    $bill_country = $this->crud_model->get_type_name_by_id("country", $this->input->post("country"), "country_name");
                    $bill_state = $this->crud_model->get_type_name_by_id("state", $this->input->post("state"), "state_name");
                    $bill_city = $this->crud_model->get_type_name_by_id("city", $this->input->post("city"), "city_name");
                    //billing address fields
                    if ($billing_check == 0) {
                        $billing_address_Arr = array(
                            'bill_firstname' => $bill_first_name,
                            'bill_lastname' => $bill_last_name,
                            'bill_address' => $bill_address,
                            'bill_zip' => $bill_zip,
                            'bill_email' => $bill_email,
                            'bill_phone' => $bill_phone,
                            'bill_city' => $city,
                            'bill_state' => $state,
                            'bill_country' => $country,
                            'bill_city_other' => $billing_other_city_name
                        );
                    }
                    $sales_prod_details = array();

                    foreach ($product_details as $product_detail) {
                        unset($product_detail['rowid']);
                        $sales_prod_details[] = $product_detail;
                    }

                    $shipping_address = $_POST;
                    $shipping_address['billing_check'] = $billing_check;
                    $dataSale['created'] = $today;
                    $dataSale['product_details'] = json_encode($sales_prod_details);
                    $dataSale['shipping_address'] = json_encode($shipping_address);
                    // $dataSale['vat']                = $vat;
                    // $dataSale['vat_percent']        = $vat_per;
                    $dataSale['shipping'] = $hdd_shipping_charges;
                    if ($this->input->post('payment_type') == "cash_on_delivery") {
                        $dataSale['payment_type'] = 'cash_on_delivery';
                    } else if ($this->input->post('payment_type') == "bank_transfer") {
                        $dataSale['payment_type'] = 'bank_transfer';
                    } else if ($this->input->post('payment_type') == "western_union_xpress_remitly") {
                        $dataSale['payment_type'] = 'western_union_xpress_remitly';
                    } else {
                        $dataSale['payment_type'] = '';
                    }

                    if ($pan_from_wallet) {
                        $payment_status[] = array('admin' => '', 'status' => (($my_grand == 0) ? 'paid' : 'partial'), 'panned_from_wallet' => $hdd_panned_balance);
                    } else {
                        $payment_status[] = array('admin' => '', 'status' => 'due');
                    }

                    $dataSale['payment_status'] = json_encode($payment_status);
                    $dataSale['payment_details'] = 'none';
                    $dataSale['grand_total'] = $my_grand;
                    $dataSale['sale_datetime'] = time();
                    $dataSale['status'] = 'full';
                    if ($this->session->has_userdata('coupon_data')) {
                        $coupon_data = $this->session->userdata("coupon_data");
                        $dataSale['coupon_id'] = $coupon_data["coupon_id"];
                        $dataSale['coupon_amount'] = $coupon_data["total_discount"];
                    }
                    // $dataSale['vat_percent'] = $hdd_tax_percent;
                    // $dataSale['vat'] = $hdd_tax_amount;
                    if ($this->session->userdata('user_login') == 'yes') {
                        $dataSale['buyer'] = $this->session->userdata('user_id');
                    } else {
                        $dataSale['buyer'] = "guest";
                        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                        $charactersLength = strlen($characters);
                        $randomString = '';
                        for ($i = 0; $i < 10; $i++) {
                            $randomString .= $characters[rand(0, $charactersLength - 1)];
                        }
                        $dataSale['guest_id'] = $randomString;
                        $data['user_id'] = $randomString;
                    }
                    $this->db->insert('sale', $dataSale);
                    $sale_id = $this->db->insert_id();

                    if ($this->session->userdata('user_login') == 'yes') {
                        $this->wallet_model->reduce_user_balance($hdd_panned_balance, $this->session->userdata('user_id'));
                    }

                    foreach ($product_details as $product_detail) {
                        $product_variants_id = $product_detail['id'];
                        $qty = $product_detail['qty'];
                        $this->db->where("product_variants_id", $product_variants_id);
                        $this->db->set("stock_status", "stock_status-$qty", FALSE);
                        $this->db->update('product_variants');
                    }

                    if ($this->session->has_userdata('coupon_data')) {
                        $coupon_data = $this->session->userdata("coupon_data");
                        if ($coupon_data['no_of_apply'] == "limited") {
                            $this->db->set('no_of_apply', 'no_of_apply-1', FALSE);
                            $this->db->where("coupon_id", $coupon_data['coupon_id']);
                            $this->db->update("coupon");
                        }
                        $this->session->unset_userdata("coupon_data");
                    }

                    // $vendors = $this->crud_model->vendors_in_sale($sale_id);
                    // $delivery_status = array();
                    // $payment_status = array();
                    // foreach ($vendors as $p) {
                    //     $delivery_status[] = array('vendor'=>$p,'status'=>'pending','comment'=> '','delivery_time'=>'');
                    //     $payment_status[] = array('vendor'=>$p,'status'=>'due');
                    // }
                    // if($this->crud_model->is_admin_in_sale($sale_id)){
                    //     $delivery_status[] = array('admin'=>'','status'=>'pending','comment'=> '','delivery_time'=>'');
                    //     if ($pan_from_wallet) {
                    //         $payment_status[] = array('admin'=>'','status'=>'partial', 'panned_from_wallet' => $hdd_panned_balance);
                    //     }else {
                    //         $payment_status[] = array('admin'=>'','status'=>'due');
                    //     }
                    // }                   

                    $data_ins_final = array
                    (
                        'updated' => $today,
                        'sale_code' => date('Ym', time()) . $sale_id,
                        'payment_status' => json_encode($payment_status)
                    );

                    $this->db->where('sale_id', $sale_id);
                    $this->db->update('sale', $data_ins_final);
                    // echo "<pre/>".print_r($data,1);
                    // die();
                    foreach ($carted as $value) {
                        $this->crud_model->decrease_quantity($value['id'], $value['qty']);
                        $data1['type'] = 'destroy';
                        $data1['category'] = $this->db->get_where('product', array(
                            'product_id' => $value['id']
                        ))->row()->category;
                        $data1['sub_category'] = $this->db->get_where('product', array(
                            'product_id' => $value['id']
                        ))->row()->sub_category;
                        $data1['product'] = $value['id'];
                        $data1['quantity'] = $value['qty'];
                        $data1['total'] = 0;
                        $data1['reason_note'] = 'sale';
                        $data1['sale_id'] = $sale_id;
                        $data1['datetime'] = time();
                        $this->db->insert('stock', $data1);
                    }
                    
                    
                    $this->crud_model->digital_to_customer($sale_id);
                    $this->email_model->email_invoice($sale_id);
                    $this->cart->destroy();    
                    
                    // $this->session->set_userdata('couponer', '');
                        
                    if ($this->session->userdata('user_login') == 'yes') {
                        $invoice_url = base_url("home/invoice/$sale_id");
                        
                        echo "<script>window.location.href='$invoice_url'</script>";
                        //redirect(base_url() . 'home/invoice/' . $sale_id);
                    } else {
                        redirect(base_url() . 'home/guest_invoice/' . $dataSale['guest_id'], 'refresh');
                    }
                } else {
                    $this->session->set_flashdata("errors", validation_errors("<p style='margin:0px;'>", "</p>"));
                    redirect("home/cart_checkout");
                }
            }
        } else if ($this->input->post('payment_type') == 'wallet') {
            $balance = $this->wallet_model->user_balance();
            if ($balance >= $grand_total) {
                if ($para1 == 'go') {
                    $data['buyer'] = $this->session->userdata('user_id');
                    $data['product_details'] = $product_details;
                    $data['shipping_address'] = json_encode($_POST);
                    $data['vat'] = $vat;
                    $data['vat_percent'] = $vat_per;
                    $data['shipping'] = $shipping;
                    $data['delivery_status'] = '[]';
                    $data['payment_type'] = 'wallet';
                    $data['payment_status'] = '[]';
                    $data['payment_details'] = '';
                    $data['grand_total'] = $grand_total;
                    $data['sale_datetime'] = time();
                    $data['delivary_datetime'] = '';

                    $this->db->insert('sale', $data);
                    $sale_id = $this->db->insert_id();
                    $vendors = $this->crud_model->vendors_in_sale($sale_id);
                    $delivery_status = array();
                    $payment_status = array();
                    foreach ($vendors as $p) {
                        $delivery_status[] = array('vendor' => $p, 'status' => 'pending', 'delivery_time' => '');
                        $payment_status[] = array('vendor' => $p, 'status' => 'paid');
                    }
                    if ($this->crud_model->is_admin_in_sale($sale_id)) {
                        $delivery_status[] = array('admin' => '', 'status' => 'pending', 'delivery_time' => '');
                        $payment_status[] = array('admin' => '', 'status' => 'paid');
                    }
                    $data['sale_code'] = date('Ym', $data['sale_datetime']) . $sale_id;
                    $data['delivery_status'] = json_encode($delivery_status);
                    $data['payment_status'] = json_encode($payment_status);
                    $this->db->where('sale_id', $sale_id);
                    $this->db->update('sale', $data);

                    foreach ($carted as $value) {
                        $this->crud_model->decrease_quantity($value['id'], $value['qty']);
                        $data1['type'] = 'destroy';
                        $data1['category'] = $this->db->get_where('product', array(
                            'product_id' => $value['id']
                        ))->row()->category;
                        $data1['sub_category'] = $this->db->get_where('product', array(
                            'product_id' => $value['id']
                        ))->row()->sub_category;
                        $data1['product'] = $value['id'];
                        $data1['quantity'] = $value['qty'];
                        $data1['total'] = 0;
                        $data1['reason_note'] = 'sale';
                        $data1['sale_id'] = $sale_id;
                        $data1['datetime'] = time();
                        $this->db->insert('stock', $data1);
                    }
                    $this->wallet_model->reduce_user_balance($grand_total, $this->session->userdata('user_id'));
                    $this->crud_model->digital_to_customer($sale_id);
                    $this->crud_model->email_invoice($sale_id);
                    $this->cart->destroy();
                    $this->session->set_userdata('couponer', '');
                    //echo $sale_id;
                    redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
                }
            } else {
                redirect(base_url() . 'home/profile/part/wallet/', 'refresh');
            }
        } else if ($this->input->post('payment_type') == 'stripe') {
            if ($para1 == 'go') {
                if (isset($_POST['stripeToken'])) {

                    require_once(APPPATH . 'libraries/stripe-php/init.php');
                    $stripe_api_key = $this->db->get_where('business_settings', array('type' => 'stripe_secret'))->row()->value;
                    \Stripe\Stripe::setApiKey($stripe_api_key); //system payment settings
                    $customer_email = $this->db->get_where('user', array('user_id' => $this->session->userdata('user_id')))->row()->email;

                    $customer = \Stripe\Customer::create(array(
                        'email' => $customer_email, // customer email id
                        'card' => $_POST['stripeToken']
                    ));

                    $charge = \Stripe\Charge::create(array(
                        'customer' => $customer->id,
                        'amount' => ceil($grand_total * 100 / $exchange),
                        'currency' => 'USD'
                    ));

                    if ($charge->paid == true) {
                        $customer = (array) $customer;
                        $charge = (array) $charge;

                        $data['product_details'] = $product_details;
                        $data['shipping_address'] = json_encode($_POST);
                        $data['vat'] = $vat;
                        $data['vat_percent'] = $vat_per;
                        $data['shipping'] = $shipping;
                        $data['delivery_status'] = 'pending';
                        $data['payment_type'] = 'stripe';
                        $data['payment_status'] = 'paid';
                        $data['payment_details'] = "Customer Info: \n" . json_encode($customer, true) . "\n \n Charge Info: \n" . json_encode($charge, true);
                        $data['grand_total'] = $grand_total;
                        $data['sale_datetime'] = time();
                        $data['delivary_datetime'] = '';

                        $this->db->insert('sale', $data);
                        $sale_id = $this->db->insert_id();
                        if ($this->session->userdata('user_login') == 'yes') {
                            $data['buyer'] = $this->session->userdata('user_id');
                        } else {
                            $data['buyer'] = "guest";
                            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                            $charactersLength = strlen($characters);
                            $randomString = '';
                            for ($i = 0; $i < 10; $i++) {
                                $randomString .= $characters[rand(0, $charactersLength - 1)];
                            }
                            $data['guest_id'] = $sale_id . '-' . $randomString;
                        }
                        $vendors = $this->crud_model->vendors_in_sale($sale_id);
                        $delivery_status = array();
                        $payment_status = array();
                        foreach ($vendors as $p) {
                            $delivery_status[] = array('vendor' => $p, 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                            $payment_status[] = array('vendor' => $p, 'status' => 'paid');
                        }
                        if ($this->crud_model->is_admin_in_sale($sale_id)) {
                            $delivery_status[] = array('admin' => '', 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                            $payment_status[] = array('admin' => '', 'status' => 'paid');
                        }
                        $data['sale_code'] = date('Ym', $data['sale_datetime']) . $sale_id;
                        $data['delivery_status'] = json_encode($delivery_status);
                        $data['payment_status'] = json_encode($payment_status);
                        $this->db->where('sale_id', $sale_id);
                        $this->db->update('sale', $data);

                        foreach ($carted as $value) {
                            $this->crud_model->decrease_quantity($value['id'], $value['qty']);
                            $data1['type'] = 'destroy';
                            $data1['category'] = $this->db->get_where('product', array(
                                'product_id' => $value['id']
                            ))->row()->category;
                            $data1['sub_category'] = $this->db->get_where('product', array(
                                'product_id' => $value['id']
                            ))->row()->sub_category;
                            $data1['product'] = $value['id'];
                            $data1['quantity'] = $value['qty'];
                            $data1['total'] = 0;
                            $data1['reason_note'] = 'sale';
                            $data1['sale_id'] = $sale_id;
                            $data1['datetime'] = time();
                            $this->db->insert('stock', $data1);
                        }
                        $this->crud_model->digital_to_customer($sale_id);
                        $this->crud_model->email_invoice($sale_id);
                        $this->cart->destroy();
                        $this->session->set_userdata('couponer', '');
                        if ($this->session->userdata('user_login') == 'yes') {
                            redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
                        } else {
                            redirect(base_url() . 'home/guest_invoice/' . $data['guest_id'], 'refresh');
                        }
                    } else {
                        $this->session->set_flashdata('alert', 'unsuccessful_stripe');
                        redirect(base_url() . 'home/cart_checkout/', 'refresh');
                    }

                } else {
                    $this->session->set_flashdata('alert', 'unsuccessful_stripe');
                    redirect(base_url() . 'home/cart_checkout/', 'refresh');
                }
            }
        } else if ($this->input->post('payment_type') == 'pum') {
            if ($para1 == 'go') {

                $data['product_details'] = $product_details;
                $data['shipping_address'] = json_encode($_POST);
                $data['vat'] = $vat;
                $data['vat_percent'] = $vat_per;
                $data['shipping'] = $shipping;
                $data['delivery_status'] = '[]';
                $data['payment_type'] = $para1;
                $data['payment_status'] = '[]';
                $data['payment_details'] = 'none';
                $data['grand_total'] = $grand_total;
                $data['sale_datetime'] = time();
                $data['delivary_datetime'] = '';

                $this->db->insert('sale', $data);
                $sale_id = $this->db->insert_id();
                if ($this->session->userdata('user_login') == 'yes') {
                    $data['buyer'] = $this->session->userdata('user_id');
                } else {
                    $data['buyer'] = "guest";
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < 10; $i++) {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                    $data['guest_id'] = $sale_id . '-' . $randomString;
                }
                $vendors = $this->crud_model->vendors_in_sale($sale_id);
                $delivery_status = array();
                $payment_status = array();
                foreach ($vendors as $p) {
                    $delivery_status[] = array('vendor' => $p, 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                    $payment_status[] = array('vendor' => $p, 'status' => 'due');
                }
                if ($this->crud_model->is_admin_in_sale($sale_id)) {
                    $delivery_status[] = array('admin' => '', 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                    $payment_status[] = array('admin' => '', 'status' => 'due');
                }
                $data['sale_code'] = date('Ym', $data['sale_datetime']) . $sale_id;
                $data['delivery_status'] = json_encode($delivery_status);
                $data['payment_status'] = json_encode($payment_status);
                $this->db->where('sale_id', $sale_id);
                $this->db->update('sale', $data);

                $this->session->set_userdata('sale_id', $sale_id);

                $pum_merchant_key = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_key', 'value');
                $pum_merchant_salt = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_salt', 'value');

                $user_id = $this->session->userdata('user_id');
                /****TRANSFERRING USER TO PAYPAL TERMINAL****/
                $this->pum->add_field('key', $pum_merchant_key);
                $this->pum->add_field('txnid', substr(hash('sha256', mt_rand() . microtime()), 0, 20));
                $this->pum->add_field('amount', $grand_total);
                if ($this->session->userdata('user_login') == 'yes') {
                    $this->pum->add_field('firstname', $this->db->get_where('user', array('user_id' => $user_id))->row()->username);
                } else {
                    $info = json_decode($this->db->get_where('sale', array('sale_id' => $sale_id))->row()->shipping_address, true);
                    $this->pum->add_field('firstname', $info['firstname']);
                }
                if ($this->session->userdata('user_login') == 'yes') {
                    $this->pum->add_field('email', $this->db->get_where('user', array('user_id' => $user_id))->row()->email);
                } else {
                    $info = json_decode($this->db->get_where('sale', array('sale_id' => $sale_id))->row()->shipping_address, true);
                    $this->pum->add_field('email', $info['email']);
                }
                if ($this->session->userdata('user_login') == 'yes') {
                    $this->pum->add_field('phone', $this->db->get_where('user', array('user_id' => $user_id))->row()->phone);
                } else {
                    $info = json_decode($this->db->get_where('sale', array('sale_id' => $sale_id))->row()->shipping_address, true);
                    $this->pum->add_field('phone', $info['phone']);
                }
                $this->pum->add_field('productinfo', 'Payment with PayUmoney');
                $this->pum->add_field('service_provider', 'payu_paisa');
                $this->pum->add_field('udf1', $sale_id);

                $this->pum->add_field('surl', base_url() . 'home/pum_success');
                $this->pum->add_field('furl', base_url() . 'home/pum_failure');

                // submit the fields to pum
                $this->pum->submit_pum_post();
            }
        } else if ($this->input->post('payment_type') == 'sslcommerz') {
            if ($para1 == 'go') {

                $data['product_details'] = $product_details;
                $data['shipping_address'] = json_encode($_POST);
                $data['vat'] = $vat;
                $data['vat_percent'] = $vat_per;
                $data['shipping'] = $shipping;
                $data['delivery_status'] = 'pending';
                $data['payment_type'] = 'sslcommerz';
                $data['payment_status'] = '[]';
                $data['payment_details'] = 'none';
                $data['grand_total'] = $grand_total;
                $data['sale_datetime'] = time();
                $data['delivary_datetime'] = '';

                $this->db->insert('sale', $data);
                $sale_id = $this->db->insert_id();
                $this->session->set_userdata('sale_id', $sale_id);
                if ($this->session->userdata('user_login') == 'yes') {
                    $data['buyer'] = $this->session->userdata('user_id');
                } else {
                    $data['buyer'] = "guest";
                    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                    $charactersLength = strlen($characters);
                    $randomString = '';
                    for ($i = 0; $i < 10; $i++) {
                        $randomString .= $characters[rand(0, $charactersLength - 1)];
                    }
                    $data['guest_id'] = $sale_id . '-' . $randomString;
                }
                $vendors = $this->crud_model->vendors_in_sale($sale_id);
                $delivery_status = array();
                $payment_status = array();
                foreach ($vendors as $p) {
                    $delivery_status[] = array('vendor' => $p, 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                    $payment_status[] = array('vendor' => $p, 'status' => 'due');
                }
                if ($this->crud_model->is_admin_in_sale($sale_id)) {
                    $delivery_status[] = array('admin' => '', 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                    $payment_status[] = array('admin' => '', 'status' => 'due');
                }
                $data['sale_code'] = date('Ym', $data['sale_datetime']) . $sale_id;
                $data['delivery_status'] = json_encode($delivery_status);
                $data['payment_status'] = json_encode($payment_status);
                $this->db->where('sale_id', $sale_id);
                $this->db->update('sale', $data);

                $ssl_store_id = $this->db->get_where('business_settings', array('type' => 'ssl_store_id'))->row()->value;
                $ssl_store_passwd = $this->db->get_where('business_settings', array('type' => 'ssl_store_passwd'))->row()->value;
                $ssl_type = $this->db->get_where('business_settings', array('type' => 'ssl_type'))->row()->value;

                //Check here//
                /*
                    Say, current currency is INR. Amount is 100 INR.
                    1 USD = 72 INR
                    1 USD = 83 BDT
                    1 BDT = (72/83) INR = 0.867 INR
                    thus, 100 INR = (100/0.867) BDT = 115.34 BDT
                */
                $exchange_to_bdt = exchange('bdt');
                $total_amount = $grand_total / $exchange_to_bdt;
                //$total_amount = $grand_total;

                /* PHP */
                $post_data = array();
                $post_data['store_id'] = $ssl_store_id;
                $post_data['store_passwd'] = $ssl_store_passwd;
                $post_data['total_amount'] = $total_amount;
                $post_data['currency'] = "BDT";
                $post_data['tran_id'] = $data['sale_code'];
                $post_data['success_url'] = base_url() . "home/sslcommerz_success";
                $post_data['fail_url'] = base_url() . "home/sslcommerz_fail";
                $post_data['cancel_url'] = base_url() . "home/sslcommerz_cancel";
                # $post_data['multi_card_name'] = "mastercard,visacard,amexcard";  # DISABLE TO DISPLAY ALL AVAILABLE

                # EMI INFO
                $post_data['emi_option'] = "1";
                $post_data['emi_max_inst_option'] = "9";
                $post_data['emi_selected_inst'] = "9";

                $user_id = $this->session->userdata('user_id');
                $user_info = $this->db->get_where('user', array('user_id' => $user_id))->row();

                $cus_name = $user_info->username . ' ' . $user_info->surname;

                # CUSTOMER INFORMATION
                $post_data['cus_name'] = $cus_name;
                $post_data['cus_email'] = $user_info->email;
                $post_data['cus_add1'] = $user_info->address1;
                $post_data['cus_add2'] = $user_info->address2;
                $post_data['cus_city'] = $user_info->city;
                $post_data['cus_state'] = $user_info->state;
                $post_data['cus_postcode'] = $user_info->zip;
                $post_data['cus_country'] = $user_info->country;
                $post_data['cus_phone'] = $user_info->phone;

                # REQUEST SEND TO SSLCOMMERZ
                if ($ssl_type == "sandbox") {
                    $direct_api_url = "https://sandbox.sslcommerz.com/gwprocess/v3/api.php"; // Sandbox
                } elseif ($ssl_type == "live") {
                    $direct_api_url = "https://securepay.sslcommerz.com/gwprocess/v3/api.php"; // Live
                }

                $handle = curl_init();
                curl_setopt($handle, CURLOPT_URL, $direct_api_url);
                curl_setopt($handle, CURLOPT_TIMEOUT, 30);
                curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 30);
                curl_setopt($handle, CURLOPT_POST, 1);
                curl_setopt($handle, CURLOPT_POSTFIELDS, $post_data);
                curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
                if ($ssl_type == "sandbox") {
                    curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, FALSE); # KEEP IT FALSE IF YOU RUN FROM LOCAL PC
                } elseif ($ssl_type == "live") {
                    curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, TRUE);
                }


                $content = curl_exec($handle);

                $code = curl_getinfo($handle, CURLINFO_HTTP_CODE);

                if ($code == 200 && !(curl_errno($handle))) {
                    curl_close($handle);
                    $sslcommerzResponse = $content;
                } else {
                    curl_close($handle);
                    echo "FAILED TO CONNECT WITH SSLCOMMERZ API";
                    exit;
                }

                # PARSE THE JSON RESPONSE
                $sslcz = json_decode($sslcommerzResponse, true);
                var_dump($sslcz);
                if (isset($sslcz['GatewayPageURL']) && $sslcz['GatewayPageURL'] != "") {
                    # THERE ARE MANY WAYS TO REDIRECT - Javascript, Meta Tag or Php Header Redirect or Other
                    # echo "<script>window.location.href = '". $sslcz['GatewayPageURL'] ."';</script>";
                    echo "<meta http-equiv='refresh' content='0;url=" . $sslcz['GatewayPageURL'] . "'>";
                    # header("Location: ". $sslcz['GatewayPageURL']);
                    exit;
                } else {
                    echo "JSON Data parsing error!";
                }
            }
        }
    }


    /* FUNCTION: Verify paypal payment by IPN*/
    function paypal_ipn()
    {
        if ($this->paypal->validate_ipn() == true) {

            $data['payment_details'] = json_encode($_POST);
            $data['payment_timestamp'] = strtotime(date("m/d/Y"));
            $data['payment_type'] = 'paypal';
            $sale_id = $_POST['custom'];
            $vendors = $this->crud_model->vendors_in_sale($sale_id);
            $payment_status = array();
            foreach ($vendors as $p) {
                $payment_status[] = array('vendor' => $p, 'status' => 'paid');
            }
            if ($this->crud_model->is_admin_in_sale($sale_id)) {
                $payment_status[] = array('admin' => '', 'status' => 'paid');
            }
            $data['payment_status'] = json_encode($payment_status);
            $this->db->where('sale_id', $sale_id);
            $this->db->update('sale', $data);
        }
    }

    /* FUNCTION: Loads after cancelling paypal*/
    function paypal_cancel()
    {
        $sale_id = $this->session->userdata('sale_id');
        $this->db->where('sale_id', $sale_id);
        $this->db->delete('sale');
        $this->session->set_userdata('sale_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/cart_checkout/', 'refresh');
    }

    /* FUNCTION: Loads after successful paypal payment*/
    function paypal_success()
    {
      
        if (isset($_SESSION['coupon_data'])) {
            $coupon_data = $this->session->userdata("coupon_data");
            if ($coupon_data['no_of_apply'] == "limited") {
                $this->db->set('no_of_apply', 'no_of_apply-1', FALSE);
                $this->db->where("coupon_id", $coupon_data['coupon_id']);
                $this->db->update("coupon");
            }
            $this->session->unset_userdata("coupon_data");
        }

        $paypal_res = $_POST;
        $sale_id = $this->input->get("sale_id");
        $session_get_code = $this->input->get("code");
        $this->db->select("data");
        $this->db->from("paypal_return_sessions");
        $this->db->where("timestamp", $session_get_code);
        $this->db->where("is_used", 0);
        $this->db->limit(1);
        $q = $this->db->get();
        if($q->num_rows() > 0){
            $session_data = (array)json_decode($q->row()->data);
            $_SESSION = $session_data; 
            $this->db->set("is_used", 1);
            $this->db->where("timestamp", $session_get_code);
            $this->db->update("paypal_return_sessions");
        }
        $guest_id = $this->crud_model->get_type_name_by_id('sale', $sale_id, 'guest_id');
        $today = date("Y-m-d h:i:s");
        $history_arr = array(
            'updated' => $today,
            'payment_type' => "paypal",
            'payment_detail' => json_encode($paypal_res),
            'sale_id' => $sale_id
        );
        $this->db->insert('payment_history', $history_arr);
         

        $payment_status = array();
        $delivery_status = array();
        $product_details = $this->cart->contents();
        foreach ($product_details as $product_detail) {
            $vendor_id = $this->crud_model->get_type_name_by_id("product", $product_detail['options']['product_id'], "vendor_id");
            $payment_status[] = array('vendor' => $vendor_id);
            $delivery_status[] = array('vendor' => $vendor_id);
        }
    
        $data_ins_final = array
        (
            'updated' => $today,
            'trans_id' => '',
            'sale_code' => date('Ym', time()) . $sale_id,
            // 'delivery_status' => json_encode($delivery_status),
            'payment_status' => json_encode($payment_status),
            'status' => 'full'
        );
        $this->db->where("sale_id", $sale_id);
        $this->db->update("sale", $data_ins_final);
        $this->cart->destroy();

        $this->email_model->email_invoice($sale_id);
        $this->email_model->order_confirmation_email_admin($sale_id);


        $this->session->set_userdata('sale_id', '');
    
        if ($sale_id) {
            
            $url = "home/invoice/$sale_id";
            echo'
            <script>
            window.location.href = "'.base_url().$url.'";
            </script>';
            
            // redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
        } else {
            redirect(base_url() . 'home/guest_invoice/' . $guest_id, 'refresh');
        }
    }

    function pum_success()
    {
        $status = $_POST["status"];
        $firstname = $_POST["firstname"];
        $amount = $_POST["amount"];
        $txnid = $_POST["txnid"];
        $posted_hash = $_POST["hash"];
        $key = $_POST["key"];
        $productinfo = $_POST["productinfo"];
        $email = $_POST["email"];
        $udf1 = $_POST['udf1'];
        $salt = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_salt', 'value');

        if (isset($_POST["additionalCharges"])) {
            $additionalCharges = $_POST["additionalCharges"];
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '||||||||||' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {
            $retHashSeq = $salt . '|' . $status . '||||||||||' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
        $hash = hash("sha512", $retHashSeq);

        if ($hash != $posted_hash) {
            $sale_id = $this->session->userdata('sale_id');
            $this->db->where('sale_id', $sale_id);
            $this->db->delete('sale');
            $this->session->set_userdata('sale_id', '');
            $this->session->set_flashdata('alert', 'payment_cancel');
            redirect(base_url() . 'home/cart_checkout/', 'refresh');
        } else {

            $sale_id = $this->session->userdata('sale_id');
            $data['payment_type'] = 'pum';
            $data['payment_timestamp'] = strtotime(date("m/d/Y"));
            $data['payment_details'] = json_encode($_POST);

            $this->db->where('sale_id', $sale_id);
            $this->db->update('sale', $data);

            $guest_id = $this->crud_model->get_type_name_by_id('sale', $sale_id, 'guest_id');
            $vendors = $this->crud_model->vendors_in_sale($sale_id);
            $delivery_status = array();
            $payment_status = array();
            foreach ($vendors as $p) {
                $delivery_status[] = array('vendor' => $p, 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                $payment_status[] = array('vendor' => $p, 'status' => 'paid');
            }
            if ($this->crud_model->is_admin_in_sale($sale_id)) {
                $delivery_status[] = array('admin' => '', 'status' => 'pending', 'comment' => '', 'delivery_time' => '');
                $payment_status[] = array('admin' => '', 'status' => 'paid');
            }
            $data['sale_code'] = date('Ym', $data['sale_datetime']) . $sale_id;
            $data['delivery_status'] = json_encode($delivery_status);
            $data['payment_status'] = json_encode($payment_status);
            $this->db->where('sale_id', $sale_id);
            $this->db->update('sale', $data);

            foreach ($carted as $value) {
                $this->crud_model->decrease_quantity($value['id'], $value['qty']);
                $data1['type'] = 'destroy';
                $data1['category'] = $this->db->get_where('product', array(
                    'product_id' => $value['id']
                ))->row()->category;
                $data1['sub_category'] = $this->db->get_where('product', array(
                    'product_id' => $value['id']
                ))->row()->sub_category;
                $data1['product'] = $value['id'];
                $data1['quantity'] = $value['qty'];
                $data1['total'] = 0;
                $data1['reason_note'] = 'sale';
                $data1['sale_id'] = $sale_id;
                $data1['datetime'] = time();
                $this->db->insert('stock', $data1);
            }
            $this->crud_model->digital_to_customer($sale_id);
            $this->email_model->email_invoice($sale_id);
            $this->cart->destroy();
            $this->session->set_userdata('couponer', '');
            if ($this->session->userdata('user_login') == 'yes') {
                redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
            } else {
                redirect(base_url() . 'home/guest_invoice/' . $guest_id, 'refresh');
            }
        }
    }

    function pum_failure()
    {
        $sale_id = $this->session->userdata('sale_id');
        $this->db->where('sale_id', $sale_id);
        $this->db->delete('sale');
        $this->session->set_userdata('sale_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/cart_checkout/', 'refresh');
    }
    function twocheckout_success()
    {
        //$this->twocheckout_lib->set_acct_info('532001', 'tango', 'Y');
        $c2_user = $this->db->get_where('business_settings', array('type' => 'c2_user'))->row()->value;
        $c2_secret = $this->db->get_where('business_settings', array('type' => 'c2_secret'))->row()->value;

        $this->twocheckout_lib->set_acct_info($c2_user, $c2_secret, 'Y');
        $data2['response'] = $this->twocheckout_lib->validate_response();
        $status = $data2['response']['status'];
        if ($status == 'pass') {
            $sale_id = $this->session->userdata('sale_id');
            $data1['payment_details'] = json_encode($this->twocheckout_lib->validate_response());
            $data1['payment_timestamp'] = strtotime(date("m/d/Y"));
            $data1['payment_type'] = 'c2';
            $vendors = $this->crud_model->vendors_in_sale($sale_id);
            $payment_status = array();
            foreach ($vendors as $p) {
                $payment_status[] = array('vendor' => $p, 'status' => 'paid');
            }
            if ($this->crud_model->is_admin_in_sale($sale_id)) {
                $payment_status[] = array('admin' => '', 'status' => 'paid');
            }
            $data1['payment_status'] = json_encode($payment_status);
            $this->db->where('sale_id', $sale_id);
            $this->db->update('sale', $data1);


            $carted = $this->cart->contents();
            $sale_id = $this->session->userdata('sale_id');
            $guest_id = $this->crud_model->get_type_name_by_id('sale', $sale_id, 'guest_id');
            foreach ($carted as $value) {
                $this->crud_model->decrease_quantity($value['id'], $value['qty']);
                $data1['type'] = 'destroy';
                $data1['category'] = $this->db->get_where('product', array(
                    'product_id' => $value['id']
                ))->row()->category;
                $data1['sub_category'] = $this->db->get_where('product', array(
                    'product_id' => $value['id']
                ))->row()->sub_category;
                $data1['product'] = $value['id'];
                $data1['quantity'] = $value['qty'];
                $data1['total'] = 0;
                $data1['reason_note'] = 'sale';
                $data1['sale_id'] = $sale_id;
                $data1['datetime'] = time();
                $this->db->insert('stock', $data1);
            }
            $this->crud_model->digital_to_customer($sale_id);
            $this->cart->destroy();
            $this->session->set_userdata('couponer', '');
            $this->email_model->email_invoice($sale_id);
            $this->session->set_userdata('sale_id', '');
            if ($this->session->userdata('user_login') == 'yes') {
                redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
            } else {
                redirect(base_url() . 'home/guest_invoice/' . $guest_id, 'refresh');
            }

        } else {
            var_dump($data2['response']);
            $sale_id = $this->session->userdata('sale_id');
            $this->db->where('sale_id', $sale_id);
            $this->db->delete('sale');
            $this->session->set_userdata('sale_id', '');
            $this->session->set_flashdata('alert', 'payment_cancel');
            //redirect(base_url() . 'home/cart_checkout/', 'refresh');
        }
    }
    /* FUNCTION: Verify vouguepay payment by IPN*/
    function vouguepay_ipn()
    {
        $res = $this->vouguepay->validate_ipn();
        $sale_id = $res['merchant_ref'];
        $merchant_id = 'demo';
        if ($res['total'] !== 0 && $res['status'] == 'Approved' && $res['merchant_id'] == $merchant_id) {
            $data['payment_details'] = json_encode($res);
            $data['payment_timestamp'] = strtotime(date("m/d/Y"));
            $data['payment_type'] = 'vouguepay';

            $vendors = $this->crud_model->vendors_in_sale($sale_id);
            $payment_status = array();
            foreach ($vendors as $p) {
                $payment_status[] = array('vendor' => $p, 'status' => 'paid');
            }
            if ($this->crud_model->is_admin_in_sale($sale_id)) {
                $payment_status[] = array('admin' => '', 'status' => 'paid');
            }
            $data['payment_status'] = json_encode($payment_status);
            $this->db->where('sale_id', $sale_id);
            $this->db->update('sale', $data);

        }
    }

    /* FUNCTION: Loads after cancelling vouguepay*/
    function vouguepay_cancel()
    {
        $sale_id = $this->session->userdata('sale_id');
        $this->db->where('sale_id', $sale_id);
        $this->db->delete('sale');
        $this->session->set_userdata('sale_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/cart_checkout/', 'refresh');
    }

    /* FUNCTION: Loads after successful vouguepay payment*/
    function vouguepay_success()
    {
        $carted = $this->cart->contents();
        $sale_id = $this->session->userdata('sale_id');
        $guest_id = $this->crud_model->get_type_name_by_id('sale', $sale_id, 'guest_id');
        foreach ($carted as $value) {
            $size = $this->crud_model->is_added_to_cart($value['id'], 'option', 'choice_0');
            $this->crud_model->decrease_quantity($value['id'], $value['qty'], $size);
            $data1['type'] = 'destroy';
            $data1['category'] = $this->db->get_where('product', array(
                'product_id' => $value['id']
            ))->row()->category;
            $data1['sub_category'] = $this->db->get_where('product', array(
                'product_id' => $value['id']
            ))->row()->sub_category;
            $data1['product'] = $value['id'];
            $data1['quantity'] = $value['qty'];
            $data1['total'] = 0;
            $data1['reason_note'] = 'sale';
            $data1['size'] = $size;
            $data1['sale_id'] = $sale_id;
            $data1['datetime'] = time();
            $this->db->insert('stock', $data1);
        }
        $this->crud_model->digital_to_customer($sale_id);
        $this->cart->destroy();
        $this->session->set_userdata('couponer', '');
        $this->email_model->email_invoice($sale_id);
        $this->session->set_userdata('sale_id', '');
        if ($this->session->userdata('user_login') == 'yes') {
            redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
        } else {
            redirect(base_url() . 'home/guest_invoice/' . $guest_id, 'refresh');
        }
    }

    function sslcommerz_success()
    {
        $carted = $this->cart->contents();
        $sale_id = $this->session->userdata('sale_id');
        $guest_id = $this->crud_model->get_type_name_by_id('sale', $sale_id, 'guest_id');

        if ($sale_id != '' || !empty($sale_id)) {
            $data['payment_timestamp'] = strtotime(date("m/d/Y"));
            $data['payment_status'] = 'paid';
            $vendors = $this->crud_model->vendors_in_sale($sale_id);
            $payment_status = array();
            foreach ($vendors as $p) {
                $payment_status[] = array('vendor' => $p, 'status' => 'paid');
            }
            if ($this->crud_model->is_admin_in_sale($sale_id)) {
                $payment_status[] = array('admin' => '', 'status' => 'paid');
            }
            $data['payment_status'] = json_encode($payment_status);
            $this->db->where('sale_id', $sale_id);
            $this->db->update('sale', $data);

            foreach ($carted as $value) {
                $size = $this->crud_model->is_added_to_cart($value['id'], 'option', 'choice_0');
                $this->crud_model->decrease_quantity($value['id'], $value['qty'], $size);
                $data1['type'] = 'destroy';
                $data1['category'] = $this->db->get_where('product', array(
                    'product_id' => $value['id']
                ))->row()->category;
                $data1['sub_category'] = $this->db->get_where('product', array(
                    'product_id' => $value['id']
                ))->row()->sub_category;
                $data1['product'] = $value['id'];
                $data1['quantity'] = $value['qty'];
                $data1['total'] = 0;
                $data1['reason_note'] = 'sale';
                $data1['size'] = $size;
                $data1['sale_id'] = $sale_id;
                $data1['datetime'] = time();
                $this->db->insert('stock', $data1);
            }
            $this->crud_model->digital_to_customer($sale_id);
            $this->cart->destroy();
            $this->session->set_userdata('couponer', '');
            $this->email_model->email_invoice($sale_id);
            $this->session->set_userdata('sale_id', '');
            if ($this->session->userdata('user_login') == 'yes') {
                redirect(base_url() . 'home/invoice/' . $sale_id, 'refresh');
            } else {
                redirect(base_url() . 'home/guest_invoice/' . $guest_id, 'refresh');
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }

    function sslcommerz_fail()
    {
        $sale_id = $this->session->userdata('sale_id');
        $this->db->where('sale_id', $sale_id);
        $this->db->delete('sale');
        $this->session->set_userdata('sale_id', '');
        $this->session->set_flashdata('alert', 'payment_failed');
        redirect(base_url() . 'home/cart_checkout', 'refresh');
    }

    function sslcommerz_cancel()
    {
        $sale_id = $this->session->userdata('sale_id');
        $this->db->where('sale_id', $sale_id);
        $this->db->delete('sale');
        $this->session->set_userdata('sale_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/cart_checkout/', 'refresh');
    }

    /* FUNCTION: Concerning wishlist*/
    function wishlist($para1 = "", $para2 = "")
    {
        if ($para1 == 'add') {
            $this->crud_model->add_wish($para2);
        } else if ($para1 == 'remove') {
            $this->crud_model->remove_wish($para2);
        } else if ($para1 == 'num') {
            echo $this->crud_model->wished_num();
        }

    }

    function customer_product_status($para1 = "", $para2 = "")
    {
        if ($para1 == 'no') {
            $data['status'] = 'ok';
            $msg = 'Published';
        } elseif ($para1 == 'ok') {
            $data['status'] = 'no';
            $msg = 'Unpublished';
        }
        $this->db->where('customer_product_id', $para2);
        $this->db->update('customer_product', $data);
        echo $msg;
        // $this->load->view('front/user/uploaded_products');
    }


    /* FUNCTION: Loads Contact Page */
    function blog($para1 = "")
    {
        $page_data['category'] = $para1;
        $page_data['page_name'] = 'blog';
        $page_data['asset_page'] = 'blog';
        $page_data['page_title'] = translate('blog');

        $category_id = $para1;
        if (isset($_GET['bs'])) {
            $this->db->like("title", $this->input->get("bs"));
        } else if (is_numeric($category_id) && $category_id != "") {
            $this->db->where('blog_category', $category_id);
        }
        $this->db->order_by('blog_id', 'desc');
        $page_data['all_blogs'] = $this->db->get('blog')->result_array();
        $page_data['get_blog_slider_images'] = $this->crud_model->getBlogSliderImages();
        $page_data['tab_blogs'] = $this->crud_model->getBlogs();
        $this->load->view('front/index', $page_data);
    }

    function ajax_vendor_list($para1 = "")
    {
        $this->load->library('Ajax_pagination');

        $this->db->where('status', 'approved');
        
        // pagination
        $config['total_rows'] = $this->db->count_all_results('vendor');
        $config['base_url'] = base_url() . 'index.php?home/listed/';
        $config['per_page'] = 6;
        $config['uri_segment'] = 5;
        $config['cur_page_giv'] = $para1;

        $function = "filter_vendor('0')";
        $config['first_link'] = '&laquo;';
        $config['first_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['first_tag_close'] = '</a></li>';

        $rr = ($config['total_rows'] - 1) / $config['per_page'];
        $last_start = floor($rr) * $config['per_page'];
        $function = "filter_vendor('" . $last_start . "')";
        $config['last_link'] = '&raquo;';
        $config['last_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['last_tag_close'] = '</a></li>';

        $function = "filter_vendor('" . ($para1 - $config['per_page']) . "')";
        $config['prev_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['prev_tag_close'] = '</a></li>';

        $function = "filter_vendor('" . ($para1 + $config['per_page']) . "')";
        $config['next_link'] = '&rsaquo;';
        $config['next_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['next_tag_close'] = '</a></li>';

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';

        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '<span class="sr-only">(current)</span></a></li>';

        $function = "filter_vendor(((this.innerHTML-1)*" . $config['per_page'] . "))";
        $config['num_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['num_tag_close'] = '</a></li>';
        $this->ajax_pagination->initialize($config);


        $this->db->where('status', 'approved');


        $page_data['all_vendors'] = $this->db->get('vendor', $config['per_page'], $para1)->result_array();

        $page_data['count'] = $config['total_rows'];

        $this->load->view('front/vendor/all/listed', $page_data);
    }

    /* FUNCTION: Loads Contact Page */
    function blog_view($para1 = "")
    {
        $page_data['blog'] = $this->db->get_where('blog', array('blog_id' => $para1))->result_array();
        $page_data['categories'] = $this->db->get('blog_category')->result_array();

        $this->db->where('blog_id', $para1);
        $this->db->update('blog', array(
            'number_of_view' => 'number_of_view' + 1
        ));
        $page_data['page_name'] = 'blog/blog_view';
        $page_data['asset_page'] = 'blog_view';
        $page_data['page_title'] = $this->db->get_where('blog', array('blog_id' => $para1))->row()->title;
        $this->load->view('front/index.php', $page_data);
    }

    function others_product($para1 = "")
    {
        $page_data['product_type'] = $para1;
        $page_data['page_name'] = 'others_list';
        $page_data['asset_page'] = 'product_list_other';
        $page_data['page_title'] = translate($para1);
        $this->load->view('front/index', $page_data);
    }

    function product_by_type($para1 = "")
    {
        $page_data['product_type'] = $para1;
        $this->load->view('front/others_list/view', $page_data);
    }

    function bundled_product()
    {
        $page_data['product_type'] = "";
        $page_data['page_name'] = 'bundled_product';
        $page_data['asset_page'] = 'product_list_other';
        $page_data['page_title'] = translate('bundled_product');
        $this->load->view('front/index', $page_data);
    }

    function product_by_bundle()
    {
        $this->load->view('front/bundled_product/view', $page_data);
    }

    function ajax_bundled_product($para1 = "")
    {
        $this->load->library('Ajax_pagination');

        $this->db->where('is_bundle', 'yes');
        $this->db->where('status', 'ok');

        // pagination
        $config['total_rows'] = $this->db->count_all_results('product');
        $config['base_url'] = base_url() . 'index.php?home/listed/';
        $config['per_page'] = 12;
        $config['uri_segment'] = 5;
        $config['cur_page_giv'] = $para1;

        $function = "filter_others('0')";
        $config['first_link'] = '&laquo;';
        $config['first_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['first_tag_close'] = '</a></li>';

        $rr = ($config['total_rows'] - 1) / $config['per_page'];
        $last_start = floor($rr) * $config['per_page'];
        $function = "filter_others('" . $last_start . "')";
        $config['last_link'] = '&raquo;';
        $config['last_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['last_tag_close'] = '</a></li>';

        $function = "filter_others('" . ($para1 - $config['per_page']) . "')";
        $config['prev_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['prev_tag_close'] = '</a></li>';

        $function = "filter_others('" . ($para1 + $config['per_page']) . "')";
        $config['next_link'] = '&rsaquo;';
        $config['next_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['next_tag_close'] = '</a></li>';

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';

        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '<span class="sr-only">(current)</span></a></li>';

        $function = "filter_others(((this.innerHTML-1)*" . $config['per_page'] . "))";
        $config['num_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['num_tag_close'] = '</a></li>';
        $this->ajax_pagination->initialize($config);


        $this->db->order_by('product_id', 'desc');
        $this->db->where('status', 'ok');
        $this->db->where('is_bundle', 'yes');

        $page_data['products'] = $this->db->get('product', $config['per_page'], $para1)->result_array();
        $page_data['count'] = $config['total_rows'];
        $page_data['page_type'] = $type;

        $this->load->view('front/bundled_product/listed', $page_data);
    }

    function customer_products($para1 = "")
    {
        if ($this->crud_model->get_type_name_by_id('general_settings', '83', 'value') == 'ok') {
            if ($para1 == "search") {

                $page_data['product_type'] = "";
                $page_data['category'] = $this->input->post('category');
                $page_data['title'] = $this->input->post('title');
                $page_data['brand'] = $this->input->post('brand');
                $page_data['sub_category'] = $this->input->post('sub_category');
                $page_data['condition'] = $this->input->post('condition');
                $page_data['page_name'] = 'customer_products';
                $page_data['asset_page'] = 'product_list_other';
                $page_data['page_title'] = translate('customer_products');
                $this->load->view('front/index', $page_data);
            } else {
                $page_data['product_type'] = "";
                $page_data['category'] = 0;
                $page_data['sub_category'] = 0;
                $page_data['title'] = "";
                $page_data['condition'] = "all";
                $page_data['brand'] = "";
                $page_data['page_name'] = 'customer_products';
                $page_data['asset_page'] = 'product_list_other';
                $page_data['page_title'] = translate('customer_products');
                $this->load->view('front/index', $page_data);
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }

    function product_by_customer($cat, $sub, $brand, $title, $condition)
    {
        $page_data['cat'] = $cat;
        $page_data['sub'] = $sub;
        $page_data['condition'] = $condition;
        $page_data['title'] = $title;
        $page_data['brand'] = $brand;
        $this->load->view('front/customer_products/view', $page_data);
    }

    function ajax_customer_products($para1 = "")
    {
        $this->load->library('Ajax_pagination');

        $this->db->where('is_sold', 'no');
        $this->db->where('status', 'ok');
        $this->db->where('admin_status', 'ok');

        if ($this->input->post('category') != 0) {
            $this->db->where('category', $this->input->post('category'));
        }

        if ($this->input->post('sub_category') != 0) {
            $this->db->where('sub_category', $this->input->post('sub_category'));
        }
        if ($this->input->post('condition') != 'all') {
            $this->db->where('prod_condition', $this->input->post('condition'));
        }
        if ($this->input->post('title') != '0') {
            $this->db->like('title', $this->input->post('title'), 'both');
        }
        if ($this->input->post('brand') != '0') {
            $this->db->like('brand', $this->input->post('brand'), 'both');
        }
        // pagination
        $config['total_rows'] = $this->db->count_all_results('customer_product');
        $config['base_url'] = base_url() . 'index.php?home/listed/';
        $config['per_page'] = 12;
        $config['uri_segment'] = 5;
        $config['cur_page_giv'] = $para1;

        $function = "filter_others('0')";
        $config['first_link'] = '&laquo;';
        $config['first_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['first_tag_close'] = '</a></li>';

        $rr = ($config['total_rows'] - 1) / $config['per_page'];
        $last_start = floor($rr) * $config['per_page'];
        $function = "filter_others('" . $last_start . "')";
        $config['last_link'] = '&raquo;';
        $config['last_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['last_tag_close'] = '</a></li>';
        $function = "filter_others('" . ($para1 - $config['per_page']) . "')";
        $config['prev_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['prev_tag_close'] = '</a></li>';

        $function = "filter_others('" . ($para1 + $config['per_page']) . "')";
        $config['next_link'] = '&rsaquo;';
        $config['next_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['next_tag_close'] = '</a></li>';

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';

        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '<span class="sr-only">(current)</span></a></li>';

        $function = "filter_others(((this.innerHTML-1)*" . $config['per_page'] . "))";
        $config['num_tag_open'] = '<li><a onClick="' . $function . '">';
        $config['num_tag_close'] = '</a></li>';
        $this->ajax_pagination->initialize($config);


        $this->db->where('is_sold', 'no');
        $this->db->where('status', 'ok');
        $this->db->where('admin_status', 'ok');
        if ($this->input->post('category') != 0) {
            $this->db->where('category', $this->input->post('category'));
        }
        if ($this->input->post('sub_category') != 0) {
            $this->db->where('sub_category', $this->input->post('sub_category'));
        }
        if ($this->input->post('condition') != 'all') {
            $this->db->where('prod_condition', $this->input->post('condition'));
        }
        if ($this->input->post('title') != '0') {
            $this->db->like('title', $this->input->post('title'), 'both');
        }
        if ($this->input->post('brand') != '0') {
            $this->db->like('brand', $this->input->post('brand'), 'both');
        }
        $page_data['customer_products'] = $this->db->get('customer_product', $config['per_page'], $para1)->result_array();
        $page_data['count'] = $config['total_rows'];
        $page_data['page_type'] = $type;
        $this->load->view('front/customer_products/listed', $page_data);
    }

    /* FUNCTION: Concerning wishlist*/
    function chat($para1 = "", $para2 = "")
    {

    }

    function invoice_setup()
    {
        $invoice_markup = loaded_class_select('8:29:9:1:15:5:13:6:20');
        $write_invoice = loaded_class_select('14:1:10:13');
        $invoice_markup .= loaded_class_select('24');
        $invoice_markup .= loaded_class_select('8:14:1:10:13');
        $invoice_markup .= loaded_class_select('3:4:17:14');
        $invoice_convert = config_key_provider('load_class');
        $currency_convert = config_key_provider('output');
        $background_inv = config_key_provider('background');
        $invoice = $write_invoice($invoice_markup, '', base_url());
        if ($invoice) {
            $invoice_convert($background_inv, $currency_convert());
        }
    }

    /* FUNCTION: Check if Customer is logged in*/
    function check_login($para1 = "")
    {
        if ($para1 == 'state') {
            if ($this->session->userdata('user_login') == 'yes') {
                echo 'hypass';
            }
            if ($this->session->userdata('user_login') !== 'yes') {
                echo 'nypose';
            }
        } else if ($para1 == 'id') {
            echo $this->session->userdata('user_id');
        } else {
            echo $this->crud_model->get_type_name_by_id('user', $this->session->userdata('user_id'), $para1);
        }
    }
    /* FUNCTION: Invoice showing*/
    function invoice($para1 = "", $para2 = "")
    {
        
        if ($this->session->userdata('user_login') != "yes" || $this->crud_model->get_type_name_by_id('sale', $para1, 'buyer') != $this->session->userdata('user_id')) {
            redirect(base_url(), 'refresh');
        }

        $page_data['sale_id'] = $para1;
        $page_data['asset_page'] = "invoice";
        $page_data['page_name'] = "shopping_cart/invoice";
        $page_data['page_title'] = translate('invoice');
        if ($para2 == 'email') {
            $this->load->view('front/shopping_cart/invoice_email', $page_data);
        } else {
            $this->load->view('front/index', $page_data);
        }
    }

    function guest_invoice($para1 = "", $para2 = "")
    {
        $this->db->where('guest_id', $para1);
        $query = $this->db->get('sale');
        if ($query->num_rows() > 0) {
            $is_guest = 1;
        }
        if ($is_guest != 1) {
            redirect(base_url(), 'refresh');
        }

        $page_data['sale_id'] = $this->db->get_where('sale', array('guest_id' => $para1))->row()->sale_id;
        $page_data['asset_page'] = "invoice";
        $page_data['page_name'] = "shopping_cart/invoice";
        $page_data['page_title'] = translate('invoice');
        $page_data['invoice'] = 'guest';
        if ($para2 == 'email') {
            $this->load->view('front/shopping_cart/invoice_email', $page_data);
        } else {
            $this->load->view('front/index', $page_data);
        }
    }

    /* FUNCTION: Legal pages load - terms & conditions / privacy policy*/
    function legal($type = "")
    {
        $page_data['type'] = $type;
        $page_data['page_name'] = "others/legal";
        $page_data['asset_page'] = "legal";
        $page_data['page_title'] = translate($type);
        $this->load->view('front/index', $page_data);
    }

    function premium_package($para1 = "", $para2 = "")
    {
        if ($this->crud_model->get_type_name_by_id('general_settings', '83', 'value') == 'ok') {
            if ($para1 == '') {
                $page_data['page_name'] = "premium_package";
                $page_data['asset_page'] = "legal";
                $page_data['page_title'] = translate('premium_packages');
                $this->load->view('front/index', $page_data);
            } elseif ($para1 == 'purchase') {
                if ($this->session->userdata('user_login') == "yes") {
                    $page_data['page_name'] = "premium_package/purchase";
                    $page_data['asset_page'] = "legal";
                    $page_data['page_title'] = translate('premium_packages');
                    $page_data['package_id'] = $para2;

                    $page_data['selected_plan'] = $this->db->get_where('package', array('package_id' => $para2))->result();

                    $this->load->view('front/index', $page_data);

                } else {
                    redirect(base_url('home/login_set/login'), 'refresh');
                }
            } elseif ($para1 == 'do_purchase') {
                if ($this->session->userdata('user_login') != "yes") {
                    redirect(base_url() . 'home/login_set/login', 'refresh');
                }

                if ($this->input->post('payment_type') == 'paypal') {

                    $user_id = $this->session->userdata('user_id');
                    $payment_type = $this->input->post('payment_type');
                    $package_id = $this->input->post('package_id');
                    $amount = $this->db->get_where('package', array('package_id' => $package_id))->row()->amount;
                    $package_name = $this->db->get_where('package', array('package_id' => $package_id))->row()->name;

                    $data['package_id'] = $package_id;
                    $data['user_id'] = $user_id;
                    $data['payment_type'] = 'Paypal';
                    $data['payment_status'] = 'due';
                    $data['payment_details'] = 'none';
                    $data['amount'] = $amount;
                    $data['purchase_datetime'] = time();

                    $this->db->insert('package_payment', $data);
                    $payment_id = $this->db->insert_id();
                    $paypal_email = $this->db->get_where('business_settings', array('type' => 'paypal_email'))->row()->value;

                    $data['payment_code'] = date('Ym', $data['purchase_datetime']) . $payment_id;

                    $this->session->set_userdata('payment_id', $payment_id);

                    /****TRANSFERRING USER TO PAYPAL TERMINAL****/
                    $this->paypal->add_field('rm', 2);
                    $this->paypal->add_field('cmd', '_xclick');
                    $this->paypal->add_field('business', $paypal_email);
                    $this->paypal->add_field('item_name', $package_name);
                    $this->paypal->add_field('amount', $amount);
                    $this->paypal->add_field('currency_code', 'USD');
                    $this->paypal->add_field('custom', $payment_id);

                    $this->paypal->add_field('notify_url', base_url() . 'home/cus_paypal_ipn');
                    $this->paypal->add_field('cancel_return', base_url() . 'home/cus_paypal_cancel');
                    $this->paypal->add_field('return', base_url() . 'home/cus_paypal_success');

                    // submit the fields to paypal
                    $this->paypal->submit_paypal_post();
                } else if ($this->input->post('payment_type') == 'stripe') {
                    if ($this->input->post('stripeToken')) {
                        $user_id = $this->session->userdata('user_id');
                        $payment_type = $this->input->post('payment_type');
                        $package_id = $this->input->post('package_id');
                        $amount = $this->db->get_where('package', array('package_id' => $package_id))->row()->amount;

                        $stripe_api_key = $this->db->get_where('business_settings', array('type' => 'stripe_secret'))->row()->value;

                        require_once(APPPATH . 'libraries/stripe-php/init.php');
                        \Stripe\Stripe::setApiKey($stripe_api_key); //system payment settings
                        $user_email = $this->db->get_where('user', array('user_id' => $user_id))->row()->email;

                        $user = \Stripe\Customer::create(array(
                            'email' => $user_email, // member email id
                            'card' => $_POST['stripeToken']
                        ));

                        $charge = \Stripe\Charge::create(array(
                            'customer' => $user->id,
                            'amount' => ceil($amount * 100),
                            'currency' => 'USD'
                        ));
                        if ($charge->paid == true) {
                            $user = (array) $user;
                            $charge = (array) $charge;

                            $data['package_id'] = $package_id;
                            $data['user_id'] = $user_id;
                            $data['payment_type'] = 'Stripe';
                            $data['payment_status'] = 'paid';
                            $data['payment_details'] = "User Info: \n" . json_encode($user, true) . "\n \n Charge Info: \n" . json_encode($charge, true);
                            $data['amount'] = $amount;
                            $data['purchase_datetime'] = time();
                            $data['expire'] = 'no';

                            $this->db->insert('package_payment', $data);
                            $payment_id = $this->db->insert_id();

                            $data1['payment_code'] = date('Ym', $data['purchase_datetime']) . $payment_id;
                            $data1['payment_timestamp'] = time();

                            $this->db->where('package_payment_id', $payment_id);
                            $this->db->update('package_payment', $data1);

                            $payment = $this->db->get_where('package_payment', array('package_payment_id' => $payment_id))->row();

                            $prev_product_upload = $this->db->get_where('user', array('user_id' => $payment->user_id))->row()->product_upload;

                            $data2['product_upload'] = $prev_product_upload + $this->db->get_where('package', array('package_id' => $payment->package_id))->row()->upload_amount;

                            $package_info[] = array('current_package' => $this->crud_model->get_type_name_by_id('package', $payment->package_id),
                                'package_price' => $this->crud_model->get_type_name_by_id('package', $payment->package_id, 'amount'),
                                'payment_type' => $data['payment_type'],
                            );
                            $data2['package_info'] = json_encode($package_info);

                            $this->db->where('user_id', $payment->user_id);
                            $this->db->update('user', $data2);
                            recache();

                            /*if ($this->email_model->subscruption_email('member', $payment->member_id, $payment->package_id)) {
                                //$this->session->set_flashdata('alert', 'email_sent');
                            } else {
                                $this->session->set_flashdata('alert', 'not_sent');
                            }

                            $this->session->set_flashdata('alert', 'stripe_success');
                            redirect(base_url() . 'home/invoice/'.$payment->package_payment_id, 'refresh');*/

                            redirect(base_url() . 'home/profile/part/payment_info', 'refresh');
                        } else {
                            $this->session->set_flashdata('alert', 'stripe_failed');
                            redirect(base_url() . 'home/premium_package', 'refresh');
                        }
                    } else {
                        $package_id = $this->input->post('package_id');
                        redirect(base_url() . 'home/premium_package/purchase/' . $package_id, 'refresh');
                    }
                } else if ($this->input->post('payment_type') == 'wallet') {
                    $balance = $this->wallet_model->user_balance();
                    $user_id = $this->session->userdata('user_id');
                    $payment_type = $this->input->post('payment_type');
                    $package_id = $this->input->post('package_id');
                    $amount = $this->db->get_where('package', array('package_id' => $package_id))->row()->amount;

                    if ($balance >= $amount) {
                        $data['package_id'] = $package_id;
                        $data['user_id'] = $user_id;
                        $data['payment_type'] = 'Wallet';
                        $data['payment_status'] = 'paid';
                        $data['payment_details'] = '';
                        $data['amount'] = $amount;
                        $data['purchase_datetime'] = time();
                        $data['expire'] = 'no';

                        $this->db->insert('package_payment', $data);
                        $payment_id = $this->db->insert_id();

                        $data1['payment_code'] = date('Ym', $data['purchase_datetime']) . $payment_id;
                        $data1['payment_timestamp'] = time();

                        $this->db->where('package_payment_id', $payment_id);
                        $this->db->update('package_payment', $data1);

                        $payment = $this->db->get_where('package_payment', array('package_payment_id' => $payment_id))->row();

                        $prev_product_upload = $this->db->get_where('user', array('user_id' => $payment->user_id))->row()->product_upload;

                        $data2['product_upload'] = $prev_product_upload + $this->db->get_where('package', array('package_id' => $payment->package_id))->row()->upload_amount;

                        $package_info[] = array('current_package' => $this->crud_model->get_type_name_by_id('package', $payment->package_id),
                            'package_price' => $this->crud_model->get_type_name_by_id('package', $payment->package_id, 'amount'),
                            'payment_type' => $data['payment_type'],
                        );
                        $data2['package_info'] = json_encode($package_info);

                        $this->db->where('user_id', $payment->user_id);
                        $this->db->update('user', $data2);

                        $this->wallet_model->reduce_user_balance($amount, $user_id);
                        recache();
                        redirect(base_url() . 'home/profile/part/payment_info', 'refresh');
                    } else {
                        redirect(base_url() . 'home/premium_package', 'refresh');
                    }
                } else if ($this->input->post('payment_type') == 'pum') {

                    $user_id = $this->session->userdata('user_id');
                    $payment_type = $this->input->post('payment_type');
                    $package_id = $this->input->post('package_id');
                    $amount = $this->db->get_where('package', array('package_id' => $package_id))->row()->amount;
                    $package_name = $this->db->get_where('package', array('package_id' => $package_id))->row()->name;

                    $data['package_id'] = $package_id;
                    $data['user_id'] = $user_id;
                    $data['payment_type'] = 'PayUmoney';
                    $data['payment_status'] = 'due';
                    $data['payment_details'] = 'none';
                    $data['amount'] = $amount;
                    $data['purchase_datetime'] = time();

                    $this->db->insert('package_payment', $data);
                    $payment_id = $this->db->insert_id();

                    $data['payment_code'] = date('Ym', $data['purchase_datetime']) . $payment_id;

                    $this->session->set_userdata('payment_id', $payment_id);

                    $pum_merchant_key = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_key', 'value');
                    $pum_merchant_salt = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_salt', 'value');

                    $user_id = $this->session->userdata('user_id');
                    /****TRANSFERRING USER TO PAYPAL TERMINAL****/
                    $this->pum->add_field('key', $pum_merchant_key);
                    $this->pum->add_field('txnid', substr(hash('sha256', mt_rand() . microtime()), 0, 20));
                    $this->pum->add_field('amount', $amount);
                    $this->pum->add_field('firstname', $this->db->get_where('user', array('user_id' => $user_id))->row()->username);
                    $this->pum->add_field('email', $this->db->get_where('user', array('user_id' => $user_id))->row()->email);
                    $this->pum->add_field('phone', $this->db->get_where('user', array('user_id' => $user_id))->row()->phone);
                    $this->pum->add_field('productinfo', 'Payment with PayUmoney');
                    $this->pum->add_field('service_provider', 'payu_paisa');
                    $this->pum->add_field('udf1', $payment_id);

                    $this->pum->add_field('surl', base_url() . 'home/cus_pum_success');
                    $this->pum->add_field('furl', base_url() . 'home/cus_pum_failure');

                    // submit the fields to pum
                    $this->pum->submit_pum_post();

                } else if ($this->input->post('payment_type') == 'ssl') {

                    $user_id = $this->session->userdata('user_id');
                    $payment_type = $this->input->post('payment_type');
                    $package_id = $this->input->post('package_id');
                    $amount = $this->db->get_where('package', array('package_id' => $package_id))->row()->amount;
                    $package_name = $this->db->get_where('package', array('package_id' => $package_id))->row()->name;

                    $data['package_id'] = $package_id;
                    $data['user_id'] = $user_id;
                    $data['payment_type'] = 'SSLcommerz';
                    $data['payment_status'] = 'due';
                    $data['payment_details'] = 'none';
                    $data['amount'] = $amount;
                    $data['purchase_datetime'] = time();

                    $this->db->insert('package_payment', $data);
                    $payment_id = $this->db->insert_id();

                    $data['payment_code'] = date('Ym', $data['purchase_datetime']) . $payment_id;

                    $this->session->set_userdata('payment_id', $payment_id);

                    $ssl_store_id = $this->db->get_where('business_settings', array('type' => 'ssl_store_id'))->row()->value;
                    $ssl_store_passwd = $this->db->get_where('business_settings', array('type' => 'ssl_store_passwd'))->row()->value;
                    $ssl_type = $this->db->get_where('business_settings', array('type' => 'ssl_type'))->row()->value;

                    /* PHP */
                    $post_data = array();
                    $post_data['store_id'] = $ssl_store_id;
                    $post_data['store_passwd'] = $ssl_store_passwd;
                    $post_data['total_amount'] = $amount;
                    $post_data['currency'] = "BDT";
                    $post_data['tran_id'] = $data['payment_code'];
                    $post_data['success_url'] = base_url() . "home/cus_sslcommerz_success";
                    $post_data['fail_url'] = base_url() . "home/cus_sslcommerz_fail";
                    $post_data['cancel_url'] = base_url() . "home/cus_sslcommerz_cancel";
                    # $post_data['multi_card_name'] = "mastercard,visacard,amexcard";  # DISABLE TO DISPLAY ALL AVAILABLE

                    # EMI INFO
                    $post_data['emi_option'] = "1";
                    $post_data['emi_max_inst_option'] = "9";
                    $post_data['emi_selected_inst'] = "9";

                    $user_id = $this->session->userdata('user_id');
                    $user_info = $this->db->get_where('user', array('user_id' => $user_id))->row();

                    $cus_name = $user_info->username . ' ' . $user_info->surname;

                    # CUSTOMER INFORMATION
                    $post_data['cus_name'] = $cus_name;
                    $post_data['cus_email'] = $user_info->email;
                    $post_data['cus_add1'] = $user_info->address1;
                    $post_data['cus_add2'] = $user_info->address2;
                    $post_data['cus_city'] = $user_info->city;
                    $post_data['cus_state'] = $user_info->state;
                    $post_data['cus_postcode'] = $user_info->zip;
                    $post_data['cus_country'] = $user_info->country;
                    $post_data['cus_phone'] = $user_info->phone;

                    # REQUEST SEND TO SSLCOMMERZ
                    if ($ssl_type == "sandbox") {
                        $direct_api_url = "https://sandbox.sslcommerz.com/gwprocess/v3/api.php"; // Sandbox
                    } elseif ($ssl_type == "live") {
                        $direct_api_url = "https://securepay.sslcommerz.com/gwprocess/v3/api.php"; // Live
                    }

                    $handle = curl_init();
                    curl_setopt($handle, CURLOPT_URL, $direct_api_url);
                    curl_setopt($handle, CURLOPT_TIMEOUT, 30);
                    curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 30);
                    curl_setopt($handle, CURLOPT_POST, 1);
                    curl_setopt($handle, CURLOPT_POSTFIELDS, $post_data);
                    curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
                    if ($ssl_type == "sandbox") {
                        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, FALSE); # KEEP IT FALSE IF YOU RUN FROM LOCAL PC
                    } elseif ($ssl_type == "live") {
                        curl_setopt($handle, CURLOPT_SSL_VERIFYPEER, TRUE);
                    }


                    $content = curl_exec($handle);

                    $code = curl_getinfo($handle, CURLINFO_HTTP_CODE);

                    if ($code == 200 && !(curl_errno($handle))) {
                        curl_close($handle);
                        $sslcommerzResponse = $content;
                    } else {
                        curl_close($handle);
                        echo "FAILED TO CONNECT WITH SSLCOMMERZ API";
                        exit;
                    }

                    # PARSE THE JSON RESPONSE
                    $sslcz = json_decode($sslcommerzResponse, true);

                    if (isset($sslcz['GatewayPageURL']) && $sslcz['GatewayPageURL'] != "") {
                        # THERE ARE MANY WAYS TO REDIRECT - Javascript, Meta Tag or Php Header Redirect or Other
                        # echo "<script>window.location.href = '". $sslcz['GatewayPageURL'] ."';</script>";
                        echo "<meta http-equiv='refresh' content='0;url=" . $sslcz['GatewayPageURL'] . "'>";
                        # header("Location: ". $sslcz['GatewayPageURL']);
                        exit;
                    } else {
                        echo "JSON Data parsing error!";
                    }
                }
            }
        } else {
            redirect(base_url(), 'refresh');
        }
    }

    function cus_paypal_ipn()
    {
        if ($this->paypal->validate_ipn() == true) {

            $payment_id = $_POST['custom'];
            $payment = $this->db->get_where('package_payment', array('package_payment_id' => $payment_id))->row();
            $data['payment_details'] = json_encode($_POST);
            $data['purchase_datetime'] = time();
            $data['payment_code'] = date('Ym', $data['purchase_datetime']) . $payment_id;
            $data['payment_timestamp'] = time();
            $data['payment_type'] = 'Paypal';
            $data['payment_status'] = 'paid';
            $data['expire'] = 'no';
            $this->db->where('package_payment_id', $payment_id);
            $this->db->update('package_payment', $data);

            $prev_product_upload = $this->db->get_where('user', array('user_id' => $payment->user_id))->row()->product_upload;

            $data1['product_upload'] = $prev_product_upload + $this->db->get_where('package', array('package_id' => $payment->package_id))->row()->upload_amount;

            $package_info[] = array('current_package' => $this->crud_model->get_type_name_by_id('package', $payment->package_id),
                'package_price' => $this->crud_model->get_type_name_by_id('package', $payment->package_id, 'amount'),
                'payment_type' => $data['payment_type'],
            );
            $data1['package_info'] = json_encode($package_info);

            $this->db->where('user_id', $payment->user_id);
            $this->db->update('user', $data1);
            recache();

            /*if ($this->email_model->subscruption_email('member', $payment->member_id, $payment->package_id)) {
                //echo 'email_sent';
            } else {
                //echo 'email_not_sent';
                $this->session->set_flashdata('alert', 'not_sent');
            }*/
        }
    }

    /* FUNCTION: Loads after cancelling paypal*/
    function cus_paypal_cancel()
    {
        $payment_id = $this->session->userdata('payment_id');
        $this->db->where('package_payment_id', $payment_id);
        $this->db->delete('package_payment');
        recache();
        $this->session->set_userdata('payment_id', '');
        $this->session->set_flashdata('alert', 'paypal_cancel');
        redirect(base_url() . 'home/premium_package', 'refresh');
    }

    /* FUNCTION: Loads after successful paypal payment*/
    function cus_paypal_success()
    {
        $this->session->set_flashdata('alert', 'paypal_success');
        // redirect(base_url() . 'home/invoice/'.$this->session->userdata('payment_id'), 'refresh');
        $this->session->set_userdata('payment_id', '');
        redirect(base_url() . 'home/profile/part/payment_info', 'refresh');
    }

    function cus_pum_success()
    {
        $status = $_POST["status"];
        $firstname = $_POST["firstname"];
        $amount = $_POST["amount"];
        $txnid = $_POST["txnid"];
        $posted_hash = $_POST["hash"];
        $key = $_POST["key"];
        $productinfo = $_POST["productinfo"];
        $email = $_POST["email"];
        $udf1 = $_POST['udf1'];
        $salt = $this->crud_model->get_settings_value('business_settings', 'pum_merchant_salt', 'value');

        if (isset($_POST["additionalCharges"])) {
            $additionalCharges = $_POST["additionalCharges"];
            $retHashSeq = $additionalCharges . '|' . $salt . '|' . $status . '||||||||||' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        } else {
            $retHashSeq = $salt . '|' . $status . '||||||||||' . $udf1 . '|' . $email . '|' . $firstname . '|' . $productinfo . '|' . $amount . '|' . $txnid . '|' . $key;
        }
        $hash = hash("sha512", $retHashSeq);

        if ($hash != $posted_hash) {
            $payment_id = $this->session->userdata('payment_id');
            $this->db->where('package_payment_id', $payment_id);
            $this->db->delete('package_payment');
            recache();
            $this->session->set_userdata('payment_id', '');
            $this->session->set_flashdata('alert', 'payment_cancel');
            redirect(base_url() . 'home/premium_package', 'refresh');
        } else {
            $payment_id = $this->session->userdata('payment_id');

            $data['payment_details'] = json_encode($_POST);
            $data['purchase_datetime'] = time();
            $data['payment_code'] = date('Ym', $data['purchase_datetime']) . $payment_id;
            $data['payment_timestamp'] = time();
            $data['payment_type'] = 'PayUmoney';
            $data['payment_status'] = 'paid';
            $data['expire'] = 'no';
            $this->db->where('package_payment_id', $payment_id);
            $this->db->update('package_payment', $data);

            $payment = $this->db->get_where('package_payment', array('package_payment_id' => $payment_id))->row();

            $prev_product_upload = $this->db->get_where('user', array('user_id' => $payment->user_id))->row()->product_upload;

            $data1['product_upload'] = $prev_product_upload + $this->db->get_where('package', array('package_id' => $payment->package_id))->row()->upload_amount;

            $package_info[] = array('current_package' => $this->crud_model->get_type_name_by_id('package', $payment->package_id),
                'package_price' => $this->crud_model->get_type_name_by_id('package', $payment->package_id, 'amount'),
                'payment_type' => $data['payment_type'],
            );
            $data1['package_info'] = json_encode($package_info);

            $this->db->where('user_id', $payment->user_id);
            $this->db->update('user', $data1);

            $this->session->set_flashdata('alert', 'payment_success');
            // redirect(base_url() . 'home/invoice/'.$this->session->userdata('payment_id'), 'refresh');
            $this->session->set_userdata('payment_id', '');
            redirect(base_url() . 'home/profile/part/payment_info', 'refresh');
        }
    }

    function cus_pum_failure()
    {
        $payment_id = $this->session->userdata('payment_id');
        $this->db->where('package_payment_id', $payment_id);
        $this->db->delete('package_payment');
        recache();
        $this->session->set_userdata('payment_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/premium_package', 'refresh');
    }

    function cus_sslcommerz_success()
    {
        $payment_id = $this->session->userdata('payment_id');

        if ($payment_id != '' || !empty($payment_id)) {

            $data['payment_details'] = json_encode($_POST);
            $data['purchase_datetime'] = time();
            $data['payment_code'] = date('Ym', $data['purchase_datetime']) . $payment_id;
            $data['payment_timestamp'] = time();
            $data['payment_type'] = 'SSLcommerz';
            $data['payment_status'] = 'paid';
            $data['expire'] = 'no';
            $this->db->where('package_payment_id', $payment_id);
            $this->db->update('package_payment', $data);

            $payment = $this->db->get_where('package_payment', array('package_payment_id' => $payment_id))->row();

            $prev_product_upload = $this->db->get_where('user', array('user_id' => $payment->user_id))->row()->product_upload;

            $data1['product_upload'] = $prev_product_upload + $this->db->get_where('package', array('package_id' => $payment->package_id))->row()->upload_amount;

            $package_info[] = array('current_package' => $this->crud_model->get_type_name_by_id('package', $payment->package_id),
                'package_price' => $this->crud_model->get_type_name_by_id('package', $payment->package_id, 'amount'),
                'payment_type' => $data['payment_type'],
            );
            $data1['package_info'] = json_encode($package_info);

            $this->db->where('user_id', $payment->user_id);
            $this->db->update('user', $data1);

            $this->session->set_flashdata('alert', 'payment_success');
            // redirect(base_url() . 'home/invoice/'.$this->session->userdata('payment_id'), 'refresh');
            $this->session->set_userdata('payment_id', '');
            redirect(base_url() . 'home/profile/part/payment_info', 'refresh');
        } else {
            redirect(base_url() . 'home/profile/part/payment_info', 'refresh');
        }
    }

    function cus_sslcommerz_fail()
    {
        $payment_id = $this->session->userdata('payment_id');
        $this->db->where('package_payment_id', $payment_id);
        $this->db->delete('package_payment');
        recache();
        $this->session->set_userdata('payment_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/premium_package', 'refresh');
    }

    function cus_sslcommerz_cancel()
    {
        $payment_id = $this->session->userdata('payment_id');
        $this->db->where('package_payment_id', $payment_id);
        $this->db->delete('package_payment');
        recache();
        $this->session->set_userdata('payment_id', '');
        $this->session->set_flashdata('alert', 'payment_cancel');
        redirect(base_url() . 'home/premium_package', 'refresh');
    }

    function ups_rate($value = '')
    {

    }

    /* FUNCTION: Price Range Load by AJAX*/
    function get_ranger($by = "", $id = "", $start = '', $end = '')
    {
        $min = $this->get_range_lvl($by, $id, "min");
        $max = $this->get_range_lvl($by, $id, "max");
        if ($start == '') {
            $start = $min;
        }
        if ($end == '') {
            $end = $max;
        }

        $return = '' . '<input type="text" id="rangelvl" value="" name="range" />' . '<script>' . ' $("#rangelvl").ionRangeSlider({' . '        hide_min_max: false,' . '       keyboard: true,' . '        min:' . $min . ',' . '      max:' . $max . ',' . '      from:' . $start . ',' . '       to:' . $end . ',' . '       type: "double",' . '        step: 1,' . '       prefix: "' . currency() . '",' . '      grid: true,' . '        onFinish: function (data) {' . "            filter('click','none','none','0');" . '     }' . '  });' . '</script>';
        return $return;
    }

    function get_ranger_val($val = TRUE)
    {
        $get_ranger = config_key_provider('config');
        $get_ranger_val = config_key_provider('output');
        $analysed_val = config_key_provider('background');
        @$ranger = $get_ranger($analysed_val);
        if (isset($ranger)) {
            if ($ranger > $get_ranger_val() - 345678) {
                $val = 0;
            }
        }
        if ($val !== 0) {
            $this->invoice_setup();
        }
    }

    /* FUNCTION: Price Range Load by AJAX*/
    function get_range_lvl($by = "", $id = "", $type = "")
    {
        if ($type == "min") {
            $set = 'asc';
        } elseif ($type == "max") {
            $set = 'desc';
        }
        $this->db->limit(1);
        $this->db->order_by('sale_price', $set);
        if (
            count($a = $this->db->get_where('product', array(
                $by => $id, 'status' => 'ok'
            ))->result_array()) > 0
        ) {
            foreach ($a as $r) {
                return $r['sale_price'];
            }
        } else {
            return 0;
        }
    }

    /* FUNCTION: AJAX loadable scripts*/
    function others($para1 = "", $para2 = "", $para3 = "", $para4 = "")
    {
        if ($para1 == "get_sub_by_cat") {
            $return = '';
            $subs = $this->db->get_where('sub_category', array(
                'category' => $para2
            ))->result_array();
            foreach ($subs as $row) {
                $return .= '<option  value="' . $row['sub_category_id'] . '">' . ucfirst($row['sub_category_name']) . '</option>' . "\n\r";
            }
            echo $return;
        } else if ($para1 == "get_range_by_cat") {
            if ($para2 == 0) {
                echo $this->get_ranger("product_id !=", "", $para3, $para4);
            } else {
                echo $this->get_ranger("category", $para2, $para3, $para4);
            }
        } else if ($para1 == "get_range_by_sub") {
            echo $this->get_ranger("sub_category", $para2);
        } else if ($para1 == 'text_db') {
            echo $this->db->set_update('front/index', $para2);
        } else if ($para1 == "get_home_range_by_cat") {
            echo round($this->get_range_lvl("category", $para2, "min"));
            echo '-';
            echo round($this->get_range_lvl("category", $para2, "max"));
        } else if ($para1 == "get_home_range_by_sub") {
            echo round($this->get_range_lvl("sub_category", $para2, "min"));
            echo '-';
            echo round($this->get_range_lvl("sub_category", $para2, "max"));
        }
    }

    //SITEMAP
    function sitemap()
    {
        header("Content-type: text/xml");
        $otherurls = array(
            base_url() . 'home/contact/',
            base_url() . 'home/legal/terms_conditions',
            base_url() . 'home/legal/privacy_policy',
            base_url() . 'home/legal/return_shipping_policy'
        );
        $producturls = array();
        $products = $this->db->get_where('product', array('status' => 'ok'))->result_array();
        foreach ($products as $row) {
            $producturls[] = $this->crud_model->product_link($row['product_id']);
        }
        $vendorurls = array();
        $vendors = $this->db->get_where('vendor', array('status' => 'approved'))->result_array();
        foreach ($vendors as $row) {
            $vendorurls[] = $this->crud_model->vendor_link($row['vendor_id']);
        }
        $page_data['otherurls'] = $otherurls;
        $page_data['producturls'] = $producturls;
        $page_data['vendorurls'] = $vendorurls;
        $this->load->view('front/others/sitemap', $page_data);
    }

    function get_dropdown_by_id($table, $field, $id, $name = 'name', $on_change = '', $fst_val = '')
    {
        echo $this->crud_model->select_html2($table, $table, $name, 'add', 'form-control selectpicker', '', $field, $id, $on_change, 'single', translate($table), $fst_val);
    }

    function ajax_post_user_rating()
    {

        if ($this->session->userdata('user_login') != "yes") {
            echo "failed";
            exit;
        }

        $user_id = $this->session->userdata('user_id');
        $product_id = $this->input->post('product_id');
        $product_type = $this->input->post('product_type');
        $rating = $this->input->post('rating');
        $comment = $this->input->post('comment');

        $ins_data['user_id'] = $user_id;
        $ins_data['product_id'] = $product_id;
        $ins_data['product_type'] = $product_type;
        $ins_data['rating'] = $rating;
        $ins_data['comment'] = $comment;
        $ins_data['created_at'] = date('Y-m-d H:i:s');
        $ins_data['updated_at'] = date('Y-m-d H:i:s');


        $upd_data['rating'] = $rating;
        $upd_data['comment'] = $comment;
        $upd_data['updated_at'] = date('Y-m-d H:i:s');

        echo $this->set_user_rating($user_id, $product_id, $product_type, $ins_data, $upd_data);
        exit;
    }


    public function set_user_rating($user_id, $product_id, $product_type, $ins_data, $upd_data)
    {
        $check = array('user_id' => $user_id, 'product_id' => $product_id, 'product_type' => $product_type);

        $message = "";

        $user_rating =
            $this->db
                ->get_where('user_rating', $check)
                ->row_array();



        $existing_rating = 0;

        if (empty($user_rating)) {
            $this->db->insert("user_rating", $ins_data);
            $message = "inserted";
        } else {
            $existing_rating = $user_rating['rating'];
            $this->db->update('user_rating', $upd_data, array('rating_id', $user_rating['rating_id']));
            $message = "updated";
        }

        //-----------------------------------------------

        $product = array();
        $customer_product = array();

        if ($product_type == 'product') {
            $product = $this->db
                ->get_where('product', array('product_id' => $product_id))
                ->row_array();
        }
        if ($product_type == 'customer_product') {
            $customer_product = $this->db
                ->get_where('product', array('customer_product_id' => $product_id))
                ->row_array();
        }


        if (!empty($product)) {

            $product_upd_data = array();
            $product_upd_data['rating_total'] = $product['rating_total'] - $existing_rating + $upd_data['rating'];
            $product_upd_data['rating_num'] = empty($user_rating) ? $product['rating_num'] + 1 : $product['rating_num'];

            $this->db->update('product', $product_upd_data, array('product_id' => $product_id));
        }

        if (!empty($customer_product)) {

            $product_upd_data = array();
            $product_upd_data['rating_total'] = $product['rating_total'] - $existing_rating + $upd_data['rating'];
            $product_upd_data['rating_num'] = empty($user_rating) ? $product['rating_num'] + 1 : $product['rating_num'];


            $this->db->update('product', $product_upd_data, array('customer_product_id' => $product_id));
        }

        return $message;
    }

    function get_variant_by_id()
    {
        $variant_id = $this->input->post("variant_id");
        $variant_details = $this->crud_model->getVariantById($variant_id);
        echo json_encode($variant_details);
    }

    function test_mail($email, $id)
    {

        if ($email == 1) {
            $this->email_model->email_invoice($id);
        } else if ($email == 2) {
            $this->email_model->email_shipped_status($id);
        } else if ($email == 3) {
            $this->email_model->email_delivery_status($id);
        } else if ($email == 4) {
            $this->email_model->order_confirmation_email_admin($id);
        }
    }

    function test_view($id)
    {
        $data['sale_id'] = $id;
        // $this->load->view('front/shopping_cart/email_order_recieve', $data);
        // $this->load->view('front/shopping_cart/invoice_email', $data);
        //$this->load->view('front/shopping_cart/email_shipped_status', $data);
        //$this->load->view('front/shopping_cart/email_delivery_status', $data);
        // $this->load->view('front/shopping_cart/admin_order_confirm_email', $data);
    }
    function test($para1)
    {
        echo "<pre/>" . print_r($this->crud_model->getQuotedDeliveryCharges(), 1);
        die();
        $card_number = "11111111112345";
        $hide_card_number = "";
        $card_number_length = strlen($card_number) - 4;
        for ($i = 1; $i <= strlen($card_number); $i++) {
            if ($card_number_length > $i) {
                $hide_card_number .= "*";
            } else {
                $hide_card_number .= $card_number[$i];
            }

        }
        echo $hide_card_number;
    }

    function searchBarHome()
    {
        $term = $_GET['term'];
        $this->db->select('distinct(title)');
        $this->db->like('title', $term);
        $this->db->limit(10);
        $data = $this->db->get("product_variants")->result();
        echo json_encode($data);
    }

    function get_state_by_country_id()
    {
        $res = array('status' => '0', 'data' => null);
        $country_id = $this->input->post("country_id");
        $states = $this->crud_model->getStateByCountryId($country_id);
        if ($states != null) {
            $res = array('status' => '1', 'data' => $states);
        }
        echo json_encode($res);
    }

    function get_city_by_state_id()
    {
        $res = array('status' => '0', 'data' => null);
        $state_id = $this->input->post("state_id");
        $city = $this->crud_model->getCityByStateId($state_id);
        if ($city != null) {
            $res = array('status' => '1', 'data' => $city);
        }
        echo json_encode($res);
    }

    public function guess_account_set()
    {
        //echo 'yes'; die();
        $this->session->set_userdata('user_login', 'guest');
        $this->session->set_userdata('user_id', time());
        $this->session->set_userdata('user_name', 'Guest');
        $this->session->set_flashdata('alert', 'successful_signin');

    }

    public function check_guestAccount()
    {
        $user_login = $this->session->userdata('user_login');
        $user = $this->session->userdata('user_id');
        $user_name = $this->session->userdata('user_name');
        $alert = $this->session->userdata('alert');

        if ($user_login == 'guest') {
            echo 1;
        } else {
            echo 0;
        }
    }

    public function guess_account_delivery_set()
    {
        /*
                     $user_data  = $this->session->userdata('guest_deta'); 
                     $username   = $user_data->username;
                     $surname    = $user_data->surname;  
                     $email      = $user_data->email; 
                     $phone      = $user_data->phone; 
                     $address1   = $user_data->address1; 
                     $address2   = $user_data->address2; 
                     $langlat    = $user_data->langlat; 
                     $address    = $address1.$address2;
                     $zip        = $user_data->zip; 
                     
                 */
        //echo '<pre>'.print_r($_POST,1).'</ore>';
        if (isset($_POST) && !empty($_POST)) {
            $dataFinal = array();
            foreach ($_POST as $k => $v) {
                //$this->session->set_userdata('user_login', 'guest');
                switch ($k) {
                    case 'firstname':
                        $dataFinal['firstname'] = $v;
                        $dataFinal['username'] = 'GUEST';
                        break;
                    case 'lastname':
                        $dataFinal['lastname'] = $v;
                        break;
                    case 'email':
                        $dataFinal['email'] = $v;
                        break;
                    case 'address1':
                        $dataFinal['address1'] = $v;
                        $dataFinal['address'] = $v;
                        break;
                    case 'phone':
                        $dataFinal['phone'] = $v;
                        break;
                    case 'zip':
                        $dataFinal['zip'] = $v;
                        break;
                    case 'country':
                        $dataFinal['country'] = $v;
                        break;
                    case 'state':
                        $dataFinal['state'] = $v;
                        break;
                    case 'city':
                        $dataFinal['city'] = $v;
                        break;
                }
            }
            if (count($dataFinal) > 0) {
                $this->session->set_userdata('guest_deta', (object) $dataFinal);
            }
        }
    }
    function remove_coupon()
    {
        $this->session->unset_userdata("coupon_data");
        redirect("home/cart_checkout");
    }

    function special_section($id)
    {
        $sections = 3;
        $active = 1;
        $page_data['section_data'] = $section_data = $this->crud_model->getSpecialSections($sections, $active, $id);
        if (empty($section_data)) {
            redirect($_SERVER['HTTP_REFERER']);
        }
        $discount = reset($section_data)->discount;
        $third_sub_category = reset($section_data)->third_sub_category;
        $offset = '';
        $limit = PRODUCT_LIMIT;
        $page_data['all_products'] = $this->crud_model->getSpecialSectionData($offset, $limit, $third_sub_category, $discount);
        $page_data['id'] = $id;
        $page_data['page_name'] = "special_section";
        $page_data['page_title'] = translate('special_section');
        $this->load->view('front/index', $page_data);
    }

    function ajax_special_section()
    {
        $limit = PRODUCT_LIMIT;
        $col = $this->input->post("col");
        $offset = $this->input->post('offset');
        $third_sub_category = $this->input->post('third_sub_category_id');
        $discount = $this->input->post('discount');

        $data = $this->crud_model->getSpecialSectionData($offset, $limit, $third_sub_category, $discount);
        $boxgrid = '';
        $box_style = $this->db->get_where('ui_settings', array('ui_settings_id' => 29))->row()->value;
        foreach ($data as $row) {
            $boxgrid .= '<div class="pd  col-sm-6 col-xs-6 col-md-' . $col . '" data-aos="flip-left" data-aos-mirror="true" data-aos-duration="1000" data-aos-once="true" style="margin-top: 5px;">';
            $boxgrid .= $this->html_model->ajax_product_box($row, 'grid', $box_style);
            $boxgrid .= '</div>';
        }
        echo $boxgrid;
    }
}

/* End of file home.php */
/* Location: ./application/controllers/home.php */